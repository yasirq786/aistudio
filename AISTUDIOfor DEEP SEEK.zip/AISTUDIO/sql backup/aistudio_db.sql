-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2026 at 08:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aistudio_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `advertisements`
--

CREATE TABLE `advertisements` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` enum('html','image','popup') NOT NULL DEFAULT 'html',
  `content` text DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `link_url` varchar(500) DEFAULT NULL,
  `position` enum('top','bottom','left','right','popup') NOT NULL DEFAULT 'top',
  `pages` varchar(500) DEFAULT NULL,
  `popup_timer_sec` smallint(5) UNSIGNED DEFAULT 5,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `impressions` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `clicks` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `sort_order` smallint(6) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `api_call_logs`
--

CREATE TABLE `api_call_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `tool_id` int(10) UNSIGNED NOT NULL,
  `api_service_id` int(10) UNSIGNED NOT NULL,
  `request_payload` mediumtext DEFAULT NULL,
  `response_payload` mediumtext DEFAULT NULL,
  `http_status` smallint(6) DEFAULT NULL,
  `latency_ms` int(10) UNSIGNED DEFAULT NULL,
  `api_cost_usd` decimal(10,6) DEFAULT NULL,
  `credits_charged` smallint(5) UNSIGNED DEFAULT NULL,
  `status` enum('success','failed','timeout','pending') NOT NULL DEFAULT 'pending',
  `error_message` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `api_call_logs`
--

INSERT INTO `api_call_logs` (`id`, `user_id`, `tool_id`, `api_service_id`, `request_payload`, `response_payload`, `http_status`, `latency_ms`, `api_cost_usd`, `credits_charged`, `status`, `error_message`, `created_at`) VALUES
(1, 1, 1, 1, '{\"provider\":\"Groq\",\"model\":\"llama3-8b-8192\",\"messages\":[{\"role\":\"user\",\"content\":\"hi groq\"},{\"role\":\"user\",\"content\":\"hi groq\"}],\"tone\":\"balanced\"}', '{\"reply\":\"\"}', 200, 1766, 0.000000, 0, 'failed', 'Invalid API Key', '2026-05-11 08:15:27'),
(2, 1, 1, 1, '{\"provider\":\"Groq\",\"model\":\"llama3-8b-8192\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"},{\"role\":\"user\",\"content\":\"hi\"}],\"tone\":\"balanced\"}', '{\"reply\":\"\"}', 200, 389, 0.000000, 0, 'failed', 'Invalid API Key', '2026-05-11 08:18:51'),
(3, 1, 1, 2, '{\"provider\":\"DeepSeek\",\"model\":\"deepseek-chat\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"},{\"role\":\"user\",\"content\":\"hi\"},{\"role\":\"user\",\"content\":\"hi\"}],\"tone\":\"balanced\"}', '{\"reply\":\"Hello! How can I help you today?\"}', 200, 1034, 0.000054, 1, 'success', NULL, '2026-05-11 08:18:56'),
(4, 1, 1, 1, '{\"provider\":\"Groq\",\"model\":\"llama3-8b-8192\",\"messages\":[{\"role\":\"user\",\"content\":\"hi groq its testing\"},{\"role\":\"user\",\"content\":\"hi groq its testing\"}],\"tone\":\"balanced\"}', '{\"reply\":\"\"}', 200, 423, 0.000000, 0, 'failed', 'The model `llama3-8b-8192` has been decommissioned and is no longer supported. Please refer to https://console.groq.com/docs/deprecations for a recommendation on which model to use instead.', '2026-05-11 08:22:12'),
(5, 1, 1, 1, '{\"provider\":\"Groq\",\"model\":\"llama-3.1-8b-instant\",\"messages\":[{\"role\":\"user\",\"content\":\"hi groq testing message\"},{\"role\":\"user\",\"content\":\"hi groq testing message\"}],\"tone\":\"balanced\"}', '{\"reply\":\"It looks like you\'re testing a message.  This is Groq, your AI assistant. I\'m here to help with any questions or topics you\'d like to discuss. Is there anything specific you\'d like to talk about, or would you like some suggestions for conversation starters?\"}', 200, 759, 0.000232, 1, 'success', NULL, '2026-05-11 08:27:58'),
(6, 1, 2, 18, '{\"provider\":\"Leonardo AI\",\"prompt\":\"Generate image of 2 red cups of coffer at round table in the garden\",\"width\":1024,\"height\":1024,\"steps\":30,\"num_images\":1}', '{\"images_count\":0}', 200, 841, 0.000000, 0, 'failed', 'Leonardo: no generation ID. Response: {\"error\":\"This model is not supported in this API version, please check the API version and model ID.\",\"path\":\"$\",\"code\":\"unexpected\"}', '2026-05-11 22:19:45'),
(7, 1, 2, 18, '{\"provider\":\"Leonardo AI\",\"prompt\":\"Two ceramic coffee cups side by side on a cozy wooden table, each cup embossed with a cute smiling emoji face, warm steam rising from freshly brewed coffee, soft morning sunlight, minimal aesthetic, realistic texture, pastel color palette, shallow depth of field, cozy café atmosphere, high-detail photorealistic style, heartwarming mood, 4K cinematic lighting.\",\"width\":1024,\"height\":1024,\"steps\":30,\"num_images\":1}', '{\"images_count\":0}', 200, 559, 0.000000, 0, 'failed', 'Leonardo: no generation ID. Response: {\"error\":\"This model is not supported in this API version, please check the API version and model ID.\",\"path\":\"$\",\"code\":\"unexpected\"}', '2026-05-11 22:21:35'),
(8, 1, 2, 18, '{\"provider\":\"Leonardo AI\",\"prompt\":\"Two ceramic coffee cups side by side on a cozy wooden table, each cup embossed with a cute smiling emoji face, warm steam rising from freshly brewed coffee, soft morning sunlight, minimal aesthetic, realistic texture, pastel color palette, shallow depth of field, cozy café atmosphere, high-detail photorealistic style, heartwarming mood, 4K cinematic lighting.\",\"width\":1024,\"height\":1024,\"steps\":30,\"num_images\":1}', '{\"images_count\":0}', 200, 786, 0.000000, 0, 'failed', 'Leonardo: no generation ID. Response: {\"error\":\"This model is not supported in this API version, please check the API version and model ID.\",\"path\":\"$\",\"code\":\"unexpected\"}', '2026-05-11 22:24:47'),
(9, 1, 2, 18, '{\"provider\":\"Leonardo AI\",\"prompt\":\"Two ceramic coffee cups side by side on a cozy wooden table, each cup embossed with a cute smiling emoji face, warm steam rising from freshly brewed coffee, soft morning sunlight, minimal aesthetic, realistic texture, pastel color palette, shallow depth of field, cozy café atmosphere, high-detail photorealistic style, heartwarming mood, 4K cinematic lighting., Realistic style\",\"width\":512,\"height\":512,\"steps\":30,\"num_images\":1}', '{\"images_count\":0}', 200, 691, 0.000000, 0, 'failed', 'Leonardo: no generation ID. Response: {\"error\":\"This model is not supported in this API version, please check the API version and model ID.\",\"path\":\"$\",\"code\":\"unexpected\"}', '2026-05-11 22:29:59'),
(10, 1, 2, 50, '{\"provider\":\"Stability AI\",\"prompt\":\"Two ceramic coffee cups side by side on a cozy wooden table, each cup embossed with a cute smiling emoji face, warm steam rising from freshly brewed coffee, soft morning sunlight, minimal aesthetic, realistic texture, pastel color palette, shallow depth of field, cozy café atmosphere, high-detail photorealistic style, heartwarming mood, 4K cinematic lighting.\",\"width\":1024,\"height\":1024,\"steps\":30,\"num_images\":1}', '{\"images_count\":1}', 200, 10658, 0.002000, 1, 'success', NULL, '2026-05-11 22:34:24'),
(11, 1, 24, 13, '{\"provider\":\"Groq\",\"prompt\":\"facebook viral nech batao\"}', '{\"reply\":\"\"}', 200, 585, 0.000000, 0, 'failed', 'The model `llama3-8b-8192` has been decommissioned and is no longer supported. Please refer to https://console.groq.com/docs/deprecations for a recommendation on which model to use instead.', '2026-05-11 22:41:34'),
(12, 1, 4, 39, '{\"provider\":\"Groq\",\"prompt\":\"mera naam chulbul panday hai\"}', '{\"reply\":\"\"}', 200, 388, 0.000000, 0, 'failed', 'The model `llama3-8b-8192` has been decommissioned and is no longer supported. Please refer to https://console.groq.com/docs/deprecations for a recommendation on which model to use instead.', '2026-05-11 23:00:41'),
(13, 1, 1, 1, '{\"provider\":\"Groq\",\"model\":\"llama-3.1-8b-instant\",\"messages\":[{\"role\":\"user\",\"content\":\"hello friend\"},{\"role\":\"user\",\"content\":\"hello friend\"}],\"tone\":\"balanced\"}', '{\"reply\":\"It\'s great to see two friendly greetings in a row. How are you doing today? Do you have something on your mind that you\'d like to talk about or perhaps a question I can help with?\"}', 200, 534, 0.000190, 1, 'success', NULL, '2026-05-11 23:01:14'),
(14, 1, 4, 54, '{\"provider\":\"ElevenLabs\",\"prompt\":\"mera naam chulbul panday nahi hai yaar kyon tang karte ho\"}', '{\"reply\":\"\"}', 404, 631, 0.000000, 0, 'failed', 'Empty response.', '2026-05-11 23:15:07'),
(15, 1, 4, 54, '{\"provider\":\"ElevenLabs\",\"prompt\":\"mera naam chulbul panday nahi hai yaar kyon tang karte ho\"}', '{\"reply\":\"\"}', 404, 607, 0.000000, 0, 'failed', 'Empty response.', '2026-05-11 23:15:11'),
(16, 1, 4, 54, '{\"provider\":\"ElevenLabs\",\"prompt\":\"mera naam chulbul panday nahi hai yaar kyon tang karte ho\"}', '{\"reply\":\"\"}', 404, 595, 0.000000, 0, 'failed', 'Empty response.', '2026-05-11 23:15:26');

-- --------------------------------------------------------

--
-- Table structure for table `api_services`
--

CREATE TABLE `api_services` (
  `id` int(10) UNSIGNED NOT NULL,
  `tool_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `provider` varchar(100) NOT NULL,
  `api_key` text DEFAULT NULL,
  `api_secret` text DEFAULT NULL,
  `endpoint` varchar(500) DEFAULT NULL,
  `model` varchar(200) DEFAULT NULL,
  `extra_config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`extra_config`)),
  `credit_cost` smallint(5) UNSIGNED NOT NULL DEFAULT 1,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` smallint(6) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `api_services`
--

INSERT INTO `api_services` (`id`, `tool_id`, `name`, `provider`, `api_key`, `api_secret`, `endpoint`, `model`, `extra_config`, `credit_cost`, `is_enabled`, `is_default`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 1, 'AI STUDO', 'Groq', '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', NULL, 'https://api.groq.com/openai/v1/chat/completions', 'llama-3.1-8b-instant', NULL, 1, 1, 1, 0, '2026-05-11 08:14:21', '2026-05-11 08:36:23'),
(2, 1, 'Smart Assistant', 'DeepSeek', 'sk-6d27a253739144518738e5c8806f4503', NULL, 'https://api.deepseek.com/v1/chat/completions', 'deepseek-chat', NULL, 1, 1, 0, 0, '2026-05-11 08:17:30', '2026-05-11 08:35:54'),
(3, 9, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(4, 11, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(5, 5, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(6, 6, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(7, 25, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(8, 10, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(9, 12, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(10, 21, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(11, 7, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(12, 22, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(13, 24, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(14, 19, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(15, 23, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(16, 20, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(17, 8, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:16:07', '2026-05-11 22:16:07'),
(18, 2, 'Leonardo AI', 'Leonardo AI', '2b7818d6-bc01-4b26-8c90-aafd0aebdd0b', NULL, 'https://cloud.leonardo.ai/api/rest/v1', 'aa77f04e-3eec-4034-9c07-d0a6e63f5240', NULL, 1, 1, 0, 0, '2026-05-11 22:18:23', '2026-05-11 22:18:23'),
(19, 9, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(20, 14, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(21, 11, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(22, 5, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(23, 6, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(24, 25, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(25, 13, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(26, 10, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(27, 17, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(28, 12, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(29, 15, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(30, 21, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(31, 7, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(32, 22, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(33, 24, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(34, 16, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(35, 19, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(36, 23, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(37, 18, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(38, 20, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(39, 4, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 0, 1, 1, '2026-05-11 22:22:03', '2026-05-11 23:01:00'),
(40, 8, 'Groq', 'Groq', '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', NULL, NULL, 'llama3-8b-8192', NULL, 1, 1, 1, 1, '2026-05-11 22:22:03', '2026-05-11 22:22:03'),
(50, 2, 'Stability AI', 'Stability AI', 'sk-sYZfP5lT4kv7qRrKBuyouW0OWl0aPsUUWmqIxhB7oUakXXgw', NULL, 'https://api.stability.ai/v1/generation', 'stable-diffusion-xl-1024-v1-0', NULL, 1, 1, 0, 0, '2026-05-11 22:34:11', '2026-05-11 22:34:11'),
(51, 3, 'Stability AI', 'Stability AI', 'sk-sYZfP5lT4kv7qRrKBuyouW0OWl0aPsUUWmqIxhB7oUakXXgw', NULL, 'https://api.stability.ai/v1/generation', 'stable-diffusion-xl-1024-v1-0', NULL, 1, 1, 0, 0, '2026-05-11 22:36:38', '2026-05-11 22:36:38'),
(52, 3, 'Eachlabs', 'Eachlabs', 'MP10193VY23EVVLO9IGM8V04U9PRW2Y2EX6J', NULL, 'https://api.eachlabs.ai/v1', NULL, NULL, 1, 1, 0, 0, '2026-05-11 22:38:47', '2026-05-11 22:38:47'),
(53, 3, 'Replicate', 'Custom', 'r8_9B4d54GBPWWE0o3RGZkDyULfS3yFjwm2fq4an', NULL, NULL, NULL, NULL, 1, 1, 0, 0, '2026-05-11 22:39:33', '2026-05-11 22:39:33'),
(54, 4, 'ElevenLabs', 'ElevenLabs', 'sk_7d77c30a71c28c673fa5a8753b58ade74202dfe9fa52d2c1', NULL, 'https://api.elevenlabs.io/v1', 'eleven_monolingual_v1', NULL, 1, 1, 0, 0, '2026-05-11 23:14:45', '2026-05-11 23:14:45');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` int(10) UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `discount_type` enum('percent','fixed') NOT NULL DEFAULT 'percent',
  `discount_value` decimal(10,2) NOT NULL,
  `max_uses` int(10) UNSIGNED DEFAULT NULL,
  `used_count` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `valid_from` datetime DEFAULT NULL,
  `valid_until` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `credit_transactions`
--

CREATE TABLE `credit_transactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `type` enum('debit','credit') NOT NULL,
  `amount` int(11) NOT NULL,
  `balance_after` int(11) NOT NULL,
  `source` enum('tool_use','subscription','admin_add','admin_deduct','referral','refund') NOT NULL,
  `tool_id` int(10) UNSIGNED DEFAULT NULL,
  `api_service_id` int(10) UNSIGNED DEFAULT NULL,
  `reference_id` varchar(100) DEFAULT NULL,
  `note` varchar(300) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `credit_transactions`
--

INSERT INTO `credit_transactions` (`id`, `user_id`, `type`, `amount`, `balance_after`, `source`, `tool_id`, `api_service_id`, `reference_id`, `note`, `created_at`) VALUES
(1, 1, 'credit', 50, 50, 'admin_add', NULL, NULL, 'signup_bonus', 'Welcome bonus credits', '2026-05-11 03:16:54'),
(2, 1, 'debit', 1, 49, 'tool_use', 1, 2, NULL, 'AI Chat: hi', '2026-05-11 08:18:57'),
(3, 1, 'debit', 1, 48, 'tool_use', 1, 1, NULL, 'AI Chat: hi groq testing message', '2026-05-11 08:27:58'),
(4, 1, 'debit', 1, 47, 'tool_use', 2, 50, NULL, 'Image: Two ceramic coffee cups side by side on a cozy woo', '2026-05-11 22:34:35'),
(5, 1, 'debit', 1, 46, 'tool_use', 1, 1, NULL, 'AI Chat: hello friend', '2026-05-11 23:01:15');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `type` enum('image','video') NOT NULL,
  `source_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `thumbnail_url` varchar(500) DEFAULT NULL,
  `media_url` varchar(500) DEFAULT NULL,
  `views` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `likes` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `removed_by_admin` tinyint(1) NOT NULL DEFAULT 0,
  `published_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `image_generation_logs`
--

CREATE TABLE `image_generation_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `api_service_id` int(10) UNSIGNED NOT NULL,
  `prompt` text DEFAULT NULL,
  `negative_prompt` text DEFAULT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `image_url` varchar(500) DEFAULT NULL,
  `thumbnail_url` varchar(500) DEFAULT NULL,
  `credits_used` smallint(5) UNSIGNED DEFAULT 0,
  `status` enum('success','failed') NOT NULL DEFAULT 'success',
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `image_generation_logs`
--

INSERT INTO `image_generation_logs` (`id`, `user_id`, `api_service_id`, `prompt`, `negative_prompt`, `settings`, `image_url`, `thumbnail_url`, `credits_used`, `status`, `is_published`, `created_at`) VALUES
(1, 1, 50, 'Two ceramic coffee cups side by side on a cozy wooden table, each cup embossed with a cute smiling emoji face, warm steam rising from freshly brewed coffee, soft morning sunlight, minimal aesthetic, realistic texture, pastel color palette, shallow depth of field, cozy café atmosphere, high-detail photorealistic style, heartwarming mood, 4K cinematic lighting.', '', '{\"width\":1024,\"height\":1024,\"steps\":30,\"cfg\":7,\"seed\":null}', '/aistudio/public/assets/img/generated/img_1778520875_1_6a02132b5a387.png', NULL, 1, 'success', 0, '2026-05-11 22:34:35');

-- --------------------------------------------------------

--
-- Table structure for table `ip_bans`
--

CREATE TABLE `ip_bans` (
  `id` int(10) UNSIGNED NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `ban_type` enum('single','range','cidr') NOT NULL DEFAULT 'single',
  `reason` varchar(500) DEFAULT NULL,
  `banned_by` int(10) UNSIGNED DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(180) NOT NULL,
  `otp` varchar(10) NOT NULL,
  `type` enum('email','sms') NOT NULL DEFAULT 'email',
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `plan_id` int(10) UNSIGNED NOT NULL,
  `coupon_id` int(10) UNSIGNED DEFAULT NULL,
  `amount_usd` decimal(10,2) NOT NULL,
  `amount_pkr` decimal(12,2) DEFAULT NULL,
  `gateway` enum('jazzcash','easypaisa','nayapay','bank_transfer','admin') NOT NULL,
  `gateway_ref` varchar(255) DEFAULT NULL,
  `screenshot_url` varchar(500) DEFAULT NULL,
  `status` enum('pending','verified','rejected','refunded') NOT NULL DEFAULT 'pending',
  `verified_by` int(10) UNSIGNED DEFAULT NULL,
  `verified_at` datetime DEFAULT NULL,
  `note` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `user_id`, `plan_id`, `coupon_id`, `amount_usd`, `amount_pkr`, `gateway`, `gateway_ref`, `screenshot_url`, `status`, `verified_by`, `verified_at`, `note`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, 9.99, 2777.22, 'jazzcash', NULL, '/aistudio/public/assets/img/payments/pay_1778472182_1.png', 'pending', NULL, NULL, NULL, '2026-05-11 09:03:02', '2026-05-11 09:03:02');

-- --------------------------------------------------------

--
-- Table structure for table `queue_jobs`
--

CREATE TABLE `queue_jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `job_type` varchar(100) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `status` enum('pending','processing','done','failed') NOT NULL DEFAULT 'pending',
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `max_attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 3,
  `error` text DEFAULT NULL,
  `scheduled_at` datetime DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `done_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `rating` tinyint(3) UNSIGNED NOT NULL DEFAULT 5,
  `title` varchar(100) DEFAULT NULL,
  `body` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `is_pinned` tinyint(1) NOT NULL DEFAULT 0,
  `helpful_count` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `not_helpful_count` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `review_votes`
--

CREATE TABLE `review_votes` (
  `id` int(10) UNSIGNED NOT NULL,
  `review_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `vote_type` enum('helpful','not_helpful') NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `subscription_plans`
--

CREATE TABLE `subscription_plans` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price_usd` decimal(10,2) NOT NULL DEFAULT 0.00,
  `duration_days` smallint(5) UNSIGNED NOT NULL DEFAULT 30,
  `credits_included` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`features`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_featured` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` smallint(6) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscription_plans`
--

INSERT INTO `subscription_plans` (`id`, `name`, `slug`, `description`, `price_usd`, `duration_days`, `credits_included`, `features`, `is_active`, `is_featured`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 'Starter', 'starter', 'Perfect to get started', 9.99, 30, 500, NULL, 1, 0, 1, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(2, 'Pro', 'pro', 'Most popular plan', 19.99, 30, 1200, NULL, 1, 1, 2, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(3, 'Business', 'business', 'For power users', 49.99, 30, 3500, NULL, 1, 0, 3, '2026-05-10 21:56:10', '2026-05-10 21:56:10');

-- --------------------------------------------------------

--
-- Table structure for table `theme_settings`
--

CREATE TABLE `theme_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `theme_settings`
--

INSERT INTO `theme_settings` (`id`, `key`, `value`, `updated_at`) VALUES
(1, 'site_name', 'AIStudio', '2026-05-10 21:56:10'),
(2, 'site_logo', '', '2026-05-10 21:56:10'),
(3, 'site_favicon', '', '2026-05-10 21:56:10'),
(4, 'site_description', 'The most powerful multi-tool AI platform', '2026-05-10 21:56:10'),
(5, 'theme_preset', 'deep_space', '2026-05-10 21:56:10'),
(6, 'theme_font', 'Inter', '2026-05-10 21:56:10'),
(7, 'theme_radius', 'soft', '2026-05-10 21:56:10'),
(8, 'theme_animation', 'neural_net', '2026-05-10 21:56:10'),
(9, 'theme_bg_image', '', '2026-05-10 21:56:10'),
(10, 'primary_color', '#a78bfa', '2026-05-10 21:56:10'),
(11, 'secondary_color', '#38bdf8', '2026-05-10 21:56:10'),
(12, 'user_log_limit', '10', '2026-05-10 21:56:10'),
(13, 'review_auto_approve', '0', '2026-05-10 21:56:10'),
(14, 'review_min_stars', '1', '2026-05-10 21:56:10'),
(15, 'watermark_enabled', '1', '2026-05-10 21:56:10'),
(16, 'watermark_text', 'AIStudio.ai', '2026-05-10 21:56:10'),
(17, 'watermark_position', 'bottom_right', '2026-05-10 21:56:10'),
(18, 'watermark_opacity', '70', '2026-05-10 21:56:10'),
(19, 'maintenance_mode', '0', '2026-05-10 21:56:10'),
(20, 'pkr_rate', '278', '2026-05-10 21:56:10'),
(21, 'smtp_host', '', '2026-05-10 21:56:10'),
(22, 'smtp_port', '587', '2026-05-10 21:56:10'),
(23, 'smtp_user', '', '2026-05-10 21:56:10'),
(24, 'smtp_pass', '', '2026-05-10 21:56:10'),
(25, 'smtp_from', '', '2026-05-10 21:56:10'),
(26, 'jazzcash_merchant', '', '2026-05-10 21:56:10'),
(27, 'jazzcash_password', '', '2026-05-10 21:56:10'),
(28, 'jazzcash_integrity', '', '2026-05-10 21:56:10'),
(29, 'easypaisa_account', '', '2026-05-10 21:56:10'),
(30, 'bank_account_name', '', '2026-05-10 21:56:10'),
(31, 'bank_account_no', '', '2026-05-10 21:56:10'),
(32, 'bank_name', '', '2026-05-10 21:56:10');

-- --------------------------------------------------------

--
-- Table structure for table `tools`
--

CREATE TABLE `tools` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `icon` varchar(100) NOT NULL DEFAULT 'ti-wand',
  `description` varchar(300) DEFAULT NULL,
  `info_how_to` text DEFAULT NULL,
  `info_features` text DEFAULT NULL,
  `info_tips` text DEFAULT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `is_visible_on_landing` tinyint(1) NOT NULL DEFAULT 1,
  `allow_publish` tinyint(1) NOT NULL DEFAULT 0,
  `sort_order` smallint(6) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tools`
--

INSERT INTO `tools` (`id`, `name`, `slug`, `icon`, `description`, `info_how_to`, `info_features`, `info_tips`, `is_enabled`, `is_visible_on_landing`, `allow_publish`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 'AI Chat Assistant', 'ai-chat', 'ti-message-circle', 'Multi-provider AI chat', NULL, NULL, NULL, 1, 1, 0, 1, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(2, 'AI Image Generator', 'ai-image', 'ti-photo', 'Generate stunning AI images', NULL, NULL, NULL, 1, 1, 1, 2, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(3, 'AI Video Generator', 'ai-video', 'ti-player-play', 'Generate AI videos', NULL, NULL, NULL, 1, 1, 1, 3, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(4, 'AI Voice Over', 'ai-voice', 'ti-microphone', 'Text-to-speech & voice cloning', NULL, NULL, NULL, 1, 1, 0, 4, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(5, 'AI Code Assistant', 'ai-code', 'ti-code', 'AI-powered coding help', NULL, NULL, NULL, 1, 1, 0, 5, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(6, 'AI Content Writer', 'ai-content', 'ti-pencil', 'Blog posts, articles, copy', NULL, NULL, NULL, 1, 1, 0, 6, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(7, 'AI SEO Optimizer', 'ai-seo', 'ti-search', 'SEO analysis and optimization', NULL, NULL, NULL, 1, 1, 0, 7, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(8, 'AI Website Builder', 'ai-website', 'ti-world', 'Generate website code with AI', NULL, NULL, NULL, 1, 1, 0, 8, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(9, 'AI App Builder', 'ai-app', 'ti-device-mobile', 'Generate app UI and logic', NULL, NULL, NULL, 1, 1, 0, 9, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(10, 'AI Funnel Builder', 'ai-funnel', 'ti-filter', 'Sales funnel creation', NULL, NULL, NULL, 1, 1, 0, 10, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(11, 'AI Blogger', 'ai-blogger', 'ti-file-text', 'Full blog post generator', NULL, NULL, NULL, 1, 1, 0, 11, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(12, 'AI Landing Page', 'ai-landing', 'ti-layout', 'High-converting landing pages', NULL, NULL, NULL, 1, 1, 0, 12, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(13, 'AI Image Enhancer', 'ai-enhance', 'ti-wand', 'Upscale and enhance images', NULL, NULL, NULL, 1, 1, 0, 13, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(14, 'AI Background Remover', 'ai-bgremove', 'ti-cut', 'Remove image backgrounds', NULL, NULL, NULL, 1, 1, 0, 14, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(15, 'AI Logo Design', 'ai-logo', 'ti-shape', 'Generate professional logos', NULL, NULL, NULL, 1, 1, 0, 15, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(16, 'AI Song Generator', 'ai-song', 'ti-music', 'Generate AI music and songs', NULL, NULL, NULL, 1, 1, 0, 16, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(17, 'AI Human Model', 'ai-human', 'ti-user', 'Generate AI human models', NULL, NULL, NULL, 1, 1, 0, 17, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(18, 'AI Video Editor', 'ai-videoeditor', 'ti-video', 'AI-powered video editing', NULL, NULL, NULL, 1, 1, 0, 18, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(19, 'AI Subtitle Generator', 'ai-subtitles', 'ti-subtask', 'Auto subtitles and captions', NULL, NULL, NULL, 1, 1, 0, 19, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(20, 'AI Video Summarizer', 'ai-videosummary', 'ti-file-description', 'Summarize any video', NULL, NULL, NULL, 1, 1, 0, 20, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(21, 'Meta Tag Generator', 'ai-metatags', 'ti-tags', 'SEO meta tags generator', NULL, NULL, NULL, 1, 1, 0, 21, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(22, 'Social Comment Generator', 'ai-socialcomment', 'ti-message-dots', 'AI social media comments', NULL, NULL, NULL, 1, 1, 0, 22, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(23, 'AI Super Agent', 'ai-superagent', 'ti-robot', 'Autonomous AI task agent', NULL, NULL, NULL, 1, 1, 0, 23, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(24, 'AI Social Media Post', 'ai-socialmedia', 'ti-share', 'Generate social media posts', NULL, NULL, NULL, 1, 1, 0, 24, '2026-05-10 21:56:10', '2026-05-10 21:56:10'),
(25, 'AI Email Writer', 'ai-email', 'ti-mail', 'Professional email generator', NULL, NULL, NULL, 1, 1, 0, 25, '2026-05-10 21:56:10', '2026-05-10 21:56:10');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(180) NOT NULL,
  `password` varchar(255) NOT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `role` enum('user','moderator','admin','super_admin') NOT NULL DEFAULT 'user',
  `credit_balance` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `referral_code` varchar(20) NOT NULL,
  `referred_by` int(10) UNSIGNED DEFAULT NULL,
  `language` enum('en','ur') NOT NULL DEFAULT 'en',
  `status` enum('active','suspended','banned') NOT NULL DEFAULT 'active',
  `last_seen_at` datetime DEFAULT NULL,
  `last_ip` varchar(45) DEFAULT NULL,
  `country_code` varchar(5) DEFAULT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `mobile`, `photo`, `role`, `credit_balance`, `referral_code`, `referred_by`, `language`, `status`, `last_seen_at`, `last_ip`, `country_code`, `email_verified`, `created_at`, `updated_at`) VALUES
(1, 'Yasir Ali Qureshi', 'yasirq110@gmail.com', '$2y$12$Fl1NHdVniid6GKjvbfe9JOJYK1TOJEyiYScchdZZ3O6ThgWjWFjGG', '+923133283193', NULL, 'super_admin', 46, '2FD8F471', NULL, 'en', 'active', '2026-05-11 23:14:53', '::1', NULL, 0, '2026-05-11 03:16:54', '2026-05-11 23:14:53');

-- --------------------------------------------------------

--
-- Table structure for table `user_activity_logs`
--

CREATE TABLE `user_activity_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `tool_id` int(10) UNSIGNED NOT NULL,
  `api_service_id` int(10) UNSIGNED DEFAULT NULL,
  `action_type` varchar(100) DEFAULT NULL,
  `input_preview` varchar(500) DEFAULT NULL,
  `result_url` varchar(500) DEFAULT NULL,
  `credits_used` smallint(5) UNSIGNED DEFAULT 0,
  `status` enum('success','failed','timeout') NOT NULL DEFAULT 'success',
  `error_message` varchar(500) DEFAULT NULL,
  `is_visible_to_user` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_activity_logs`
--

INSERT INTO `user_activity_logs` (`id`, `user_id`, `tool_id`, `api_service_id`, `action_type`, `input_preview`, `result_url`, `credits_used`, `status`, `error_message`, `is_visible_to_user`, `created_at`) VALUES
(1, 1, 1, 1, NULL, 'hi groq', NULL, 0, 'failed', 'Invalid API Key', 1, '2026-05-11 08:15:29'),
(2, 1, 1, 1, NULL, 'hi', NULL, 0, 'failed', 'Invalid API Key', 1, '2026-05-11 08:18:52'),
(3, 1, 1, 2, NULL, 'hi', NULL, 1, 'success', NULL, 1, '2026-05-11 08:18:57'),
(4, 1, 1, 1, NULL, 'hi groq its testing', NULL, 0, 'failed', 'The model `llama3-8b-8192` has been decommissioned and is no longer supported. Please refer to https://console.groq.com/docs/deprecations for a recommendation on which model to use instead.', 1, '2026-05-11 08:22:12'),
(5, 1, 1, 1, NULL, 'hi groq testing message', NULL, 1, 'success', NULL, 1, '2026-05-11 08:27:59'),
(6, 1, 2, 18, NULL, 'Generate image of 2 red cups of coffer at round table in the garden', NULL, 0, 'failed', 'Leonardo: no generation ID. Response: {\"error\":\"This model is not supported in this API version, please check the API version and model ID.\",\"path\":\"$\",\"code\":\"unexpected\"}', 1, '2026-05-11 22:19:46'),
(7, 1, 2, 18, NULL, 'Two ceramic coffee cups side by side on a cozy wooden table, each cup embossed with a cute smiling emoji face, warm steam rising from freshly brewed coffee, soft morning sunlight, minimal aesthetic, realistic texture, pastel color palette, shallow depth of field, cozy café atmosphere, high-detail photorealistic style, heartwarming mood, 4K cinematic lighting.', NULL, 0, 'failed', 'Leonardo: no generation ID. Response: {\"error\":\"This model is not supported in this API version, please check the API version and model ID.\",\"path\":\"$\",\"code\":\"unexpected\"}', 1, '2026-05-11 22:21:35'),
(8, 1, 2, 18, NULL, 'Two ceramic coffee cups side by side on a cozy wooden table, each cup embossed with a cute smiling emoji face, warm steam rising from freshly brewed coffee, soft morning sunlight, minimal aesthetic, realistic texture, pastel color palette, shallow depth of field, cozy café atmosphere, high-detail photorealistic style, heartwarming mood, 4K cinematic lighting.', NULL, 0, 'failed', 'Leonardo: no generation ID. Response: {\"error\":\"This model is not supported in this API version, please check the API version and model ID.\",\"path\":\"$\",\"code\":\"unexpected\"}', 1, '2026-05-11 22:24:47'),
(9, 1, 2, 18, NULL, 'Two ceramic coffee cups side by side on a cozy wooden table, each cup embossed with a cute smiling emoji face, warm steam rising from freshly brewed coffee, soft morning sunlight, minimal aesthetic, realistic texture, pastel color palette, shallow depth of field, cozy café atmosphere, high-detail photorealistic style, heartwarming mood, 4K cinematic lighting., Realistic style', NULL, 0, 'failed', 'Leonardo: no generation ID. Response: {\"error\":\"This model is not supported in this API version, please check the API version and model ID.\",\"path\":\"$\",\"code\":\"unexpected\"}', 1, '2026-05-11 22:30:00'),
(10, 1, 2, 50, NULL, 'Two ceramic coffee cups side by side on a cozy wooden table, each cup embossed with a cute smiling emoji face, warm steam rising from freshly brewed coffee, soft morning sunlight, minimal aesthetic, realistic texture, pastel color palette, shallow depth of field, cozy café atmosphere, high-detail photorealistic style, heartwarming mood, 4K cinematic lighting.', '/aistudio/public/assets/img/generated/img_1778520875_1_6a02132b5a387.png', 1, 'success', NULL, 1, '2026-05-11 22:34:35'),
(11, 1, 24, 13, NULL, 'facebook viral nech batao', NULL, 0, 'failed', 'The model `llama3-8b-8192` has been decommissioned and is no longer supported. Please refer to https://console.groq.com/docs/deprecations for a recommendation on which model to use instead.', 1, '2026-05-11 22:41:35'),
(12, 1, 4, 39, NULL, 'mera naam chulbul panday hai', NULL, 0, 'failed', 'The model `llama3-8b-8192` has been decommissioned and is no longer supported. Please refer to https://console.groq.com/docs/deprecations for a recommendation on which model to use instead.', 1, '2026-05-11 23:00:42'),
(13, 1, 1, 1, NULL, 'hello friend', NULL, 1, 'success', NULL, 1, '2026-05-11 23:01:15'),
(14, 1, 4, 54, NULL, 'mera naam chulbul panday nahi hai yaar kyon tang karte ho', NULL, 0, 'failed', 'Empty response.', 1, '2026-05-11 23:15:07'),
(15, 1, 4, 54, NULL, 'mera naam chulbul panday nahi hai yaar kyon tang karte ho', NULL, 0, 'failed', 'Empty response.', 1, '2026-05-11 23:15:11'),
(16, 1, 4, 54, NULL, 'mera naam chulbul panday nahi hai yaar kyon tang karte ho', NULL, 0, 'failed', 'Empty response.', 1, '2026-05-11 23:15:27');

-- --------------------------------------------------------

--
-- Table structure for table `user_cloned_voices`
--

CREATE TABLE `user_cloned_voices` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `provider_id` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `session_token` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `fingerprint` varchar(128) DEFAULT NULL,
  `last_activity` datetime NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_sessions`
--

INSERT INTO `user_sessions` (`id`, `user_id`, `session_token`, `ip_address`, `user_agent`, `fingerprint`, `last_activity`, `expires_at`, `created_at`) VALUES
(1, 1, 'pgagg62e0a5ldunbhi44u25me6', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36', 'c70ee17594bba200fe85e36494c1265c11e7887100ed67ae2cb9a090aec852c8', '2026-05-11 23:14:54', '2026-05-12 00:17:06', '2026-05-11 03:17:06');

-- --------------------------------------------------------

--
-- Table structure for table `user_subscriptions`
--

CREATE TABLE `user_subscriptions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `plan_id` int(10) UNSIGNED NOT NULL,
  `payment_id` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('active','expired','cancelled','pending') NOT NULL DEFAULT 'pending',
  `started_at` datetime DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `video_credit_tiers`
--

CREATE TABLE `video_credit_tiers` (
  `id` int(10) UNSIGNED NOT NULL,
  `duration_sec` smallint(5) UNSIGNED NOT NULL,
  `credit_cost` smallint(5) UNSIGNED NOT NULL,
  `label` varchar(50) DEFAULT NULL,
  `sort_order` smallint(6) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `video_credit_tiers`
--

INSERT INTO `video_credit_tiers` (`id`, `duration_sec`, `credit_cost`, `label`, `sort_order`, `created_at`) VALUES
(5, 4, 5, '4 seconds', 1, '2026-05-11 09:10:09'),
(6, 8, 9, '8 seconds', 2, '2026-05-11 09:10:09'),
(7, 15, 16, '15 seconds', 3, '2026-05-11 09:10:09'),
(8, 30, 30, '30 seconds', 4, '2026-05-11 09:10:09'),
(9, 60, 60, '60 Second', 5, '2026-05-11 09:10:09');

-- --------------------------------------------------------

--
-- Table structure for table `video_generation_logs`
--

CREATE TABLE `video_generation_logs` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `api_service_id` int(10) UNSIGNED NOT NULL,
  `prompt` text DEFAULT NULL,
  `settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`settings`)),
  `duration_sec` smallint(5) UNSIGNED DEFAULT NULL,
  `video_url` varchar(500) DEFAULT NULL,
  `thumbnail_url` varchar(500) DEFAULT NULL,
  `provider_job_id` varchar(255) DEFAULT NULL,
  `credits_used` smallint(5) UNSIGNED DEFAULT 0,
  `status` enum('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
  `is_published` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `advertisements`
--
ALTER TABLE `advertisements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `api_call_logs`
--
ALTER TABLE `api_call_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_tool_id` (`tool_id`),
  ADD KEY `idx_service_id` (`api_service_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `api_services`
--
ALTER TABLE `api_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tool_id` (`tool_id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `idx_code` (`code`),
  ADD KEY `idx_is_active` (`is_active`);

--
-- Indexes for table `credit_transactions`
--
ALTER TABLE `credit_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_type` (`type`),
  ADD KEY `idx_source` (`source`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_type` (`type`),
  ADD KEY `idx_is_active` (`is_active`);

--
-- Indexes for table `image_generation_logs`
--
ALTER TABLE `image_generation_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_is_published` (`is_published`);

--
-- Indexes for table `ip_bans`
--
ALTER TABLE `ip_bans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ip` (`ip_address`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_expires_at` (`expires_at`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_gateway` (`gateway`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `queue_jobs`
--
ALTER TABLE `queue_jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_scheduled_at` (`scheduled_at`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_rating` (`rating`);

--
-- Indexes for table `review_votes`
--
ALTER TABLE `review_votes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_vote` (`review_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `theme_settings`
--
ALTER TABLE `theme_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`);

--
-- Indexes for table `tools`
--
ALTER TABLE `tools`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `idx_slug` (`slug`),
  ADD KEY `idx_enabled` (`is_enabled`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `referral_code` (`referral_code`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_role` (`role`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_referral` (`referral_code`);

--
-- Indexes for table `user_activity_logs`
--
ALTER TABLE `user_activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_tool_id` (`tool_id`),
  ADD KEY `idx_visible` (`is_visible_to_user`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Indexes for table `user_cloned_voices`
--
ALTER TABLE `user_cloned_voices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `session_token` (`session_token`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_token` (`session_token`),
  ADD KEY `idx_activity` (`last_activity`);

--
-- Indexes for table `user_subscriptions`
--
ALTER TABLE `user_subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_expires_at` (`expires_at`),
  ADD KEY `plan_id` (`plan_id`);

--
-- Indexes for table `video_credit_tiers`
--
ALTER TABLE `video_credit_tiers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `video_generation_logs`
--
ALTER TABLE `video_generation_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_is_published` (`is_published`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `advertisements`
--
ALTER TABLE `advertisements`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `api_call_logs`
--
ALTER TABLE `api_call_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `api_services`
--
ALTER TABLE `api_services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `credit_transactions`
--
ALTER TABLE `credit_transactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `image_generation_logs`
--
ALTER TABLE `image_generation_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ip_bans`
--
ALTER TABLE `ip_bans`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `queue_jobs`
--
ALTER TABLE `queue_jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `review_votes`
--
ALTER TABLE `review_votes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscription_plans`
--
ALTER TABLE `subscription_plans`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `theme_settings`
--
ALTER TABLE `theme_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tools`
--
ALTER TABLE `tools`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_activity_logs`
--
ALTER TABLE `user_activity_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `user_cloned_voices`
--
ALTER TABLE `user_cloned_voices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_sessions`
--
ALTER TABLE `user_sessions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_subscriptions`
--
ALTER TABLE `user_subscriptions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `video_credit_tiers`
--
ALTER TABLE `video_credit_tiers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `video_generation_logs`
--
ALTER TABLE `video_generation_logs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `api_call_logs`
--
ALTER TABLE `api_call_logs`
  ADD CONSTRAINT `api_call_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `api_services`
--
ALTER TABLE `api_services`
  ADD CONSTRAINT `api_services_ibfk_1` FOREIGN KEY (`tool_id`) REFERENCES `tools` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `credit_transactions`
--
ALTER TABLE `credit_transactions`
  ADD CONSTRAINT `credit_transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `gallery`
--
ALTER TABLE `gallery`
  ADD CONSTRAINT `gallery_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `image_generation_logs`
--
ALTER TABLE `image_generation_logs`
  ADD CONSTRAINT `image_generation_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `review_votes`
--
ALTER TABLE `review_votes`
  ADD CONSTRAINT `review_votes_ibfk_1` FOREIGN KEY (`review_id`) REFERENCES `reviews` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `review_votes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_activity_logs`
--
ALTER TABLE `user_activity_logs`
  ADD CONSTRAINT `user_activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_cloned_voices`
--
ALTER TABLE `user_cloned_voices`
  ADD CONSTRAINT `user_cloned_voices_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_subscriptions`
--
ALTER TABLE `user_subscriptions`
  ADD CONSTRAINT `user_subscriptions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `user_subscriptions_ibfk_2` FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans` (`id`);

--
-- Constraints for table `video_generation_logs`
--
ALTER TABLE `video_generation_logs`
  ADD CONSTRAINT `video_generation_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
