<?php
/**
 * AIStudio — Bootstrap
 * Include this at the top of EVERY public and admin PHP file.
 * Sets up: env, DB, security, auth, theme.
 */

define('ROOT', dirname(__DIR__));
define('START_TIME', microtime(true));

// ── Autoloader ────────────────────────────────────────────────────
spl_autoload_register(function (string $class): void {
    $paths = [
        ROOT . '/config/'           . $class . '.php',
        ROOT . '/app/Core/'         . $class . '.php',
        ROOT . '/app/Helpers/'      . $class . '.php',
        ROOT . '/app/Middleware/'   . $class . '.php',
    ];
    foreach ($paths as $path) {
        if (file_exists($path)) {
            require_once $path;
            return;
        }
    }
});

// ── Load .env ─────────────────────────────────────────────────────
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');

// ── PHP settings ──────────────────────────────────────────────────
error_reporting(env('APP_DEBUG', 'false') === 'true' ? E_ALL : 0);
ini_set('display_errors',  env('APP_DEBUG', 'false') === 'true' ? '1' : '0');
ini_set('log_errors', '1');
date_default_timezone_set('UTC');
mb_internal_encoding('UTF-8');

// ── Security: start session + CSRF ────────────────────────────────
Security::startSession();

// ── IP Ban check (before everything) ─────────────────────────────
Security::checkIpBan();

// ── Maintenance mode ──────────────────────────────────────────────
if (ThemeEngine::isMaintenanceMode()) {
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    if (!str_starts_with($uri, '/admin')) {
        http_response_code(503);
        include ROOT . '/public/errors/maintenance.php';
        exit;
    }
}

// ── Session fingerprint (only for logged-in users) ────────────────
if (Auth::check()) {
    Security::validateFingerprint();
}

// ── CSRF verification for POST ────────────────────────────────────
Security::verifyCsrfToken();

// ── Helper functions ──────────────────────────────────────────────
require_once ROOT . '/app/Helpers/functions.php';
