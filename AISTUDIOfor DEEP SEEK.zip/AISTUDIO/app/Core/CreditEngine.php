<?php
/**
 * AIStudio — Credit Engine
 * All credit operations go through this class.
 * Every transaction is logged to credit_transactions.
 */

class CreditEngine
{
    // ─── GET BALANCE ──────────────────────────────────────────────
    public static function balance(int $userId): int
    {
        return (int) DB::scalar(
            "SELECT credit_balance FROM users WHERE id = ?", [$userId]
        );
    }

    // ─── CHECK SUFFICIENT ─────────────────────────────────────────
    public static function hasSufficient(int $userId, int $amount): bool
    {
        return self::balance($userId) >= $amount;
    }

    // ─── DEDUCT CREDITS ───────────────────────────────────────────
    /**
     * Deduct credits for a tool use.
     * Returns ['success'=>true] or ['success'=>false,'error'=>'...']
     */
    public static function deduct(
        int    $userId,
        int    $amount,
        int    $toolId,
        int    $apiServiceId,
        string $note = ''
    ): array {
        if ($amount <= 0) {
            return ['success' => true]; // free tool
        }

        DB::beginTransaction();
        try {
            // Lock the row for this transaction
            $user = DB::queryOne(
                "SELECT credit_balance FROM users WHERE id = ? FOR UPDATE",
                [$userId]
            );

            if (!$user || $user['credit_balance'] < $amount) {
                DB::rollback();
                return [
                    'success' => false,
                    'error'   => 'Insufficient credits. Please top up your account.',
                ];
            }

            $newBalance = $user['credit_balance'] - $amount;

            DB::execute(
                "UPDATE users SET credit_balance = ? WHERE id = ?",
                [$newBalance, $userId]
            );

            DB::execute(
                "INSERT INTO credit_transactions
                    (user_id, type, amount, balance_after, source, tool_id, api_service_id, note)
                 VALUES (?, 'debit', ?, ?, 'tool_use', ?, ?, ?)",
                [$userId, $amount, $newBalance, $toolId, $apiServiceId, $note]
            );

            DB::commit();
            return ['success' => true, 'new_balance' => $newBalance];

        } catch (Throwable $e) {
            DB::rollback();
            return ['success' => false, 'error' => 'Credit deduction failed. Please try again.'];
        }
    }

    // ─── ADD CREDITS ──────────────────────────────────────────────
    /**
     * Add credits (subscription, admin gift, referral, refund).
     */
    public static function add(
        int    $userId,
        int    $amount,
        string $source,
        string $note        = '',
        string $referenceId = ''
    ): array {
        if ($amount <= 0) {
            return ['success' => false, 'error' => 'Amount must be positive.'];
        }

        DB::beginTransaction();
        try {
            DB::execute(
                "UPDATE users SET credit_balance = credit_balance + ? WHERE id = ?",
                [$amount, $userId]
            );

            $newBalance = (int) DB::scalar(
                "SELECT credit_balance FROM users WHERE id = ?", [$userId]
            );

            DB::execute(
                "INSERT INTO credit_transactions
                    (user_id, type, amount, balance_after, source, reference_id, note)
                 VALUES (?, 'credit', ?, ?, ?, ?, ?)",
                [$userId, $amount, $newBalance, $source, $referenceId ?: null, $note]
            );

            DB::commit();
            return ['success' => true, 'new_balance' => $newBalance];

        } catch (Throwable $e) {
            DB::rollback();
            return ['success' => false, 'error' => 'Credit operation failed.'];
        }
    }

    // ─── ADMIN MANUAL ADD/DEDUCT ──────────────────────────────────
    public static function adminAdjust(
        int    $userId,
        int    $amount,
        string $type,  // 'credit' or 'debit'
        string $note   = ''
    ): array {
        if ($type === 'credit') {
            return self::add($userId, $amount, 'admin_add', $note);
        }

        // Admin deduct
        DB::beginTransaction();
        try {
            $user = DB::queryOne(
                "SELECT credit_balance FROM users WHERE id = ? FOR UPDATE",
                [$userId]
            );

            $newBalance = max(0, $user['credit_balance'] - $amount);

            DB::execute(
                "UPDATE users SET credit_balance = ? WHERE id = ?",
                [$newBalance, $userId]
            );

            DB::execute(
                "INSERT INTO credit_transactions
                    (user_id, type, amount, balance_after, source, note)
                 VALUES (?, 'debit', ?, ?, 'admin_deduct', ?)",
                [$userId, $amount, $newBalance, $note]
            );

            DB::commit();
            return ['success' => true, 'new_balance' => $newBalance];

        } catch (Throwable $e) {
            DB::rollback();
            return ['success' => false, 'error' => 'Adjustment failed.'];
        }
    }

    // ─── VIDEO CREDIT COST ────────────────────────────────────────
    public static function videoCreditCost(int $durationSec): int
    {
        $tier = DB::queryOne(
            "SELECT credit_cost FROM video_credit_tiers
             WHERE duration_sec = ? LIMIT 1",
            [$durationSec]
        );

        return $tier ? (int) $tier['credit_cost'] : 10; // fallback
    }

    // ─── TRANSACTION HISTORY (for user dashboard) ─────────────────
    public static function history(int $userId, int $limit = 20, int $offset = 0): array
    {
        return DB::query(
            "SELECT ct.*, t.name as tool_name, a.name as service_name
             FROM credit_transactions ct
             LEFT JOIN tools t         ON t.id = ct.tool_id
             LEFT JOIN api_services a  ON a.id = ct.api_service_id
             WHERE ct.user_id = ?
             ORDER BY ct.created_at DESC
             LIMIT ? OFFSET ?",
            [$userId, $limit, $offset]
        );
    }

    // ─── TOTAL CREDITS HELD (admin dashboard) ─────────────────────
    public static function totalCreditsHeld(): int
    {
        return (int) DB::scalar("SELECT SUM(credit_balance) FROM users");
    }

    // ─── CREDITS VALUE IN USD ─────────────────────────────────────
    public static function creditsToUsd(int $credits): float
    {
        return round($credits * 0.02, 2);
    }
}
