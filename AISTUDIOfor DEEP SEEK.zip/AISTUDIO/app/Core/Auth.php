<?php
/**
 * AIStudio — Auth class
 * Handles registration, login, logout, OTP password reset.
 */

class Auth
{
    // ─── CHECK IF LOGGED IN ───────────────────────────────────────
    public static function check(): bool
    {
        return !empty($_SESSION['user_id']);
    }

    public static function user(): ?array
    {
        if (!self::check()) {
            return null;
        }

        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }

        $cached = DB::queryOne(
            "SELECT id, name, email, mobile, photo, role, credit_balance,
                    referral_code, language, status, created_at
             FROM users WHERE id = ? AND status != 'banned'",
            [$_SESSION['user_id']]
        );

        return $cached;
    }

    public static function id(): int
    {
        return (int) ($_SESSION['user_id'] ?? 0);
    }

    public static function isAdmin(): bool
    {
        $user = self::user();
        return $user && in_array($user['role'], ['admin', 'super_admin', 'moderator']);
    }

    public static function isSuperAdmin(): bool
    {
        $user = self::user();
        return $user && $user['role'] === 'super_admin';
    }

    // ─── REQUIRE LOGIN (redirect if not) ─────────────────────────
    public static function requireLogin(string $redirect = '/login'): void
    {
        if (!self::check()) {
            header('Location: ' . $redirect);
            exit;
        }

        // Check suspended/banned
        $user = self::user();
        if (!$user || $user['status'] === 'banned') {
            self::logout();
            header('Location: /login?reason=banned');
            exit;
        }

        if ($user['status'] === 'suspended') {
            self::logout();
            header('Location: /login?reason=suspended');
            exit;
        }

        Security::updateLastSeen(self::id());
    }

    public static function requireAdmin(): void
    {
        self::requireLogin('/aistudio/public/login.php');
        if (!self::isAdmin()) {
            http_response_code(403);
            include ROOT . '/public/errors/403.php';
            exit;
        }
    }

    // ─── REGISTER ─────────────────────────────────────────────────
    public static function register(array $data): array
    {
        $name     = Security::sanitizeRaw($data['name']     ?? '');
        $email    = strtolower(trim($data['email']          ?? ''));
        $password = $data['password']                        ?? '';
        $mobile   = Security::sanitizeRaw($data['mobile']   ?? '');
        $refCode  = Security::sanitizeRaw($data['ref_code'] ?? '');

        // Validation
        if (strlen($name) < 2 || strlen($name) > 100) {
            return ['success' => false, 'error' => 'Name must be 2–100 characters.'];
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'error' => 'Invalid email address.'];
        }
        if (strlen($password) < 8) {
            return ['success' => false, 'error' => 'Password must be at least 8 characters.'];
        }

        // Check email exists
        $exists = DB::scalar("SELECT COUNT(*) FROM users WHERE email = ?", [$email]);
        if ($exists > 0) {
            return ['success' => false, 'error' => 'Email already registered.'];
        }

        // Handle referral
        $referredBy = null;
        if (!empty($refCode)) {
            $referrer = DB::queryOne(
                "SELECT id FROM users WHERE referral_code = ?", [$refCode]
            );
            $referredBy = $referrer ? $referrer['id'] : null;
        }

        DB::beginTransaction();
        try {
            $userId = DB::insert(
                "INSERT INTO users (name, email, password, mobile, referral_code, referred_by)
                 VALUES (?, ?, ?, ?, ?, ?)",
                [
                    $name,
                    $email,
                    password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]),
                    $mobile ?: null,
                    self::generateReferralCode(),
                    $referredBy,
                ]
            );

            // Award referral credits if applicable
            if ($referredBy) {
                self::awardReferralCredits($referredBy, $userId);
            }

            DB::commit();
            return ['success' => true, 'user_id' => $userId];

        } catch (Throwable $e) {
            DB::rollback();
            return ['success' => false, 'error' => 'Registration failed. Please try again.'];
        }
    }

    // ─── LOGIN ────────────────────────────────────────────────────
    public static function login(string $email, string $password, bool $remember = false): array
    {
        $email = strtolower(trim($email));

        $user = DB::queryOne(
            "SELECT id, name, email, password, role, status, credit_balance
             FROM users WHERE email = ?",
            [$email]
        );

        if (!$user) {
            return ['success' => false, 'error' => 'Invalid email or password.'];
        }

        if ($user['status'] === 'banned') {
            return ['success' => false, 'error' => 'Your account has been banned.'];
        }

        if ($user['status'] === 'suspended') {
            return ['success' => false, 'error' => 'Your account is suspended.'];
        }

        if (!password_verify($password, $user['password'])) {
            return ['success' => false, 'error' => 'Invalid email or password.'];
        }

        // Set session
        session_regenerate_id(true);
        $_SESSION['user_id']   = $user['id'];
        $_SESSION['user_role'] = $user['role'];

        // Log session to DB
        $expiry = $remember
            ? date('Y-m-d H:i:s', strtotime('+30 days'))
            : date('Y-m-d H:i:s', strtotime('+1 day'));

        DB::execute(
            "INSERT INTO user_sessions (user_id, session_token, ip_address, user_agent, fingerprint, expires_at)
             VALUES (?, ?, ?, ?, ?, ?)",
            [
                $user['id'],
                session_id(),
                Security::getClientIp(),
                substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
                hash('sha256', ($_SERVER['HTTP_USER_AGENT'] ?? '') . Security::getClientIp() . env('APP_SECRET')),
                $expiry,
            ]
        );

        DB::execute(
            "UPDATE users SET last_seen_at = NOW(), last_ip = ? WHERE id = ?",
            [Security::getClientIp(), $user['id']]
        );

        return ['success' => true, 'user' => $user];
    }

    // ─── LOGOUT ───────────────────────────────────────────────────
    public static function logout(): void
    {
        if (self::check()) {
            DB::execute(
                "DELETE FROM user_sessions WHERE session_token = ?",
                [session_id()]
            );
        }
        Security::destroySession();
    }

    // ─── OTP PASSWORD RESET ───────────────────────────────────────
    public static function sendPasswordOtp(string $email): array
    {
        $email = strtolower(trim($email));
        $user  = DB::queryOne("SELECT id FROM users WHERE email = ?", [$email]);

        if (!$user) {
            // Don't reveal if email exists
            return ['success' => true];
        }

        $otp     = (string) random_int(100000, 999999);
        $expires = date('Y-m-d H:i:s', strtotime('+15 minutes'));

        DB::execute(
            "DELETE FROM password_resets WHERE email = ?", [$email]
        );

        DB::execute(
            "INSERT INTO password_resets (email, otp, type, expires_at) VALUES (?, ?, 'email', ?)",
            [$email, $otp, $expires]
        );

        Mailer::send(
            to:      $email,
            subject: 'Your AIStudio password reset OTP',
            body:    self::otpEmailBody($otp)
        );

        return ['success' => true];
    }

    public static function verifyOtp(string $email, string $otp): bool
    {
        $email = strtolower(trim($email));
        $now   = date('Y-m-d H:i:s');

        $record = DB::queryOne(
            "SELECT id FROM password_resets
             WHERE email = ? AND otp = ? AND used = 0 AND expires_at > ?",
            [$email, $otp, $now]
        );

        return $record !== null;
    }

    public static function resetPassword(string $email, string $otp, string $newPassword): array
    {
        if (!self::verifyOtp($email, $otp)) {
            return ['success' => false, 'error' => 'Invalid or expired OTP.'];
        }

        if (strlen($newPassword) < 8) {
            return ['success' => false, 'error' => 'Password must be at least 8 characters.'];
        }

        DB::execute(
            "UPDATE users SET password = ? WHERE email = ?",
            [password_hash($newPassword, PASSWORD_BCRYPT, ['cost' => 12]), $email]
        );

        DB::execute(
            "UPDATE password_resets SET used = 1 WHERE email = ?", [$email]
        );

        return ['success' => true];
    }

    // ─── HELPERS ──────────────────────────────────────────────────
    private static function generateReferralCode(): string
    {
        do {
            $code   = strtoupper(substr(md5(uniqid('', true)), 0, 8));
            $exists = DB::scalar("SELECT COUNT(*) FROM users WHERE referral_code = ?", [$code]);
        } while ($exists > 0);

        return $code;
    }

    private static function awardReferralCredits(int $referrerId, int $newUserId): void
    {
        $amount = 50; // 50 free credits for referrer

        DB::execute(
            "UPDATE users SET credit_balance = credit_balance + ? WHERE id = ?",
            [$amount, $referrerId]
        );

        $balance = DB::scalar("SELECT credit_balance FROM users WHERE id = ?", [$referrerId]);

        DB::execute(
            "INSERT INTO credit_transactions (user_id, type, amount, balance_after, source, reference_id, note)
             VALUES (?, 'credit', ?, ?, 'referral', ?, ?)",
            [$referrerId, $amount, $balance, "ref_{$newUserId}", "Referral bonus — new user joined"]
        );
    }

    private static function otpEmailBody(string $otp): string
    {
        return "
        <div style='font-family:Arial,sans-serif;max-width:500px;margin:0 auto'>
            <h2 style='color:#a78bfa'>AIStudio Password Reset</h2>
            <p>Your one-time password (OTP) is:</p>
            <div style='font-size:36px;font-weight:bold;letter-spacing:8px;color:#a78bfa;
                        background:#f3f0ff;padding:20px;text-align:center;border-radius:8px'>
                {$otp}
            </div>
            <p style='color:#666;margin-top:16px'>This OTP expires in 15 minutes.</p>
            <p style='color:#666'>If you did not request a password reset, ignore this email.</p>
        </div>";
    }
}
