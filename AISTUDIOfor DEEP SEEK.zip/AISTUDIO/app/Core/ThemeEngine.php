<?php
/**
 * AIStudio — Theme Engine
 * Loads settings from theme_settings table.
 * Outputs a <style> block with CSS custom properties.
 * Admin can switch presets or customise individual values.
 */

class ThemeEngine
{
    public static array $settings = [];

    // ─── PRESETS ──────────────────────────────────────────────────
    public static array $presets = [
        'deep_space' => [
            'label'          => 'Deep space',
            'bg_primary'     => '#0d0d1a',
            'bg_secondary'   => '#13132a',
            'bg_card'        => '#1a1a35',
            'bg_sidebar'     => '#0a0a16',
            'primary'        => '#a78bfa',
            'secondary'      => '#38bdf8',
            'accent'         => '#f0abfc',
            'text_primary'   => '#f1f1ff',
            'text_secondary' => '#9b9bc0',
            'border'         => 'rgba(167,139,250,0.15)',
            'dark'           => true,
        ],
        'arctic_light' => [
            'label'          => 'Arctic light',
            'bg_primary'     => '#ffffff',
            'bg_secondary'   => '#f8fafc',
            'bg_card'        => '#ffffff',
            'bg_sidebar'     => '#f0f4ff',
            'primary'        => '#4338ca',
            'secondary'      => '#059669',
            'accent'         => '#0ea5e9',
            'text_primary'   => '#1e1b4b',
            'text_secondary' => '#6b7280',
            'border'         => 'rgba(67,56,202,0.12)',
            'dark'           => false,
        ],
        'matrix_dark' => [
            'label'          => 'Matrix dark',
            'bg_primary'     => '#0a0a0a',
            'bg_secondary'   => '#111111',
            'bg_card'        => '#161616',
            'bg_sidebar'     => '#080808',
            'primary'        => '#00ff88',
            'secondary'      => '#00ccff',
            'accent'         => '#ff6b00',
            'text_primary'   => '#e0ffe0',
            'text_secondary' => '#6aff6a',
            'border'         => 'rgba(0,255,136,0.12)',
            'dark'           => true,
        ],
        'ember_forge' => [
            'label'          => 'Ember forge',
            'bg_primary'     => '#100500',
            'bg_secondary'   => '#1a0a00',
            'bg_card'        => '#221000',
            'bg_sidebar'     => '#0d0400',
            'primary'        => '#ff6b35',
            'secondary'      => '#ffd700',
            'accent'         => '#ff3366',
            'text_primary'   => '#fff8f0',
            'text_secondary' => '#d4a090',
            'border'         => 'rgba(255,107,53,0.15)',
            'dark'           => true,
        ],
        'sand_rose' => [
            'label'          => 'Sand & rose',
            'bg_primary'     => '#fef9f4',
            'bg_secondary'   => '#fdf4ef',
            'bg_card'        => '#ffffff',
            'bg_sidebar'     => '#fef3e8',
            'primary'        => '#92400e',
            'secondary'      => '#be185d',
            'accent'         => '#d97706',
            'text_primary'   => '#1c0a00',
            'text_secondary' => '#78350f',
            'border'         => 'rgba(146,64,14,0.12)',
            'dark'           => false,
        ],
        'neon_ocean' => [
            'label'          => 'Neon ocean',
            'bg_primary'     => '#000a14',
            'bg_secondary'   => '#001020',
            'bg_card'        => '#001828',
            'bg_sidebar'     => '#00060f',
            'primary'        => '#00e5ff',
            'secondary'      => '#69ff47',
            'accent'         => '#ff4081',
            'text_primary'   => '#e0faff',
            'text_secondary' => '#4dd0e1',
            'border'         => 'rgba(0,229,255,0.12)',
            'dark'           => true,
        ],
        'custom' => [
            'label' => 'Custom',
        ],
    ];

    // ─── LOAD SETTINGS FROM DB ────────────────────────────────────
    public static function load(): void
    {
        if (!empty(self::$settings)) {
            return;
        }

        $rows = DB::query("SELECT `key`, `value` FROM theme_settings");
        foreach ($rows as $row) {
            self::$settings[$row['key']] = $row['value'];
        }
    }

    public static function get(string $key, string $default = ''): string
    {
        self::load();
        return self::$settings[$key] ?? $default;
    }

    // ─── SAVE A SETTING ───────────────────────────────────────────
    public static function set(string $key, string $value): void
    {
        DB::execute(
            "INSERT INTO theme_settings (`key`, `value`) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE `value` = ?",
            [$key, $value, $value]
        );
        self::$settings[$key] = $value;
    }

    // ─── APPLY PRESET ─────────────────────────────────────────────
    public static function applyPreset(string $presetKey): void
    {
        if (!isset(self::$presets[$presetKey])) {
            return;
        }

        $p = self::$presets[$presetKey];
        self::set('theme_preset',    $presetKey);
        self::set('primary_color',   $p['primary']        ?? '#a78bfa');
        self::set('secondary_color', $p['secondary']      ?? '#38bdf8');
        // Store full preset as JSON for CSS generation
        self::set('theme_preset_data', json_encode($p));
    }

    // ─── OUTPUT CSS VARIABLES ─────────────────────────────────────
    public static function cssVars(): string
    {
        self::load();

        $preset    = self::get('theme_preset', 'deep_space');
        $animation = self::get('theme_animation', 'neural_net');
        $radius    = self::get('theme_radius', 'soft');
        $font      = self::get('theme_font', 'Inter');

        // Get colors from preset or custom
        if ($preset !== 'custom' && isset(self::$presets[$preset])) {
            $p = self::$presets[$preset];
        } else {
            $p = [
                'bg_primary'     => self::get('custom_bg_primary',   '#0d0d1a'),
                'bg_secondary'   => self::get('custom_bg_secondary',  '#13132a'),
                'bg_card'        => self::get('custom_bg_card',       '#1a1a35'),
                'bg_sidebar'     => self::get('custom_bg_sidebar',    '#0a0a16'),
                'primary'        => self::get('primary_color',        '#a78bfa'),
                'secondary'      => self::get('secondary_color',      '#38bdf8'),
                'accent'         => self::get('custom_accent',        '#f0abfc'),
                'text_primary'   => self::get('custom_text_primary',  '#f1f1ff'),
                'text_secondary' => self::get('custom_text_secondary','#9b9bc0'),
                'border'         => self::get('custom_border',        'rgba(167,139,250,0.15)'),
                'dark'           => true,
            ];
        }

        $radiusMap = [
            'sharp'   => '0px',
            'soft'    => '8px',
            'rounded' => '16px',
        ];
        $radiusVal = $radiusMap[$radius] ?? '8px';

        $fontImport = self::fontImport($font);
        $bgImage    = self::get('theme_bg_image', '');
        $bgImageCss = $bgImage ? "url('{$bgImage}')" : 'none';

        $isDark = $p['dark'] ? '1' : '0';

        $css = <<<CSS
        {$fontImport}
        :root {
            --as-bg-primary:      {$p['bg_primary']};
            --as-bg-secondary:    {$p['bg_secondary']};
            --as-bg-card:         {$p['bg_card']};
            --as-bg-sidebar:      {$p['bg_sidebar']};
            --as-primary:         {$p['primary']};
            --as-secondary:       {$p['secondary']};
            --as-accent:          {$p['accent']};
            --as-text-primary:    {$p['text_primary']};
            --as-text-secondary:  {$p['text_secondary']};
            --as-border:          {$p['border']};
            --as-radius:          {$radiusVal};
            --as-radius-lg:       calc({$radiusVal} * 1.5);
            --as-font:            '{$font}', system-ui, sans-serif;
            --as-bg-image:        {$bgImageCss};
            --as-is-dark:         {$isDark};
            --as-animation:       '{$animation}';

            /* Glass effect */
            --as-glass-bg:        rgba(255,255,255,0.04);
            --as-glass-border:    rgba(255,255,255,0.08);
            --as-glass-blur:      12px;

            /* Status */
            --as-success:     #22c55e;
            --as-warning:     #f59e0b;
            --as-danger:      #ef4444;
            --as-info:        var(--as-secondary);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            background-color:  var(--as-bg-primary);
            background-image:  var(--as-bg-image);
            background-size:   cover;
            background-attachment: fixed;
            color:             var(--as-text-primary);
            font-family:       var(--as-font);
            font-size:         15px;
            line-height:       1.6;
            min-height:        100vh;
        }

        /* Glassmorphism card */
        .as-card {
            background:    var(--as-glass-bg);
            backdrop-filter: blur(var(--as-glass-blur));
            -webkit-backdrop-filter: blur(var(--as-glass-blur));
            border:        0.5px solid var(--as-glass-border);
            border-radius: var(--as-radius-lg);
            padding:       1.25rem;
        }

        /* Solid card */
        .as-card-solid {
            background:    var(--as-bg-card);
            border:        0.5px solid var(--as-border);
            border-radius: var(--as-radius-lg);
            padding:       1.25rem;
        }

        /* Buttons */
        .as-btn {
            display:         inline-flex;
            align-items:     center;
            gap:             6px;
            padding:         10px 20px;
            border-radius:   var(--as-radius);
            font-family:     var(--as-font);
            font-size:       14px;
            font-weight:     500;
            cursor:          pointer;
            transition:      all 0.2s ease;
            border:          none;
            text-decoration: none;
        }
        .as-btn-primary {
            background: var(--as-primary);
            color:      #000;
        }
        .as-btn-primary:hover {
            filter: brightness(1.15);
            transform: translateY(-1px);
        }
        .as-btn-primary:active { transform: scale(0.97); }

        .as-btn-ghost {
            background: transparent;
            color:      var(--as-primary);
            border:     0.5px solid var(--as-primary);
        }
        .as-btn-ghost:hover { background: rgba(var(--as-primary), 0.08); }

        /* Inputs */
        .as-input {
            width:         100%;
            background:    var(--as-glass-bg);
            border:        0.5px solid var(--as-border);
            border-radius: var(--as-radius);
            color:         var(--as-text-primary);
            font-family:   var(--as-font);
            font-size:     14px;
            padding:       10px 14px;
            outline:       none;
            transition:    border-color 0.2s;
        }
        .as-input:focus {
            border-color:  var(--as-primary);
            box-shadow:    0 0 0 3px rgba(167,139,250,0.12);
        }
        .as-input::placeholder { color: var(--as-text-secondary); opacity: 0.7; }

        /* Status badges */
        .as-badge {
            display:       inline-block;
            padding:       3px 10px;
            border-radius: 20px;
            font-size:     11px;
            font-weight:   500;
        }
        .as-badge-success { background: rgba(34,197,94,0.15);  color: #22c55e; }
        .as-badge-danger  { background: rgba(239,68,68,0.15);  color: #ef4444; }
        .as-badge-warning { background: rgba(245,158,11,0.15); color: #f59e0b; }
        .as-badge-info    { background: rgba(56,189,248,0.15); color: #38bdf8; }
        .as-badge-primary { background: rgba(167,139,250,0.15);color: #a78bfa; }

        /* Sidebar */
        .as-sidebar {
            background:  var(--as-bg-sidebar);
            border-right: 0.5px solid var(--as-border);
            width:        64px;
            height:       100vh;
            position:     fixed;
            left:         0;
            top:          0;
            overflow:     hidden;
            transition:   width 0.25s ease;
            z-index:      100;
        }
        .as-sidebar:hover { width: 220px; }

        /* Micro animations */
        @media (prefers-reduced-motion: no-preference) {
            .as-animate-in {
                animation: asfadeIn 0.3s ease both;
            }
            @keyframes asfadeIn {
                from { opacity: 0; transform: translateY(8px); }
                to   { opacity: 1; transform: translateY(0); }
            }
            .as-btn-primary, .as-btn-ghost {
                transition: all 0.2s ease;
            }
        }
        CSS;

        $animCss = self::animationCss($animation);

        return "<style>\n{$css}\n{$animCss}\n</style>";
    }

    // ─── ANIMATION CSS ────────────────────────────────────────────
    private static function animationCss(string $mode): string
    {
        return match ($mode) {
            'neural_net' => '
                .as-neural-bg { position:fixed;inset:0;pointer-events:none;z-index:0;overflow:hidden; }
                .as-neural-bg canvas { width:100%;height:100%; }',

            'particles' => '
                .as-particles { position:fixed;inset:0;pointer-events:none;z-index:0; }',

            'glow_pulse' => '
                @media (prefers-reduced-motion: no-preference) {
                    .as-btn-primary { animation: glowPulse 3s ease-in-out infinite; }
                    @keyframes glowPulse {
                        0%,100%{ box-shadow:0 0 8px rgba(167,139,250,0.4); }
                        50%    { box-shadow:0 0 20px rgba(167,139,250,0.8); }
                    }
                }',

            default => '',
        };
    }

    // ─── FONT IMPORT ──────────────────────────────────────────────
    private static function fontImport(string $font): string
    {
        $fonts = [
            'Inter'             => 'Inter:wght@400;500;600',
            'Sora'              => 'Sora:wght@400;500;600',
            'Space+Grotesk'     => 'Space+Grotesk:wght@400;500;600',
            'Plus+Jakarta+Sans' => 'Plus+Jakarta+Sans:wght@400;500;600',
            'Outfit'            => 'Outfit:wght@400;500;600',
            'Geist'             => 'Geist:wght@400;500;600',
        ];

        $param = $fonts[$font] ?? 'Inter:wght@400;500;600';
        return "@import url('https://fonts.googleapis.com/css2?family={$param}&display=swap');";
    }

    // ─── SITE NAME + META HELPERS ─────────────────────────────────
    public static function siteName(): string
    {
        return htmlspecialchars(self::get('site_name', 'AIStudio'), ENT_QUOTES);
    }

    public static function logoHtml(): string
    {
        $logo = self::get('site_logo', '');
        $name = self::siteName();

        if ($logo) {
            return "<img src='" . htmlspecialchars($logo, ENT_QUOTES) . "' alt='{$name} logo' class='as-logo-img'>";
        }

        return "<span class='as-logo-text'>{$name}</span>";
    }

    public static function favicon(): string
    {
        $fav = self::get('site_favicon', '');
        if (!$fav) {
            return '';
        }
        return "<link rel='icon' href='" . htmlspecialchars($fav, ENT_QUOTES) . "'>";
    }

    public static function isMaintenanceMode(): bool
    {
        return self::get('maintenance_mode', '0') === '1';
    }
}
