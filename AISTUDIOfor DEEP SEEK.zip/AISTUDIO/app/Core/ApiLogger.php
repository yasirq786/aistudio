<?php
/**
 * AIStudio — API Logger
 * Called from every tool handler via try/finally.
 * Logs both api_call_logs (admin) and user_activity_logs (user-facing).
 */

class ApiLogger
{
    private int    $userId;
    private int    $toolId;
    private int    $apiServiceId;
    private float  $startTime;
    private int    $apiCallLogId = 0;
    private string $inputPreview = '';
    private int    $creditsUsed  = 0;

    public function __construct(int $userId, int $toolId, int $apiServiceId)
    {
        $this->userId       = $userId;
        $this->toolId       = $toolId;
        $this->apiServiceId = $apiServiceId;
        $this->startTime    = microtime(true);
    }

    /**
     * Call before sending the API request.
     * Creates a pending log entry and returns the log ID.
     */
    public function logStart(array $requestPayload, string $inputPreview = ''): int
    {
        $this->inputPreview = substr($inputPreview, 0, 500);

        $this->apiCallLogId = DB::insert(
            "INSERT INTO api_call_logs
                (user_id, tool_id, api_service_id, request_payload, status)
             VALUES (?, ?, ?, ?, 'pending')",
            [
                $this->userId,
                $this->toolId,
                $this->apiServiceId,
                json_encode($requestPayload, JSON_UNESCAPED_UNICODE),
            ]
        );

        return $this->apiCallLogId;
    }

    /**
     * Call in finally block with the result.
     * Updates api_call_logs and creates user_activity_logs entry.
     */
    public function logEnd(
        array   $responsePayload,
        string  $status,         // 'success' | 'failed' | 'timeout'
        int     $httpStatus      = 200,
        float   $apiCostUsd      = 0.0,
        int     $creditsCharged  = 0,
        string  $resultUrl       = '',
        string  $errorMessage    = ''
    ): void {
        $latencyMs = (int) round((microtime(true) - $this->startTime) * 1000);
        $this->creditsUsed = $creditsCharged;

        // Update api_call_logs
        if ($this->apiCallLogId > 0) {
            DB::execute(
                "UPDATE api_call_logs SET
                    response_payload = ?,
                    http_status      = ?,
                    latency_ms       = ?,
                    api_cost_usd     = ?,
                    credits_charged  = ?,
                    status           = ?,
                    error_message    = ?
                 WHERE id = ?",
                [
                    json_encode($responsePayload, JSON_UNESCAPED_UNICODE),
                    $httpStatus,
                    $latencyMs,
                    round($apiCostUsd, 6),
                    $creditsCharged,
                    $status,
                    $errorMessage ?: null,
                    $this->apiCallLogId,
                ]
            );
        }

        // Create user_activity_logs entry
        DB::execute(
            "INSERT INTO user_activity_logs
                (user_id, tool_id, api_service_id, input_preview,
                 result_url, credits_used, status, error_message)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $this->userId,
                $this->toolId,
                $this->apiServiceId,
                $this->inputPreview,
                $resultUrl ?: null,
                $creditsCharged,
                $status,
                $errorMessage ?: null,
            ]
        );
    }

    /**
     * Convenience: log a complete call in one shot (for sync APIs).
     */
    public static function log(
        int    $userId,
        int    $toolId,
        int    $apiServiceId,
        array  $requestPayload,
        array  $responsePayload,
        string $status,
        int    $httpStatus     = 200,
        float  $apiCostUsd     = 0.0,
        int    $creditsCharged = 0,
        string $inputPreview   = '',
        string $resultUrl      = '',
        string $errorMessage   = '',
        float  $latencyMs      = 0.0
    ): void {
        $requestJson  = json_encode($requestPayload,  JSON_UNESCAPED_UNICODE);
        $responseJson = json_encode($responsePayload, JSON_UNESCAPED_UNICODE);

        DB::execute(
            "INSERT INTO api_call_logs
                (user_id, tool_id, api_service_id, request_payload, response_payload,
                 http_status, latency_ms, api_cost_usd, credits_charged, status, error_message)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $userId, $toolId, $apiServiceId,
                $requestJson, $responseJson,
                $httpStatus, (int) $latencyMs,
                round($apiCostUsd, 6), $creditsCharged,
                $status, $errorMessage ?: null,
            ]
        );

        DB::execute(
            "INSERT INTO user_activity_logs
                (user_id, tool_id, api_service_id, input_preview,
                 result_url, credits_used, status, error_message)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $userId, $toolId, $apiServiceId,
                substr($inputPreview, 0, 500),
                $resultUrl ?: null,
                $creditsCharged,
                $status,
                $errorMessage ?: null,
            ]
        );
    }

    // ─── FETCH USER ACTIVITY LOGS ─────────────────────────────────
    public static function getUserLogs(int $userId, int $limit = 10): array
    {
        return DB::query(
            "SELECT ual.*, t.name as tool_name, t.icon as tool_icon, a.name as api_name
             FROM user_activity_logs ual
             LEFT JOIN tools       t ON t.id = ual.tool_id
             LEFT JOIN api_services a ON a.id = ual.api_service_id
             WHERE ual.user_id = ? AND ual.is_visible_to_user = 1
             ORDER BY ual.created_at DESC
             LIMIT ?",
            [$userId, $limit]
        );
    }

    // ─── FETCH ADMIN API LOGS ─────────────────────────────────────
    public static function getApiLogs(
        array  $filters = [],
        int    $limit   = 50,
        int    $offset  = 0
    ): array {
        $where  = ['1=1'];
        $params = [];

        if (!empty($filters['user_id'])) {
            $where[]  = 'acl.user_id = ?';
            $params[] = (int) $filters['user_id'];
        }
        if (!empty($filters['tool_id'])) {
            $where[]  = 'acl.tool_id = ?';
            $params[] = (int) $filters['tool_id'];
        }
        if (!empty($filters['status'])) {
            $where[]  = 'acl.status = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['date_from'])) {
            $where[]  = 'acl.created_at >= ?';
            $params[] = $filters['date_from'] . ' 00:00:00';
        }
        if (!empty($filters['date_to'])) {
            $where[]  = 'acl.created_at <= ?';
            $params[] = $filters['date_to'] . ' 23:59:59';
        }

        $whereStr = implode(' AND ', $where);
        $params[] = $limit;
        $params[] = $offset;

        return DB::query(
            "SELECT acl.*, u.name as user_name, u.email as user_email,
                    t.name as tool_name, a.name as api_name
             FROM api_call_logs acl
             LEFT JOIN users        u ON u.id = acl.user_id
             LEFT JOIN tools        t ON t.id = acl.tool_id
             LEFT JOIN api_services a ON a.id = acl.api_service_id
             WHERE {$whereStr}
             ORDER BY acl.created_at DESC
             LIMIT ? OFFSET ?",
            $params
        );
    }

    // ─── ADMIN BULK DELETE ────────────────────────────────────────
    public static function deleteOlderThan(int $days): int
    {
        $affected = DB::execute(
            "DELETE FROM api_call_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)",
            [$days]
        );
        DB::execute(
            "DELETE FROM user_activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)
             AND is_visible_to_user = 0",
            [$days]
        );
        return $affected;
    }
}
