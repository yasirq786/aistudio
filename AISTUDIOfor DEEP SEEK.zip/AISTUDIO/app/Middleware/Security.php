<?php
/**
 * AIStudio — Security Middleware
 * Runs on every request before any page logic.
 * Order: IP ban → session start → fingerprint → CSRF
 */

class Security
{
    // ─── IP BAN CHECK ────────────────────────────────────────────
    public static function checkIpBan(): void
    {
        $ip  = self::getClientIp();
        $now = date('Y-m-d H:i:s');

        $ban = DB::queryOne(
            "SELECT id, reason FROM ip_bans
             WHERE ip_address = ?
               AND (expires_at IS NULL OR expires_at > ?)
             LIMIT 1",
            [$ip, $now]
        );

        if ($ban) {
            http_response_code(403);
            include ROOT . '/public/errors/banned.php';
            exit;
        }
    }

    // ─── SESSION ──────────────────────────────────────────────────
    public static function startSession(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        $secure   = env('SESSION_SECURE',   'true')  === 'true';
        $httpOnly = env('SESSION_HTTPONLY',  'true')  === 'true';
        $sameSite = env('SESSION_SAMESITE',  'Strict');
        $lifetime = (int) env('SESSION_LIFETIME', 86400);

        session_set_cookie_params([
            'lifetime' => $lifetime,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $secure,
            'httponly' => $httpOnly,
            'samesite' => $sameSite,
        ]);

        session_name('AISTUDIO_SID');
        session_start();

        // Regenerate ID to prevent session fixation
        if (empty($_SESSION['_initialized'])) {
            session_regenerate_id(true);
            $_SESSION['_initialized'] = true;
        }
    }

    // ─── SESSION FINGERPRINTING ───────────────────────────────────
    public static function validateFingerprint(): void
    {
        $fp = self::generateFingerprint();

        if (!isset($_SESSION['_fingerprint'])) {
            $_SESSION['_fingerprint'] = $fp;
            return;
        }

        if ($_SESSION['_fingerprint'] !== $fp) {
            // Fingerprint mismatch — possible session hijack
            self::destroySession();
            header('Location: /login?reason=session_invalid');
            exit;
        }
    }

    private static function generateFingerprint(): string
    {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $ip = self::getClientIp();
        return hash('sha256', $ua . $ip . env('APP_SECRET', 'secret'));
    }

    public static function destroySession(): void
    {
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $params['path'],
                $params['domain'], $params['secure'], $params['httponly']);
        }
        session_destroy();
    }

    // ─── CSRF ─────────────────────────────────────────────────────
    public static function generateCsrfToken(): string
    {
        if (empty($_SESSION['_csrf_token'])) {
            $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['_csrf_token'];
    }

    public static function verifyCsrfToken(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return;
        }

        $token = $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';

        if (!hash_equals($_SESSION['_csrf_token'] ?? '', $token)) {
            http_response_code(419);
            die(json_encode(['error' => 'CSRF token mismatch.']));
        }
    }

    public static function csrfInput(): string
    {
        return '<input type="hidden" name="_csrf" value="' .
            htmlspecialchars(self::generateCsrfToken(), ENT_QUOTES) . '">';
    }

    public static function csrfMeta(): string
    {
        return '<meta name="csrf-token" content="' .
            htmlspecialchars(self::generateCsrfToken(), ENT_QUOTES) . '">';
    }

    // ─── RATE LIMITING ────────────────────────────────────────────
    /**
     * Simple DB-based rate limiter.
     * Returns true if allowed, false if limited.
     */
    public static function rateLimit(string $key, int $maxAttempts, int $windowSeconds): bool
    {
        $ip  = self::getClientIp();
        $uid = $_SESSION['user_id'] ?? 0;
        $rk  = 'rl_' . md5($key . $ip . $uid);

        if (!isset($_SESSION[$rk])) {
            $_SESSION[$rk] = ['count' => 0, 'reset_at' => time() + $windowSeconds];
        }

        if (time() > $_SESSION[$rk]['reset_at']) {
            $_SESSION[$rk] = ['count' => 0, 'reset_at' => time() + $windowSeconds];
        }

        $_SESSION[$rk]['count']++;

        return $_SESSION[$rk]['count'] <= $maxAttempts;
    }

    // ─── INPUT SANITIZATION ───────────────────────────────────────
    public static function sanitize(mixed $input): mixed
    {
        if (is_array($input)) {
            return array_map([self::class, 'sanitize'], $input);
        }
        return htmlspecialchars(trim((string) $input), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    public static function sanitizeRaw(string $input): string
    {
        return trim(strip_tags($input));
    }

    // ─── IP HELPER ────────────────────────────────────────────────
    public static function getClientIp(): string
    {
        $keys = [
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR',
        ];

        foreach ($keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip  = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return '0.0.0.0';
    }

    // ─── UPDATE LAST SEEN ─────────────────────────────────────────
    public static function updateLastSeen(int $userId): void
    {
        DB::execute(
            "UPDATE users SET last_seen_at = NOW(), last_ip = ? WHERE id = ?",
            [self::getClientIp(), $userId]
        );

        DB::execute(
            "UPDATE user_sessions SET last_activity = NOW()
             WHERE user_id = ? AND session_token = ?",
            [$userId, session_id()]
        );
    }
}
