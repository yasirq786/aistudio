<?php
/**
 * AIStudio — Global helper functions
 */

// ─── REDIRECT ─────────────────────────────────────────────────────
function redirect(string $url, int $code = 302): never
{
    header("Location: {$url}", true, $code);
    exit;
}

// ─── JSON RESPONSE ────────────────────────────────────────────────
function jsonResponse(array $data, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// ─── ABORT ────────────────────────────────────────────────────────
function abort(int $code = 404, string $message = ''): never
{
    http_response_code($code);
    include ROOT . "/public/errors/{$code}.php";
    exit;
}

// ─── FLASH MESSAGES ───────────────────────────────────────────────
function setFlash(string $type, string $message): void
{
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array
{
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function flashHtml(): string
{
    $flash = getFlash();
    if (!$flash) {
        return '';
    }
    $type = htmlspecialchars($flash['type'], ENT_QUOTES);
    $msg  = htmlspecialchars($flash['message'], ENT_QUOTES);
    return "<div class='as-flash as-flash-{$type}' id='asFlash'>{$msg}</div>";
}

// ─── PKR CONVERSION ───────────────────────────────────────────────
function usdToPkr(float $usd): float
{
    $rate = (float) (ThemeEngine::get('pkr_rate', '278'));
    return round($usd * $rate, 2);
}

function formatPkr(float $pkr): string
{
    return 'Rs ' . number_format($pkr, 0);
}

function formatUsd(float $usd): string
{
    return '$' . number_format($usd, 2);
}

// ─── CREDIT DISPLAY ───────────────────────────────────────────────
function formatCredits(int $credits): string
{
    return number_format($credits) . ' cr';
}

// ─── DATE HELPERS ─────────────────────────────────────────────────
function timeAgo(string $datetime): string
{
    $diff = time() - strtotime($datetime);

    if ($diff < 60)         return 'just now';
    if ($diff < 3600)       return (int)($diff / 60)   . ' min ago';
    if ($diff < 86400)      return (int)($diff / 3600)  . ' hr ago';
    if ($diff < 2592000)    return (int)($diff / 86400) . ' days ago';
    return date('M j, Y', strtotime($datetime));
}

function isOnline(string $lastSeen): bool
{
    return (time() - strtotime($lastSeen)) < 300; // 5 minutes
}

// ─── SAFE HTML OUTPUT ─────────────────────────────────────────────
function h(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

// ─── PAGINATION ───────────────────────────────────────────────────
function paginate(int $total, int $perPage, int $currentPage, string $url): string
{
    $totalPages = (int) ceil($total / $perPage);
    if ($totalPages <= 1) {
        return '';
    }

    $html = "<div class='as-pagination'>";
    for ($i = 1; $i <= $totalPages; $i++) {
        $active = $i === $currentPage ? ' active' : '';
        $link   = str_contains($url, '?')
            ? $url . "&page={$i}"
            : $url . "?page={$i}";
        $html .= "<a href='{$link}' class='as-page-btn{$active}'>{$i}</a>";
    }
    $html .= "</div>";
    return $html;
}

// ─── TOOL CREDIT BADGE ────────────────────────────────────────────
function creditBadge(int $credits): string
{
    return "<span class='as-credit-badge'><i class='ti ti-coin'></i> {$credits} cr</span>";
}

// ─── GENERATE CSRF META FOR AJAX ─────────────────────────────────
function csrfMeta(): string
{
    return Security::csrfMeta();
}

// ─── GET REQUEST DATA SAFELY ──────────────────────────────────────
function post(string $key, mixed $default = ''): mixed
{
    return $_POST[$key] ?? $default;
}

function get(string $key, mixed $default = ''): mixed
{
    return $_GET[$key] ?? $default;
}

// ─── FILE SIZE HELPER ─────────────────────────────────────────────
function humanFileSize(int $bytes): string
{
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576)    return round($bytes / 1048576, 2)    . ' MB';
    if ($bytes >= 1024)       return round($bytes / 1024, 2)       . ' KB';
    return $bytes . ' B';
}

// ─── ACTIVE NAV HELPER ────────────────────────────────────────────
function isActivePage(string $slug): string
{
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    return str_contains($uri, $slug) ? ' active' : '';
}
