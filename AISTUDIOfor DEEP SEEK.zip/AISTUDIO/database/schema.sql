-- ============================================================
-- AIStudio — Complete Database Schema
-- MySQL / MariaDB
-- ============================================================

SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;

-- ============================================================
-- 1. USERS
-- ============================================================
CREATE TABLE IF NOT EXISTS `users` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name`            VARCHAR(100)  NOT NULL,
  `email`           VARCHAR(180)  NOT NULL UNIQUE,
  `password`        VARCHAR(255)  NOT NULL,
  `mobile`          VARCHAR(20)   DEFAULT NULL,
  `photo`           VARCHAR(255)  DEFAULT NULL,
  `role`            ENUM('user','moderator','admin','super_admin') NOT NULL DEFAULT 'user',
  `credit_balance`  INT UNSIGNED  NOT NULL DEFAULT 0,
  `referral_code`   VARCHAR(20)   NOT NULL UNIQUE,
  `referred_by`     INT UNSIGNED  DEFAULT NULL,
  `language`        ENUM('en','ur') NOT NULL DEFAULT 'en',
  `status`          ENUM('active','suspended','banned') NOT NULL DEFAULT 'active',
  `last_seen_at`    DATETIME      DEFAULT NULL,
  `last_ip`         VARCHAR(45)   DEFAULT NULL,
  `country_code`    VARCHAR(5)    DEFAULT NULL,
  `email_verified`  TINYINT(1)    NOT NULL DEFAULT 0,
  `created_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_email`   (`email`),
  INDEX `idx_role`    (`role`),
  INDEX `idx_status`  (`status`),
  INDEX `idx_referral`(`referral_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 2. USER SESSIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS `user_sessions` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`       INT UNSIGNED NOT NULL,
  `session_token` VARCHAR(128) NOT NULL UNIQUE,
  `ip_address`    VARCHAR(45)  NOT NULL,
  `user_agent`    VARCHAR(500) DEFAULT NULL,
  `fingerprint`   VARCHAR(128) DEFAULT NULL,
  `last_activity` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at`    DATETIME     NOT NULL,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user_id`  (`user_id`),
  INDEX `idx_token`    (`session_token`),
  INDEX `idx_activity` (`last_activity`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 3. PASSWORD RESETS (OTP)
-- ============================================================
CREATE TABLE IF NOT EXISTS `password_resets` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `email`      VARCHAR(180) NOT NULL,
  `otp`        VARCHAR(10)  NOT NULL,
  `type`       ENUM('email','sms') NOT NULL DEFAULT 'email',
  `used`       TINYINT(1)   NOT NULL DEFAULT 0,
  `expires_at` DATETIME     NOT NULL,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_email`      (`email`),
  INDEX `idx_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 4. IP BANS
-- ============================================================
CREATE TABLE IF NOT EXISTS `ip_bans` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `ip_address` VARCHAR(50)  NOT NULL,
  `ban_type`   ENUM('single','range','cidr') NOT NULL DEFAULT 'single',
  `reason`     VARCHAR(500) DEFAULT NULL,
  `banned_by`  INT UNSIGNED DEFAULT NULL,
  `expires_at` DATETIME     DEFAULT NULL,
  `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_ip` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 5. TOOLS
-- ============================================================
CREATE TABLE IF NOT EXISTS `tools` (
  `id`                    INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name`                  VARCHAR(100) NOT NULL,
  `slug`                  VARCHAR(100) NOT NULL UNIQUE,
  `icon`                  VARCHAR(100) NOT NULL DEFAULT 'ti-wand',
  `description`           VARCHAR(300) DEFAULT NULL,
  `info_how_to`           TEXT         DEFAULT NULL,
  `info_features`         TEXT         DEFAULT NULL,
  `info_tips`             TEXT         DEFAULT NULL,
  `is_enabled`            TINYINT(1)   NOT NULL DEFAULT 1,
  `is_visible_on_landing` TINYINT(1)   NOT NULL DEFAULT 1,
  `allow_publish`         TINYINT(1)   NOT NULL DEFAULT 0,
  `sort_order`            SMALLINT     NOT NULL DEFAULT 0,
  `created_at`            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`            DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_slug`    (`slug`),
  INDEX `idx_enabled` (`is_enabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 6. API SERVICES
-- ============================================================
CREATE TABLE IF NOT EXISTS `api_services` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `tool_id`        INT UNSIGNED NOT NULL,
  `name`           VARCHAR(100) NOT NULL,
  `provider`       VARCHAR(100) NOT NULL,
  `api_key`        TEXT         DEFAULT NULL,
  `api_secret`     TEXT         DEFAULT NULL,
  `endpoint`       VARCHAR(500) DEFAULT NULL,
  `model`          VARCHAR(200) DEFAULT NULL,
  `extra_config`   JSON         DEFAULT NULL,
  `credit_cost`    SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  `is_enabled`     TINYINT(1)   NOT NULL DEFAULT 1,
  `is_default`     TINYINT(1)   NOT NULL DEFAULT 0,
  `sort_order`     SMALLINT     NOT NULL DEFAULT 0,
  `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_tool_id` (`tool_id`),
  FOREIGN KEY (`tool_id`) REFERENCES `tools`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 7. VIDEO CREDIT TIERS (per-second pricing)
-- ============================================================
CREATE TABLE IF NOT EXISTS `video_credit_tiers` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `duration_sec`SMALLINT UNSIGNED NOT NULL,
  `credit_cost` SMALLINT UNSIGNED NOT NULL,
  `label`       VARCHAR(50) DEFAULT NULL,
  `sort_order`  SMALLINT    NOT NULL DEFAULT 0,
  `created_at`  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 8. CREDIT TRANSACTIONS (ledger)
-- ============================================================
CREATE TABLE IF NOT EXISTS `credit_transactions` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`     INT UNSIGNED NOT NULL,
  `type`        ENUM('debit','credit') NOT NULL,
  `amount`      INT NOT NULL,
  `balance_after` INT NOT NULL,
  `source`      ENUM('tool_use','subscription','admin_add','admin_deduct','referral','refund') NOT NULL,
  `tool_id`     INT UNSIGNED DEFAULT NULL,
  `api_service_id` INT UNSIGNED DEFAULT NULL,
  `reference_id`   VARCHAR(100) DEFAULT NULL,
  `note`           VARCHAR(300) DEFAULT NULL,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user_id`   (`user_id`),
  INDEX `idx_type`      (`type`),
  INDEX `idx_source`    (`source`),
  INDEX `idx_created_at`(`created_at`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 9. API CALL LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS `api_call_logs` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`          INT UNSIGNED NOT NULL,
  `tool_id`          INT UNSIGNED NOT NULL,
  `api_service_id`   INT UNSIGNED NOT NULL,
  `request_payload`  MEDIUMTEXT   DEFAULT NULL,
  `response_payload` MEDIUMTEXT   DEFAULT NULL,
  `http_status`      SMALLINT     DEFAULT NULL,
  `latency_ms`       INT UNSIGNED DEFAULT NULL,
  `api_cost_usd`     DECIMAL(10,6) DEFAULT NULL,
  `credits_charged`  SMALLINT UNSIGNED DEFAULT NULL,
  `status`           ENUM('success','failed','timeout','pending') NOT NULL DEFAULT 'pending',
  `error_message`    TEXT         DEFAULT NULL,
  `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user_id`     (`user_id`),
  INDEX `idx_tool_id`     (`tool_id`),
  INDEX `idx_service_id`  (`api_service_id`),
  INDEX `idx_status`      (`status`),
  INDEX `idx_created_at`  (`created_at`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 10. USER ACTIVITY LOGS (user-facing logs)
-- ============================================================
CREATE TABLE IF NOT EXISTS `user_activity_logs` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`          INT UNSIGNED NOT NULL,
  `tool_id`          INT UNSIGNED NOT NULL,
  `api_service_id`   INT UNSIGNED DEFAULT NULL,
  `action_type`      VARCHAR(100) DEFAULT NULL,
  `input_preview`    VARCHAR(500) DEFAULT NULL,
  `result_url`       VARCHAR(500) DEFAULT NULL,
  `credits_used`     SMALLINT UNSIGNED DEFAULT 0,
  `status`           ENUM('success','failed','timeout') NOT NULL DEFAULT 'success',
  `error_message`    VARCHAR(500) DEFAULT NULL,
  `is_visible_to_user` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user_id`   (`user_id`),
  INDEX `idx_tool_id`   (`tool_id`),
  INDEX `idx_visible`   (`is_visible_to_user`),
  INDEX `idx_created_at`(`created_at`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 11. SUBSCRIPTION PLANS
-- ============================================================
CREATE TABLE IF NOT EXISTS `subscription_plans` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name`          VARCHAR(100) NOT NULL,
  `slug`          VARCHAR(100) NOT NULL UNIQUE,
  `description`   TEXT         DEFAULT NULL,
  `price_usd`     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `duration_days` SMALLINT UNSIGNED NOT NULL DEFAULT 30,
  `credits_included` INT UNSIGNED NOT NULL DEFAULT 0,
  `features`      JSON         DEFAULT NULL,
  `is_active`     TINYINT(1)   NOT NULL DEFAULT 1,
  `is_featured`   TINYINT(1)   NOT NULL DEFAULT 0,
  `sort_order`    SMALLINT     NOT NULL DEFAULT 0,
  `created_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 12. USER SUBSCRIPTIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS `user_subscriptions` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`     INT UNSIGNED NOT NULL,
  `plan_id`     INT UNSIGNED NOT NULL,
  `payment_id`  INT UNSIGNED DEFAULT NULL,
  `status`      ENUM('active','expired','cancelled','pending') NOT NULL DEFAULT 'pending',
  `started_at`  DATETIME     DEFAULT NULL,
  `expires_at`  DATETIME     DEFAULT NULL,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user_id`   (`user_id`),
  INDEX `idx_status`    (`status`),
  INDEX `idx_expires_at`(`expires_at`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`plan_id`) REFERENCES `subscription_plans`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 13. COUPONS
-- ============================================================
CREATE TABLE IF NOT EXISTS `coupons` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `code`            VARCHAR(50) NOT NULL UNIQUE,
  `discount_type`   ENUM('percent','fixed') NOT NULL DEFAULT 'percent',
  `discount_value`  DECIMAL(10,2) NOT NULL,
  `max_uses`        INT UNSIGNED DEFAULT NULL,
  `used_count`      INT UNSIGNED NOT NULL DEFAULT 0,
  `valid_from`      DATETIME     DEFAULT NULL,
  `valid_until`     DATETIME     DEFAULT NULL,
  `is_active`       TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_code`      (`code`),
  INDEX `idx_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 14. PAYMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS `payments` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`        INT UNSIGNED NOT NULL,
  `plan_id`        INT UNSIGNED NOT NULL,
  `coupon_id`      INT UNSIGNED DEFAULT NULL,
  `amount_usd`     DECIMAL(10,2) NOT NULL,
  `amount_pkr`     DECIMAL(12,2) DEFAULT NULL,
  `gateway`        ENUM('jazzcash','easypaisa','nayapay','bank_transfer','admin') NOT NULL,
  `gateway_ref`    VARCHAR(255)  DEFAULT NULL,
  `screenshot_url` VARCHAR(500)  DEFAULT NULL,
  `status`         ENUM('pending','verified','rejected','refunded') NOT NULL DEFAULT 'pending',
  `verified_by`    INT UNSIGNED  DEFAULT NULL,
  `verified_at`    DATETIME      DEFAULT NULL,
  `note`           VARCHAR(500)  DEFAULT NULL,
  `created_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_user_id`   (`user_id`),
  INDEX `idx_status`    (`status`),
  INDEX `idx_gateway`   (`gateway`),
  INDEX `idx_created_at`(`created_at`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 15. IMAGE GENERATION LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS `image_generation_logs` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`        INT UNSIGNED NOT NULL,
  `api_service_id` INT UNSIGNED NOT NULL,
  `prompt`         TEXT         DEFAULT NULL,
  `negative_prompt`TEXT         DEFAULT NULL,
  `settings`       JSON         DEFAULT NULL,
  `image_url`      VARCHAR(500) DEFAULT NULL,
  `thumbnail_url`  VARCHAR(500) DEFAULT NULL,
  `credits_used`   SMALLINT UNSIGNED DEFAULT 0,
  `status`         ENUM('success','failed') NOT NULL DEFAULT 'success',
  `is_published`   TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user_id`    (`user_id`),
  INDEX `idx_is_published`(`is_published`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 16. VIDEO GENERATION LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS `video_generation_logs` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`        INT UNSIGNED NOT NULL,
  `api_service_id` INT UNSIGNED NOT NULL,
  `prompt`         TEXT         DEFAULT NULL,
  `settings`       JSON         DEFAULT NULL,
  `duration_sec`   SMALLINT UNSIGNED DEFAULT NULL,
  `video_url`      VARCHAR(500) DEFAULT NULL,
  `thumbnail_url`  VARCHAR(500) DEFAULT NULL,
  `provider_job_id`VARCHAR(255) DEFAULT NULL,
  `credits_used`   SMALLINT UNSIGNED DEFAULT 0,
  `status`         ENUM('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
  `is_published`   TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_user_id`    (`user_id`),
  INDEX `idx_status`     (`status`),
  INDEX `idx_is_published`(`is_published`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 17. GALLERY (published images + videos)
-- ============================================================
CREATE TABLE IF NOT EXISTS `gallery` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`         INT UNSIGNED NOT NULL,
  `type`            ENUM('image','video') NOT NULL,
  `source_id`       INT UNSIGNED NOT NULL,
  `title`           VARCHAR(200) DEFAULT NULL,
  `description`     TEXT         DEFAULT NULL,
  `thumbnail_url`   VARCHAR(500) DEFAULT NULL,
  `media_url`       VARCHAR(500) DEFAULT NULL,
  `views`           INT UNSIGNED NOT NULL DEFAULT 0,
  `likes`           INT UNSIGNED NOT NULL DEFAULT 0,
  `is_active`       TINYINT(1)   NOT NULL DEFAULT 1,
  `removed_by_admin`TINYINT(1)   NOT NULL DEFAULT 0,
  `published_at`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user_id`  (`user_id`),
  INDEX `idx_type`     (`type`),
  INDEX `idx_is_active`(`is_active`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 18. REVIEWS
-- ============================================================
CREATE TABLE IF NOT EXISTS `reviews` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`          INT UNSIGNED NOT NULL,
  `rating`           TINYINT UNSIGNED NOT NULL DEFAULT 5,
  `title`            VARCHAR(100) DEFAULT NULL,
  `body`             TEXT         DEFAULT NULL,
  `status`           ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `is_pinned`        TINYINT(1)   NOT NULL DEFAULT 0,
  `helpful_count`    INT UNSIGNED NOT NULL DEFAULT 0,
  `not_helpful_count`INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_user_id` (`user_id`),
  INDEX `idx_status`  (`status`),
  INDEX `idx_rating`  (`rating`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 19. REVIEW VOTES
-- ============================================================
CREATE TABLE IF NOT EXISTS `review_votes` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `review_id`  INT UNSIGNED NOT NULL,
  `user_id`    INT UNSIGNED NOT NULL,
  `vote_type`  ENUM('helpful','not_helpful') NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_vote` (`review_id`,`user_id`),
  FOREIGN KEY (`review_id`) REFERENCES `reviews`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`user_id`)   REFERENCES `users`(`id`)   ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 20. ADVERTISEMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS `advertisements` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name`         VARCHAR(100) NOT NULL,
  `type`         ENUM('html','image','popup') NOT NULL DEFAULT 'html',
  `content`      TEXT         DEFAULT NULL,
  `image_url`    VARCHAR(500) DEFAULT NULL,
  `link_url`     VARCHAR(500) DEFAULT NULL,
  `position`     ENUM('top','bottom','left','right','popup') NOT NULL DEFAULT 'top',
  `pages`        VARCHAR(500) DEFAULT NULL,
  `popup_timer_sec` SMALLINT UNSIGNED DEFAULT 5,
  `is_active`    TINYINT(1)   NOT NULL DEFAULT 1,
  `impressions`  INT UNSIGNED NOT NULL DEFAULT 0,
  `clicks`       INT UNSIGNED NOT NULL DEFAULT 0,
  `sort_order`   SMALLINT     NOT NULL DEFAULT 0,
  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 21. THEME SETTINGS (key-value)
-- ============================================================
CREATE TABLE IF NOT EXISTS `theme_settings` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `key`         VARCHAR(100) NOT NULL UNIQUE,
  `value`       TEXT         DEFAULT NULL,
  `updated_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 22. QUEUE JOBS (async tasks)
-- ============================================================
CREATE TABLE IF NOT EXISTS `queue_jobs` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `job_type`     VARCHAR(100) NOT NULL,
  `payload`      JSON         DEFAULT NULL,
  `status`       ENUM('pending','processing','done','failed') NOT NULL DEFAULT 'pending',
  `attempts`     TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `max_attempts` TINYINT UNSIGNED NOT NULL DEFAULT 3,
  `error`        TEXT         DEFAULT NULL,
  `scheduled_at` DATETIME     DEFAULT NULL,
  `started_at`   DATETIME     DEFAULT NULL,
  `done_at`      DATETIME     DEFAULT NULL,
  `created_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_status`       (`status`),
  INDEX `idx_scheduled_at` (`scheduled_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 23. USER CLONED VOICES (ElevenLabs)
-- ============================================================
CREATE TABLE IF NOT EXISTS `user_cloned_voices` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`     INT UNSIGNED NOT NULL,
  `name`        VARCHAR(100) NOT NULL,
  `provider_id` VARCHAR(255) DEFAULT NULL,
  `is_active`   TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_user_id` (`user_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- SEED: Default theme settings
-- ============================================================
INSERT INTO `theme_settings` (`key`, `value`) VALUES
  ('site_name',         'AIStudio'),
  ('site_logo',         ''),
  ('site_favicon',      ''),
  ('site_description',  'The most powerful multi-tool AI platform'),
  ('theme_preset',      'deep_space'),
  ('theme_font',        'Inter'),
  ('theme_radius',      'soft'),
  ('theme_animation',   'neural_net'),
  ('theme_bg_image',    ''),
  ('primary_color',     '#a78bfa'),
  ('secondary_color',   '#38bdf8'),
  ('user_log_limit',    '10'),
  ('review_auto_approve','0'),
  ('review_min_stars',  '1'),
  ('watermark_enabled', '1'),
  ('watermark_text',    'AIStudio.ai'),
  ('watermark_position','bottom_right'),
  ('watermark_opacity', '70'),
  ('maintenance_mode',  '0'),
  ('pkr_rate',          '278'),
  ('smtp_host',         ''),
  ('smtp_port',         '587'),
  ('smtp_user',         ''),
  ('smtp_pass',         ''),
  ('smtp_from',         ''),
  ('jazzcash_merchant', ''),
  ('jazzcash_password', ''),
  ('jazzcash_integrity',''),
  ('easypaisa_account', ''),
  ('bank_account_name', ''),
  ('bank_account_no',   ''),
  ('bank_name',         '');

-- ============================================================
-- SEED: All 25 tools
-- ============================================================
INSERT INTO `tools` (`name`,`slug`,`icon`,`description`,`is_enabled`,`is_visible_on_landing`,`allow_publish`,`sort_order`) VALUES
  ('AI Chat Assistant',      'ai-chat',           'ti-message-circle',  'Multi-provider AI chat',           1,1,0, 1),
  ('AI Image Generator',     'ai-image',          'ti-photo',           'Generate stunning AI images',      1,1,1, 2),
  ('AI Video Generator',     'ai-video',          'ti-player-play',     'Generate AI videos',               1,1,1, 3),
  ('AI Voice Over',          'ai-voice',          'ti-microphone',      'Text-to-speech & voice cloning',   1,1,0, 4),
  ('AI Code Assistant',      'ai-code',           'ti-code',            'AI-powered coding help',           1,1,0, 5),
  ('AI Content Writer',      'ai-content',        'ti-pencil',          'Blog posts, articles, copy',       1,1,0, 6),
  ('AI SEO Optimizer',       'ai-seo',            'ti-search',          'SEO analysis and optimization',    1,1,0, 7),
  ('AI Website Builder',     'ai-website',        'ti-world',           'Generate website code with AI',    1,1,0, 8),
  ('AI App Builder',         'ai-app',            'ti-device-mobile',   'Generate app UI and logic',        1,1,0, 9),
  ('AI Funnel Builder',      'ai-funnel',         'ti-filter',          'Sales funnel creation',            1,1,0,10),
  ('AI Blogger',             'ai-blogger',        'ti-file-text',       'Full blog post generator',         1,1,0,11),
  ('AI Landing Page',        'ai-landing',        'ti-layout',          'High-converting landing pages',    1,1,0,12),
  ('AI Image Enhancer',      'ai-enhance',        'ti-wand',            'Upscale and enhance images',       1,1,0,13),
  ('AI Background Remover',  'ai-bgremove',       'ti-cut',             'Remove image backgrounds',         1,1,0,14),
  ('AI Logo Design',         'ai-logo',           'ti-shape',           'Generate professional logos',      1,1,0,15),
  ('AI Song Generator',      'ai-song',           'ti-music',           'Generate AI music and songs',      1,1,0,16),
  ('AI Human Model',         'ai-human',          'ti-user',            'Generate AI human models',         1,1,0,17),
  ('AI Video Editor',        'ai-videoeditor',    'ti-video',           'AI-powered video editing',         1,1,0,18),
  ('AI Subtitle Generator',  'ai-subtitles',      'ti-subtask',         'Auto subtitles and captions',      1,1,0,19),
  ('AI Video Summarizer',    'ai-videosummary',   'ti-file-description','Summarize any video',              1,1,0,20),
  ('Meta Tag Generator',     'ai-metatags',       'ti-tags',            'SEO meta tags generator',          1,1,0,21),
  ('Social Comment Generator','ai-socialcomment', 'ti-message-dots',    'AI social media comments',         1,1,0,22),
  ('AI Super Agent',         'ai-superagent',     'ti-robot',           'Autonomous AI task agent',         1,1,0,23),
  ('AI Social Media Post',   'ai-socialmedia',    'ti-share',           'Generate social media posts',      1,1,0,24),
  ('AI Email Writer',        'ai-email',          'ti-mail',            'Professional email generator',     1,1,0,25);

-- ============================================================
-- SEED: Video credit tiers
-- ============================================================
INSERT INTO `video_credit_tiers` (`duration_sec`,`credit_cost`,`label`,`sort_order`) VALUES
  (4,  5,  '4 seconds',  1),
  (8,  9,  '8 seconds',  2),
  (15, 16, '15 seconds', 3),
  (30, 30, '30 seconds', 4);

-- ============================================================
-- SEED: Default subscription plans
-- ============================================================
INSERT INTO `subscription_plans` (`name`,`slug`,`description`,`price_usd`,`duration_days`,`credits_included`,`is_active`,`is_featured`,`sort_order`) VALUES
  ('Starter', 'starter', 'Perfect to get started', 9.99,  30, 500,  1, 0, 1),
  ('Pro',     'pro',     'Most popular plan',       19.99, 30, 1200, 1, 1, 2),
  ('Business','business','For power users',         49.99, 30, 3500, 1, 0, 3);

SET foreign_key_checks = 1;
