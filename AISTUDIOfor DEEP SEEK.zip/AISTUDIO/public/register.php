<?php
define('ROOT', dirname(__DIR__));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';

Security::startSession();
Security::checkIpBan();

if (Auth::check()) {
    header('Location: dashboard.php');
    exit;
}

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();

    if (!Security::rateLimit('register', 3, 300)) {
        $error = 'Too many registrations. Please wait 5 minutes.';
    } else {
        // Validate passwords match
        if ($_POST['password'] !== $_POST['password_confirm']) {
            $error = 'Passwords do not match.';
        } else {
            $result = Auth::register([
                'name'     => $_POST['name']     ?? '',
                'email'    => $_POST['email']    ?? '',
                'password' => $_POST['password'] ?? '',
                'mobile'   => $_POST['mobile']   ?? '',
                'ref_code' => $_POST['ref_code'] ?? '',
            ]);

            if ($result['success']) {
                // Give 50 free credits on signup
                CreditEngine::add(
                    $result['user_id'], 50, 'admin_add',
                    'Welcome bonus credits', 'signup_bonus'
                );
                $success = 'Account created! You got 50 free credits. Please login.';
            } else {
                $error = $result['error'];
            }
        }
    }
}

$csrf    = Security::generateCsrfToken();
$refCode = $_GET['ref'] ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{
    background:#0d0d1a;color:#f1f1ff;
    font-family:'Inter',system-ui,sans-serif;
    min-height:100vh;display:flex;
    align-items:center;justify-content:center;
    padding:1rem;position:relative;overflow:hidden;
}
canvas{position:fixed;inset:0;z-index:0;opacity:0.35;pointer-events:none}
.wrap{position:relative;z-index:1;width:100%;max-width:440px}
.logo{text-align:center;margin-bottom:1.5rem}
.logo-icon{
    width:52px;height:52px;
    background:linear-gradient(135deg,#a78bfa,#38bdf8);
    border-radius:14px;display:inline-flex;
    align-items:center;justify-content:center;font-size:26px;margin-bottom:10px;
}
.logo h1{
    font-size:1.5rem;font-weight:600;
    background:linear-gradient(135deg,#a78bfa,#38bdf8);
    -webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.logo p{color:#9b9bc0;font-size:13px;margin-top:4px}
.card{
    background:rgba(255,255,255,0.04);
    backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);
    border:0.5px solid rgba(167,139,250,0.2);
    border-radius:20px;padding:1.75rem;
}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.form-group{margin-bottom:1rem}
.form-label{display:block;font-size:13px;font-weight:500;color:#9b9bc0;margin-bottom:5px}
.input-wrap{position:relative}
.input-wrap i.icon{
    position:absolute;left:11px;top:50%;transform:translateY(-50%);
    color:#6b6b90;font-size:16px;pointer-events:none;
}
.form-input{
    width:100%;background:rgba(255,255,255,0.05);
    border:0.5px solid rgba(167,139,250,0.2);border-radius:10px;
    color:#f1f1ff;font-family:'Inter',sans-serif;font-size:14px;
    padding:10px 14px 10px 36px;outline:none;
    transition:border-color .2s,box-shadow .2s;
}
.form-input.no-icon{padding-left:14px}
.form-input:focus{border-color:#a78bfa;box-shadow:0 0 0 3px rgba(167,139,250,.12)}
.form-input::placeholder{color:#6b6b90}
.eye-btn{
    position:absolute;right:11px;top:50%;transform:translateY(-50%);
    background:none;border:none;color:#6b6b90;cursor:pointer;font-size:16px;padding:0;
}
.eye-btn:hover{color:#a78bfa}
.strength-bar{
    height:3px;border-radius:2px;margin-top:6px;
    background:rgba(255,255,255,0.1);overflow:hidden;
}
.strength-fill{height:100%;border-radius:2px;transition:width .3s,background .3s;width:0}
.strength-label{font-size:11px;color:#6b6b90;margin-top:3px}
.btn-register{
    width:100%;padding:12px;
    background:linear-gradient(135deg,#a78bfa,#7c3aed);
    border:none;border-radius:10px;color:#fff;
    font-family:'Inter',sans-serif;font-size:15px;font-weight:500;
    cursor:pointer;transition:all .2s;
    display:flex;align-items:center;justify-content:center;gap:8px;
    margin-top:0.25rem;
}
.btn-register:hover{filter:brightness(1.1);transform:translateY(-1px)}
.btn-register:active{transform:scale(0.98)}
.btn-register:disabled{opacity:0.6;cursor:not-allowed;transform:none}
.bonus-badge{
    display:flex;align-items:center;gap:8px;
    background:rgba(34,197,94,0.08);border:0.5px solid rgba(34,197,94,0.25);
    border-radius:8px;padding:10px 14px;margin-bottom:1.25rem;
    font-size:13px;color:#86efac;
}
.login-link{text-align:center;font-size:13px;color:#9b9bc0;margin-top:1.25rem}
.login-link a{color:#a78bfa;text-decoration:none;font-weight:500}
.login-link a:hover{text-decoration:underline}
.alert{
    padding:10px 14px;border-radius:8px;font-size:13px;
    margin-bottom:1rem;display:flex;align-items:center;gap:8px;
}
.alert-error{background:rgba(239,68,68,.1);border:.5px solid #ef4444;color:#fca5a5}
.alert-success{background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.fade-in{animation:fadeIn .4s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
.loading-dots span{
    display:inline-block;width:5px;height:5px;border-radius:50%;
    background:#fff;margin:0 2px;animation:bounce .8s infinite;
}
.loading-dots span:nth-child(2){animation-delay:.15s}
.loading-dots span:nth-child(3){animation-delay:.3s}
@keyframes bounce{0%,80%,100%{transform:scale(0)}40%{transform:scale(1)}}
</style>
</head>
<body>
<canvas id="neuralCanvas"></canvas>

<div class="wrap fade-in">
    <div class="logo">
        <div class="logo-icon"><i class="ti ti-sparkles" style="color:#fff"></i></div>
        <h1><?= ThemeEngine::siteName() ?></h1>
        <p>Create your AI workspace account</p>
    </div>

    <div class="card">

        <div class="bonus-badge">
            <i class="ti ti-gift" style="font-size:18px"></i>
            <span>Sign up and get <strong>50 free credits</strong> — start generating instantly!</span>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-error">
            <i class="ti ti-alert-circle"></i>
            <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <?php if ($success): ?>
        <div class="alert alert-success">
            <i class="ti ti-check"></i>
            <?= htmlspecialchars($success) ?>
            <br><a href="login.php" style="color:#22c55e;font-weight:500">Go to Login →</a>
        </div>
        <?php endif; ?>

        <?php if (!$success): ?>
        <form method="POST" action="" id="regForm">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf) ?>">

            <div class="form-group">
                <label class="form-label" for="name">Full name</label>
                <div class="input-wrap">
                    <i class="ti ti-user icon"></i>
                    <input type="text" id="name" name="name" class="form-input"
                           placeholder="Your name"
                           value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"
                           required autocomplete="name" autofocus minlength="2" maxlength="100">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="email">Email address</label>
                <div class="input-wrap">
                    <i class="ti ti-mail icon"></i>
                    <input type="email" id="email" name="email" class="form-input"
                           placeholder="you@example.com"
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                           required autocomplete="email">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="mobile">Mobile number <span style="color:#6b6b90">(optional)</span></label>
                <div class="input-wrap">
                    <i class="ti ti-phone icon"></i>
                    <input type="tel" id="mobile" name="mobile" class="form-input"
                           placeholder="+92 3XX XXXXXXX"
                           value="<?= htmlspecialchars($_POST['mobile'] ?? '') ?>"
                           autocomplete="tel">
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <div class="input-wrap">
                    <i class="ti ti-lock icon"></i>
                    <input type="password" id="password" name="password" class="form-input"
                           placeholder="Min 8 characters"
                           required autocomplete="new-password"
                           minlength="8" oninput="checkStrength(this.value)">
                    <button type="button" class="eye-btn" onclick="togglePass('password','eye1')" aria-label="Show password">
                        <i class="ti ti-eye" id="eye1"></i>
                    </button>
                </div>
                <div class="strength-bar">
                    <div class="strength-fill" id="strengthFill"></div>
                </div>
                <div class="strength-label" id="strengthLabel"></div>
            </div>

            <div class="form-group">
                <label class="form-label" for="password_confirm">Confirm password</label>
                <div class="input-wrap">
                    <i class="ti ti-lock-check icon"></i>
                    <input type="password" id="password_confirm" name="password_confirm"
                           class="form-input" placeholder="Repeat password"
                           required autocomplete="new-password">
                    <button type="button" class="eye-btn" onclick="togglePass('password_confirm','eye2')" aria-label="Show password">
                        <i class="ti ti-eye" id="eye2"></i>
                    </button>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="ref_code">Referral code <span style="color:#6b6b90">(optional)</span></label>
                <div class="input-wrap">
                    <i class="ti ti-ticket icon"></i>
                    <input type="text" id="ref_code" name="ref_code" class="form-input"
                           placeholder="Enter referral code"
                           value="<?= htmlspecialchars($refCode ?: ($_POST['ref_code'] ?? '')) ?>"
                           maxlength="20" style="text-transform:uppercase">
                </div>
            </div>

            <button type="submit" class="btn-register" id="regBtn">
                <span id="btnText"><i class="ti ti-user-plus"></i> Create Account</span>
                <span id="btnLoad" style="display:none" class="loading-dots">
                    <span></span><span></span><span></span>
                </span>
            </button>
        </form>
        <?php endif; ?>

        <div class="login-link">
            Already have an account?
            <a href="login.php">Sign in</a>
        </div>
    </div>
</div>

<script>
function togglePass(id, iconId) {
    const inp = document.getElementById(id);
    const ico = document.getElementById(iconId);
    inp.type = inp.type === 'password' ? 'text' : 'password';
    ico.className = inp.type === 'text' ? 'ti ti-eye-off' : 'ti ti-eye';
}

function checkStrength(val) {
    const fill  = document.getElementById('strengthFill');
    const label = document.getElementById('strengthLabel');
    let score = 0;
    if (val.length >= 8)  score++;
    if (val.length >= 12) score++;
    if (/[A-Z]/.test(val)) score++;
    if (/[0-9]/.test(val)) score++;
    if (/[^A-Za-z0-9]/.test(val)) score++;
    const map = [
        {w:'0%',   c:'transparent', t:''},
        {w:'25%',  c:'#ef4444',     t:'Weak'},
        {w:'50%',  c:'#f59e0b',     t:'Fair'},
        {w:'75%',  c:'#38bdf8',     t:'Good'},
        {w:'100%', c:'#22c55e',     t:'Strong'},
    ];
    const s = map[Math.min(score, 4)];
    fill.style.width      = s.w;
    fill.style.background = s.c;
    label.textContent     = s.t;
    label.style.color     = s.c;
}

document.getElementById('regForm')?.addEventListener('submit', function(e) {
    const p1 = document.getElementById('password').value;
    const p2 = document.getElementById('password_confirm').value;
    if (p1 !== p2) {
        e.preventDefault();
        alert('Passwords do not match.');
        return;
    }
    document.getElementById('regBtn').disabled   = true;
    document.getElementById('btnText').style.display = 'none';
    document.getElementById('btnLoad').style.display = 'inline-flex';
});

/* Neural net */
(function(){
    const c = document.getElementById('neuralCanvas');
    const x = c.getContext('2d');
    let n = [];
    const resize=()=>{c.width=innerWidth;c.height=innerHeight};
    const init=()=>{n=[];for(let i=0;i<50;i++)n.push({x:Math.random()*c.width,y:Math.random()*c.height,vx:(Math.random()-.5)*.35,vy:(Math.random()-.5)*.35,r:Math.random()*1.8+.8})};
    const draw=()=>{
        x.clearRect(0,0,c.width,c.height);
        n.forEach((a,i)=>{
            a.x+=a.vx;a.y+=a.vy;
            if(a.x<0||a.x>c.width)a.vx*=-1;
            if(a.y<0||a.y>c.height)a.vy*=-1;
            n.slice(i+1).forEach(b=>{
                const d=Math.hypot(a.x-b.x,a.y-b.y);
                if(d<130){x.beginPath();x.strokeStyle='#a78bfa';x.globalAlpha=(1-d/130)*.22;x.lineWidth=.5;x.moveTo(a.x,a.y);x.lineTo(b.x,b.y);x.stroke()}
            });
            x.beginPath();x.globalAlpha=.55;x.fillStyle='#a78bfa';x.arc(a.x,a.y,a.r,0,Math.PI*2);x.fill();
        });
        requestAnimationFrame(draw);
    };
    window.addEventListener('resize',()=>{resize();init()});
    resize();init();
    if(!matchMedia('(prefers-reduced-motion:reduce)').matches)draw();
})();
</script>
</body>
</html>
