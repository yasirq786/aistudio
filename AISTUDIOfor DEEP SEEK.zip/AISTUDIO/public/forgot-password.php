<?php
define('ROOT', dirname(__DIR__));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();

if (Auth::check()) { header('Location: dashboard.php'); exit; }

$step    = $_SESSION['fp_step'] ?? 1;
$error   = '';
$success = '';
$csrf    = Security::generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();

    // Step 1 — send OTP
    if (isset($_POST['send_otp'])) {
        if (!Security::rateLimit('forgot', 3, 300)) {
            $error = 'Too many attempts. Wait 5 minutes.';
        } else {
            $email = strtolower(trim($_POST['email'] ?? ''));
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = 'Please enter a valid email.';
            } else {
                Auth::sendPasswordOtp($email);
                $_SESSION['fp_email'] = $email;
                $_SESSION['fp_step']  = 2;
                $step    = 2;
                $success = 'OTP sent to your email. Check inbox (and spam folder).';
            }
        }
    }

    // Step 2 — verify OTP
    elseif (isset($_POST['verify_otp'])) {
        $otp = trim($_POST['otp'] ?? '');
        $email = $_SESSION['fp_email'] ?? '';
        if (Auth::verifyOtp($email, $otp)) {
            $_SESSION['fp_otp']  = $otp;
            $_SESSION['fp_step'] = 3;
            $step = 3;
        } else {
            $error = 'Invalid or expired OTP. Try again.';
            $step  = 2;
        }
    }

    // Step 3 — reset password
    elseif (isset($_POST['reset_pass'])) {
        $email    = $_SESSION['fp_email'] ?? '';
        $otp      = $_SESSION['fp_otp']   ?? '';
        $newPass  = $_POST['new_password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        if ($newPass !== $confirm) {
            $error = 'Passwords do not match.';
            $step  = 3;
        } else {
            $result = Auth::resetPassword($email, $otp, $newPass);
            if ($result['success']) {
                unset($_SESSION['fp_step'], $_SESSION['fp_email'], $_SESSION['fp_otp']);
                $success = 'Password reset! You can now login.';
                $step    = 4; // done
            } else {
                $error = $result['error'];
                $step  = 3;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Forgot Password — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d0d1a;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;
     min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem}
.wrap{width:100%;max-width:400px}
.logo{text-align:center;margin-bottom:1.5rem}
.logo h1{font-size:1.4rem;font-weight:600;
          background:linear-gradient(135deg,#a78bfa,#38bdf8);
          -webkit-background-clip:text;-webkit-text-fill-color:transparent}
.logo p{color:#9b9bc0;font-size:13px;margin-top:4px}
.card{background:rgba(255,255,255,0.04);backdrop-filter:blur(20px);
      border:0.5px solid rgba(167,139,250,.2);border-radius:20px;padding:2rem}
.steps{display:flex;justify-content:center;gap:8px;margin-bottom:1.5rem}
.step-dot{width:8px;height:8px;border-radius:50%;background:rgba(167,139,250,.2);transition:background .3s}
.step-dot.done{background:#22c55e}
.step-dot.active{background:#a78bfa;width:24px;border-radius:4px}
.step-title{font-size:15px;font-weight:500;margin-bottom:4px}
.step-sub{font-size:13px;color:#9b9bc0;margin-bottom:1.25rem}
.form-label{display:block;font-size:13px;font-weight:500;color:#9b9bc0;margin-bottom:6px}
.input-wrap{position:relative;margin-bottom:1rem}
.input-wrap i{position:absolute;left:11px;top:50%;transform:translateY(-50%);color:#6b6b90;font-size:16px;pointer-events:none}
.form-input{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);
            border-radius:10px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:14px;
            padding:11px 14px 11px 36px;outline:none;transition:border-color .2s}
.form-input:focus{border-color:#a78bfa;box-shadow:0 0 0 3px rgba(167,139,250,.12)}
.form-input::placeholder{color:#6b6b90}
.otp-input{text-align:center;letter-spacing:10px;font-size:22px;font-weight:600;
           padding-left:14px!important}
.btn{width:100%;padding:12px;background:linear-gradient(135deg,#a78bfa,#7c3aed);
     border:none;border-radius:10px;color:#fff;font-family:'Inter',sans-serif;
     font-size:15px;font-weight:500;cursor:pointer;transition:all .2s;
     display:flex;align-items:center;justify-content:center;gap:8px}
.btn:hover{filter:brightness(1.1);transform:translateY(-1px)}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;
       margin-bottom:1rem;display:flex;align-items:center;gap:8px}
.alert-error{background:rgba(239,68,68,.1);border:.5px solid #ef4444;color:#fca5a5}
.alert-success{background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.back-link{text-align:center;margin-top:1.25rem;font-size:13px}
.back-link a{color:#a78bfa;text-decoration:none}
.back-link a:hover{text-decoration:underline}
.fade-in{animation:fadeIn .4s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
</style>
</head>
<body>
<div class="wrap fade-in">
    <div class="logo">
        <h1>&#9670; <?= ThemeEngine::siteName() ?></h1>
        <p>Password recovery</p>
    </div>
    <div class="card">
        <div class="steps">
            <div class="step-dot <?= $step >= 1 ? ($step > 1 ? 'done' : 'active') : '' ?>"></div>
            <div class="step-dot <?= $step >= 2 ? ($step > 2 ? 'done' : 'active') : '' ?>"></div>
            <div class="step-dot <?= $step >= 3 ? ($step > 3 ? 'done' : 'active') : '' ?>"></div>
        </div>

        <?php if ($error): ?>
        <div class="alert alert-error"><i class="ti ti-alert-circle"></i><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>
        <?php if ($success && $step != 4): ?>
        <div class="alert alert-success"><i class="ti ti-check"></i><?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <?php if ($step === 1): ?>
        <p class="step-title">Enter your email</p>
        <p class="step-sub">We'll send a 6-digit OTP to reset your password.</p>
        <form method="POST">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf) ?>">
            <label class="form-label">Email address</label>
            <div class="input-wrap">
                <i class="ti ti-mail"></i>
                <input type="email" name="email" class="form-input" placeholder="you@example.com" required autofocus>
            </div>
            <button type="submit" name="send_otp" class="btn"><i class="ti ti-send"></i>Send OTP</button>
        </form>

        <?php elseif ($step === 2): ?>
        <p class="step-title">Enter OTP</p>
        <p class="step-sub">Check your email <strong style="color:#a78bfa"><?= htmlspecialchars($_SESSION['fp_email'] ?? '') ?></strong> for the 6-digit code.</p>
        <form method="POST">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf) ?>">
            <label class="form-label">6-digit OTP</label>
            <div class="input-wrap">
                <i class="ti ti-key"></i>
                <input type="text" name="otp" class="form-input otp-input"
                       placeholder="000000" maxlength="6" pattern="[0-9]{6}"
                       required autofocus autocomplete="one-time-code">
            </div>
            <button type="submit" name="verify_otp" class="btn"><i class="ti ti-check"></i>Verify OTP</button>
        </form>

        <?php elseif ($step === 3): ?>
        <p class="step-title">New password</p>
        <p class="step-sub">Choose a strong new password.</p>
        <form method="POST">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf) ?>">
            <label class="form-label">New password</label>
            <div class="input-wrap">
                <i class="ti ti-lock"></i>
                <input type="password" name="new_password" class="form-input"
                       placeholder="Min 8 characters" required minlength="8" autofocus>
            </div>
            <label class="form-label">Confirm password</label>
            <div class="input-wrap">
                <i class="ti ti-lock-check"></i>
                <input type="password" name="confirm_password" class="form-input"
                       placeholder="Repeat password" required minlength="8">
            </div>
            <button type="submit" name="reset_pass" class="btn"><i class="ti ti-lock-open"></i>Reset Password</button>
        </form>

        <?php elseif ($step === 4): ?>
        <div style="text-align:center;padding:1rem 0">
            <i class="ti ti-circle-check" style="font-size:48px;color:#22c55e;display:block;margin-bottom:12px"></i>
            <p class="step-title" style="font-size:18px">Password Reset!</p>
            <p style="color:#9b9bc0;font-size:14px;margin-top:8px">You can now login with your new password.</p>
            <a href="login.php" style="display:inline-block;margin-top:1.25rem;padding:11px 28px;
               background:linear-gradient(135deg,#a78bfa,#7c3aed);border-radius:10px;color:#fff;
               text-decoration:none;font-weight:500;font-size:14px">
                <i class="ti ti-login"></i> Go to Login
            </a>
        </div>
        <?php endif; ?>

        <?php if ($step < 4): ?>
        <div class="back-link"><a href="login.php"><i class="ti ti-arrow-left"></i> Back to login</a></div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
