<?php
define('ROOT', dirname(__DIR__));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Auth::logout();
header('Location: /aistudio/public/login.php');
exit;
