<!DOCTYPE html>
<html lang="<?= h(Auth::user()['language'] ?? 'en') ?>" dir="<?= (Auth::user()['language'] ?? 'en') === 'ur' ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= h($pageTitle ?? '') ?> — <?= ThemeEngine::siteName() ?></title>
    <?= ThemeEngine::favicon() ?>
    <?= csrfMeta() ?>
    <meta name="description" content="<?= h(ThemeEngine::get('site_description')) ?>">

    <!-- Tabler Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">

    <!-- Theme CSS Variables (generated from DB) -->
    <?= ThemeEngine::cssVars() ?>

    <style>
        /* ── Layout ────────────────────────────────────── */
        .as-layout   { display:flex; min-height:100vh; }
        .as-main     { margin-left:64px; flex:1; display:flex; flex-direction:column; min-height:100vh; transition:margin-left .25s ease; }
        .as-topbar   { height:56px; display:flex; align-items:center; justify-content:space-between;
                        padding:0 1.5rem; border-bottom:.5px solid var(--as-border);
                        background:var(--as-bg-secondary); position:sticky; top:0; z-index:50; }
        .as-content  { flex:1; padding:1.5rem; }

        /* ── Sidebar ────────────────────────────────────── */
        .as-sidebar  { display:flex; flex-direction:column; padding:12px 0; }
        .as-sidebar-logo { padding:12px 14px 20px; overflow:hidden; white-space:nowrap; }
        .as-logo-text  { font-size:18px; font-weight:600; color:var(--as-primary);
                          background:linear-gradient(135deg,var(--as-primary),var(--as-secondary));
                          -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
        .as-tool-btn { display:flex; align-items:center; gap:12px; padding:10px 14px;
                        color:var(--as-text-secondary); text-decoration:none; white-space:nowrap;
                        transition:all .15s ease; font-size:13px; cursor:pointer; border:none;
                        background:transparent; width:100%; }
        .as-tool-btn i { font-size:20px; flex-shrink:0; min-width:20px; }
        .as-tool-btn:hover, .as-tool-btn.active {
            color:var(--as-primary); background:rgba(167,139,250,.08); }
        .as-tool-btn.active { border-left:2px solid var(--as-primary); }
        .as-tool-btn.disabled { opacity:.4; cursor:not-allowed; }
        .as-tool-label { opacity:0; transition:opacity .2s ease; font-size:13px; }
        .as-sidebar:hover .as-tool-label { opacity:1; }
        .as-sidebar-sep { height:.5px; background:var(--as-border); margin:8px 14px; }

        /* ── Topbar elements ─────────────────────────────── */
        .as-credit-pill { display:flex; align-items:center; gap:6px; padding:6px 14px;
                           background:var(--as-glass-bg); border:.5px solid var(--as-border);
                           border-radius:20px; font-size:13px; font-weight:500; color:var(--as-primary); }
        .as-avatar     { width:34px; height:34px; border-radius:50%; background:var(--as-primary);
                          display:flex; align-items:center; justify-content:center;
                          font-size:13px; font-weight:600; color:#000; cursor:pointer; overflow:hidden; }
        .as-avatar img { width:100%; height:100%; object-fit:cover; }
        .as-topbar-right { display:flex; align-items:center; gap:12px; }

        /* ── Neural net canvas ───────────────────────────── */
        #asNeuralCanvas { position:fixed;inset:0;z-index:0;pointer-events:none;opacity:.4; }
        .as-layout > *:not(#asNeuralCanvas) { position:relative; z-index:1; }

        /* ── Flash toast ─────────────────────────────────── */
        .as-flash { position:fixed; bottom:24px; right:24px; padding:12px 20px;
                     border-radius:var(--as-radius); font-size:14px; font-weight:500;
                     z-index:9999; animation:asfadeIn .3s ease; max-width:360px; }
        .as-flash-success { background:rgba(34,197,94,.15); border:.5px solid #22c55e; color:#22c55e; }
        .as-flash-error   { background:rgba(239,68,68,.15);  border:.5px solid #ef4444; color:#ef4444; }
        .as-flash-info    { background:rgba(56,189,248,.15); border:.5px solid #38bdf8; color:#38bdf8; }

        /* ── Loading overlay ─────────────────────────────── */
        .as-generating { display:flex; align-items:center; gap:10px; padding:16px;
                          background:var(--as-glass-bg); border:.5px solid var(--as-border);
                          border-radius:var(--as-radius); font-size:14px; color:var(--as-primary); }
        @keyframes spin { to { transform:rotate(360deg); } }
        .as-spinner { width:20px; height:20px; border:2px solid var(--as-border);
                       border-top-color:var(--as-primary); border-radius:50%;
                       animation:spin .8s linear infinite; }

        /* ── Mobile ──────────────────────────────────────── */
        @media (max-width:768px) {
            .as-sidebar { display:none; }
            .as-main    { margin-left:0; }
            .as-mobile-nav {
                position:fixed; bottom:0; left:0; right:0; height:60px;
                background:var(--as-bg-sidebar); border-top:.5px solid var(--as-border);
                display:flex; align-items:center; justify-content:space-around; z-index:100; }
            .as-content { padding:1rem; padding-bottom:80px; }
        }
        @media (min-width:769px) { .as-mobile-nav { display:none; } }
    </style>
</head>
<body>

<?php
$animation = ThemeEngine::get('theme_animation', 'neural_net');
if ($animation === 'neural_net'): ?>
<canvas id="asNeuralCanvas"></canvas>
<?php endif; ?>

<div class="as-layout">

    <!-- ── Sidebar ─────────────────────────────────────────── -->
    <nav class="as-sidebar" id="asSidebar" aria-label="Tools navigation">
        <div class="as-sidebar-logo">
            <?= ThemeEngine::logoHtml() ?>
        </div>

        <?php
        $tools = DB::query(
            "SELECT slug, name, icon, is_enabled FROM tools
             WHERE is_visible_on_landing = 1 ORDER BY sort_order ASC"
        );
        $currentSlug = $pageToolSlug ?? '';
        foreach ($tools as $tool):
            $active   = $tool['slug'] === $currentSlug ? ' active' : '';
            $disabled = !$tool['is_enabled'] ? ' disabled' : '';
            $href     = $tool['is_enabled'] ? '/tools/' . h($tool['slug']) : '#';
            $title    = $tool['is_enabled'] ? h($tool['name']) : h($tool['name']) . ' (unavailable)';
        ?>
        <a href="<?= $href ?>"
           class="as-tool-btn<?= $active . $disabled ?>"
           title="<?= $title ?>"
           <?= !$tool['is_enabled'] ? 'onclick="return false"' : '' ?>>
            <i class="ti <?= h($tool['icon']) ?>" aria-hidden="true"></i>
            <span class="as-tool-label"><?= h($tool['name']) ?></span>
        </a>
        <?php endforeach; ?>

        <div class="as-sidebar-sep"></div>

        <a href="/dashboard" class="as-tool-btn<?= isActivePage('/dashboard') ?>">
            <i class="ti ti-layout-dashboard" aria-hidden="true"></i>
            <span class="as-tool-label">Dashboard</span>
        </a>
        <a href="/profile" class="as-tool-btn<?= isActivePage('/profile') ?>">
            <i class="ti ti-user" aria-hidden="true"></i>
            <span class="as-tool-label">Profile</span>
        </a>
        <a href="/billing" class="as-tool-btn<?= isActivePage('/billing') ?>">
            <i class="ti ti-receipt" aria-hidden="true"></i>
            <span class="as-tool-label">Billing</span>
        </a>
        <a href="/logout" class="as-tool-btn" style="margin-top:auto">
            <i class="ti ti-logout" aria-hidden="true"></i>
            <span class="as-tool-label">Logout</span>
        </a>
    </nav>

    <!-- ── Main area ────────────────────────────────────────── -->
    <div class="as-main">

        <!-- Topbar -->
        <header class="as-topbar">
            <div style="display:flex;align-items:center;gap:12px">
                <span style="font-size:14px;color:var(--as-text-secondary)">
                    <?= h($pageTitle ?? 'Dashboard') ?>
                </span>
            </div>
            <div class="as-topbar-right">
                <!-- Credit balance -->
                <div class="as-credit-pill">
                    <i class="ti ti-coin" aria-hidden="true"></i>
                    <span id="creditBalance"><?= number_format(Auth::user()['credit_balance'] ?? 0) ?></span>
                    <span style="color:var(--as-text-secondary);font-size:11px">credits</span>
                </div>

                <!-- Notifications -->
                <button class="as-tool-btn" style="width:auto;padding:8px" aria-label="Notifications">
                    <i class="ti ti-bell" style="font-size:18px" aria-hidden="true"></i>
                </button>

                <!-- Language toggle -->
                <button class="as-tool-btn" style="width:auto;padding:8px;font-size:12px"
                        onclick="toggleLanguage()" aria-label="Switch language">
                    <?= (Auth::user()['language'] ?? 'en') === 'en' ? 'EN' : 'اردو' ?>
                </button>

                <!-- Avatar -->
                <div class="as-avatar" onclick="window.location='/profile'">
                    <?php $user = Auth::user(); ?>
                    <?php if (!empty($user['photo'])): ?>
                        <img src="<?= h($user['photo']) ?>" alt="profile photo">
                    <?php else: ?>
                        <?= strtoupper(substr($user['name'] ?? 'U', 0, 1)) ?>
                    <?php endif; ?>
                </div>
            </div>
        </header>

        <!-- Page content injected here -->
        <main class="as-content as-animate-in">
            <?= flashHtml() ?>
