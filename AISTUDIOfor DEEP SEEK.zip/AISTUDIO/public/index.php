<?php
/**
 * AIStudio — Main entry point
 * Redirects to landing page
 */
header('Location: /aistudio/public/landing.php');
exit;
