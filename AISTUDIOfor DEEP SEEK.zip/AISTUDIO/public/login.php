<?php
define('ROOT', dirname(__DIR__));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();

// Already logged in
if (Auth::check()) {
    header('Location: /aistudio/public/dashboard.php');
    exit;
}

$error   = '';
$success = '';

// Handle reason param
$reason = $_GET['reason'] ?? '';
if ($reason === 'banned')    $error = 'Your account has been banned.';
if ($reason === 'suspended') $error = 'Your account is suspended.';
if ($reason === 'session_invalid') $error = 'Session expired. Please login again.';

// POST — process login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();

    if (!Security::rateLimit('login', 5, 60)) {
        $error = 'Too many attempts. Please wait 1 minute.';
    } else {
        $email    = trim($_POST['email']    ?? '');
        $password = $_POST['password']      ?? '';
        $remember = isset($_POST['remember']);

        $result = Auth::login($email, $password, $remember);

        if ($result['success']) {
            $user = $result['user'];
            if (in_array($user['role'], ['admin', 'super_admin', 'moderator'])) {
                header('Location: /aistudio/public/admin/index.php');
            } else {
                header('Location: /aistudio/public/dashboard.php');
            }
            exit;
        } else {
            $error = $result['error'];
        }
    }
}

$csrf = Security::generateCsrfToken();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{
    background:#0d0d1a;
    color:#f1f1ff;
    font-family:'Inter',system-ui,sans-serif;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:1rem;
    position:relative;
    overflow:hidden;
}
canvas{position:fixed;inset:0;z-index:0;opacity:0.35;pointer-events:none}

.login-wrap{
    position:relative;z-index:1;
    width:100%;max-width:420px;
}
.login-logo{
    text-align:center;margin-bottom:2rem;
}
.login-logo .icon{
    width:56px;height:56px;
    background:linear-gradient(135deg,#a78bfa,#38bdf8);
    border-radius:16px;
    display:inline-flex;align-items:center;justify-content:center;
    font-size:28px;margin-bottom:12px;
}
.login-logo h1{
    font-size:1.6rem;font-weight:600;
    background:linear-gradient(135deg,#a78bfa,#38bdf8);
    -webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.login-logo p{color:#9b9bc0;font-size:13px;margin-top:4px}

.login-card{
    background:rgba(255,255,255,0.04);
    backdrop-filter:blur(20px);
    -webkit-backdrop-filter:blur(20px);
    border:0.5px solid rgba(167,139,250,0.2);
    border-radius:20px;
    padding:2rem;
}

.form-group{margin-bottom:1.1rem}
.form-label{
    display:block;font-size:13px;font-weight:500;
    color:#9b9bc0;margin-bottom:6px;
}
.input-wrap{position:relative}
.input-wrap i{
    position:absolute;left:12px;top:50%;transform:translateY(-50%);
    color:#6b6b90;font-size:17px;pointer-events:none;
}
.form-input{
    width:100%;
    background:rgba(255,255,255,0.05);
    border:0.5px solid rgba(167,139,250,0.2);
    border-radius:10px;
    color:#f1f1ff;
    font-family:'Inter',sans-serif;
    font-size:14px;
    padding:11px 14px 11px 38px;
    outline:none;
    transition:border-color .2s,box-shadow .2s;
}
.form-input:focus{
    border-color:#a78bfa;
    box-shadow:0 0 0 3px rgba(167,139,250,0.12);
}
.form-input::placeholder{color:#6b6b90}

.eye-btn{
    position:absolute;right:12px;top:50%;transform:translateY(-50%);
    background:none;border:none;color:#6b6b90;cursor:pointer;
    font-size:17px;padding:0;
}
.eye-btn:hover{color:#a78bfa}

.remember-row{
    display:flex;align-items:center;justify-content:space-between;
    margin-bottom:1.25rem;font-size:13px;
}
.checkbox-wrap{display:flex;align-items:center;gap:8px;cursor:pointer}
.checkbox-wrap input{
    width:16px;height:16px;accent-color:#a78bfa;cursor:pointer;
}
.checkbox-wrap span{color:#9b9bc0}
.forgot-link{color:#a78bfa;text-decoration:none;font-size:13px}
.forgot-link:hover{text-decoration:underline}

.btn-login{
    width:100%;padding:12px;
    background:linear-gradient(135deg,#a78bfa,#7c3aed);
    border:none;border-radius:10px;
    color:#fff;font-family:'Inter',sans-serif;
    font-size:15px;font-weight:500;
    cursor:pointer;transition:all .2s;
    display:flex;align-items:center;justify-content:center;gap:8px;
}
.btn-login:hover{filter:brightness(1.1);transform:translateY(-1px)}
.btn-login:active{transform:scale(0.98)}
.btn-login:disabled{opacity:0.6;cursor:not-allowed;transform:none}

.divider{
    text-align:center;color:#6b6b90;font-size:12px;
    margin:1.25rem 0;position:relative;
}
.divider::before,.divider::after{
    content:'';position:absolute;top:50%;width:42%;height:0.5px;
    background:rgba(167,139,250,0.15);
}
.divider::before{left:0}
.divider::after{right:0}

.register-link{
    text-align:center;font-size:13px;color:#9b9bc0;margin-top:1.25rem;
}
.register-link a{color:#a78bfa;text-decoration:none;font-weight:500}
.register-link a:hover{text-decoration:underline}

.alert{
    padding:10px 14px;border-radius:8px;
    font-size:13px;margin-bottom:1rem;
    display:flex;align-items:center;gap:8px;
}
.alert-error{background:rgba(239,68,68,0.1);border:0.5px solid #ef4444;color:#fca5a5}
.alert-success{background:rgba(34,197,94,0.1);border:0.5px solid #22c55e;color:#86efac}

.loading-dots span{
    display:inline-block;width:5px;height:5px;border-radius:50%;
    background:#fff;margin:0 2px;
    animation:bounce .8s infinite;
}
.loading-dots span:nth-child(2){animation-delay:.15s}
.loading-dots span:nth-child(3){animation-delay:.3s}
@keyframes bounce{0%,80%,100%{transform:scale(0)}40%{transform:scale(1)}}

.fade-in{animation:fadeIn .4s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}
</style>
</head>
<body>
<canvas id="neuralCanvas"></canvas>

<div class="login-wrap fade-in">
    <div class="login-logo">
        <div class="icon"><i class="ti ti-sparkles" style="color:#fff"></i></div>
        <h1><?= ThemeEngine::siteName() ?></h1>
        <p>Sign in to your AI workspace</p>
    </div>

    <div class="login-card">

        <?php if ($error): ?>
        <div class="alert alert-error">
            <i class="ti ti-alert-circle"></i>
            <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <?php if ($success): ?>
        <div class="alert alert-success">
            <i class="ti ti-check"></i>
            <?= htmlspecialchars($success) ?>
        </div>
        <?php endif; ?>

        <form method="POST" action="" id="loginForm">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf) ?>">

            <div class="form-group">
                <label class="form-label" for="email">Email address</label>
                <div class="input-wrap">
                    <i class="ti ti-mail"></i>
                    <input
                        type="email" id="email" name="email"
                        class="form-input"
                        placeholder="you@example.com"
                        value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                        required autocomplete="email" autofocus>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label" for="password">Password</label>
                <div class="input-wrap">
                    <i class="ti ti-lock"></i>
                    <input
                        type="password" id="password" name="password"
                        class="form-input"
                        placeholder="••••••••"
                        required autocomplete="current-password">
                    <button type="button" class="eye-btn" onclick="togglePass()" aria-label="Show password">
                        <i class="ti ti-eye" id="eyeIcon"></i>
                    </button>
                </div>
            </div>

            <div class="remember-row">
                <label class="checkbox-wrap">
                    <input type="checkbox" name="remember" value="1">
                    <span>Remember me</span>
                </label>
                <a href="forgot-password.php" class="forgot-link">Forgot password?</a>
            </div>

            <button type="submit" class="btn-login" id="loginBtn">
                <span id="btnText"><i class="ti ti-login"></i> Sign In</span>
                <span id="btnLoading" style="display:none" class="loading-dots">
                    <span></span><span></span><span></span>
                </span>
            </button>
        </form>

        <div class="divider">or</div>

        <div class="register-link">
            Don't have an account?
            <a href="register.php">Create one free</a>
        </div>
    </div>
</div>

<script>
/* Password toggle */
function togglePass() {
    const inp = document.getElementById('password');
    const ico = document.getElementById('eyeIcon');
    if (inp.type === 'password') {
        inp.type = 'text';
        ico.className = 'ti ti-eye-off';
    } else {
        inp.type = 'password';
        ico.className = 'ti ti-eye';
    }
}

/* Loading state on submit */
document.getElementById('loginForm').addEventListener('submit', function() {
    const btn  = document.getElementById('loginBtn');
    const text = document.getElementById('btnText');
    const load = document.getElementById('btnLoading');
    btn.disabled   = true;
    text.style.display = 'none';
    load.style.display = 'inline-flex';
});

/* Neural net background */
(function() {
    const canvas = document.getElementById('neuralCanvas');
    const ctx    = canvas.getContext('2d');
    let nodes    = [];
    const N      = 55;
    const DIST   = 130;

    function resize() {
        canvas.width  = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    function init() {
        nodes = [];
        for (let i = 0; i < N; i++) {
            nodes.push({
                x:  Math.random() * canvas.width,
                y:  Math.random() * canvas.height,
                vx: (Math.random() - .5) * .35,
                vy: (Math.random() - .5) * .35,
                r:  Math.random() * 1.8 + .8,
            });
        }
    }
    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        for (let i = 0; i < nodes.length; i++) {
            const n = nodes[i];
            n.x += n.vx; n.y += n.vy;
            if (n.x < 0 || n.x > canvas.width)  n.vx *= -1;
            if (n.y < 0 || n.y > canvas.height)  n.vy *= -1;
            for (let j = i+1; j < nodes.length; j++) {
                const m  = nodes[j];
                const dx = n.x - m.x, dy = n.y - m.y;
                const d  = Math.sqrt(dx*dx + dy*dy);
                if (d < DIST) {
                    ctx.beginPath();
                    ctx.strokeStyle = '#a78bfa';
                    ctx.globalAlpha = (1 - d/DIST) * 0.22;
                    ctx.lineWidth   = 0.5;
                    ctx.moveTo(n.x, n.y);
                    ctx.lineTo(m.x, m.y);
                    ctx.stroke();
                }
            }
            ctx.beginPath();
            ctx.globalAlpha = 0.55;
            ctx.fillStyle   = '#a78bfa';
            ctx.arc(n.x, n.y, n.r, 0, Math.PI*2);
            ctx.fill();
        }
        requestAnimationFrame(draw);
    }
    window.addEventListener('resize', () => { resize(); init(); });
    resize(); init();
    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) draw();
})();
</script>
</body>
</html>
