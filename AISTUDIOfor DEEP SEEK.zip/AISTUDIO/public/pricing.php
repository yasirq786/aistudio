<?php
define('ROOT', dirname(__DIR__));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();

$plans   = DB::query("SELECT * FROM subscription_plans WHERE is_active=1 ORDER BY sort_order ASC");
$pkrRate = (float)ThemeEngine::get('pkr_rate','278');
$isLoggedIn = Auth::check();
$user = $isLoggedIn ? Auth::user() : null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Pricing — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d0d1a;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh}
canvas{position:fixed;inset:0;z-index:0;opacity:.25;pointer-events:none}
.wrap{position:relative;z-index:1;max-width:1100px;margin:0 auto;padding:2rem 1.5rem}

/* Nav */
nav{display:flex;align-items:center;justify-content:space-between;padding:1rem 1.5rem;position:sticky;top:0;background:rgba(8,8,15,.85);backdrop-filter:blur(12px);border-bottom:.5px solid rgba(167,139,250,.1);z-index:50}
.nav-logo{font-size:18px;font-weight:700;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-decoration:none}
.nav-links{display:flex;align-items:center;gap:12px}
.nav-btn{padding:7px 18px;border-radius:8px;font-size:13px;font-weight:500;text-decoration:none;transition:all .2s}
.nav-btn-ghost{color:#9b9bc0;border:.5px solid rgba(167,139,250,.2)}
.nav-btn-ghost:hover{color:#a78bfa;border-color:#a78bfa}
.nav-btn-primary{background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff}
.nav-btn-primary:hover{filter:brightness(1.1)}

/* Hero */
.hero{text-align:center;padding:4rem 1rem 3rem}
.hero h1{font-size:clamp(2rem,5vw,3.2rem);font-weight:700;line-height:1.15;margin-bottom:1rem}
.hero h1 span{background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hero p{font-size:1.1rem;color:#9b9bc0;max-width:500px;margin:0 auto}

/* Plans grid */
.plans-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-bottom:3rem}
.plan-card{background:rgba(255,255,255,.04);border:.5px solid rgba(167,139,250,.15);border-radius:20px;padding:2rem;position:relative;transition:transform .2s,border-color .2s}
.plan-card:hover{transform:translateY(-4px);border-color:rgba(167,139,250,.3)}
.plan-card.featured{background:rgba(167,139,250,.08);border-color:#a78bfa;border-width:1.5px}
.popular-badge{position:absolute;top:-12px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff;font-size:11px;font-weight:600;padding:4px 16px;border-radius:20px;white-space:nowrap}
.plan-name{font-size:20px;font-weight:600;margin-bottom:8px}
.plan-price{font-size:40px;font-weight:700;color:#a78bfa;line-height:1;margin-bottom:4px}
.plan-price span{font-size:16px;color:#9b9bc0;font-weight:400}
.plan-pkr{font-size:13px;color:#6b6b90;margin-bottom:6px}
.plan-period{font-size:13px;color:#9b9bc0;margin-bottom:1.25rem}
.plan-credits{display:flex;align-items:center;gap:8px;background:rgba(56,189,248,.08);border:.5px solid rgba(56,189,248,.2);border-radius:8px;padding:10px 14px;margin-bottom:1.25rem;font-size:14px;font-weight:500;color:#38bdf8}
.plan-features{list-style:none;margin-bottom:1.5rem}
.plan-features li{display:flex;align-items:center;gap:8px;font-size:14px;color:#9b9bc0;padding:6px 0;border-top:.5px solid rgba(255,255,255,.05)}
.plan-features li:first-child{border-top:none}
.plan-features li i{color:#22c55e;font-size:15px;flex-shrink:0}
.btn-plan{width:100%;padding:13px;border-radius:11px;font-size:15px;font-weight:500;cursor:pointer;border:none;font-family:'Inter',sans-serif;transition:all .2s;text-align:center;display:block;text-decoration:none}
.btn-plan-primary{background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff}
.btn-plan-primary:hover{filter:brightness(1.1);transform:translateY(-1px)}
.btn-plan-ghost{background:transparent;border:.5px solid rgba(167,139,250,.3);color:#a78bfa}
.btn-plan-ghost:hover{background:rgba(167,139,250,.08);border-color:#a78bfa}

/* FAQ */
.faq{margin-bottom:3rem}
.faq h2{font-size:24px;font-weight:600;text-align:center;margin-bottom:1.5rem}
.faq-item{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:12px;margin-bottom:8px;overflow:hidden}
.faq-q{padding:14px 18px;cursor:pointer;display:flex;justify-content:space-between;align-items:center;font-size:14px;font-weight:500;user-select:none}
.faq-q:hover{background:rgba(167,139,250,.04)}
.faq-a{padding:0 18px;max-height:0;overflow:hidden;transition:max-height .3s ease,padding .3s;font-size:13px;color:#9b9bc0;line-height:1.7}
.faq-item.open .faq-a{max-height:200px;padding:0 18px 14px}
.faq-item.open .faq-icon{transform:rotate(45deg)}
.faq-icon{transition:transform .3s;color:#a78bfa}

@media(max-width:600px){.plans-grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<canvas id="nc"></canvas>

<nav>
    <a href="/aistudio/public/index.php" class="nav-logo">&#9670; <?= ThemeEngine::siteName() ?></a>
    <div class="nav-links">
        <?php if ($isLoggedIn): ?>
        <a href="/aistudio/public/dashboard.php" class="nav-btn nav-btn-ghost">Dashboard</a>
        <a href="/aistudio/public/billing.php"   class="nav-btn nav-btn-primary">My Billing</a>
        <?php else: ?>
        <a href="/aistudio/public/login.php"    class="nav-btn nav-btn-ghost">Login</a>
        <a href="/aistudio/public/register.php" class="nav-btn nav-btn-primary">Get Started</a>
        <?php endif; ?>
    </div>
</nav>

<div class="wrap">
    <div class="hero">
        <h1>Simple, transparent <span>pricing</span></h1>
        <p>Start free, upgrade when you need more. All plans include access to all AI tools.</p>
    </div>

    <?php if (empty($plans)): ?>
    <div style="text-align:center;padding:3rem;color:#6b6b90">
        <i class="ti ti-ticket" style="font-size:48px;display:block;margin-bottom:1rem;opacity:.3"></i>
        No plans available yet. Check back soon.
    </div>
    <?php else: ?>
    <div class="plans-grid">
        <!-- Free plan always shown -->
        <div class="plan-card">
            <div class="plan-name">Free</div>
            <div class="plan-price">$0<span>/forever</span></div>
            <div class="plan-pkr">Rs 0 PKR</div>
            <div class="plan-period">No credit card required</div>
            <div class="plan-credits"><i class="ti ti-coin"></i> 50 welcome credits</div>
            <ul class="plan-features">
                <li><i class="ti ti-check"></i> Access to all AI tools</li>
                <li><i class="ti ti-check"></i> 50 free credits on signup</li>
                <li><i class="ti ti-check"></i> Community gallery</li>
                <li><i class="ti ti-x" style="color:#6b6b90"></i> <span style="opacity:.5">Priority support</span></li>
                <li><i class="ti ti-x" style="color:#6b6b90"></i> <span style="opacity:.5">Watermark-free downloads</span></li>
            </ul>
            <?php if ($isLoggedIn): ?>
            <span class="btn-plan btn-plan-ghost" style="cursor:default;opacity:.6">Current plan</span>
            <?php else: ?>
            <a href="/aistudio/public/register.php" class="btn-plan btn-plan-ghost">Get started free</a>
            <?php endif; ?>
        </div>

        <?php foreach ($plans as $plan):
            $features = array_filter(array_map('trim', explode(',', $plan['features'] ?? '')));
        ?>
        <div class="plan-card <?= $plan['is_featured'] ? 'featured' : '' ?>">
            <?php if ($plan['is_featured']): ?>
            <div class="popular-badge">⭐ Most Popular</div>
            <?php endif; ?>

            <div class="plan-name"><?= h($plan['name']) ?></div>
            <div class="plan-price">$<?= number_format($plan['price_usd'], 0) ?><span>/<?= $plan['duration_days'] ?> days</span></div>
            <div class="plan-pkr">Rs <?= number_format($plan['price_usd'] * $pkrRate, 0) ?> PKR</div>
            <div class="plan-period"><?= $plan['duration_days'] ?>-day access</div>
            <div class="plan-credits">
                <i class="ti ti-coin"></i>
                <?= number_format($plan['credits_included']) ?> credits included
            </div>
            <ul class="plan-features">
                <li><i class="ti ti-check"></i> All AI tools access</li>
                <li><i class="ti ti-check"></i> Watermark-free downloads</li>
                <li><i class="ti ti-check"></i> Priority support</li>
                <?php foreach ($features as $f): ?>
                <li><i class="ti ti-check"></i> <?= h($f) ?></li>
                <?php endforeach; ?>
            </ul>

            <?php if ($isLoggedIn): ?>
            <a href="/aistudio/public/checkout.php?plan=<?= $plan['id'] ?>"
               class="btn-plan <?= $plan['is_featured'] ? 'btn-plan-primary' : 'btn-plan-ghost' ?>">
                <i class="ti ti-rocket"></i> Get <?= h($plan['name']) ?>
            </a>
            <?php else: ?>
            <a href="/aistudio/public/register.php"
               class="btn-plan <?= $plan['is_featured'] ? 'btn-plan-primary' : 'btn-plan-ghost' ?>">
                <i class="ti ti-user-plus"></i> Sign up & subscribe
            </a>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- FAQ -->
    <div class="faq">
        <h2>Frequently asked questions</h2>
        <?php
        $faqs = [
            ['What is a credit?', '1 credit = $0.02 USD. Credits are used each time you generate content. Different tools have different credit costs — AI Chat uses 1 credit per message, image generation uses 2-3 credits, etc.'],
            ['Do unused credits expire?', 'No — credits never expire. They stay in your account until you use them.'],
            ['Which payment methods are accepted?', 'We accept JazzCash, Easypaisa, Nayapay, and bank transfer with screenshot verification.'],
            ['Can I get watermark-free downloads?', 'Yes! All paid subscribers can download AI-generated images and videos without any watermark.'],
            ['What happens when my plan expires?', 'You keep your remaining credits. You just lose the subscriber benefits until you renew.'],
            ['Is there a refund policy?', 'We offer refunds within 48 hours of purchase if you have not used more than 50 credits. Contact support to request.'],
        ];
        foreach ($faqs as $faq): ?>
        <div class="faq-item">
            <div class="faq-q" onclick="this.closest('.faq-item').classList.toggle('open')">
                <?= h($faq[0]) ?>
                <i class="ti ti-plus faq-icon"></i>
            </div>
            <div class="faq-a"><?= h($faq[1]) ?></div>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
// Neural net bg
(function(){
    const c=document.getElementById('nc'),x=c.getContext('2d');
    let n=[];
    const r=()=>{c.width=innerWidth;c.height=innerHeight};
    const init=()=>{n=[];for(let i=0;i<45;i++)n.push({x:Math.random()*c.width,y:Math.random()*c.height,vx:(Math.random()-.5)*.3,vy:(Math.random()-.5)*.3,r:Math.random()*1.5+.5})};
    const draw=()=>{x.clearRect(0,0,c.width,c.height);n.forEach((a,i)=>{a.x+=a.vx;a.y+=a.vy;if(a.x<0||a.x>c.width)a.vx*=-1;if(a.y<0||a.y>c.height)a.vy*=-1;n.slice(i+1).forEach(b=>{const d=Math.hypot(a.x-b.x,a.y-b.y);if(d<120){x.beginPath();x.strokeStyle='#a78bfa';x.globalAlpha=(1-d/120)*.15;x.lineWidth=.5;x.moveTo(a.x,a.y);x.lineTo(b.x,b.y);x.stroke()}});x.beginPath();x.globalAlpha=.4;x.fillStyle='#a78bfa';x.arc(a.x,a.y,a.r,0,Math.PI*2);x.fill()});requestAnimationFrame(draw)};
    window.addEventListener('resize',()=>{r();init()});r();init();
    if(!matchMedia('(prefers-reduced-motion:reduce)').matches)draw();
})();
</script>
</body>
</html>
