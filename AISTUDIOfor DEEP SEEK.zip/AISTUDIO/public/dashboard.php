<?php
define('ROOT', dirname(__DIR__));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';
require_once ROOT . '/app/Core/ApiLogger.php';

Security::startSession();
Security::checkIpBan();
Auth::requireLogin('/aistudio/public/login.php');

$user     = Auth::user();
$logLimit = (int)(ThemeEngine::get('user_log_limit', '10'));
$logs     = ApiLogger::getUserLogs($user['id'], $logLimit);
$txns     = CreditEngine::history($user['id'], 5);
$tools    = DB::query("SELECT * FROM tools WHERE is_enabled=1 ORDER BY sort_order ASC LIMIT 25");

// Stats
$totalGenerated = DB::scalar(
    "SELECT COUNT(*) FROM user_activity_logs WHERE user_id=? AND status='success'",
    [$user['id']]
);
$thisMonthUsed = DB::scalar(
    "SELECT COALESCE(SUM(credits_used),0) FROM user_activity_logs
     WHERE user_id=? AND MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())",
    [$user['id']]
);

// Active subscription
$subscription = DB::queryOne(
    "SELECT us.*, sp.name as plan_name, sp.credits_included
     FROM user_subscriptions us
     JOIN subscription_plans sp ON sp.id = us.plan_id
     WHERE us.user_id=? AND us.status='active' AND us.expires_at > NOW()
     ORDER BY us.expires_at DESC LIMIT 1",
    [$user['id']]
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dashboard — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d0d1a;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh}
canvas{position:fixed;inset:0;z-index:0;opacity:0.25;pointer-events:none}

/* Layout */
.layout{display:flex;min-height:100vh;position:relative;z-index:1}

/* Sidebar */
.sidebar{
    width:64px;min-height:100vh;
    background:#08080f;
    border-right:0.5px solid rgba(167,139,250,0.1);
    display:flex;flex-direction:column;
    position:fixed;left:0;top:0;
    transition:width .25s ease;
    overflow:hidden;z-index:100;
}
.sidebar:hover{width:220px}
.sidebar-logo{
    padding:16px 14px 20px;
    font-size:17px;font-weight:600;white-space:nowrap;
    background:linear-gradient(135deg,#a78bfa,#38bdf8);
    -webkit-background-clip:text;-webkit-text-fill-color:transparent;
    overflow:hidden;
}
.tool-btn{
    display:flex;align-items:center;gap:12px;
    padding:10px 14px;color:#9b9bc0;
    text-decoration:none;white-space:nowrap;
    transition:all .15s;font-size:13px;
    border-left:2px solid transparent;
}
.tool-btn i{font-size:19px;flex-shrink:0;min-width:20px}
.tool-btn:hover{color:#a78bfa;background:rgba(167,139,250,.07);border-left-color:rgba(167,139,250,.3)}
.tool-btn.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.tool-btn.disabled{opacity:.35;cursor:not-allowed}
.tool-label{opacity:0;transition:opacity .2s;font-size:13px}
.sidebar:hover .tool-label{opacity:1}
.sep{height:.5px;background:rgba(167,139,250,.1);margin:6px 14px}

/* Main */
.main{margin-left:64px;flex:1;display:flex;flex-direction:column}
.topbar{
    height:54px;display:flex;align-items:center;
    justify-content:space-between;padding:0 1.5rem;
    border-bottom:.5px solid rgba(167,139,250,.1);
    background:rgba(8,8,15,.8);backdrop-filter:blur(10px);
    position:sticky;top:0;z-index:50;
}
.topbar-left{font-size:14px;color:#9b9bc0}
.topbar-right{display:flex;align-items:center;gap:10px}
.credit-pill{
    display:flex;align-items:center;gap:6px;
    padding:5px 14px;background:rgba(167,139,250,.1);
    border:.5px solid rgba(167,139,250,.25);
    border-radius:20px;font-size:13px;font-weight:500;color:#a78bfa;
}
.avatar{
    width:32px;height:32px;border-radius:50%;
    background:linear-gradient(135deg,#a78bfa,#7c3aed);
    display:flex;align-items:center;justify-content:center;
    font-size:13px;font-weight:600;color:#fff;cursor:pointer;overflow:hidden;
}
.avatar img{width:100%;height:100%;object-fit:cover}

.content{padding:1.5rem;flex:1}

/* Stats grid */
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:1.5rem}
.stat-card{
    background:rgba(255,255,255,.04);
    border:.5px solid rgba(167,139,250,.15);
    border-radius:14px;padding:1rem 1.25rem;
}
.stat-label{font-size:12px;color:#9b9bc0;margin-bottom:6px;display:flex;align-items:center;gap:6px}
.stat-val{font-size:22px;font-weight:600;color:#f1f1ff}
.stat-sub{font-size:11px;color:#6b6b90;margin-top:3px}

/* Tools quick access */
.section-title{
    font-size:13px;font-weight:500;color:#9b9bc0;
    margin-bottom:12px;display:flex;align-items:center;gap:6px;
}
.tools-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px;margin-bottom:1.5rem}
.tool-card{
    background:rgba(255,255,255,.04);
    border:.5px solid rgba(167,139,250,.12);
    border-radius:12px;padding:12px;
    text-decoration:none;color:#f1f1ff;
    transition:all .2s;display:flex;flex-direction:column;align-items:center;
    gap:8px;text-align:center;cursor:pointer;
}
.tool-card:hover{background:rgba(167,139,250,.08);border-color:rgba(167,139,250,.3);transform:translateY(-2px)}
.tool-card i{font-size:24px;color:#a78bfa}
.tool-card span{font-size:12px;font-weight:500;line-height:1.3}
.tool-card.disabled{opacity:.35;cursor:not-allowed}
.tool-card.disabled:hover{transform:none;background:rgba(255,255,255,.04)}

/* Logs table */
.logs-card{
    background:rgba(255,255,255,.04);
    border:.5px solid rgba(167,139,250,.12);
    border-radius:14px;overflow:hidden;margin-bottom:1.5rem;
}
.logs-header{
    padding:12px 16px;
    border-bottom:.5px solid rgba(167,139,250,.1);
    font-size:13px;font-weight:500;color:#9b9bc0;
    display:flex;align-items:center;gap:6px;
}
.log-row{
    display:grid;
    grid-template-columns:36px 1fr 90px 70px 80px;
    align-items:center;gap:12px;
    padding:10px 16px;
    border-top:.5px solid rgba(255,255,255,.04);
    font-size:12px;
}
.log-row:first-of-type{border-top:none}
.log-icon{
    width:32px;height:32px;border-radius:8px;
    background:rgba(167,139,250,.1);
    display:flex;align-items:center;justify-content:center;
    font-size:16px;color:#a78bfa;flex-shrink:0;
}
.log-tool{font-weight:500;color:#f1f1ff;font-size:13px}
.log-preview{color:#9b9bc0;font-size:11px;margin-top:2px;
             overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:200px}
.badge{display:inline-block;padding:2px 8px;border-radius:5px;font-size:11px;font-weight:500}
.badge-success{background:rgba(34,197,94,.12);color:#22c55e}
.badge-failed{background:rgba(239,68,68,.12);color:#ef4444}
.log-time{color:#6b6b90;font-size:11px;text-align:right}
.log-credits{color:#a78bfa;font-size:12px;font-weight:500;text-align:right}
.empty-state{padding:2rem;text-align:center;color:#6b6b90;font-size:13px}
.empty-state i{font-size:32px;display:block;margin-bottom:8px;opacity:.4}

/* Sub card */
.sub-card{
    background:rgba(167,139,250,.06);
    border:.5px solid rgba(167,139,250,.2);
    border-radius:12px;padding:1rem 1.25rem;
    display:flex;align-items:center;justify-content:space-between;
    flex-wrap:wrap;gap:10px;margin-bottom:1.5rem;
}
.sub-card .plan{font-size:14px;font-weight:500;color:#a78bfa}
.sub-card .exp{font-size:12px;color:#9b9bc0}
.btn-upgrade{
    padding:7px 16px;border-radius:8px;font-size:13px;font-weight:500;
    background:linear-gradient(135deg,#a78bfa,#7c3aed);
    color:#fff;text-decoration:none;border:none;cursor:pointer;transition:filter .2s;
}
.btn-upgrade:hover{filter:brightness(1.1)}

/* Mobile */
.mobile-nav{
    display:none;position:fixed;bottom:0;left:0;right:0;height:58px;
    background:#08080f;border-top:.5px solid rgba(167,139,250,.1);
    z-index:100;align-items:center;justify-content:space-around;
}
@media(max-width:768px){
    .sidebar{display:none}
    .main{margin-left:0}
    .mobile-nav{display:flex}
    .content{padding:1rem;padding-bottom:70px}
    .stats-grid{grid-template-columns:1fr 1fr}
    .log-row{grid-template-columns:32px 1fr 70px}
}
.m-nav-btn{
    display:flex;flex-direction:column;align-items:center;gap:2px;
    color:#9b9bc0;text-decoration:none;font-size:10px;
}
.m-nav-btn i{font-size:20px}
.m-nav-btn.active{color:#a78bfa}
.fade-in{animation:fadeIn .35s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
</style>
</head>
<body>
<canvas id="neuralCanvas"></canvas>

<div class="layout">

    <!-- Sidebar -->
    <nav class="sidebar" aria-label="Tools">
        <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?></div>

        <?php foreach ($tools as $t):
            $disabled = !$t['is_enabled'] ? ' disabled' : '';
            $href     = $t['is_enabled'] ? '/aistudio/public/tools/' . h($t['slug']) . '.php' : '#';
        ?>
        <a href="<?= $href ?>" class="tool-btn<?= $disabled ?>" title="<?= h($t['name']) ?>">
            <i class="ti <?= h($t['icon']) ?>" aria-hidden="true"></i>
            <span class="tool-label"><?= h($t['name']) ?></span>
        </a>
        <?php endforeach; ?>

        <div class="sep"></div>
        <a href="/aistudio/public/dashboard.php" class="tool-btn active">
            <i class="ti ti-layout-dashboard" aria-hidden="true"></i>
            <span class="tool-label">Dashboard</span>
        </a>
        <a href="/aistudio/public/profile.php" class="tool-btn">
            <i class="ti ti-user" aria-hidden="true"></i>
            <span class="tool-label">Profile</span>
        </a>
        <a href="/aistudio/public/billing.php" class="tool-btn">
            <i class="ti ti-receipt" aria-hidden="true"></i>
            <span class="tool-label">Billing</span>
        </a>
        <div class="sep"></div>
        <a href="/aistudio/public/logout.php" class="tool-btn" style="margin-top:auto">
            <i class="ti ti-logout" aria-hidden="true"></i>
            <span class="tool-label">Logout</span>
        </a>
    </nav>

    <!-- Main -->
    <div class="main">
        <header class="topbar">
            <span class="topbar-left">
                Welcome back, <strong style="color:#f1f1ff"><?= h($user['name']) ?></strong>
            </span>
            <div class="topbar-right">
                <div class="credit-pill">
                    <i class="ti ti-coin" aria-hidden="true"></i>
                    <span id="creditBal"><?= number_format($user['credit_balance']) ?></span>
                    <span style="color:#6b6b90;font-size:11px">credits</span>
                </div>
                <div class="avatar" onclick="location.href='/aistudio/public/profile.php'">
                    <?php if (!empty($user['photo'])): ?>
                        <img src="<?= h($user['photo']) ?>" alt="avatar">
                    <?php else: ?>
                        <?= strtoupper(substr($user['name'], 0, 1)) ?>
                    <?php endif; ?>
                </div>
            </div>
        </header>

        <div class="content fade-in">

            <!-- Subscription banner -->
            <?php if ($subscription): ?>
            <div class="sub-card">
                <div>
                    <div class="plan"><i class="ti ti-crown" style="font-size:15px"></i> <?= h($subscription['plan_name']) ?> Plan</div>
                    <div class="exp">Expires <?= date('M j, Y', strtotime($subscription['expires_at'])) ?></div>
                </div>
                <a href="/aistudio/public/billing.php" class="btn-upgrade">Manage Plan</a>
            </div>
            <?php else: ?>
            <div class="sub-card" style="background:rgba(245,158,11,.05);border-color:rgba(245,158,11,.2)">
                <div>
                    <div class="plan" style="color:#f59e0b"><i class="ti ti-star" style="font-size:15px"></i> Free Plan</div>
                    <div class="exp">Upgrade to get more credits and features</div>
                </div>
                <a href="/aistudio/public/pricing.php" class="btn-upgrade" style="background:linear-gradient(135deg,#f59e0b,#d97706)">Upgrade Now</a>
            </div>
            <?php endif; ?>

            <!-- Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-label"><i class="ti ti-coin" aria-hidden="true"></i> Credits</div>
                    <div class="stat-val"><?= number_format($user['credit_balance']) ?></div>
                    <div class="stat-sub">= <?= formatUsd(CreditEngine::creditsToUsd($user['credit_balance'])) ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label"><i class="ti ti-sparkles" aria-hidden="true"></i> Total generated</div>
                    <div class="stat-val"><?= number_format($totalGenerated) ?></div>
                    <div class="stat-sub">all time</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label"><i class="ti ti-calendar" aria-hidden="true"></i> This month</div>
                    <div class="stat-val"><?= number_format($thisMonthUsed) ?></div>
                    <div class="stat-sub">credits used</div>
                </div>
                <div class="stat-card">
                    <div class="stat-label"><i class="ti ti-users" aria-hidden="true"></i> Referrals</div>
                    <div class="stat-val"><?= (int)DB::scalar("SELECT COUNT(*) FROM users WHERE referred_by=?", [$user['id']]) ?></div>
                    <div class="stat-sub">Code: <strong style="color:#a78bfa"><?= h($user['referral_code']) ?></strong></div>
                </div>
            </div>

            <!-- Quick tool access -->
            <div class="section-title"><i class="ti ti-grid-dots" aria-hidden="true"></i> AI Tools</div>
            <div class="tools-grid">
                <?php foreach ($tools as $t):
                    $dis = !$t['is_enabled'] ? ' disabled' : '';
                    $href = $t['is_enabled'] ? '/aistudio/public/tools/' . h($t['slug']) . '.php' : '#';
                ?>
                <a href="<?= $href ?>" class="tool-card<?= $dis ?>" <?= !$t['is_enabled'] ? 'onclick="return false"' : '' ?>>
                    <i class="ti <?= h($t['icon']) ?>" aria-hidden="true"></i>
                    <span><?= h($t['name']) ?></span>
                </a>
                <?php endforeach; ?>
            </div>

            <!-- Recent activity logs -->
            <div class="section-title"><i class="ti ti-list" aria-hidden="true"></i> Recent activity</div>
            <div class="logs-card">
                <div class="logs-header"><i class="ti ti-history" aria-hidden="true"></i> Last <?= $logLimit ?> generations</div>
                <?php if (empty($logs)): ?>
                <div class="empty-state">
                    <i class="ti ti-sparkles"></i>
                    No activity yet — pick a tool above and start generating!
                </div>
                <?php else: ?>
                <?php foreach ($logs as $log): ?>
                <div class="log-row">
                    <div class="log-icon">
                        <i class="ti <?= h($log['tool_icon'] ?? 'ti-wand') ?>" aria-hidden="true"></i>
                    </div>
                    <div>
                        <div class="log-tool"><?= h($log['tool_name'] ?? 'Tool') ?></div>
                        <div class="log-preview"><?= h($log['input_preview'] ?? '') ?></div>
                    </div>
                    <span class="badge badge-<?= $log['status'] === 'success' ? 'success' : 'failed' ?>">
                        <?= $log['status'] ?>
                    </span>
                    <span class="log-credits">-<?= $log['credits_used'] ?> cr</span>
                    <span class="log-time"><?= timeAgo($log['created_at']) ?></span>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>

        </div><!-- end content -->
    </div><!-- end main -->
</div><!-- end layout -->

<!-- Mobile nav -->
<nav class="mobile-nav" aria-label="Mobile navigation">
    <a href="/aistudio/public/dashboard.php" class="m-nav-btn active"><i class="ti ti-home"></i>Home</a>
    <a href="/aistudio/public/tools/ai-chat.php" class="m-nav-btn"><i class="ti ti-message-circle"></i>Chat</a>
    <a href="/aistudio/public/tools/ai-image.php" class="m-nav-btn"><i class="ti ti-photo"></i>Image</a>
    <a href="/aistudio/public/billing.php" class="m-nav-btn"><i class="ti ti-coin"></i>Credits</a>
    <a href="/aistudio/public/profile.php" class="m-nav-btn"><i class="ti ti-user"></i>Profile</a>
</nav>

<script>
/* Neural net */
(function(){
    const c=document.getElementById('neuralCanvas'),x=c.getContext('2d');
    let n=[];
    const r=()=>{c.width=innerWidth;c.height=innerHeight};
    const init=()=>{n=[];for(let i=0;i<50;i++)n.push({x:Math.random()*c.width,y:Math.random()*c.height,vx:(Math.random()-.5)*.3,vy:(Math.random()-.5)*.3,r:Math.random()*1.5+.5})};
    const draw=()=>{
        x.clearRect(0,0,c.width,c.height);
        n.forEach((a,i)=>{
            a.x+=a.vx;a.y+=a.vy;
            if(a.x<0||a.x>c.width)a.vx*=-1;
            if(a.y<0||a.y>c.height)a.vy*=-1;
            n.slice(i+1).forEach(b=>{
                const d=Math.hypot(a.x-b.x,a.y-b.y);
                if(d<120){x.beginPath();x.strokeStyle='#a78bfa';x.globalAlpha=(1-d/120)*.18;x.lineWidth=.5;x.moveTo(a.x,a.y);x.lineTo(b.x,b.y);x.stroke()}
            });
            x.beginPath();x.globalAlpha=.5;x.fillStyle='#a78bfa';x.arc(a.x,a.y,a.r,0,Math.PI*2);x.fill();
        });
        requestAnimationFrame(draw);
    };
    window.addEventListener('resize',()=>{r();init()});
    r();init();
    if(!matchMedia('(prefers-reduced-motion:reduce)').matches)draw();
})();
</script>
</body>
</html>
