<?php
/**
 * AIStudio — Debug script
 * DELETE after use!
 */
define('ROOT', dirname(__DIR__));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';

echo '<style>body{background:#080810;color:#f1f1ff;font-family:monospace;padding:2rem}
.ok{color:#22c55e}.err{color:#ef4444}.warn{color:#f59e0b}
.box{background:#13132a;padding:1rem;border-radius:8px;margin:1rem 0;border:.5px solid rgba(167,139,250,.2)}
h2{color:#a78bfa;margin-bottom:.5rem}
</style>';

echo '<h1 style="color:#a78bfa">&#9670; AIStudio Debug</h1>';

// ── Check api_services table ───────────────────────────────────────
echo '<div class="box"><h2>API Services in Database</h2>';
$services = DB::query("SELECT id, name, provider, model, credit_cost, is_enabled,
    LEFT(api_key, 12) as key_preview,
    LENGTH(api_key) as key_length
    FROM api_services ORDER BY id DESC");

if (empty($services)) {
    echo '<p class="err">No API services found!</p>';
} else {
    foreach ($services as $s) {
        $keyStatus = $s['key_length'] > 0
            ? '<span class="ok">✓ Key present (' . $s['key_length'] . ' chars) — starts with: ' . htmlspecialchars($s['key_preview']) . '...</span>'
            : '<span class="err">✗ No key stored!</span>';

        echo "<p><strong>" . htmlspecialchars($s['name']) . "</strong> (ID:{$s['id']}) — 
              Provider: {$s['provider']} | Model: {$s['model']} | 
              Cost: {$s['credit_cost']}cr | Enabled: {$s['is_enabled']}<br>
              Key: {$keyStatus}</p><hr style='border-color:rgba(255,255,255,.05);margin:.5rem 0'>";
    }
}
echo '</div>';

// ── Test Groq API directly ─────────────────────────────────────────
$groqService = DB::queryOne(
    "SELECT * FROM api_services WHERE LOWER(provider) LIKE '%groq%' LIMIT 1"
);

if ($groqService && $groqService['api_key']) {
    echo '<div class="box"><h2>Testing Groq API Live</h2>';
    echo '<p>Key starts with: <code>' . htmlspecialchars(substr($groqService['api_key'], 0, 15)) . '...</code></p>';

    $payload = json_encode([
        'model'    => $groqService['model'] ?: 'llama3-8b-8192',
        'messages' => [
            ['role' => 'system',  'content' => 'You are helpful.'],
            ['role' => 'user',    'content' => 'Say hello in one word.'],
        ],
        'max_tokens' => 10,
    ]);

    $ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . trim($groqService['api_key']),
        ],
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);
    curl_close($ch);

    echo "<p>HTTP Status: <strong class='" . ($httpCode === 200 ? 'ok' : 'err') . "'>$httpCode</strong></p>";

    if ($curlErr) {
        echo "<p class='err'>cURL Error: $curlErr</p>";
    }

    $data = json_decode($response, true);
    if ($httpCode === 200 && isset($data['choices'][0]['message']['content'])) {
        echo "<p class='ok'>✓ API working! Response: <strong>" . htmlspecialchars($data['choices'][0]['message']['content']) . "</strong></p>";
    } else {
        echo "<p class='err'>✗ API Error:</p><pre>" . htmlspecialchars($response) . "</pre>";
    }
    echo '</div>';
} else {
    echo '<div class="box"><p class="warn">No Groq service found or no API key stored.</p></div>';
}

// ── cURL check ────────────────────────────────────────────────────
echo '<div class="box"><h2>PHP Extensions</h2>';
echo '<p>cURL: ' . (function_exists('curl_init') ? '<span class="ok">✓ enabled</span>' : '<span class="err">✗ disabled</span>') . '</p>';
echo '<p>JSON: ' . (function_exists('json_encode') ? '<span class="ok">✓ enabled</span>' : '<span class="err">✗ disabled</span>') . '</p>';
echo '<p>SSL: ' . (in_array('https', stream_get_wrappers()) ? '<span class="ok">✓ enabled</span>' : '<span class="warn">⚠ check php.ini</span>') . '</p>';
echo '</div>';

echo '<p class="warn" style="margin-top:1rem">⚠ DELETE this file after use: public/debug.php</p>';
?>
