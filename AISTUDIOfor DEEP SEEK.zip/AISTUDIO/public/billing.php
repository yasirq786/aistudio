<?php
define('ROOT', dirname(__DIR__));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';

Security::startSession();
Security::checkIpBan();
Auth::requireLogin('/aistudio/public/login.php');

$user = Auth::user();
$csrf = Security::generateCsrfToken();

// Active subscription
$subscription = DB::queryOne(
    "SELECT us.*, sp.name as plan_name, sp.price_usd, sp.credits_included, sp.features
     FROM user_subscriptions us
     JOIN subscription_plans sp ON sp.id = us.plan_id
     WHERE us.user_id=? AND us.status='active' AND us.expires_at > NOW()
     ORDER BY us.expires_at DESC LIMIT 1",
    [$user['id']]
);

// Payment history
$payments = DB::query(
    "SELECT p.*, sp.name as plan_name
     FROM payments p
     JOIN subscription_plans sp ON sp.id = p.plan_id
     WHERE p.user_id=?
     ORDER BY p.created_at DESC LIMIT 20",
    [$user['id']]
);

// Credit transactions
$page    = max(1,(int)($_GET['page'] ?? 1));
$perPage = 15;
$total   = (int)DB::scalar("SELECT COUNT(*) FROM credit_transactions WHERE user_id=?", [$user['id']]);
$txns    = DB::query(
    "SELECT ct.*, t.name as tool_name
     FROM credit_transactions ct
     LEFT JOIN tools t ON t.id = ct.tool_id
     WHERE ct.user_id=?
     ORDER BY ct.created_at DESC LIMIT ? OFFSET ?",
    [$user['id'], $perPage, ($page-1)*$perPage]
);

// Stats
$totalSpent  = (float)DB::scalar("SELECT COALESCE(SUM(amount_usd),0) FROM payments WHERE user_id=? AND status='verified'", [$user['id']]);
$totalUsed   = (int)DB::scalar("SELECT COALESCE(SUM(amount),0) FROM credit_transactions WHERE user_id=? AND type='debit'", [$user['id']]);
$totalEarned = (int)DB::scalar("SELECT COALESCE(SUM(amount),0) FROM credit_transactions WHERE user_id=? AND type='credit'", [$user['id']]);
$pkrRate     = (float)ThemeEngine::get('pkr_rate','278');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Billing — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d0d1a;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:64px;min-height:100vh;background:#08080f;border-right:.5px solid rgba(167,139,250,.1);display:flex;flex-direction:column;position:fixed;left:0;top:0;transition:width .25s;overflow:hidden;z-index:100}
.sidebar:hover{width:220px}
.sidebar-logo{padding:16px 14px 20px;font-size:17px;font-weight:600;white-space:nowrap;overflow:hidden;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.tool-btn{display:flex;align-items:center;gap:12px;padding:10px 14px;color:#9b9bc0;text-decoration:none;white-space:nowrap;transition:all .15s;font-size:13px;border-left:2px solid transparent}
.tool-btn i{font-size:19px;flex-shrink:0;min-width:20px}
.tool-btn:hover{color:#a78bfa;background:rgba(167,139,250,.07)}
.tool-btn.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.tool-label{opacity:0;transition:opacity .2s}
.sidebar:hover .tool-label{opacity:1}
.sep{height:.5px;background:rgba(167,139,250,.1);margin:6px 14px}
.main{margin-left:64px;flex:1;display:flex;flex-direction:column}
.topbar{height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.9);position:sticky;top:0;z-index:50}
.content{padding:1.5rem}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:1.5rem}
.stat{background:rgba(255,255,255,.04);border:.5px solid rgba(167,139,250,.12);border-radius:12px;padding:1rem 1.25rem}
.stat-label{font-size:11px;color:#6b6b90;margin-bottom:6px;display:flex;align-items:center;gap:5px}
.stat-val{font-size:20px;font-weight:600;color:#f1f1ff}
.stat-sub{font-size:11px;color:#9b9bc0;margin-top:3px}
.card{background:rgba(255,255,255,.04);border:.5px solid rgba(167,139,250,.12);border-radius:14px;overflow:hidden;margin-bottom:1.5rem}
.card-header{padding:12px 16px;border-bottom:.5px solid rgba(167,139,250,.1);font-size:13px;font-weight:500;display:flex;align-items:center;justify-content:space-between}
.card-header i{color:#a78bfa}
table{width:100%;border-collapse:collapse}
th{padding:8px 14px;text-align:left;font-size:11px;font-weight:500;color:#6b6b90;text-transform:uppercase;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(0,0,0,.15)}
td{padding:10px 14px;font-size:13px;color:#9b9bc0;border-top:.5px solid rgba(255,255,255,.04)}
tr:first-child td{border-top:none}
.badge{display:inline-block;padding:2px 8px;border-radius:5px;font-size:11px;font-weight:500}
.badge-success{background:rgba(34,197,94,.12);color:#22c55e}
.badge-danger{background:rgba(239,68,68,.12);color:#ef4444}
.badge-warning{background:rgba(245,158,11,.12);color:#f59e0b}
.badge-info{background:rgba(56,189,248,.12);color:#38bdf8}
.sub-card{background:rgba(167,139,250,.08);border:.5px solid rgba(167,139,250,.25);border-radius:14px;padding:1.25rem;margin-bottom:1.5rem;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}
.plan-name{font-size:18px;font-weight:600;color:#a78bfa}
.plan-exp{font-size:13px;color:#9b9bc0;margin-top:4px}
.btn-upgrade{padding:9px 20px;border-radius:9px;font-size:13px;font-weight:500;background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff;text-decoration:none;border:none;cursor:pointer;display:inline-flex;align-items:center;gap:6px;transition:filter .2s}
.btn-upgrade:hover{filter:brightness(1.1)}
.credit-pill{display:flex;align-items:center;gap:5px;padding:4px 12px;background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.2);border-radius:20px;font-size:12px;font-weight:500;color:#a78bfa}
.empty{padding:1.5rem;text-align:center;color:#6b6b90;font-size:13px}
.pages{display:flex;gap:6px;padding:12px 16px;justify-content:center}
.page-btn{padding:5px 11px;border-radius:6px;font-size:12px;text-decoration:none;color:#9b9bc0;border:.5px solid rgba(167,139,250,.15)}
.page-btn.active{background:rgba(167,139,250,.15);color:#a78bfa;border-color:#a78bfa}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?></div>
    <?php $tools = DB::query("SELECT slug,name,icon FROM tools WHERE is_visible_on_landing=1 AND is_enabled=1 ORDER BY sort_order LIMIT 25");
    foreach ($tools as $t): ?>
    <a href="/aistudio/public/tools/<?= h($t['slug']) ?>.php" class="tool-btn" title="<?= h($t['name']) ?>">
        <i class="ti <?= h($t['icon']) ?>"></i><span class="tool-label"><?= h($t['name']) ?></span>
    </a>
    <?php endforeach; ?>
    <div class="sep"></div>
    <a href="/aistudio/public/dashboard.php" class="tool-btn"><i class="ti ti-layout-dashboard"></i><span class="tool-label">Dashboard</span></a>
    <a href="/aistudio/public/profile.php"   class="tool-btn"><i class="ti ti-user"></i><span class="tool-label">Profile</span></a>
    <a href="/aistudio/public/billing.php"   class="tool-btn active"><i class="ti ti-receipt"></i><span class="tool-label">Billing</span></a>
    <a href="/aistudio/public/logout.php"    class="tool-btn" style="margin-top:auto"><i class="ti ti-logout"></i><span class="tool-label">Logout</span></a>
</nav>

<div class="main">
    <header class="topbar">
        <span style="font-size:14px;font-weight:500"><i class="ti ti-receipt" style="color:#a78bfa;vertical-align:-2px;margin-right:6px"></i>Billing</span>
        <div class="credit-pill"><i class="ti ti-coin"></i><?= number_format($user['credit_balance']) ?> credits</div>
    </header>

    <div class="content">

        <!-- Subscription -->
        <?php if ($subscription): ?>
        <div class="sub-card">
            <div>
                <div class="plan-name"><i class="ti ti-crown" style="font-size:17px"></i> <?= h($subscription['plan_name']) ?></div>
                <div class="plan-exp">Expires <?= date('M j, Y', strtotime($subscription['expires_at'])) ?> &nbsp;·&nbsp; <?= number_format($subscription['credits_included']) ?> credits/month</div>
                <?php if ($subscription['features']): ?>
                <div style="font-size:12px;color:#9b9bc0;margin-top:4px"><?= h($subscription['features']) ?></div>
                <?php endif; ?>
            </div>
            <a href="/aistudio/public/pricing.php" class="btn-upgrade"><i class="ti ti-arrow-up-circle"></i> Upgrade</a>
        </div>
        <?php else: ?>
        <div class="sub-card" style="background:rgba(245,158,11,.06);border-color:rgba(245,158,11,.2)">
            <div>
                <div class="plan-name" style="color:#f59e0b"><i class="ti ti-star"></i> Free Plan</div>
                <div class="plan-exp">Upgrade to unlock more credits and features</div>
            </div>
            <a href="/aistudio/public/pricing.php" class="btn-upgrade" style="background:linear-gradient(135deg,#f59e0b,#d97706)">
                <i class="ti ti-rocket"></i> Upgrade Now
            </a>
        </div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat">
                <div class="stat-label"><i class="ti ti-coin"></i> Balance</div>
                <div class="stat-val"><?= number_format($user['credit_balance']) ?></div>
                <div class="stat-sub">= <?= formatUsd(CreditEngine::creditsToUsd($user['credit_balance'])) ?></div>
            </div>
            <div class="stat">
                <div class="stat-label"><i class="ti ti-trending-down"></i> Credits used</div>
                <div class="stat-val"><?= number_format($totalUsed) ?></div>
                <div class="stat-sub">all time</div>
            </div>
            <div class="stat">
                <div class="stat-label"><i class="ti ti-trending-up"></i> Credits earned</div>
                <div class="stat-val"><?= number_format($totalEarned) ?></div>
                <div class="stat-sub">all time</div>
            </div>
            <div class="stat">
                <div class="stat-label"><i class="ti ti-cash"></i> Total spent</div>
                <div class="stat-val"><?= formatUsd($totalSpent) ?></div>
                <div class="stat-sub">Rs <?= number_format($totalSpent * $pkrRate, 0) ?> PKR</div>
            </div>
        </div>

        <!-- Payment history -->
        <div class="card">
            <div class="card-header">
                <span><i class="ti ti-credit-card"></i> Payment History</span>
                <a href="/aistudio/public/pricing.php" class="btn-upgrade" style="padding:5px 14px;font-size:12px">
                    <i class="ti ti-plus"></i> Buy Credits
                </a>
            </div>
            <table>
                <thead><tr><th>Plan</th><th>Amount</th><th>PKR</th><th>Method</th><th>Status</th><th>Date</th></tr></thead>
                <tbody>
                <?php if (empty($payments)): ?>
                <tr><td colspan="6" class="empty">No payments yet — <a href="/aistudio/public/pricing.php" style="color:#a78bfa">subscribe now</a></td></tr>
                <?php else: ?>
                <?php foreach ($payments as $p): ?>
                <tr>
                    <td style="color:#f1f1ff;font-weight:500"><?= h($p['plan_name']) ?></td>
                    <td style="color:#22c55e;font-weight:500"><?= formatUsd($p['amount_usd']) ?></td>
                    <td style="color:#9b9bc0">Rs <?= number_format($p['amount_pkr'] ?? ($p['amount_usd']*$pkrRate), 0) ?></td>
                    <td>
                        <span class="badge badge-info"><?= h(ucfirst(str_replace('_',' ',$p['gateway']))) ?></span>
                    </td>
                    <td>
                        <?php if ($p['status']==='verified'): ?>
                            <span class="badge badge-success">Verified</span>
                        <?php elseif ($p['status']==='pending'): ?>
                            <span class="badge badge-warning">Pending</span>
                        <?php else: ?>
                            <span class="badge badge-danger"><?= h($p['status']) ?></span>
                        <?php endif; ?>
                    </td>
                    <td><?= date('M j, Y', strtotime($p['created_at'])) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Credit transactions -->
        <div class="card">
            <div class="card-header">
                <span><i class="ti ti-list"></i> Credit Transactions</span>
                <span style="font-size:12px;color:#6b6b90"><?= number_format($total) ?> total</span>
            </div>
            <table>
                <thead><tr><th>Type</th><th>Amount</th><th>Balance after</th><th>Source</th><th>Note</th><th>Date</th></tr></thead>
                <tbody>
                <?php if (empty($txns)): ?>
                <tr><td colspan="6" class="empty">No transactions yet</td></tr>
                <?php else: ?>
                <?php foreach ($txns as $t): ?>
                <tr>
                    <td>
                        <?php if ($t['type']==='credit'): ?>
                            <span class="badge badge-success"><i class="ti ti-arrow-down"></i> Credit</span>
                        <?php else: ?>
                            <span class="badge badge-danger"><i class="ti ti-arrow-up"></i> Debit</span>
                        <?php endif; ?>
                    </td>
                    <td style="font-weight:500;color:<?= $t['type']==='credit' ? '#22c55e' : '#ef4444' ?>">
                        <?= $t['type']==='credit' ? '+' : '-' ?><?= number_format($t['amount']) ?>
                    </td>
                    <td style="color:#a78bfa"><?= number_format($t['balance_after']) ?></td>
                    <td><span class="badge badge-info"><?= h(str_replace('_',' ',$t['source'])) ?></span></td>
                    <td style="font-size:12px"><?= h($t['note'] ?: ($t['tool_name'] ?? '—')) ?></td>
                    <td style="font-size:12px"><?= timeAgo($t['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
            <?php if ($total > $perPage):
                $totalPages = ceil($total/$perPage);
                echo '<div class="pages">';
                for ($i=1; $i<=$totalPages; $i++):
                    $active = $i===$page ? ' active' : '';
                    echo "<a href='?page={$i}' class='page-btn{$active}'>{$i}</a>";
                endfor;
                echo '</div>';
            endif; ?>
        </div>
    </div>
</div>
</body>
</html>
