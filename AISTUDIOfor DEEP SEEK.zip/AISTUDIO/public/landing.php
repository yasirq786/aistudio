<?php
define('ROOT', dirname(__DIR__));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();

$siteName   = ThemeEngine::siteName();
$isLoggedIn = Auth::check();
$tools      = DB::query("SELECT * FROM tools WHERE is_enabled=1 AND is_visible_on_landing=1 ORDER BY sort_order ASC LIMIT 25");
$plans      = DB::query("SELECT * FROM subscription_plans WHERE is_active=1 ORDER BY sort_order ASC LIMIT 3");
$gallery    = DB::query("SELECT g.*, u.name as author FROM gallery g JOIN users u ON u.id=g.user_id WHERE g.is_active=1 AND g.removed_by_admin=0 ORDER BY g.published_at DESC LIMIT 8");
$reviews    = DB::query("SELECT r.*, u.name as user_name, u.photo as user_photo FROM reviews r JOIN users u ON u.id=r.user_id WHERE r.status='approved' ORDER BY r.is_pinned DESC, r.helpful_count DESC LIMIT 6");
$totalUsers = (int)DB::scalar("SELECT COUNT(*) FROM users");
$totalGens  = (int)DB::scalar("SELECT COUNT(*) FROM user_activity_logs WHERE status='success'");
$avgRating  = (float)DB::scalar("SELECT COALESCE(AVG(rating),5) FROM reviews WHERE status='approved'");
$pkrRate    = (float)ThemeEngine::get('pkr_rate','278');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= h($siteName) ?> — The Most Powerful AI Platform</title>
<meta name="description" content="<?= h(ThemeEngine::get('site_description','Generate AI images, videos, chat, voice and more')) ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<?= ThemeEngine::favicon() ?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
:root{
    --bg:#0d0d1a;--bg2:#13132a;--card:rgba(255,255,255,.04);
    --primary:#a78bfa;--secondary:#38bdf8;--accent:#f0abfc;
    --text:#f1f1ff;--muted:#9b9bc0;--border:rgba(167,139,250,.15);
}
html{scroll-behavior:smooth}
body{background:var(--bg);color:var(--text);font-family:'Inter',system-ui,sans-serif;min-height:100vh;overflow-x:hidden}
canvas{position:fixed;inset:0;z-index:0;opacity:.3;pointer-events:none}
.z1{position:relative;z-index:1}

/* Nav */
nav{display:flex;align-items:center;justify-content:space-between;padding:1rem 2rem;position:sticky;top:0;background:rgba(13,13,26,.85);backdrop-filter:blur(16px);border-bottom:.5px solid var(--border);z-index:100}
.nav-logo{font-size:20px;font-weight:800;background:linear-gradient(135deg,var(--primary),var(--secondary));-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-decoration:none;display:flex;align-items:center;gap:8px}
.nav-links{display:flex;align-items:center;gap:8px}
.nav-link{color:var(--muted);text-decoration:none;font-size:14px;padding:6px 12px;border-radius:8px;transition:color .2s}
.nav-link:hover{color:var(--text)}
.nav-btn{padding:8px 20px;border-radius:9px;font-size:14px;font-weight:500;text-decoration:none;transition:all .2s}
.nav-btn-ghost{color:var(--primary);border:.5px solid var(--border)}
.nav-btn-ghost:hover{background:rgba(167,139,250,.08)}
.nav-btn-primary{background:linear-gradient(135deg,var(--primary),#7c3aed);color:#fff}
.nav-btn-primary:hover{filter:brightness(1.1)}

/* Hero */
.hero{text-align:center;padding:6rem 1.5rem 4rem;max-width:900px;margin:0 auto}
.hero-badge{display:inline-flex;align-items:center;gap:6px;background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.25);border-radius:20px;padding:5px 14px;font-size:12px;font-weight:500;color:var(--primary);margin-bottom:1.5rem}
.hero h1{font-size:clamp(2.4rem,7vw,4.5rem);font-weight:800;line-height:1.1;margin-bottom:1.25rem;letter-spacing:-1px}
.hero h1 .grad{background:linear-gradient(135deg,var(--primary),var(--secondary),var(--accent));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hero-sub{font-size:1.1rem;color:var(--muted);max-width:560px;margin:0 auto 2.5rem;line-height:1.7}
.hero-btns{display:flex;gap:12px;justify-content:center;flex-wrap:wrap;margin-bottom:3rem}
.hero-btn-main{padding:14px 32px;border-radius:12px;font-size:16px;font-weight:600;background:linear-gradient(135deg,var(--primary),#7c3aed);color:#fff;text-decoration:none;transition:all .25s;display:inline-flex;align-items:center;gap:8px}
.hero-btn-main:hover{filter:brightness(1.1);transform:translateY(-2px);box-shadow:0 8px 24px rgba(167,139,250,.3)}
.hero-btn-ghost{padding:14px 32px;border-radius:12px;font-size:16px;font-weight:500;border:.5px solid var(--border);color:var(--text);text-decoration:none;transition:all .2s;display:inline-flex;align-items:center;gap:8px}
.hero-btn-ghost:hover{border-color:var(--primary);background:rgba(167,139,250,.06)}
.hero-stats{display:flex;gap:2rem;justify-content:center;flex-wrap:wrap}
.hero-stat{text-align:center}
.hero-stat-val{font-size:1.6rem;font-weight:700;color:var(--text)}
.hero-stat-val span{background:linear-gradient(135deg,var(--primary),var(--secondary));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hero-stat-label{font-size:12px;color:var(--muted);margin-top:2px}

/* Section */
.section{padding:4rem 1.5rem;max-width:1200px;margin:0 auto}
.section-tag{display:inline-block;background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.2);border-radius:6px;padding:3px 10px;font-size:11px;font-weight:600;color:var(--primary);text-transform:uppercase;letter-spacing:.08em;margin-bottom:.75rem}
.section-title{font-size:clamp(1.6rem,4vw,2.5rem);font-weight:700;margin-bottom:.75rem;line-height:1.2}
.section-sub{font-size:1rem;color:var(--muted);max-width:520px;margin-bottom:2.5rem;line-height:1.7}

/* Tools grid */
.tools-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px}
.tool-card{background:var(--card);border:.5px solid var(--border);border-radius:14px;padding:1.25rem 1rem;text-decoration:none;color:var(--text);transition:all .25s;display:flex;flex-direction:column;align-items:center;gap:10px;text-align:center}
.tool-card:hover{background:rgba(167,139,250,.08);border-color:rgba(167,139,250,.35);transform:translateY(-3px);box-shadow:0 8px 24px rgba(0,0,0,.3)}
.tool-icon{width:48px;height:48px;border-radius:14px;background:rgba(167,139,250,.12);display:flex;align-items:center;justify-content:center;font-size:24px;color:var(--primary);transition:all .25s}
.tool-card:hover .tool-icon{background:rgba(167,139,250,.2);transform:scale(1.1)}
.tool-name{font-size:13px;font-weight:500;line-height:1.3}

/* Gallery */
.gallery-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px}
.gallery-card{border-radius:14px;overflow:hidden;position:relative;background:var(--card);border:.5px solid var(--border);aspect-ratio:1;cursor:pointer}
.gallery-card img{width:100%;height:100%;object-fit:cover;transition:transform .3s}
.gallery-card:hover img{transform:scale(1.05)}
.gallery-card-overlay{position:absolute;inset:0;background:linear-gradient(to top,rgba(0,0,0,.7) 0%,transparent 50%);opacity:0;transition:opacity .3s;display:flex;align-items:flex-end;padding:12px}
.gallery-card:hover .gallery-card-overlay{opacity:1}
.gallery-author{font-size:12px;color:#fff;font-weight:500}
.gallery-empty{text-align:center;padding:3rem;color:var(--muted);background:var(--card);border:.5px solid var(--border);border-radius:14px}
.gallery-empty i{font-size:48px;display:block;margin-bottom:1rem;opacity:.3}

/* Reviews */
.reviews-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px}
.review-card{background:var(--card);border:.5px solid var(--border);border-radius:14px;padding:1.25rem}
.review-header{display:flex;align-items:center;gap:10px;margin-bottom:.75rem}
.review-avatar{width:36px;height:36px;border-radius:50%;background:linear-gradient(135deg,var(--primary),#7c3aed);display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:600;color:#fff;flex-shrink:0;overflow:hidden}
.review-avatar img{width:100%;height:100%;object-fit:cover}
.review-name{font-size:14px;font-weight:500}
.review-stars{color:#f59e0b;font-size:13px;margin-top:2px}
.review-text{font-size:13px;color:var(--muted);line-height:1.7}
.review-avg{display:flex;align-items:center;gap:12px;margin-bottom:1.5rem;flex-wrap:wrap}
.review-avg-val{font-size:48px;font-weight:800;color:var(--primary);line-height:1}
.review-avg-stars{color:#f59e0b;font-size:20px}
.review-avg-count{font-size:13px;color:var(--muted)}

/* Pricing */
.pricing-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}
.price-card{background:var(--card);border:.5px solid var(--border);border-radius:20px;padding:2rem;position:relative;transition:all .2s}
.price-card.featured{border-color:var(--primary);border-width:1.5px;background:rgba(167,139,250,.06)}
.price-card:hover{transform:translateY(-4px)}
.popular-tag{position:absolute;top:-12px;left:50%;transform:translateX(-50%);background:linear-gradient(135deg,var(--primary),#7c3aed);color:#fff;font-size:11px;font-weight:600;padding:4px 16px;border-radius:20px;white-space:nowrap}
.plan-name{font-size:18px;font-weight:600;margin-bottom:.5rem}
.plan-price{font-size:38px;font-weight:800;color:var(--primary);line-height:1;margin-bottom:4px}
.plan-price-sub{font-size:13px;color:var(--muted);margin-bottom:1rem}
.plan-credits-badge{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:500;color:var(--secondary);background:rgba(56,189,248,.08);border:.5px solid rgba(56,189,248,.2);border-radius:8px;padding:8px 12px;margin-bottom:1.25rem}
.plan-btn{display:block;text-align:center;padding:12px;border-radius:10px;font-size:14px;font-weight:500;text-decoration:none;transition:all .2s;margin-top:1.25rem}
.plan-btn-primary{background:linear-gradient(135deg,var(--primary),#7c3aed);color:#fff}
.plan-btn-primary:hover{filter:brightness(1.1)}
.plan-btn-ghost{border:.5px solid var(--border);color:var(--primary)}
.plan-btn-ghost:hover{background:rgba(167,139,250,.08);border-color:var(--primary)}
.plan-features-list{list-style:none}
.plan-features-list li{display:flex;align-items:center;gap:7px;font-size:13px;color:var(--muted);padding:5px 0;border-top:.5px solid rgba(255,255,255,.05)}
.plan-features-list li:first-child{border-top:none}
.plan-features-list li i{color:#22c55e;font-size:14px;flex-shrink:0}

/* CTA */
.cta{text-align:center;padding:5rem 1.5rem;background:linear-gradient(135deg,rgba(167,139,250,.08),rgba(56,189,248,.06));border-top:.5px solid var(--border);border-bottom:.5px solid var(--border)}

/* Footer */
footer{padding:2rem 1.5rem;text-align:center;color:var(--muted);font-size:13px;border-top:.5px solid var(--border)}

/* Divider */
.divider{height:.5px;background:var(--border);max-width:1200px;margin:0 auto}

@media(max-width:768px){
    .nav-links{gap:4px}
    .nav-link{display:none}
    .tools-grid{grid-template-columns:repeat(auto-fill,minmax(130px,1fr))}
    .pricing-grid{grid-template-columns:1fr}
    .hero{padding:4rem 1rem 3rem}
    nav{padding:.75rem 1rem}
}
</style>
</head>
<body>
<canvas id="nc"></canvas>

<!-- Nav -->
<nav class="z1">
    <a href="/" class="nav-logo">&#9670; <?= h($siteName) ?></a>
    <div class="nav-links">
        <a href="#tools"   class="nav-link">Tools</a>
        <a href="#pricing" class="nav-link">Pricing</a>
        <a href="#gallery" class="nav-link">Gallery</a>
        <?php if ($isLoggedIn): ?>
        <a href="/aistudio/public/dashboard.php" class="nav-btn nav-btn-ghost">Dashboard</a>
        <?php else: ?>
        <a href="/aistudio/public/login.php"    class="nav-btn nav-btn-ghost">Login</a>
        <a href="/aistudio/public/register.php" class="nav-btn nav-btn-primary">Get Started Free</a>
        <?php endif; ?>
    </div>
</nav>

<!-- Hero -->
<div class="z1">
<div class="hero">
    <div class="hero-badge"><i class="ti ti-sparkles"></i> 25 AI Tools in One Platform</div>
    <h1>Create anything with<br><span class="grad">AI superpowers</span></h1>
    <p class="hero-sub">Generate images, videos, voice, code, content and more — powered by the world's best AI APIs. Start free, upgrade when you need more.</p>
    <div class="hero-btns">
        <?php if ($isLoggedIn): ?>
        <a href="/aistudio/public/dashboard.php" class="hero-btn-main"><i class="ti ti-layout-dashboard"></i> Go to Dashboard</a>
        <?php else: ?>
        <a href="/aistudio/public/register.php" class="hero-btn-main"><i class="ti ti-rocket"></i> Start for Free</a>
        <a href="#tools" class="hero-btn-ghost"><i class="ti ti-eye"></i> Explore tools</a>
        <?php endif; ?>
    </div>
    <div class="hero-stats">
        <div class="hero-stat"><div class="hero-stat-val"><span><?= number_format($totalUsers) ?>+</span></div><div class="hero-stat-label">Users</div></div>
        <div class="hero-stat"><div class="hero-stat-val"><span><?= number_format($totalGens) ?>+</span></div><div class="hero-stat-label">Generations</div></div>
        <div class="hero-stat"><div class="hero-stat-val"><span><?= number_format($avgRating,1) ?>★</span></div><div class="hero-stat-label">Average rating</div></div>
        <div class="hero-stat"><div class="hero-stat-val"><span>25+</span></div><div class="hero-stat-label">AI tools</div></div>
    </div>
</div>

<!-- Tools -->
<div class="divider"></div>
<section id="tools" class="section">
    <div class="section-tag">AI Tools</div>
    <h2 class="section-title">Everything you need to create</h2>
    <p class="section-sub">One platform, 25 powerful AI tools. Switch between them instantly with a single click.</p>
    <div class="tools-grid">
        <?php foreach ($tools as $t):
            $href = $isLoggedIn
                ? '/aistudio/public/tools/'.h($t['slug']).'.php'
                : '/aistudio/public/register.php';
        ?>
        <a href="<?= $href ?>" class="tool-card">
            <div class="tool-icon"><i class="ti <?= h($t['icon']) ?>"></i></div>
            <div class="tool-name"><?= h($t['name']) ?></div>
        </a>
        <?php endforeach; ?>
    </div>
</section>

<!-- Gallery -->
<div class="divider"></div>
<section id="gallery" class="section">
    <div class="section-tag">Community Gallery</div>
    <h2 class="section-title">Created by our community</h2>
    <p class="section-sub">See what others are creating. Publish your own AI generations to inspire the world.</p>
    <?php if (empty($gallery)): ?>
    <div class="gallery-empty">
        <i class="ti ti-photo"></i>
        <p>No gallery posts yet — be the first to publish!</p>
        <a href="/aistudio/public/register.php" style="display:inline-block;margin-top:1rem;padding:10px 24px;background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff;border-radius:9px;text-decoration:none;font-size:14px">Start creating →</a>
    </div>
    <?php else: ?>
    <div class="gallery-grid">
        <?php foreach ($gallery as $item): ?>
        <div class="gallery-card">
            <?php if ($item['type']==='image'): ?>
            <img src="<?= h($item['media_url']) ?>" alt="<?= h($item['title'] ?? 'AI Generated') ?>" loading="lazy">
            <?php elseif ($item['type']==='video'): ?>
            <video src="<?= h($item['media_url']) ?>" muted autoplay loop playsinline style="width:100%;height:100%;object-fit:cover"></video>
            <?php endif; ?>
            <div class="gallery-card-overlay">
                <div>
                    <div class="gallery-author">by <?= h($item['author']) ?></div>
                    <?php if ($item['title']): ?><div style="font-size:11px;color:rgba(255,255,255,.7)"><?= h(substr($item['title'],0,40)) ?></div><?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</section>

<!-- Reviews -->
<?php if (!empty($reviews)): ?>
<div class="divider"></div>
<section id="reviews" class="section">
    <div class="section-tag">Reviews</div>
    <h2 class="section-title">What users say</h2>
    <div class="review-avg">
        <div class="review-avg-val"><?= number_format($avgRating,1) ?></div>
        <div>
            <div class="review-avg-stars"><?= str_repeat('★', round($avgRating)) ?><?= str_repeat('☆', 5-round($avgRating)) ?></div>
            <div class="review-avg-count"><?= (int)DB::scalar("SELECT COUNT(*) FROM reviews WHERE status='approved'") ?> reviews</div>
        </div>
    </div>
    <div class="reviews-grid">
        <?php foreach ($reviews as $r): ?>
        <div class="review-card">
            <div class="review-header">
                <div class="review-avatar">
                    <?php if ($r['user_photo']): ?><img src="<?= h($r['user_photo']) ?>" alt=""><?php
                    else: echo strtoupper(substr($r['user_name'],0,1)); endif; ?>
                </div>
                <div>
                    <div class="review-name"><?= h($r['user_name']) ?></div>
                    <div class="review-stars"><?= str_repeat('★',$r['rating']) ?><?= str_repeat('☆',5-$r['rating']) ?></div>
                </div>
            </div>
            <?php if ($r['title']): ?><div style="font-size:14px;font-weight:500;margin-bottom:6px"><?= h($r['title']) ?></div><?php endif; ?>
            <div class="review-text"><?= h($r['body']) ?></div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php if ($isLoggedIn): ?>
    <div style="text-align:center;margin-top:1.5rem">
        <a href="#write-review" onclick="document.getElementById('reviewForm').style.display='block';this.style.display='none'"
           style="color:var(--primary);font-size:14px;text-decoration:none;border:.5px solid var(--border);padding:8px 20px;border-radius:8px">
            <i class="ti ti-pencil"></i> Write a review
        </a>
        <div id="reviewForm" style="display:none;max-width:500px;margin:1rem auto;background:var(--card);border:.5px solid var(--border);border-radius:14px;padding:1.5rem;text-align:left">
            <h3 style="font-size:15px;font-weight:500;margin-bottom:1rem">Write your review</h3>
            <form method="POST" action="/aistudio/public/api/submit-review.php">
                <input type="hidden" name="_csrf" value="<?= Security::generateCsrfToken() ?>">
                <div style="margin-bottom:12px">
                    <div style="font-size:12px;color:var(--muted);margin-bottom:6px">Rating</div>
                    <div style="display:flex;gap:6px;font-size:24px">
                        <?php for($i=1;$i<=5;$i++): ?>
                        <label style="cursor:pointer;color:#f59e0b">
                            <input type="radio" name="rating" value="<?= $i ?>" style="display:none" <?= $i===5?'checked':'' ?>>
                            ★
                        </label>
                        <?php endfor; ?>
                    </div>
                </div>
                <div style="margin-bottom:12px">
                    <input type="text" name="title" placeholder="Review title (optional)" maxlength="60"
                           style="width:100%;background:rgba(255,255,255,.05);border:.5px solid var(--border);border-radius:8px;color:var(--text);font-family:'Inter',sans-serif;font-size:13px;padding:9px 12px;outline:none">
                </div>
                <div style="margin-bottom:12px">
                    <textarea name="body" placeholder="Share your experience..." maxlength="500" required rows="4"
                              style="width:100%;background:rgba(255,255,255,.05);border:.5px solid var(--border);border-radius:8px;color:var(--text);font-family:'Inter',sans-serif;font-size:13px;padding:9px 12px;outline:none;resize:vertical"></textarea>
                </div>
                <button type="submit" style="padding:9px 20px;background:linear-gradient(135deg,#a78bfa,#7c3aed);border:none;border-radius:8px;color:#fff;font-family:'Inter',sans-serif;font-size:14px;font-weight:500;cursor:pointer">
                    Submit review
                </button>
            </form>
        </div>
    </div>
    <?php endif; ?>
</section>
<?php endif; ?>

<!-- Pricing -->
<div class="divider"></div>
<section id="pricing" class="section">
    <div class="section-tag">Pricing</div>
    <h2 class="section-title">Simple, transparent pricing</h2>
    <p class="section-sub">Start free, upgrade when you need more. All plans include all 25 AI tools.</p>
    <div class="pricing-grid">
        <div class="price-card">
            <div class="plan-name">Free</div>
            <div class="plan-price">$0</div>
            <div class="plan-price-sub">forever · no card needed</div>
            <div class="plan-credits-badge"><i class="ti ti-coin"></i> 50 welcome credits</div>
            <ul class="plan-features-list">
                <li><i class="ti ti-check"></i> All 25 AI tools</li>
                <li><i class="ti ti-check"></i> 50 free credits on signup</li>
                <li><i class="ti ti-check"></i> Community gallery access</li>
            </ul>
            <?php if ($isLoggedIn): ?>
            <span class="plan-btn plan-btn-ghost" style="cursor:default;opacity:.6">Current plan</span>
            <?php else: ?>
            <a href="/aistudio/public/register.php" class="plan-btn plan-btn-ghost">Get started free</a>
            <?php endif; ?>
        </div>
        <?php foreach ($plans as $p):
            $features = array_filter(array_map('trim', explode(',', $p['features'] ?? '')));
        ?>
        <div class="price-card <?= $p['is_featured']?'featured':'' ?>">
            <?php if ($p['is_featured']): ?><div class="popular-tag">⭐ Most Popular</div><?php endif; ?>
            <div class="plan-name"><?= h($p['name']) ?></div>
            <div class="plan-price">$<?= number_format($p['price_usd'],0) ?></div>
            <div class="plan-price-sub"><?= $p['duration_days'] ?> days · Rs <?= number_format($p['price_usd']*$pkrRate,0) ?> PKR</div>
            <div class="plan-credits-badge"><i class="ti ti-coin"></i> <?= number_format($p['credits_included']) ?> credits</div>
            <ul class="plan-features-list">
                <li><i class="ti ti-check"></i> All AI tools</li>
                <li><i class="ti ti-check"></i> Watermark-free downloads</li>
                <?php foreach ($features as $f): ?><li><i class="ti ti-check"></i> <?= h($f) ?></li><?php endforeach; ?>
            </ul>
            <a href="<?= $isLoggedIn ? '/aistudio/public/checkout.php?plan='.$p['id'] : '/aistudio/public/register.php' ?>"
               class="plan-btn <?= $p['is_featured']?'plan-btn-primary':'plan-btn-ghost' ?>">
                <?= $isLoggedIn ? 'Subscribe now' : 'Sign up & subscribe' ?>
            </a>
        </div>
        <?php endforeach; ?>
    </div>
</section>

<!-- CTA -->
<div class="cta z1">
    <div style="max-width:600px;margin:0 auto">
        <h2 style="font-size:clamp(1.8rem,4vw,2.8rem);font-weight:800;margin-bottom:1rem;line-height:1.2">
            Ready to create with AI?
        </h2>
        <p style="font-size:1rem;color:var(--muted);margin-bottom:2rem">Join <?= number_format($totalUsers) ?>+ creators already using <?= h($siteName) ?>. Start free — no credit card required.</p>
        <?php if ($isLoggedIn): ?>
        <a href="/aistudio/public/dashboard.php" style="display:inline-flex;align-items:center;gap:8px;padding:14px 36px;background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff;border-radius:12px;font-size:16px;font-weight:600;text-decoration:none;transition:all .2s">
            <i class="ti ti-layout-dashboard"></i> Go to Dashboard
        </a>
        <?php else: ?>
        <a href="/aistudio/public/register.php" style="display:inline-flex;align-items:center;gap:8px;padding:14px 36px;background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff;border-radius:12px;font-size:16px;font-weight:600;text-decoration:none;transition:all .2s">
            <i class="ti ti-rocket"></i> Get started free — 50 credits
        </a>
        <?php endif; ?>
    </div>
</div>

<!-- Footer -->
<footer class="z1">
    <div style="max-width:1200px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px">
        <div>
            <span style="font-weight:700;color:var(--primary)">&#9670; <?= h($siteName) ?></span>
            &nbsp;·&nbsp; <?= date('Y') ?> All rights reserved
        </div>
        <div style="display:flex;gap:16px;align-items:center">
            <a href="/aistudio/public/pricing.php" style="color:var(--muted);text-decoration:none">Pricing</a>
            <a href="/aistudio/public/login.php"   style="color:var(--muted);text-decoration:none">Login</a>
            <a href="/aistudio/public/register.php" style="color:var(--muted);text-decoration:none">Register</a>
        </div>
    </div>
</footer>
</div>

<script>
// Neural net bg
(function(){
    const c=document.getElementById('nc'),x=c.getContext('2d');
    let n=[];
    const r=()=>{c.width=innerWidth;c.height=innerHeight};
    const init=()=>{n=[];for(let i=0;i<60;i++)n.push({x:Math.random()*c.width,y:Math.random()*c.height,vx:(Math.random()-.5)*.35,vy:(Math.random()-.5)*.35,r:Math.random()*1.8+.6})};
    const draw=()=>{x.clearRect(0,0,c.width,c.height);n.forEach((a,i)=>{a.x+=a.vx;a.y+=a.vy;if(a.x<0||a.x>c.width)a.vx*=-1;if(a.y<0||a.y>c.height)a.vy*=-1;n.slice(i+1).forEach(b=>{const d=Math.hypot(a.x-b.x,a.y-b.y);if(d<130){x.beginPath();x.strokeStyle='#a78bfa';x.globalAlpha=(1-d/130)*.18;x.lineWidth=.5;x.moveTo(a.x,a.y);x.lineTo(b.x,b.y);x.stroke()}});x.beginPath();x.globalAlpha=.45;x.fillStyle='#a78bfa';x.arc(a.x,a.y,a.r,0,Math.PI*2);x.fill()});requestAnimationFrame(draw)};
    window.addEventListener('resize',()=>{r();init()});r();init();
    if(!matchMedia('(prefers-reduced-motion:reduce)').matches)draw();
})();

// Smooth scroll for nav links
document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click',e=>{
        const el=document.querySelector(a.getAttribute('href'));
        if(el){e.preventDefault();el.scrollIntoView({behavior:'smooth',block:'start'});}
    });
});
</script>
</body>
</html>
