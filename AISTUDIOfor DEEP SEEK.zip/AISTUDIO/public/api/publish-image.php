<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Core/Auth.php';

header('Content-Type: application/json');
Security::startSession();

if (!Auth::check()) { echo json_encode(['success'=>false,'error'=>'Not logged in']); exit; }

$token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!hash_equals($_SESSION['_csrf_token'] ?? '', $token)) { echo json_encode(['success'=>false,'error'=>'Invalid request']); exit; }

$body  = json_decode(file_get_contents('php://input'), true) ?? [];
$logId = (int)($body['log_id'] ?? 0);

if (!$logId) { echo json_encode(['success'=>false,'error'=>'Missing log ID']); exit; }

$log = DB::queryOne(
    "SELECT * FROM image_generation_logs WHERE id=? AND user_id=?",
    [$logId, Auth::id()]
);

if (!$log) { echo json_encode(['success'=>false,'error'=>'Log not found']); exit; }
if (!$log['image_url']) { echo json_encode(['success'=>false,'error'=>'No image URL']); exit; }

// Already published?
$existing = DB::queryOne("SELECT id FROM gallery WHERE source_id=? AND type='image'", [$logId]);
if ($existing) { echo json_encode(['success'=>false,'error'=>'Already published']); exit; }

DB::execute(
    "INSERT INTO gallery (user_id,type,source_id,title,media_url,thumbnail_url,is_active)
     VALUES (?,'image',?,?,?,?,1)",
    [Auth::id(), $logId, substr($log['prompt'] ?? 'AI Image', 0, 100), $log['image_url'], $log['image_url']]
);

DB::execute("UPDATE image_generation_logs SET is_published=1 WHERE id=?", [$logId]);

echo json_encode(['success'=>true]);
