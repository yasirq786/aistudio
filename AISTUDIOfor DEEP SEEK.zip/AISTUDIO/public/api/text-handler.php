<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';
require_once ROOT . '/app/Core/ApiLogger.php';

header('Content-Type: application/json');
Security::startSession();

if (!Auth::check()) { echo json_encode(['success'=>false,'error'=>'Not authenticated.']); exit; }

$token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!hash_equals($_SESSION['_csrf_token'] ?? '', $token)) { echo json_encode(['success'=>false,'error'=>'Invalid request.']); exit; }

if (!Security::rateLimit('text_api', 20, 60)) { echo json_encode(['success'=>false,'error'=>'Too many requests.']); exit; }

$user = Auth::user();
$body = json_decode(file_get_contents('php://input'), true) ?? [];

$apiServiceId = (int)($body['api_service_id'] ?? 0);
$toolSlug     = preg_replace('/[^a-z0-9\-]/', '', $body['tool_slug'] ?? '');
$prompt       = trim($body['prompt'] ?? '');
$systemPrompt = trim($body['system_prompt'] ?? 'You are a helpful AI assistant.');
$maxTokens    = min((int)($body['max_tokens'] ?? 1000), 4000);

if (!$prompt || !$apiServiceId || !$toolSlug) {
    echo json_encode(['success'=>false,'error'=>'Missing required fields.']); exit;
}

$tool = DB::queryOne("SELECT * FROM tools WHERE slug=? AND is_enabled=1", [$toolSlug]);
if (!$tool) { echo json_encode(['success'=>false,'error'=>'Tool not found.']); exit; }

$service = DB::queryOne(
    "SELECT a.*, t.id as tool_id FROM api_services a JOIN tools t ON t.id=a.tool_id
     WHERE a.id=? AND a.is_enabled=1 AND t.id=?",
    [$apiServiceId, $tool['id']]
);
if (!$service) { echo json_encode(['success'=>false,'error'=>'API service not found.']); exit; }

$toolId     = (int)$service['tool_id'];
$creditCost = (int)$service['credit_cost'];

if (!CreditEngine::hasSufficient($user['id'], $creditCost)) {
    echo json_encode(['success'=>false,'error'=>'Insufficient credits.']); exit;
}

$apiKey = $service['api_key'];
if (!$apiKey) { echo json_encode(['success'=>false,'error'=>'API key not configured.']); exit; }

$messages = [['role'=>'user','content'=>$prompt]];
$logger   = new ApiLogger($user['id'], $toolId, $apiServiceId);
$logger->logStart(['provider'=>$service['provider'],'prompt'=>$prompt], $prompt);

$reply=''; $status='failed'; $errorMsg=''; $apiCost=0.0; $httpCode=200;

try {
    $p = strtolower($service['provider']);
    if (str_contains($p,'deepseek')) {
        [$reply,$httpCode,$apiCost]=callOAI('https://api.deepseek.com/v1/chat/completions',$apiKey,$service['model']?:'deepseek-chat',$messages,$systemPrompt,$maxTokens);
    } elseif (str_contains($p,'groq')) {
        [$reply,$httpCode,$apiCost]=callOAI('https://api.groq.com/openai/v1/chat/completions',$apiKey,$service['model']?:'llama3-8b-8192',$messages,$systemPrompt,$maxTokens);
    } elseif (str_contains($p,'openai')||str_contains($p,'gpt')) {
        [$reply,$httpCode,$apiCost]=callOAI('https://api.openai.com/v1/chat/completions',$apiKey,$service['model']?:'gpt-4o-mini',$messages,$systemPrompt,$maxTokens);
    } elseif (str_contains($p,'anthropic')||str_contains($p,'claude')) {
        [$reply,$httpCode,$apiCost]=callAnth($apiKey,$service['model']?:'claude-3-5-haiku-20241022',$messages,$systemPrompt,$maxTokens);
    } else {
        $ep=$service['endpoint']?:'https://api.openai.com/v1/chat/completions';
        [$reply,$httpCode,$apiCost]=callOAI($ep,$apiKey,$service['model']?:'gpt-4o-mini',$messages,$systemPrompt,$maxTokens);
    }
    if ($reply) $status='success'; else $errorMsg='Empty response.';
} catch (Throwable $e) { $errorMsg=$e->getMessage(); }

$newBalance=$user['credit_balance'];
if ($status==='success') {
    $d=CreditEngine::deduct($user['id'],$creditCost,$toolId,$apiServiceId,$tool['name'].': '.substr($prompt,0,50));
    $newBalance=$d['new_balance']??($user['credit_balance']-$creditCost);
}
$logger->logEnd(['reply'=>substr($reply,0,200)],$status,$httpCode,$apiCost,$status==='success'?$creditCost:0,'',$errorMsg);

echo json_encode($status==='success'
    ? ['success'=>true,'reply'=>$reply,'new_balance'=>$newBalance,'credits_used'=>$creditCost]
    : ['success'=>false,'error'=>$errorMsg?:'Request failed.']);

function callOAI(string $url,string $key,string $model,array $msgs,string $sys,int $max):array{
    $ch=curl_init($url);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>json_encode(['model'=>$model,'max_tokens'=>$max,'messages'=>array_merge([['role'=>'system','content'=>$sys]],$msgs)]),
        CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$key],
        CURLOPT_TIMEOUT=>60,CURLOPT_SSL_VERIFYPEER=>false]);
    $res=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    $d=json_decode($res,true);
    if(isset($d['error']['message']))throw new \RuntimeException($d['error']['message']);
    return[$d['choices'][0]['message']['content']??'',$code,round(($d['usage']['total_tokens']??0)*0.000002,6)];
}

function callAnth(string $key,string $model,array $msgs,string $sys,int $max):array{
    $ch=curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>json_encode(['model'=>$model,'max_tokens'=>$max,'system'=>$sys,'messages'=>$msgs]),
        CURLOPT_HTTPHEADER=>['Content-Type: application/json','x-api-key: '.$key,'anthropic-version: 2023-06-01'],
        CURLOPT_TIMEOUT=>60,CURLOPT_SSL_VERIFYPEER=>false]);
    $res=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    $d=json_decode($res,true);
    if(isset($d['error']['message']))throw new \RuntimeException($d['error']['message']);
    return[$d['content'][0]['text']??'',$code,round((($d['usage']['input_tokens']??0)+($d['usage']['output_tokens']??0))*0.000003,6)];
}
