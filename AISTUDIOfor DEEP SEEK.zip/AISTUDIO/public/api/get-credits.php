<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Core/Auth.php';

header('Content-Type: application/json');
Security::startSession();

if (!Auth::check()) { echo json_encode(['balance' => 0]); exit; }

$balance = (int) DB::scalar("SELECT credit_balance FROM users WHERE id=?", [Auth::id()]);
echo json_encode(['balance' => $balance]);
