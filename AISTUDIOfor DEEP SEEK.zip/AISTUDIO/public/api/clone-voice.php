<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Core/Auth.php';
header('Content-Type: application/json');
Security::startSession();
if (!Auth::check()) { echo json_encode(['success'=>false,'error'=>'Not authenticated.']); exit; }
$token=$_POST['_csrf']??'';
if (!hash_equals($_SESSION['_csrf_token']??'',$token)) { echo json_encode(['success'=>false,'error'=>'Invalid request.']); exit; }
$svcId=(int)($_POST['api_service_id']??0);
$name=trim($_POST['name']??'');
$audio=$_FILES['audio']??null;
if (!$svcId||!$name||!$audio||$audio['error']!==UPLOAD_ERR_OK) { echo json_encode(['success'=>false,'error'=>'Missing data.']); exit; }
$service=DB::queryOne("SELECT * FROM api_services WHERE id=? AND is_enabled=1",[$svcId]);
if (!$service) { echo json_encode(['success'=>false,'error'=>'API not found.']); exit; }
$apiKey=$service['api_key'];
try {
    $ch=curl_init('https://api.elevenlabs.io/v1/voices/add');
    $cfile=new CURLFile($audio['tmp_name'],$audio['type'],$audio['name']);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>['name'=>$name,'files'=>$cfile],CURLOPT_HTTPHEADER=>['xi-api-key: '.$apiKey,'Accept: application/json'],CURLOPT_TIMEOUT=>120,CURLOPT_SSL_VERIFYPEER=>false]);
    $res=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    $data=json_decode($res,true);
    if ($code!==200||empty($data['voice_id'])) throw new RuntimeException('Clone failed: '.($data['detail']['message']??$res));
    DB::execute("INSERT INTO user_cloned_voices (user_id,name,provider_id,is_active) VALUES (?,?,?,1)",[Auth::id(),$name,$data['voice_id']]);
    echo json_encode(['success'=>true,'voice_id'=>$data['voice_id'],'name'=>$name]);
} catch (Throwable $e) { echo json_encode(['success'=>false,'error'=>$e->getMessage()]); }
