<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/ThemeEngine.php';

Security::startSession();
Security::checkIpBan();

if (!Auth::check()) { header('Location: /aistudio/public/login.php'); exit; }

Security::verifyCsrfToken();

$rating = min(5, max(1, (int)($_POST['rating'] ?? 5)));
$title  = Security::sanitizeRaw(substr($_POST['title'] ?? '', 0, 100));
$body   = Security::sanitizeRaw(substr($_POST['body']  ?? '', 0, 500));

if (strlen($body) < 10) {
    header('Location: /aistudio/public/landing.php#reviews');
    exit;
}

// Check if already reviewed
$existing = DB::queryOne("SELECT id FROM reviews WHERE user_id=?", [Auth::id()]);
if ($existing) {
    // Update existing review
    DB::execute(
        "UPDATE reviews SET rating=?,title=?,body=?,status=?,updated_at=NOW() WHERE user_id=?",
        [$rating, $title ?: null, $body,
         ThemeEngine::get('review_auto_approve','0')==='1' ? 'approved' : 'pending',
         Auth::id()]
    );
} else {
    $autoApprove = ThemeEngine::get('review_auto_approve','0') === '1';
    DB::execute(
        "INSERT INTO reviews (user_id,rating,title,body,status) VALUES (?,?,?,?,?)",
        [Auth::id(), $rating, $title ?: null, $body, $autoApprove ? 'approved' : 'pending']
    );
}

header('Location: /aistudio/public/landing.php#reviews');
exit;
