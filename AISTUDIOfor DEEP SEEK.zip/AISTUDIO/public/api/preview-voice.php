<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Core/Auth.php';
Security::startSession();
if (!Auth::check()) { http_response_code(401); exit; }
$voiceId=$_GET['voice_id']??'';
$apiId=(int)($_GET['api_id']??0);
if (!$voiceId||!$apiId) { http_response_code(400); exit; }
$service=DB::queryOne("SELECT api_key FROM api_services WHERE id=? AND is_enabled=1",[$apiId]);
if (!$service) { http_response_code(404); exit; }
$payload=['text'=>'Hello! This is a preview of my voice. I hope you enjoy the sound.','model_id'=>'eleven_multilingual_v2','voice_settings'=>['stability'=>0.5,'similarity_boost'=>0.75]];
$ch=curl_init("https://api.elevenlabs.io/v1/text-to-speech/{$voiceId}?output_format=mp3_44100_128");
curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_HTTPHEADER=>['Content-Type: application/json','xi-api-key: '.$service['api_key'],'Accept: audio/mpeg'],CURLOPT_TIMEOUT=>30,CURLOPT_SSL_VERIFYPEER=>false]);
$res=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
if ($code===200) { header('Content-Type: audio/mpeg'); header('Content-Length: '.strlen($res)); echo $res; }
else { http_response_code(500); }
