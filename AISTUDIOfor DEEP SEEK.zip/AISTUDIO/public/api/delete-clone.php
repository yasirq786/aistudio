<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Core/Auth.php';

header('Content-Type: application/json');
Security::startSession();
if (!Auth::check()) { echo json_encode(['success'=>false,'error'=>'Not authenticated']); exit; }

$token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!hash_equals($_SESSION['_csrf_token'] ?? '', $token)) {
    echo json_encode(['success'=>false,'error'=>'Invalid request']); exit;
}

$body = json_decode(file_get_contents('php://input'), true) ?? [];
$id   = (int)($body['id'] ?? 0);
if (!$id) { echo json_encode(['success'=>false,'error'=>'Missing ID']); exit; }

$clone = DB::queryOne(
    "SELECT ucv.*, a.api_key FROM user_cloned_voices ucv
     JOIN api_services a ON a.tool_id = (SELECT id FROM tools WHERE slug='ai-voice' LIMIT 1)
     WHERE ucv.id=? AND ucv.user_id=? AND ucv.is_active=1",
    [$id, Auth::id()]
);
if (!$clone) { echo json_encode(['success'=>false,'error'=>'Voice not found']); exit; }

// Delete from ElevenLabs
if (!empty($clone['provider_id']) && !empty($clone['api_key'])) {
    $ch = curl_init("https://api.elevenlabs.io/v1/voices/{$clone['provider_id']}");
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST  => 'DELETE',
        CURLOPT_HTTPHEADER     => ['xi-api-key: '.$clone['api_key']],
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    curl_exec($ch);
    curl_close($ch);
}

// Soft delete from DB
DB::execute("UPDATE user_cloned_voices SET is_active=0 WHERE id=?", [$id]);

echo json_encode(['success'=>true]);
