<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Core/Auth.php';

header('Content-Type: application/json');
Security::startSession();

if (!Auth::check()) {
    echo json_encode(['valid' => false, 'error' => 'Not logged in']);
    exit;
}

$code   = strtoupper(trim($_GET['code']  ?? ''));
$planId = (int)($_GET['plan'] ?? 0);

if (!$code || !$planId) {
    echo json_encode(['valid' => false, 'error' => 'Missing code or plan']);
    exit;
}

$plan = DB::queryOne("SELECT price_usd FROM subscription_plans WHERE id=? AND is_active=1", [$planId]);
if (!$plan) {
    echo json_encode(['valid' => false, 'error' => 'Invalid plan']);
    exit;
}

$coupon = DB::queryOne(
    "SELECT * FROM coupons WHERE code=? AND is_active=1
     AND (max_uses IS NULL OR used_count < max_uses)
     AND (valid_from IS NULL OR valid_from <= NOW())
     AND (valid_until IS NULL OR valid_until >= NOW())",
    [$code]
);

if (!$coupon) {
    echo json_encode(['valid' => false, 'error' => 'Invalid or expired coupon code']);
    exit;
}

$discount = $coupon['discount_type'] === 'percent'
    ? $plan['price_usd'] * ($coupon['discount_value'] / 100)
    : min((float)$coupon['discount_value'], $plan['price_usd']);

echo json_encode([
    'valid'          => true,
    'discount'       => round($discount, 2),
    'discount_value' => $coupon['discount_value'],
    'percent'        => $coupon['discount_type'] === 'percent',
]);
