<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';
require_once ROOT . '/app/Core/ApiLogger.php';

header('Content-Type: application/json');
Security::startSession();

if (!Auth::check()) { echo json_encode(['success'=>false,'error'=>'Not authenticated.']); exit; }

$token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!hash_equals($_SESSION['_csrf_token'] ?? '', $token)) { echo json_encode(['success'=>false,'error'=>'Invalid request.']); exit; }

if (!Security::rateLimit('image_api', 10, 60)) { echo json_encode(['success'=>false,'error'=>'Too many requests.']); exit; }

$user = Auth::user();
$body = json_decode(file_get_contents('php://input'), true) ?? [];

$apiServiceId  = (int)($body['api_service_id'] ?? 0);
$prompt        = trim($body['prompt']           ?? '');
$negPrompt     = trim($body['negative_prompt']  ?? '');
$width         = min(max((int)($body['width']   ?? 1024), 256), 1920);
$height        = min(max((int)($body['height']  ?? 1024), 256), 1920);
$steps         = min(max((int)($body['steps']   ?? 30), 10), 50);
$cfgScale      = min(max((float)($body['cfg_scale'] ?? 7), 1), 20);
$seed          = !empty($body['seed']) ? (int)$body['seed'] : null;
$numImages     = min(max((int)($body['num_images'] ?? 1), 1), 4);

if (!$prompt || !$apiServiceId) { echo json_encode(['success'=>false,'error'=>'Missing prompt or API.']); exit; }

$service = DB::queryOne(
    "SELECT a.*, t.id as tool_id FROM api_services a JOIN tools t ON t.id=a.tool_id
     WHERE a.id=? AND a.is_enabled=1 AND t.slug='ai-image'",
    [$apiServiceId]
);
if (!$service) { echo json_encode(['success'=>false,'error'=>'API service not found.']); exit; }

$toolId     = (int)$service['tool_id'];
$creditCost = (int)$service['credit_cost'] * $numImages;

if (!CreditEngine::hasSufficient($user['id'], $creditCost)) {
    echo json_encode(['success'=>false,'error'=>'Insufficient credits.']); exit;
}

$apiKey  = $service['api_key'];
if (!$apiKey) { echo json_encode(['success'=>false,'error'=>'API key not configured.']); exit; }

$logger = new ApiLogger($user['id'], $toolId, $apiServiceId);
$reqPayload = ['provider'=>$service['provider'],'prompt'=>$prompt,'width'=>$width,'height'=>$height,'steps'=>$steps,'num_images'=>$numImages];
$logger->logStart($reqPayload, $prompt);

$images   = [];
$status   = 'failed';
$errorMsg = '';
$apiCost  = 0.0;
$logId    = 0;

try {
    $provider = strtolower($service['provider']);

    if (str_contains($provider, 'stability')) {
        [$images, $apiCost] = callStabilityAI($apiKey, $prompt, $negPrompt, $width, $height, $steps, $cfgScale, $seed, $numImages, $service['model']);
    } elseif (str_contains($provider, 'leonardo')) {
        [$images, $apiCost] = callLeonardoAI($apiKey, $prompt, $negPrompt, $width, $height, $steps, $numImages, $service['model']);
    } elseif (str_contains($provider, 'openai') || str_contains($provider, 'dall')) {
        [$images, $apiCost] = callDallE($apiKey, $prompt, $width, $height, $numImages);
    } else {
        // Default: Stability AI compatible
        [$images, $apiCost] = callStabilityAI($apiKey, $prompt, $negPrompt, $width, $height, $steps, $cfgScale, $seed, $numImages, $service['model']);
    }

    if ($images) {
        $status = 'success';

        // Save storage locally
        $savedUrls = [];
        $storageDir = ROOT . '/public/assets/img/generated/';
        if (!is_dir($storageDir)) mkdir($storageDir, 0755, true);

        foreach ($images as $imgData) {
            $fname = 'img_' . time() . '_' . $user['id'] . '_' . uniqid() . '.png';
            $fpath = $storageDir . $fname;

            if (str_starts_with($imgData, 'http')) {
                // URL — download it
                $content = @file_get_contents($imgData);
                if ($content) { file_put_contents($fpath, $content); }
                $savedUrls[] = '/aistudio/public/assets/img/generated/' . $fname;
            } elseif (str_starts_with($imgData, 'data:')) {
                // Base64
                $b64 = preg_replace('/^data:image\/\w+;base64,/', '', $imgData);
                file_put_contents($fpath, base64_decode($b64));
                $savedUrls[] = '/aistudio/public/assets/img/generated/' . $fname;
            } else {
                // Raw base64
                file_put_contents($fpath, base64_decode($imgData));
                $savedUrls[] = '/aistudio/public/assets/img/generated/' . $fname;
            }
        }

        // Log to image_generation_logs
        $settings = json_encode(['width'=>$width,'height'=>$height,'steps'=>$steps,'cfg'=>$cfgScale,'seed'=>$seed]);
        $logId = DB::insert(
            "INSERT INTO image_generation_logs (user_id,api_service_id,prompt,negative_prompt,settings,image_url,credits_used,status)
             VALUES (?,?,?,?,?,?,?,'success')",
            [$user['id'], $apiServiceId, $prompt, $negPrompt, $settings, $savedUrls[0] ?? '', $creditCost]
        );

        $images = $savedUrls;
    } else {
        $errorMsg = 'No images returned from API.';
    }
} catch (Throwable $e) {
    $errorMsg = $e->getMessage();
    $status   = 'failed';
}

// Deduct credits
$newBalance = $user['credit_balance'];
if ($status === 'success') {
    $deduct     = CreditEngine::deduct($user['id'], $creditCost, $toolId, $apiServiceId, 'Image: '.substr($prompt,0,50));
    $newBalance = $deduct['new_balance'] ?? ($user['credit_balance'] - $creditCost);
}

$logger->logEnd(['images_count'=>count($images)], $status, 200, $apiCost, $status==='success'?$creditCost:0, $images[0]??'', $errorMsg);

if ($status === 'success') {
    echo json_encode(['success'=>true,'images'=>$images,'new_balance'=>$newBalance,'credits_used'=>$creditCost,'log_id'=>$logId]);
} else {
    echo json_encode(['success'=>false,'error'=>$errorMsg?:'Generation failed.']);
}

// ── API Functions ─────────────────────────────────────────────────

function callStabilityAI(string $key, string $prompt, string $neg, int $w, int $h, int $steps, float $cfg, ?int $seed, int $n, string $model): array
{
    $model = $model ?: 'stable-diffusion-xl-1024-v1-0';
    $url   = "https://api.stability.ai/v1/generation/{$model}/text-to-image";

    $body = [
        'text_prompts' => [
            ['text' => $prompt,  'weight' => 1],
            ['text' => $neg ?: 'blurry, low quality, distorted', 'weight' => -1],
        ],
        'cfg_scale'    => $cfg,
        'width'        => $w,
        'height'       => $h,
        'steps'        => $steps,
        'samples'      => $n,
    ];
    if ($seed) $body['seed'] = $seed;

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($body),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer '.$key, 'Accept: application/json'],
        CURLOPT_TIMEOUT        => 120,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $resp = curl_exec($ch);
    curl_close($ch);

    $data = json_decode($resp, true);
    if (isset($data['message'])) throw new RuntimeException($data['message']);
    if (empty($data['artifacts'])) throw new RuntimeException('No artifacts returned');

    $images = array_map(fn($a) => $a['base64'], $data['artifacts']);
    $cost   = count($images) * 0.002;
    return [$images, $cost];
}

function callLeonardoAI(string $key, string $prompt, string $neg, int $w, int $h, int $steps, int $n, string $model): array
{
    // Step 1: Create generation
    $body = [
        'prompt'         => $prompt,
        'negative_prompt'=> $neg ?: 'blurry, low quality',
        'width'          => $w,
        'height'         => $h,
        'num_images'     => $n,
        'num_inference_steps' => $steps,
    ];
    if ($model) $body['modelId'] = $model;

    $ch = curl_init('https://cloud.leonardo.ai/api/rest/v1/generations');
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>json_encode($body),
        CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$key],
        CURLOPT_TIMEOUT=>30, CURLOPT_SSL_VERIFYPEER=>false,
    ]);
    $resp = curl_exec($ch); curl_close($ch);
    $data = json_decode($resp, true);

    $genId = $data['sdGenerationJob']['generationId'] ?? null;
    if (!$genId) throw new RuntimeException('Leonardo: no generation ID. Response: '.substr($resp,0,200));

    // Step 2: Poll for result
    $maxAttempts = 20;
    for ($i = 0; $i < $maxAttempts; $i++) {
        sleep(3);
        $ch2 = curl_init("https://cloud.leonardo.ai/api/rest/v1/generations/{$genId}");
        curl_setopt_array($ch2,[
            CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$key],
            CURLOPT_TIMEOUT=>30, CURLOPT_SSL_VERIFYPEER=>false,
        ]);
        $res2 = curl_exec($ch2); curl_close($ch2);
        $d2   = json_decode($res2, true);
        $gen  = $d2['generations_by_pk'] ?? null;

        if ($gen && $gen['status'] === 'COMPLETE') {
            $urls = array_map(fn($img) => $img['url'], $gen['generated_images'] ?? []);
            return [$urls, count($urls) * 0.003];
        }
        if ($gen && $gen['status'] === 'FAILED') {
            throw new RuntimeException('Leonardo generation failed.');
        }
    }
    throw new RuntimeException('Leonardo: generation timed out.');
}

function callDallE(string $key, string $prompt, int $w, int $h, int $n): array
{
    $size = "{$w}x{$h}";
    $ch = curl_init('https://api.openai.com/v1/images/generations');
    curl_setopt_array($ch,[
        CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>json_encode(['model'=>'dall-e-3','prompt'=>$prompt,'n'=>min($n,1),'size'=>'1024x1024','response_format'=>'url']),
        CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$key],
        CURLOPT_TIMEOUT=>60, CURLOPT_SSL_VERIFYPEER=>false,
    ]);
    $resp=curl_exec($ch);curl_close($ch);
    $data=json_decode($resp,true);
    if(isset($data['error']))throw new RuntimeException($data['error']['message']);
    $urls=array_map(fn($i)=>$i['url'],$data['data']??[]);
    return[$urls,count($urls)*0.04];
}
