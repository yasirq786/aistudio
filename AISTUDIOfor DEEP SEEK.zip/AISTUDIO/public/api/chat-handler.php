<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';
require_once ROOT . '/app/Core/ApiLogger.php';

header('Content-Type: application/json');

Security::startSession();

// Auth check
if (!Auth::check()) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated.']);
    exit;
}

// CSRF check
$token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!hash_equals($_SESSION['_csrf_token'] ?? '', $token)) {
    echo json_encode(['success' => false, 'error' => 'Invalid request.']);
    exit;
}

// Rate limit
if (!Security::rateLimit('chat_api', 30, 60)) {
    echo json_encode(['success' => false, 'error' => 'Too many requests. Please slow down.']);
    exit;
}

$user = Auth::user();

// Parse JSON body
$body         = json_decode(file_get_contents('php://input'), true) ?? [];
$apiServiceId = (int)($body['api_service_id'] ?? 0);
$message      = trim($body['message']         ?? '');
$history      = $body['history']              ?? [];
$tone         = $body['tone']                 ?? 'balanced';
$language     = $body['language']             ?? 'en';
$maxTokens    = min((int)($body['max_tokens'] ?? 1000), 4000);

if (!$message || !$apiServiceId) {
    echo json_encode(['success' => false, 'error' => 'Missing message or API service.']);
    exit;
}

// Get API service
$service = DB::queryOne(
    "SELECT a.*, t.id as tool_id, t.slug as tool_slug
     FROM api_services a
     JOIN tools t ON t.id = a.tool_id
     WHERE a.id = ? AND a.is_enabled = 1 AND t.slug = 'ai-chat'",
    [$apiServiceId]
);

if (!$service) {
    echo json_encode(['success' => false, 'error' => 'API service not found or disabled.']);
    exit;
}

$toolId      = (int)$service['tool_id'];
$creditCost  = (int)$service['credit_cost'];

// Check credits
if (!CreditEngine::hasSufficient($user['id'], $creditCost)) {
    echo json_encode(['success' => false, 'error' => 'Insufficient credits.']);
    exit;
}

// Get API key
$apiKey = $service['api_key'];
if (!$apiKey) {
    echo json_encode(['success' => false, 'error' => 'API key not configured. Please contact admin.']);
    exit;
}

// Build system prompt based on tone
$toneMap = [
    'balanced'  => 'You are a helpful, balanced AI assistant.',
    'creative'  => 'You are a creative and imaginative AI assistant. Think outside the box.',
    'precise'   => 'You are a precise and technical AI assistant. Be concise and accurate.',
    'friendly'  => 'You are a warm, friendly AI assistant. Use a conversational tone.',
    'formal'    => 'You are a professional AI assistant. Use formal, business-appropriate language.',
];
$systemPrompt = $toneMap[$tone] ?? $toneMap['balanced'];
if ($language === 'ur') {
    $systemPrompt .= ' Always respond in Urdu language.';
}

// Build messages array
$messages = [];
foreach (array_slice($history, -10) as $h) {
    if (in_array($h['role'] ?? '', ['user', 'assistant'])) {
        $messages[] = ['role' => $h['role'], 'content' => (string)($h['content'] ?? '')];
    }
}
$messages[] = ['role' => 'user', 'content' => $message];

// Start logging
$logger = new ApiLogger($user['id'], $toolId, $apiServiceId);
$requestPayload = [
    'provider' => $service['provider'],
    'model'    => $service['model'],
    'messages' => $messages,
    'tone'     => $tone,
];
$logger->logStart($requestPayload, $message);

// ── Call the appropriate API ──────────────────────────────────────
$reply       = '';
$httpStatus  = 200;
$apiCostUsd  = 0.0;
$status      = 'failed';
$errorMsg    = '';

try {
    $provider = strtolower($service['provider']);

    if (str_contains($provider, 'deepseek')) {
        [$reply, $httpStatus, $apiCostUsd] = callOpenAICompat(
            'https://api.deepseek.com/v1/chat/completions',
            $apiKey, $service['model'] ?: 'deepseek-chat',
            $messages, $systemPrompt, $maxTokens
        );
    } elseif (str_contains($provider, 'groq')) {
        [$reply, $httpStatus, $apiCostUsd] = callOpenAICompat(
            'https://api.groq.com/openai/v1/chat/completions',
            $apiKey, $service['model'] ?: 'llama3-8b-8192',
            $messages, $systemPrompt, $maxTokens
        );
    } elseif (str_contains($provider, 'openai') || str_contains($provider, 'gpt')) {
        [$reply, $httpStatus, $apiCostUsd] = callOpenAICompat(
            'https://api.openai.com/v1/chat/completions',
            $apiKey, $service['model'] ?: 'gpt-4o-mini',
            $messages, $systemPrompt, $maxTokens
        );
    } elseif (str_contains($provider, 'anthropic') || str_contains($provider, 'claude')) {
        [$reply, $httpStatus, $apiCostUsd] = callAnthropic(
            $apiKey, $service['model'] ?: 'claude-3-5-haiku-20241022',
            $messages, $systemPrompt, $maxTokens
        );
    } else {
        // Default: try OpenAI-compatible
        $endpoint = $service['endpoint'] ?: 'https://api.openai.com/v1/chat/completions';
        [$reply, $httpStatus, $apiCostUsd] = callOpenAICompat(
            $endpoint, $apiKey, $service['model'] ?: 'gpt-4o-mini',
            $messages, $systemPrompt, $maxTokens
        );
    }

    if ($reply) {
        $status = 'success';
    } else {
        $errorMsg = 'Empty response from API.';
    }

} catch (Throwable $e) {
    $errorMsg = $e->getMessage();
    $status   = 'failed';
}

// ── Deduct credits if success ─────────────────────────────────────
$newBalance = $user['credit_balance'];
if ($status === 'success') {
    $deduct     = CreditEngine::deduct($user['id'], $creditCost, $toolId, $apiServiceId, 'AI Chat: ' . substr($message, 0, 50));
    $newBalance = $deduct['new_balance'] ?? $user['credit_balance'] - $creditCost;
}

// ── Log end ───────────────────────────────────────────────────────
$logger->logEnd(
    ['reply' => $reply],
    $status, $httpStatus, $apiCostUsd,
    $status === 'success' ? $creditCost : 0,
    '', $errorMsg
);

// ── Response ──────────────────────────────────────────────────────
if ($status === 'success') {
    echo json_encode([
        'success'     => true,
        'reply'       => $reply,
        'new_balance' => $newBalance,
        'credits_used'=> $creditCost,
    ]);
} else {
    echo json_encode([
        'success' => false,
        'error'   => $errorMsg ?: 'API call failed. Please try again.',
    ]);
}

// ── API call functions ────────────────────────────────────────────
function callOpenAICompat(
    string $endpoint, string $apiKey, string $model,
    array  $messages, string $system, int $maxTokens
): array {
    $payload = [
        'model'       => $model,
        'max_tokens'  => $maxTokens,
        'messages'    => array_merge(
            [['role' => 'system', 'content' => $system]],
            $messages
        ),
    ];

    $ch = curl_init($endpoint);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apiKey,
        ],
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $response   = curl_exec($ch);
    $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $data  = json_decode($response, true);
    $reply = $data['choices'][0]['message']['content'] ?? '';

    // Rough cost estimate
    $tokens     = $data['usage']['total_tokens'] ?? 0;
    $costPerTok = 0.000002; // ~$2 per 1M tokens estimate
    $cost       = round($tokens * $costPerTok, 6);

    if (!$reply && isset($data['error']['message'])) {
        throw new RuntimeException($data['error']['message']);
    }

    return [$reply, $httpStatus, $cost];
}

function callAnthropic(
    string $apiKey, string $model,
    array  $messages, string $system, int $maxTokens
): array {
    $payload = [
        'model'      => $model,
        'max_tokens' => $maxTokens,
        'system'     => $system,
        'messages'   => $messages,
    ];

    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'x-api-key: '         . $apiKey,
            'anthropic-version: 2023-06-01',
        ],
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $response   = curl_exec($ch);
    $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $data  = json_decode($response, true);
    $reply = $data['content'][0]['text'] ?? '';

    $tokens = ($data['usage']['input_tokens'] ?? 0) + ($data['usage']['output_tokens'] ?? 0);
    $cost   = round($tokens * 0.000003, 6);

    if (!$reply && isset($data['error']['message'])) {
        throw new RuntimeException($data['error']['message']);
    }

    return [$reply, $httpStatus, $cost];
}
