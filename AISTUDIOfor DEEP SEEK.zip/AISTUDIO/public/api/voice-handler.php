<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';
require_once ROOT . '/app/Core/ApiLogger.php';
header('Content-Type: application/json');
Security::startSession();
if (!Auth::check()) { echo json_encode(['success'=>false,'error'=>'Not authenticated.']); exit; }
$token=$_SERVER['HTTP_X_CSRF_TOKEN']??'';
if (!hash_equals($_SESSION['_csrf_token']??'',$token)) { echo json_encode(['success'=>false,'error'=>'Invalid request.']); exit; }
$user=Auth::user();
$body=json_decode(file_get_contents('php://input'),true)??[];
$svcId=(int)($body['api_service_id']??0);
$text=trim($body['text']??'');
$voiceId=$body['voice_id']??'21m00Tcm4TlvDq8ikWAM';
$voiceName=$body['voice_name']??'Rachel';
$stability=(float)($body['stability']??0.5);
$similarity=(float)($body['similarity_boost']??0.75);
$style=(float)($body['style']??0);
$fmt=$body['output_format']??'mp3_44100_128';
if (!$text||!$svcId) { echo json_encode(['success'=>false,'error'=>'Missing text or API.']); exit; }
$service=DB::queryOne("SELECT a.*,t.id as tool_id FROM api_services a JOIN tools t ON t.id=a.tool_id WHERE a.id=? AND a.is_enabled=1 AND t.slug='ai-voice'",[$svcId]);
if (!$service) { echo json_encode(['success'=>false,'error'=>'API not found.']); exit; }
$creditCost=(int)$service['credit_cost'];
if (!CreditEngine::hasSufficient($user['id'],$creditCost)) { echo json_encode(['success'=>false,'error'=>'Insufficient credits.']); exit; }
$apiKey=$service['api_key'];
$toolId=(int)$service['tool_id'];
$logger=new ApiLogger($user['id'],$toolId,$svcId);
$logger->logStart(['voice_id'=>$voiceId,'text_length'=>strlen($text)],$text);
try {
    $payload=['text'=>$text,'model_id'=>'eleven_multilingual_v2','voice_settings'=>['stability'=>$stability,'similarity_boost'=>$similarity,'style'=>$style,'use_speaker_boost'=>true]];
    $ch=curl_init("https://api.elevenlabs.io/v1/text-to-speech/{$voiceId}?output_format={$fmt}");
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_HTTPHEADER=>['Content-Type: application/json','xi-api-key: '.$apiKey,'Accept: audio/mpeg'],CURLOPT_TIMEOUT=>60,CURLOPT_SSL_VERIFYPEER=>false]);
    $res=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);$ct=curl_getinfo($ch,CURLINFO_CONTENT_TYPE);curl_close($ch);
    if ($code!==200||!str_contains($ct??'','audio')) {
        $err=json_decode($res,true);
        throw new RuntimeException('ElevenLabs error '.$code.': '.($err['detail']['message']??$err['detail']??$res));
    }
    // Save audio file
    $dir=ROOT.'/public/assets/audio/';if(!is_dir($dir))mkdir($dir,0755,true);
    $fname='voice_'.time().'_'.$user['id'].'_'.uniqid().'.mp3';
    file_put_contents($dir.$fname,$res);
    $audioUrl='/aistudio/public/assets/audio/'.$fname;
    $deduct=CreditEngine::deduct($user['id'],$creditCost,$toolId,$svcId,'Voice: '.substr($text,0,50));
    $logger->logEnd(['audio_url'=>$audioUrl],'success',$code,0.001,$creditCost,$audioUrl,'');
    echo json_encode(['success'=>true,'audio_url'=>$audioUrl,'new_balance'=>$deduct['new_balance']??0,'credits_used'=>$creditCost]);
} catch (Throwable $e) {
    $logger->logEnd([],'failed',500,0,0,'',$e->getMessage());
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
