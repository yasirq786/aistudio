<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';
require_once ROOT . '/app/Core/ApiLogger.php';

header('Content-Type: application/json');
Security::startSession();
if (!Auth::check()) { echo json_encode(['success'=>false,'error'=>'Not authenticated.']); exit; }
$token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!hash_equals($_SESSION['_csrf_token'] ?? '', $token)) { echo json_encode(['success'=>false,'error'=>'Invalid request.']); exit; }

$user   = Auth::user();
$body   = json_decode(file_get_contents('php://input'), true) ?? [];
$svcId  = (int)($body['api_service_id'] ?? 0);
$prompt = trim($body['prompt'] ?? '');
$neg    = trim($body['negative_prompt'] ?? '');
$dur    = (int)($body['duration_sec'] ?? 5);
$aspect = $body['aspect_ratio'] ?? '16:9';
$mode   = $body['mode'] ?? 'text'; // text or image
$imgB64 = $body['image_base64'] ?? '';
$imgUrl = $body['image_url'] ?? '';

if (!$prompt || !$svcId) { echo json_encode(['success'=>false,'error'=>'Missing fields.']); exit; }

$service = DB::queryOne(
    "SELECT a.*,t.id as tool_id FROM api_services a JOIN tools t ON t.id=a.tool_id WHERE a.id=? AND a.is_enabled=1 AND t.slug='ai-video'",
    [$svcId]
);
if (!$service) { echo json_encode(['success'=>false,'error'=>'API service not found.']); exit; }

$tier = DB::queryOne("SELECT credit_cost FROM video_credit_tiers WHERE duration_sec<=? ORDER BY duration_sec DESC LIMIT 1", [$dur]);
$creditCost = $tier ? (int)$tier['credit_cost'] : 10;
if (!CreditEngine::hasSufficient($user['id'], $creditCost)) { echo json_encode(['success'=>false,'error'=>'Insufficient credits.']); exit; }

$apiKey   = $service['api_key'];
$toolId   = (int)$service['tool_id'];
$provider = strtolower($service['provider']);
$logger   = new ApiLogger($user['id'], $toolId, $svcId);
$logger->logStart(['prompt'=>$prompt,'duration'=>$dur,'provider'=>$provider,'mode'=>$mode], $prompt);

$jobId=''; $videoUrl=''; $logId=0;

try {
    if (str_contains($provider, 'replicate')) {
        // Replicate — Seedance 2.0
        $endpoint = $service['endpoint'] ?: 'https://api.replicate.com/v1/models/bytedance/seedance-2.0-fast/predictions';
        $input = ['prompt'=>$prompt,'duration'=>$dur,'aspect_ratio'=>$aspect,'negative_prompt'=>$neg];
        if ($mode==='image' && ($imgUrl || $imgB64)) {
            $input['first_frame_image'] = $imgUrl ?: 'data:image/jpeg;base64,'.$imgB64;
        }
        $ch=curl_init($endpoint);
        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
            CURLOPT_POSTFIELDS=>json_encode(['input'=>$input]),
            CURLOPT_HTTPHEADER=>['Content-Type: application/json','Authorization: Bearer '.$apiKey,'Prefer: wait=60'],
            CURLOPT_TIMEOUT=>90, CURLOPT_SSL_VERIFYPEER=>false,
        ]);
        $res=curl_exec($ch); $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
        $data=json_decode($res,true);
        if (!empty($data['output'])) {
            $videoUrl = is_array($data['output']) ? ($data['output'][0]??'') : $data['output'];
        } elseif (!empty($data['id'])) {
            $jobId = $data['id'];
        } else {
            throw new RuntimeException('Replicate error: '.substr($res,0,300));
        }

    } elseif (str_contains($provider, 'eachlabs') || str_contains($provider, 'veo')) {
        // Eachlabs Veo 3.1
        $payload = ['prompt'=>$prompt,'duration'=>$dur,'aspect_ratio'=>$aspect];
        if ($neg) $payload['negative_prompt'] = $neg;
        if ($mode==='image' && ($imgUrl || $imgB64)) {
            $payload['image'] = $imgUrl ?: 'data:image/jpeg;base64,'.$imgB64;
            $payload['mode']  = 'image_to_video';
        }
        $ch=curl_init('https://api.eachlabs.ai/v1/video/generate');
        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
            CURLOPT_POSTFIELDS=>json_encode($payload),
            CURLOPT_HTTPHEADER=>['Content-Type: application/json','X-API-Key: '.$apiKey],
            CURLOPT_TIMEOUT=>30, CURLOPT_SSL_VERIFYPEER=>false,
        ]);
        $res=curl_exec($ch); curl_close($ch);
        $data=json_decode($res,true);
        $jobId = $data['task_id']??$data['id']??'';
        if (!$jobId) throw new RuntimeException('Eachlabs: no task ID. '.substr($res,0,200));

    } elseif (str_contains($provider, 'leonardo')) {
        // Leonardo text-to-video
        $dims=['16:9'=>['w'=>832,'h'=>480],'9:16'=>['w'=>480,'h'=>832],'1:1'=>['w'=>640,'h'=>640]];
        $wh=$dims[$aspect]??$dims['16:9'];
        $payload=['prompt'=>$prompt,'width'=>$wh['w'],'height'=>$wh['h'],'resolution'=>'RESOLUTION_480','frameInterpolation'=>true,'promptEnhance'=>true,'isPublic'=>false];
        if ($neg) $payload['negative_prompt']=$neg;
        if ($mode==='image' && ($imgUrl||$imgB64)) {
            $payload['imageSource']=$imgUrl?:('data:image/jpeg;base64,'.$imgB64);
        }
        $ch=curl_init('https://cloud.leonardo.ai/api/rest/v1/generations-text-to-video');
        curl_setopt_array($ch,[
            CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
            CURLOPT_POSTFIELDS=>json_encode($payload),
            CURLOPT_HTTPHEADER=>['Content-Type: application/json','Accept: application/json','Authorization: Bearer '.$apiKey],
            CURLOPT_TIMEOUT=>30, CURLOPT_SSL_VERIFYPEER=>false,
        ]);
        $res=curl_exec($ch); curl_close($ch);
        $data=json_decode($res,true);
        $jobId=$data['generation']['id']??$data['generationId']??$data['textToVideoGenerationJob']['generationId']??'';
        if (!$jobId) throw new RuntimeException('Leonardo no gen ID: '.substr($res,0,300));

    } else {
        throw new RuntimeException('Unsupported video provider: '.$service['provider']);
    }

    // Save log
    $logId=DB::insert(
        "INSERT INTO video_generation_logs (user_id,api_service_id,prompt,duration_sec,provider_job_id,video_url,status,credits_used)
         VALUES (?,?,?,?,?,?,?,?)",
        [$user['id'],$svcId,$prompt,$dur,$jobId,$videoUrl,$videoUrl?'completed':'processing',$creditCost]
    );

    // Deduct credits
    $d=CreditEngine::deduct($user['id'],$creditCost,$toolId,$svcId,'Video: '.substr($prompt,0,50));
    $newBal=$d['new_balance']??($user['credit_balance']-$creditCost);
    $logger->logEnd(['job_id'=>$jobId,'video_url'=>$videoUrl],'success',200,0.05,$creditCost,$videoUrl,'');

    echo json_encode(['success'=>true,'log_id'=>$logId,'job_id'=>$jobId,'video_url'=>$videoUrl,'new_balance'=>$newBal,'status'=>$videoUrl?'completed':'processing']);

} catch (Throwable $e) {
    $logger->logEnd([],'failed',500,0,0,'',$e->getMessage());
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
