<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Core/Auth.php';
header('Content-Type: application/json');
Security::startSession();
if (!Auth::check()) { echo json_encode(['status'=>'failed']); exit; }
$logId=(int)($_GET['id']??0);
if (!$logId) { echo json_encode(['status'=>'failed']); exit; }
$log=DB::queryOne("SELECT vgl.*,a.api_key,a.provider,a.endpoint FROM video_generation_logs vgl JOIN api_services a ON a.id=vgl.api_service_id WHERE vgl.id=? AND vgl.user_id=?",[$logId,Auth::id()]);
if (!$log) { echo json_encode(['status'=>'failed']); exit; }
if ($log['status']==='completed'&&$log['video_url']) { echo json_encode(['status'=>'completed','video_url'=>$log['video_url']]); exit; }
if ($log['status']==='failed') { echo json_encode(['status'=>'failed']); exit; }
$p=strtolower($log['provider']); $jid=$log['provider_job_id']; $key=$log['api_key']; $url='';
try {
    if (str_contains($p,'replicate')) {
        $ch=curl_init("https://api.replicate.com/v1/predictions/{$jid}");
        curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Authorization: Bearer '.$key],CURLOPT_TIMEOUT=>15,CURLOPT_SSL_VERIFYPEER=>false]);
        $res=curl_exec($ch);curl_close($ch);
        $d=json_decode($res,true);
        $st=$d['status']??'';
        if ($st==='succeeded') { $out=$d['output']??''; $url=is_array($out)?($out[0]??''):$out; }
        elseif ($st==='failed') { DB::execute("UPDATE video_generation_logs SET status='failed' WHERE id=?",[$logId]); echo json_encode(['status'=>'failed']); exit; }
    } elseif (str_contains($p,'eachlabs')||str_contains($p,'veo')) {
        $ch=curl_init("https://api.eachlabs.ai/v1/video/status/{$jid}");
        curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['X-API-Key: '.$key],CURLOPT_TIMEOUT=>15,CURLOPT_SSL_VERIFYPEER=>false]);
        $res=curl_exec($ch);curl_close($ch);
        $d=json_decode($res,true);
        if (($d['status']??'')==='completed') $url=$d['video_url']??$d['url']??'';
        elseif (($d['status']??'')==='failed') { DB::execute("UPDATE video_generation_logs SET status='failed' WHERE id=?",[$logId]); echo json_encode(['status'=>'failed']); exit; }
    } elseif (str_contains($p,'leonardo')) {
        $ch=curl_init("https://cloud.leonardo.ai/api/rest/v1/generations/{$jid}");
        curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_HTTPHEADER=>['Accept: application/json','Authorization: Bearer '.$key],CURLOPT_TIMEOUT=>15,CURLOPT_SSL_VERIFYPEER=>false]);
        $res=curl_exec($ch);curl_close($ch);
        $d=json_decode($res,true);
        $gen=$d['generations_by_pk']??null;
        if ($gen&&($gen['status']??'')==='COMPLETE') {
            foreach($gen['generated_images']??[] as $img) { if(!empty($img['motionMP4URL'])){$url=$img['motionMP4URL'];break;} if(!empty($img['url'])&&!$url)$url=$img['url']; }
            if(!$url)$url=$gen['videoUrl']??'';
        } elseif($gen&&($gen['status']??'')==='FAILED'){DB::execute("UPDATE video_generation_logs SET status='failed' WHERE id=?",[$logId]);echo json_encode(['status'=>'failed']);exit;}
    }
    if ($url) { DB::execute("UPDATE video_generation_logs SET status='completed',video_url=?,updated_at=NOW() WHERE id=?",[$url,$logId]); echo json_encode(['status'=>'completed','video_url'=>$url]); }
    else { echo json_encode(['status'=>'processing']); }
} catch (Throwable $e) { echo json_encode(['status'=>'processing']); }
