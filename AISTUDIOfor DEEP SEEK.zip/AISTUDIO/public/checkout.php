<?php
define('ROOT', dirname(__DIR__));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();
Auth::requireLogin('/aistudio/public/login.php');

$user    = Auth::user();
$planId  = (int)($_GET['plan'] ?? 0);
$csrf    = Security::generateCsrfToken();
$msg     = '';
$error   = '';

$plan = DB::queryOne("SELECT * FROM subscription_plans WHERE id=? AND is_active=1", [$planId]);
if (!$plan) {
    header('Location: /aistudio/public/pricing.php');
    exit;
}

$pkrRate    = (float)ThemeEngine::get('pkr_rate','278');
$amountPkr  = round($plan['price_usd'] * $pkrRate, 0);

// Get payment account info from settings
$settings = [];
$rows = DB::query("SELECT `key`,`value` FROM theme_settings WHERE `key` IN ('jazzcash_merchant','easypaisa_account','bank_account_name','bank_account_no','bank_name')");
foreach ($rows as $r) $settings[$r['key']] = $r['value'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();

    $gateway    = in_array($_POST['gateway'] ?? '', ['jazzcash','easypaisa','nayapay','bank_transfer']) ? $_POST['gateway'] : '';
    $gatewayRef = Security::sanitizeRaw($_POST['gateway_ref'] ?? '');
    $couponCode = strtoupper(trim($_POST['coupon'] ?? ''));

    if (!$gateway) {
        $error = 'Please select a payment method.';
    } else {
        // Coupon check
        $discount   = 0;
        $couponId   = null;
        $finalPrice = $plan['price_usd'];

        if ($couponCode) {
            $coupon = DB::queryOne(
                "SELECT * FROM coupons WHERE code=? AND is_active=1
                 AND (max_uses IS NULL OR used_count < max_uses)
                 AND (valid_from IS NULL OR valid_from <= NOW())
                 AND (valid_until IS NULL OR valid_until >= NOW())",
                [$couponCode]
            );
            if ($coupon) {
                if ($coupon['discount_type'] === 'percent') {
                    $discount   = $plan['price_usd'] * ($coupon['discount_value'] / 100);
                } else {
                    $discount   = min($coupon['discount_value'], $plan['price_usd']);
                }
                $finalPrice = max(0, $plan['price_usd'] - $discount);
                $couponId   = $coupon['id'];
            } else {
                $error = 'Invalid or expired coupon code.';
            }
        }

        if (!$error) {
            // Handle screenshot upload
            $screenshotUrl = null;
            if (!empty($_FILES['screenshot']['name'])) {
                $ext = strtolower(pathinfo($_FILES['screenshot']['name'], PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg','jpeg','png','webp','pdf']) && $_FILES['screenshot']['size'] < 5242880) {
                    $dir  = ROOT . '/public/assets/img/payments/';
                    if (!is_dir($dir)) mkdir($dir, 0755, true);
                    $fname = 'pay_' . time() . '_' . $user['id'] . '.' . $ext;
                    move_uploaded_file($_FILES['screenshot']['tmp_name'], $dir . $fname);
                    $screenshotUrl = '/aistudio/public/assets/img/payments/' . $fname;
                }
            }

            // Save payment record
            $payId = DB::insert(
                "INSERT INTO payments (user_id,plan_id,coupon_id,amount_usd,amount_pkr,gateway,gateway_ref,screenshot_url,status)
                 VALUES (?,?,?,?,?,?,?,?,'pending')",
                [$user['id'], $plan['id'], $couponId, $finalPrice,
                 round($finalPrice * $pkrRate, 2), $gateway,
                 $gatewayRef ?: null, $screenshotUrl]
            );

            // Update coupon usage
            if ($couponId) {
                DB::execute("UPDATE coupons SET used_count = used_count+1 WHERE id=?", [$couponId]);
            }

            $msg = "Payment submitted! Your order #{$payId} is pending admin verification. You'll receive access once verified.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Checkout — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d0d1a;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex;align-items:flex-start;justify-content:center;padding:2rem 1rem}
.wrap{width:100%;max-width:520px}
.back{display:inline-flex;align-items:center;gap:6px;color:#9b9bc0;text-decoration:none;font-size:13px;margin-bottom:1.5rem;transition:color .2s}
.back:hover{color:#a78bfa}
h1{font-size:22px;font-weight:600;margin-bottom:1.5rem}
.plan-summary{background:rgba(167,139,250,.08);border:.5px solid rgba(167,139,250,.2);border-radius:14px;padding:1.25rem;margin-bottom:1.5rem}
.plan-summary h3{font-size:13px;color:#9b9bc0;margin-bottom:.75rem;font-weight:500}
.plan-row{display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:14px;border-top:.5px solid rgba(255,255,255,.06)}
.plan-row:first-of-type{border-top:none}
.plan-row .label{color:#9b9bc0}
.plan-row .val{font-weight:500;color:#f1f1ff}
.plan-row.total .val{color:#a78bfa;font-size:18px;font-weight:600}
.card{background:rgba(255,255,255,.04);border:.5px solid rgba(167,139,250,.12);border-radius:14px;padding:1.25rem;margin-bottom:1.25rem}
.card-title{font-size:14px;font-weight:500;margin-bottom:1rem;display:flex;align-items:center;gap:7px;color:#f1f1ff}
.card-title i{color:#a78bfa;font-size:17px}
.form-group{margin-bottom:14px}
.form-label{display:block;font-size:12px;font-weight:500;color:#9b9bc0;margin-bottom:5px}
.form-input{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:9px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:14px;padding:10px 13px;outline:none;transition:border-color .2s}
.form-input:focus{border-color:#a78bfa;box-shadow:0 0 0 3px rgba(167,139,250,.1)}
.gw-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:4px}
.gw-card{display:flex;align-items:center;gap:10px;padding:12px;border-radius:10px;border:.5px solid rgba(167,139,250,.15);cursor:pointer;transition:all .2s;background:rgba(255,255,255,.02)}
.gw-card:hover{border-color:rgba(167,139,250,.3);background:rgba(167,139,250,.06)}
.gw-card.selected{border-color:#a78bfa;background:rgba(167,139,250,.1)}
.gw-card input{display:none}
.gw-icon{width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.gw-name{font-size:13px;font-weight:500;color:#f1f1ff}
.gw-sub{font-size:11px;color:#9b9bc0}
.account-info{background:rgba(56,189,248,.06);border:.5px solid rgba(56,189,248,.2);border-radius:10px;padding:12px 14px;margin-bottom:1rem;font-size:13px}
.account-info h4{font-size:12px;color:#38bdf8;font-weight:500;margin-bottom:8px}
.account-row{display:flex;justify-content:space-between;padding:4px 0;border-top:.5px solid rgba(56,189,248,.1);font-size:12px}
.account-row:first-of-type{border-top:none}
.account-row .key{color:#9b9bc0}
.account-row .val{color:#f1f1ff;font-weight:500}
.coupon-row{display:flex;gap:8px}
.coupon-row input{flex:1}
.btn-coupon{padding:10px 16px;background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.25);border-radius:9px;color:#a78bfa;font-size:14px;font-weight:500;cursor:pointer;transition:all .2s;white-space:nowrap}
.btn-coupon:hover{background:rgba(167,139,250,.2)}
.btn-submit{width:100%;padding:13px;background:linear-gradient(135deg,#a78bfa,#7c3aed);border:none;border-radius:10px;color:#fff;font-family:'Inter',sans-serif;font-size:15px;font-weight:500;cursor:pointer;transition:all .2s;display:flex;align-items:center;justify-content:center;gap:8px}
.btn-submit:hover{filter:brightness(1.1)}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:1rem;display:flex;align-items:flex-start;gap:8px}
.alert-success{background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.alert-error{background:rgba(239,68,68,.1);border:.5px solid #ef4444;color:#fca5a5}
.discount-badge{display:inline-block;background:rgba(34,197,94,.12);color:#22c55e;font-size:12px;padding:2px 8px;border-radius:5px;margin-left:6px}
</style>
</head>
<body>
<div class="wrap">
    <a href="/aistudio/public/pricing.php" class="back"><i class="ti ti-arrow-left"></i> Back to pricing</a>
    <h1><i class="ti ti-shopping-cart" style="color:#a78bfa;vertical-align:-3px;margin-right:8px"></i>Checkout</h1>

    <?php if ($msg): ?>
    <div class="alert alert-success">
        <i class="ti ti-check" style="flex-shrink:0;margin-top:2px"></i>
        <div><?= h($msg) ?><br><a href="/aistudio/public/dashboard.php" style="color:#22c55e;font-weight:500;margin-top:4px;display:inline-block">Go to dashboard →</a></div>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <div class="alert alert-error"><i class="ti ti-alert-circle"></i><?= h($error) ?></div>
    <?php endif; ?>

    <?php if (!$msg): ?>
    <!-- Plan summary -->
    <div class="plan-summary">
        <h3>Order summary</h3>
        <div class="plan-row">
            <span class="label"><?= h($plan['name']) ?> Plan</span>
            <span class="val">$<?= number_format($plan['price_usd'],2) ?></span>
        </div>
        <div class="plan-row">
            <span class="label">Duration</span>
            <span class="val"><?= $plan['duration_days'] ?> days</span>
        </div>
        <div class="plan-row">
            <span class="label">Credits</span>
            <span class="val"><?= number_format($plan['credits_included']) ?> credits</span>
        </div>
        <div class="plan-row total" id="totalRow">
            <span class="label">Total</span>
            <span class="val">
                $<?= number_format($plan['price_usd'],2) ?>
                <span style="font-size:13px;color:#9b9bc0;font-weight:400">&nbsp;/&nbsp;Rs <?= number_format($amountPkr,0) ?></span>
            </span>
        </div>
    </div>

    <form method="POST" enctype="multipart/form-data" id="checkoutForm">
        <input type="hidden" name="_csrf" value="<?= h($csrf) ?>">

        <!-- Coupon -->
        <div class="card">
            <div class="card-title"><i class="ti ti-discount"></i>Coupon code (optional)</div>
            <div class="coupon-row">
                <input type="text" name="coupon" id="couponInput" class="form-input" placeholder="Enter coupon code" style="text-transform:uppercase" maxlength="30">
                <button type="button" class="btn-coupon" onclick="applyCoupon()">Apply</button>
            </div>
            <div id="couponMsg" style="font-size:12px;margin-top:6px"></div>
        </div>

        <!-- Payment method -->
        <div class="card">
            <div class="card-title"><i class="ti ti-credit-card"></i>Payment method</div>
            <div class="gw-grid">
                <label class="gw-card" onclick="selectGw(this,'jazzcash')">
                    <input type="radio" name="gateway" value="jazzcash">
                    <div class="gw-icon" style="background:rgba(255,100,0,.15);color:#ff6400">
                        <i class="ti ti-device-mobile"></i>
                    </div>
                    <div><div class="gw-name">JazzCash</div><div class="gw-sub">Mobile wallet</div></div>
                </label>
                <label class="gw-card" onclick="selectGw(this,'easypaisa')">
                    <input type="radio" name="gateway" value="easypaisa">
                    <div class="gw-icon" style="background:rgba(0,180,0,.12);color:#00b400">
                        <i class="ti ti-device-mobile-dollar"></i>
                    </div>
                    <div><div class="gw-name">Easypaisa</div><div class="gw-sub">Mobile wallet</div></div>
                </label>
                <label class="gw-card" onclick="selectGw(this,'nayapay')">
                    <input type="radio" name="gateway" value="nayapay">
                    <div class="gw-icon" style="background:rgba(56,189,248,.12);color:#38bdf8">
                        <i class="ti ti-wallet"></i>
                    </div>
                    <div><div class="gw-name">NayaPay</div><div class="gw-sub">Digital wallet</div></div>
                </label>
                <label class="gw-card" onclick="selectGw(this,'bank_transfer')">
                    <input type="radio" name="gateway" value="bank_transfer">
                    <div class="gw-icon" style="background:rgba(167,139,250,.12);color:#a78bfa">
                        <i class="ti ti-building-bank"></i>
                    </div>
                    <div><div class="gw-name">Bank Transfer</div><div class="gw-sub">Direct transfer</div></div>
                </label>
            </div>
        </div>

        <!-- Payment details (shown after selecting method) -->
        <div id="payDetails" style="display:none">
            <div class="account-info" id="accountInfo"></div>

            <div class="card">
                <div class="card-title"><i class="ti ti-file-upload"></i>Payment confirmation</div>
                <div class="form-group">
                    <label class="form-label">Transaction ID / Reference number (optional)</label>
                    <input type="text" name="gateway_ref" class="form-input" placeholder="e.g. TXN123456789">
                </div>
                <div class="form-group">
                    <label class="form-label">Payment screenshot <span style="color:#ef4444">*</span></label>
                    <input type="file" name="screenshot" class="form-input" accept=".jpg,.jpeg,.png,.webp,.pdf" required>
                    <div style="font-size:11px;color:#6b6b90;margin-top:4px">Upload screenshot of your payment — JPG/PNG/PDF, max 5MB</div>
                </div>
                <button type="submit" class="btn-submit">
                    <i class="ti ti-send"></i> Submit Payment for Verification
                </button>
                <div style="font-size:12px;color:#6b6b90;text-align:center;margin-top:10px">
                    <i class="ti ti-clock" style="vertical-align:-2px"></i>
                    Admin will verify within 24 hours. You'll receive access immediately after verification.
                </div>
            </div>
        </div>
    </form>
    <?php endif; ?>
</div>

<script>
const pkrRate   = <?= $pkrRate ?>;
const planPrice = <?= $plan['price_usd'] ?>;
let discount    = 0;

const accountDetails = {
    jazzcash:      { title: 'JazzCash Account', rows: [['Account title','<?= h($settings['jazzcash_merchant'] ?: 'Contact admin') ?>'],['Amount','Rs <?= number_format($amountPkr,0) ?>'],['Note','Send exact amount and keep screenshot']] },
    easypaisa:     { title: 'Easypaisa Account', rows: [['Account number','<?= h($settings['easypaisa_account'] ?: 'Contact admin') ?>'],['Amount','Rs <?= number_format($amountPkr,0) ?>'],['Note','Send exact amount and keep screenshot']] },
    nayapay:       { title: 'NayaPay Account', rows: [['Account','Contact admin for NayaPay details'],['Amount','Rs <?= number_format($amountPkr,0) ?>']] },
    bank_transfer: { title: 'Bank Transfer Details', rows: [['Bank name','<?= h($settings['bank_name'] ?: 'Contact admin') ?>'],['Account title','<?= h($settings['bank_account_name'] ?: 'Contact admin') ?>'],['Account number','<?= h($settings['bank_account_no'] ?: 'Contact admin') ?>'],['Amount','Rs <?= number_format($amountPkr,0) ?>'],['Note','Use your name as reference']] },
};

function selectGw(el, gw) {
    document.querySelectorAll('.gw-card').forEach(c => c.classList.remove('selected'));
    el.classList.add('selected');
    el.querySelector('input').checked = true;

    const det = accountDetails[gw];
    let html = `<h4><i class="ti ti-info-circle"></i> ${det.title}</h4>`;
    det.rows.forEach(([k,v]) => html += `<div class="account-row"><span class="key">${k}</span><span class="val">${v}</span></div>`);
    document.getElementById('accountInfo').innerHTML = html;
    document.getElementById('payDetails').style.display = 'block';
}

async function applyCoupon() {
    const code = document.getElementById('couponInput').value.trim().toUpperCase();
    const msg  = document.getElementById('couponMsg');
    if (!code) return;

    try {
        const res  = await fetch('/aistudio/public/api/check-coupon.php?code=' + encodeURIComponent(code) + '&plan=<?= $plan['id'] ?>');
        const data = await res.json();
        if (data.valid) {
            discount = data.discount;
            const final = Math.max(0, planPrice - discount);
            msg.innerHTML = `<span style="color:#22c55e"><i class="ti ti-check"></i> Coupon applied! You save $${discount.toFixed(2)}</span>`;
            document.getElementById('totalRow').querySelector('.val').innerHTML =
                `$${final.toFixed(2)} <span style="font-size:13px;color:#9b9bc0;font-weight:400">&nbsp;/&nbsp;Rs ${Math.round(final*pkrRate).toLocaleString()}</span> <span class="discount-badge">-${data.percent ? data.discount_value+'%' : '$'+data.discount_value}</span>`;
        } else {
            msg.innerHTML = `<span style="color:#ef4444"><i class="ti ti-x"></i> ${data.error || 'Invalid coupon'}</span>`;
        }
    } catch(e) {
        msg.innerHTML = '<span style="color:#ef4444">Could not check coupon</span>';
    }
}
</script>
</body>
</html>
