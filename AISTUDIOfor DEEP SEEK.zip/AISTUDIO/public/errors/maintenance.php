<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Maintenance</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:system-ui,sans-serif;
     min-height:100vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:2rem}
h1{font-size:2rem;font-weight:600;color:#a78bfa;margin-bottom:1rem}
p{color:#9b9bc0;font-size:1rem}
</style>
</head>
<body>
<div>
  <h1>&#9670; Under Maintenance</h1>
  <p>We'll be back soon. Thank you for your patience.</p>
</div>
</body>
</html>
