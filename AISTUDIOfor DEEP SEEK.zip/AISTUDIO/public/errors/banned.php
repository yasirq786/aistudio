<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Access Banned</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:system-ui,sans-serif;
     min-height:100vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:2rem}
h1{font-size:3rem;font-weight:700;color:#ef4444}
p{color:#9b9bc0;margin:1rem 0;font-size:1rem}
</style>
</head>
<body>
<div>
  <h1>Access Denied</h1>
  <p>Your IP address has been banned. Contact support if you think this is a mistake.</p>
</div>
</body>
</html>
