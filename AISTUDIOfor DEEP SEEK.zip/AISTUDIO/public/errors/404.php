<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>404 — Not Found</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:system-ui,sans-serif;
     min-height:100vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:2rem}
h1{font-size:5rem;font-weight:700;color:#a78bfa;line-height:1}
p{color:#9b9bc0;margin:1rem 0 1.5rem;font-size:1rem}
a{display:inline-block;padding:10px 24px;background:#a78bfa;color:#000;border-radius:8px;
  text-decoration:none;font-weight:500;font-size:14px}
</style>
</head>
<body>
<div>
  <h1>404</h1>
  <p>Page not found.</p>
  <a href="/aistudio/public/dashboard.php">← Go to Dashboard</a>
</div>
</body>
</html>
