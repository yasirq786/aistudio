<?php
// AIStudio — ai-email tool
// Uses universal tool template
$toolSlug = 'ai-email';
require_once __DIR__ . '/_universal.php';
