<?php
// AIStudio — ai-blogger tool
// Uses universal tool template
$toolSlug = 'ai-blogger';
require_once __DIR__ . '/_universal.php';
