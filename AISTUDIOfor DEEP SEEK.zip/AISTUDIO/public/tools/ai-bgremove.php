<?php
// AIStudio — ai-bgremove tool
// Uses universal tool template
$toolSlug = 'ai-bgremove';
require_once __DIR__ . '/_universal.php';
