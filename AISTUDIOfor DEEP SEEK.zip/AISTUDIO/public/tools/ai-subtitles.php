<?php
// AIStudio — ai-subtitles tool
// Uses universal tool template
$toolSlug = 'ai-subtitles';
require_once __DIR__ . '/_universal.php';
