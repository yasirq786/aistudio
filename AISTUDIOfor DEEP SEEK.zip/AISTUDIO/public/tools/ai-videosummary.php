<?php
// AIStudio — ai-videosummary tool
// Uses universal tool template
$toolSlug = 'ai-videosummary';
require_once __DIR__ . '/_universal.php';
