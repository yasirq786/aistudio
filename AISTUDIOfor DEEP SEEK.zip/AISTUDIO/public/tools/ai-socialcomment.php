<?php
// AIStudio — ai-socialcomment tool
// Uses universal tool template
$toolSlug = 'ai-socialcomment';
require_once __DIR__ . '/_universal.php';
