<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';

Security::startSession();
Security::checkIpBan();
Auth::requireLogin('/aistudio/public/login.php');

$user = Auth::user();

// Get tool info
$tool = DB::queryOne("SELECT * FROM tools WHERE slug='ai-chat' AND is_enabled=1");
if (!$tool) {
    header('Location: /aistudio/public/dashboard.php');
    exit;
}

// Get available API services for this tool
$services = DB::query(
    "SELECT * FROM api_services WHERE tool_id=? AND is_enabled=1 ORDER BY sort_order ASC",
    [$tool['id']]
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AI Chat — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d0d1a;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}

/* Sidebar */
.sidebar{
    width:64px;min-height:100vh;background:#08080f;
    border-right:.5px solid rgba(167,139,250,.1);
    display:flex;flex-direction:column;
    position:fixed;left:0;top:0;
    transition:width .25s ease;overflow:hidden;z-index:100;
}
.sidebar:hover{width:220px}
.sidebar-logo{
    padding:16px 14px 20px;font-size:17px;font-weight:600;
    white-space:nowrap;overflow:hidden;
    background:linear-gradient(135deg,#a78bfa,#38bdf8);
    -webkit-background-clip:text;-webkit-text-fill-color:transparent;
}
.tool-btn{
    display:flex;align-items:center;gap:12px;padding:10px 14px;
    color:#9b9bc0;text-decoration:none;white-space:nowrap;
    transition:all .15s;font-size:13px;border-left:2px solid transparent;
}
.tool-btn i{font-size:19px;flex-shrink:0;min-width:20px}
.tool-btn:hover{color:#a78bfa;background:rgba(167,139,250,.07);border-left-color:rgba(167,139,250,.3)}
.tool-btn.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.tool-label{opacity:0;transition:opacity .2s;font-size:13px}
.sidebar:hover .tool-label{opacity:1}
.sep{height:.5px;background:rgba(167,139,250,.1);margin:6px 14px}

/* Main layout */
.main{margin-left:64px;flex:1;display:flex;flex-direction:column;height:100vh}

/* Topbar */
.topbar{
    height:54px;display:flex;align-items:center;justify-content:space-between;
    padding:0 1.25rem;border-bottom:.5px solid rgba(167,139,250,.1);
    background:rgba(8,8,15,.9);backdrop-filter:blur(10px);flex-shrink:0;
}
.topbar-left{display:flex;align-items:center;gap:10px}
.tool-title{font-size:15px;font-weight:500}
.info-btn{
    width:22px;height:22px;border-radius:50%;
    background:rgba(167,139,250,.15);border:.5px solid rgba(167,139,250,.3);
    color:#a78bfa;font-size:12px;cursor:pointer;
    display:flex;align-items:center;justify-content:center;
    transition:all .2s;flex-shrink:0;
}
.info-btn:hover{background:rgba(167,139,250,.25)}
.credit-pill{
    display:flex;align-items:center;gap:5px;padding:4px 12px;
    background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.2);
    border-radius:20px;font-size:12px;font-weight:500;color:#a78bfa;
}

/* Chat area */
.chat-wrap{display:flex;flex:1;overflow:hidden}

/* API selector panel */
.api-panel{
    width:220px;flex-shrink:0;
    border-right:.5px solid rgba(167,139,250,.1);
    background:rgba(8,8,15,.6);
    padding:14px;overflow-y:auto;
    display:flex;flex-direction:column;gap:10px;
}
.api-panel-title{font-size:11px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px}
.api-chip{
    display:flex;align-items:center;gap:10px;
    padding:10px 12px;border-radius:10px;
    border:.5px solid rgba(167,139,250,.15);
    background:rgba(255,255,255,.03);
    cursor:pointer;transition:all .2s;
}
.api-chip:hover{background:rgba(167,139,250,.08);border-color:rgba(167,139,250,.3)}
.api-chip.selected{
    background:rgba(167,139,250,.12);
    border-color:#a78bfa;
}
.api-chip-icon{
    width:32px;height:32px;border-radius:8px;
    background:rgba(167,139,250,.15);
    display:flex;align-items:center;justify-content:center;
    font-size:15px;color:#a78bfa;flex-shrink:0;font-weight:600;
}
.api-chip-name{font-size:13px;font-weight:500;color:#f1f1ff}
.api-chip-cost{font-size:11px;color:#9b9bc0}
.api-chip.selected .api-chip-name{color:#a78bfa}
.active-dot{
    width:7px;height:7px;border-radius:50%;
    background:#22c55e;margin-left:auto;flex-shrink:0;
}

/* Settings section */
.settings-section{margin-top:8px}
.settings-label{font-size:11px;color:#6b6b90;margin-bottom:6px;font-weight:500;text-transform:uppercase;letter-spacing:.05em}
.select-input{
    width:100%;background:rgba(255,255,255,.05);
    border:.5px solid rgba(167,139,250,.2);border-radius:8px;
    color:#f1f1ff;font-size:12px;padding:7px 10px;outline:none;
    font-family:'Inter',sans-serif;cursor:pointer;
}
.range-wrap{display:flex;align-items:center;gap:8px;margin-bottom:4px}
.range-wrap input{flex:1;accent-color:#a78bfa}
.range-val{font-size:12px;color:#a78bfa;min-width:28px;text-align:right}

/* Chat messages */
.chat-main{flex:1;display:flex;flex-direction:column;overflow:hidden}
.messages{flex:1;overflow-y:auto;padding:1.25rem;display:flex;flex-direction:column;gap:12px}
.messages::-webkit-scrollbar{width:4px}
.messages::-webkit-scrollbar-thumb{background:rgba(167,139,250,.2);border-radius:2px}

.msg{display:flex;gap:10px;max-width:85%}
.msg.user{align-self:flex-end;flex-direction:row-reverse}
.msg-avatar{
    width:30px;height:30px;border-radius:50%;
    display:flex;align-items:center;justify-content:center;
    font-size:13px;font-weight:600;flex-shrink:0;
}
.msg.user .msg-avatar{background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff}
.msg.ai   .msg-avatar{background:rgba(167,139,250,.15);color:#a78bfa}
.msg-bubble{
    padding:10px 14px;border-radius:14px;font-size:14px;line-height:1.6;
    max-width:100%;word-wrap:break-word;
}
.msg.user .msg-bubble{
    background:linear-gradient(135deg,rgba(167,139,250,.25),rgba(124,58,237,.2));
    border:.5px solid rgba(167,139,250,.3);border-radius:14px 4px 14px 14px;
}
.msg.ai .msg-bubble{
    background:rgba(255,255,255,.05);
    border:.5px solid rgba(255,255,255,.08);border-radius:4px 14px 14px 14px;
}
.msg-time{font-size:10px;color:#6b6b90;margin-top:4px;padding:0 4px}
.msg.user .msg-time{text-align:right}

/* Typing indicator */
.typing{display:flex;gap:4px;align-items:center;padding:12px 16px}
.typing span{width:6px;height:6px;border-radius:50%;background:#a78bfa;animation:typingDot 1.2s infinite}
.typing span:nth-child(2){animation-delay:.2s}
.typing span:nth-child(3){animation-delay:.4s}
@keyframes typingDot{0%,60%,100%{opacity:.3;transform:scale(.8)}30%{opacity:1;transform:scale(1)}}

/* Welcome screen */
.welcome{
    flex:1;display:flex;flex-direction:column;
    align-items:center;justify-content:center;
    text-align:center;padding:2rem;
    color:#9b9bc0;
}
.welcome-icon{
    width:64px;height:64px;border-radius:20px;
    background:rgba(167,139,250,.1);
    border:.5px solid rgba(167,139,250,.2);
    display:flex;align-items:center;justify-content:center;
    font-size:32px;color:#a78bfa;margin-bottom:16px;
}
.welcome h2{font-size:18px;font-weight:500;color:#f1f1ff;margin-bottom:8px}
.welcome p{font-size:13px;line-height:1.6;max-width:300px}
.starter-prompts{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:16px}
.starter-btn{
    padding:7px 14px;border-radius:8px;font-size:12px;
    background:rgba(167,139,250,.08);border:.5px solid rgba(167,139,250,.2);
    color:#a78bfa;cursor:pointer;transition:all .2s;
}
.starter-btn:hover{background:rgba(167,139,250,.15)}

/* Input area */
.input-area{
    padding:12px 16px;
    border-top:.5px solid rgba(167,139,250,.1);
    background:rgba(8,8,15,.8);backdrop-filter:blur(10px);
    flex-shrink:0;
}
.input-cost{font-size:11px;color:#6b6b90;margin-bottom:6px;display:flex;align-items:center;gap:4px}
.input-row{display:flex;gap:8px;align-items:flex-end}
.msg-input{
    flex:1;background:rgba(255,255,255,.05);
    border:.5px solid rgba(167,139,250,.2);border-radius:12px;
    color:#f1f1ff;font-family:'Inter',sans-serif;font-size:14px;
    padding:10px 14px;outline:none;resize:none;
    transition:border-color .2s;min-height:44px;max-height:120px;line-height:1.5;
}
.msg-input:focus{border-color:#a78bfa;box-shadow:0 0 0 3px rgba(167,139,250,.1)}
.msg-input::placeholder{color:#6b6b90}
.send-btn{
    width:44px;height:44px;border-radius:12px;
    background:linear-gradient(135deg,#a78bfa,#7c3aed);
    border:none;color:#fff;font-size:18px;cursor:pointer;
    display:flex;align-items:center;justify-content:center;
    flex-shrink:0;transition:all .2s;
}
.send-btn:hover{filter:brightness(1.1);transform:translateY(-1px)}
.send-btn:disabled{opacity:.5;cursor:not-allowed;transform:none}
.send-btn.loading{background:rgba(167,139,250,.3)}
.credit-warn{
    padding:8px 14px;border-radius:8px;font-size:12px;
    background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);
    color:#fca5a5;margin-bottom:8px;display:flex;align-items:center;gap:6px;
}

/* Info panel */
.info-panel{
    position:fixed;right:-360px;top:0;width:340px;height:100vh;
    background:#0d0d1a;border-left:.5px solid rgba(167,139,250,.2);
    padding:1.5rem;overflow-y:auto;transition:right .3s ease;z-index:200;
}
.info-panel.open{right:0}
.info-close{
    position:absolute;top:14px;right:14px;background:none;
    border:none;color:#9b9bc0;font-size:20px;cursor:pointer;
}
.info-panel h3{font-size:16px;font-weight:500;margin-bottom:4px}
.info-panel p{font-size:13px;color:#9b9bc0;line-height:1.6;margin-bottom:12px}
.info-section{margin-bottom:1rem}
.info-section h4{font-size:12px;font-weight:500;color:#a78bfa;margin-bottom:6px;text-transform:uppercase;letter-spacing:.05em}
.info-item{font-size:13px;color:#9b9bc0;padding:4px 0;display:flex;align-items:center;gap:6px;border-top:.5px solid rgba(255,255,255,.04)}
.info-item:first-of-type{border-top:none}
.info-item i{color:#a78bfa;font-size:14px}

/* Mobile */
@media(max-width:768px){
    .sidebar{display:none}
    .main{margin-left:0}
    .api-panel{display:none}
    .chat-wrap{flex-direction:column}
}
</style>
</head>
<body>

<!-- Sidebar with all tools -->
<nav class="sidebar" aria-label="Tools">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?></div>
    <?php
    $allTools = DB::query("SELECT * FROM tools WHERE is_visible_on_landing=1 ORDER BY sort_order ASC");
    foreach ($allTools as $t):
        $active = $t['slug'] === 'ai-chat' ? ' active' : '';
        $href   = '/aistudio/public/tools/' . h($t['slug']) . '.php';
    ?>
    <a href="<?= $href ?>" class="tool-btn<?= $active ?>" title="<?= h($t['name']) ?>">
        <i class="ti <?= h($t['icon']) ?>" aria-hidden="true"></i>
        <span class="tool-label"><?= h($t['name']) ?></span>
    </a>
    <?php endforeach; ?>
    <div class="sep"></div>
    <a href="/aistudio/public/dashboard.php" class="tool-btn">
        <i class="ti ti-layout-dashboard" aria-hidden="true"></i>
        <span class="tool-label">Dashboard</span>
    </a>
    <a href="/aistudio/public/logout.php" class="tool-btn" style="margin-top:auto">
        <i class="ti ti-logout" aria-hidden="true"></i>
        <span class="tool-label">Logout</span>
    </a>
</nav>

<!-- Main -->
<div class="main">
    <!-- Topbar -->
    <header class="topbar">
        <div class="topbar-left">
            <i class="ti ti-message-circle" style="font-size:18px;color:#a78bfa" aria-hidden="true"></i>
            <span class="tool-title">AI Chat Assistant</span>
            <button class="info-btn" onclick="toggleInfo()" aria-label="Tool info" title="How to use">i</button>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
            <div class="credit-pill">
                <i class="ti ti-coin" aria-hidden="true"></i>
                <span id="creditBal"><?= number_format($user['credit_balance']) ?></span> cr
            </div>
            <button onclick="clearChat()" style="background:none;border:.5px solid rgba(167,139,250,.2);
                    color:#9b9bc0;padding:5px 12px;border-radius:7px;cursor:pointer;font-size:12px;
                    font-family:inherit;transition:all .2s"
                    onmouseover="this.style.borderColor='#a78bfa';this.style.color='#a78bfa'"
                    onmouseout="this.style.borderColor='rgba(167,139,250,.2)';this.style.color='#9b9bc0'">
                <i class="ti ti-trash" aria-hidden="true"></i> Clear
            </button>
        </div>
    </header>

    <div class="chat-wrap">

        <!-- API selector panel -->
        <aside class="api-panel" aria-label="API selection">
            <div class="api-panel-title">Select AI Provider</div>

            <?php if (empty($services)): ?>
            <div style="font-size:12px;color:#6b6b90;text-align:center;padding:1rem">
                No API services configured.<br>
                <a href="/aistudio/public/admin/apis.php" style="color:#a78bfa">Add in Admin Panel →</a>
            </div>
            <?php else: ?>
            <?php foreach ($services as $i => $svc):
                $selected = $i === 0 ? ' selected' : '';
                $initial  = strtoupper(substr($svc['name'], 0, 2));
            ?>
            <div class="api-chip<?= $selected ?>"
                 onclick="selectApi(this, <?= $svc['id'] ?>, <?= $svc['credit_cost'] ?>, '<?= h($svc['name']) ?>')"
                 data-id="<?= $svc['id'] ?>"
                 data-cost="<?= $svc['credit_cost'] ?>">
                <div class="api-chip-icon"><?= $initial ?></div>
                <div style="flex:1;min-width:0">
                    <div class="api-chip-name"><?= h($svc['name']) ?></div>
                    <div class="api-chip-cost"><?= $svc['credit_cost'] ?> cr/msg</div>
                </div>
                <?php if ($selected): ?>
                <div class="active-dot"></div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>

            <!-- Chat settings -->
            <div class="settings-section">
                <div class="settings-label">Settings</div>

                <div style="margin-bottom:10px">
                    <div class="settings-label" style="margin-bottom:4px">Tone</div>
                    <select id="chatTone" class="select-input">
                        <option value="balanced">Balanced</option>
                        <option value="creative">Creative</option>
                        <option value="precise">Precise</option>
                        <option value="friendly">Friendly</option>
                        <option value="formal">Formal</option>
                    </select>
                </div>

                <div style="margin-bottom:10px">
                    <div class="settings-label" style="margin-bottom:4px">Language</div>
                    <select id="chatLang" class="select-input">
                        <option value="en">English</option>
                        <option value="ur">Urdu</option>
                        <option value="auto">Auto detect</option>
                    </select>
                </div>

                <div>
                    <div class="settings-label" style="margin-bottom:4px">
                        Max length
                        <span id="maxLenVal" style="color:#a78bfa;float:right">1000</span>
                    </div>
                    <input type="range" min="200" max="4000" step="100" value="1000"
                           oninput="document.getElementById('maxLenVal').textContent=this.value"
                           style="width:100%;accent-color:#a78bfa">
                </div>
            </div>
        </aside>

        <!-- Chat messages -->
        <div class="chat-main">
            <div class="messages" id="messages">
                <!-- Welcome screen (hidden when chat starts) -->
                <div class="welcome" id="welcomeScreen">
                    <div class="welcome-icon">
                        <i class="ti ti-message-circle" aria-hidden="true"></i>
                    </div>
                    <h2>AI Chat Assistant</h2>
                    <p>Ask anything — coding, writing, analysis, math, or just have a conversation.</p>
                    <div class="starter-prompts">
                        <div class="starter-btn" onclick="useStarter('Explain quantum computing in simple terms')">Explain quantum computing</div>
                        <div class="starter-btn" onclick="useStarter('Write a Python function to sort a list')">Write Python code</div>
                        <div class="starter-btn" onclick="useStarter('What are the best practices for SEO in 2026?')">SEO best practices</div>
                        <div class="starter-btn" onclick="useStarter('Write a professional email to request a meeting')">Professional email</div>
                        <div class="starter-btn" onclick="useStarter('Translate to Urdu: Hello, how are you?')">Translate to Urdu</div>
                        <div class="starter-btn" onclick="useStarter('Give me 5 creative business ideas for 2026')">Business ideas</div>
                    </div>
                </div>
            </div>

            <!-- Input area -->
            <div class="input-area">
                <div id="creditWarn" class="credit-warn" style="display:none">
                    <i class="ti ti-alert-circle" aria-hidden="true"></i>
                    Insufficient credits.
                    <a href="/aistudio/public/billing.php" style="color:#f87171;font-weight:500;margin-left:4px">Top up →</a>
                </div>
                <div class="input-cost">
                    <i class="ti ti-coin" aria-hidden="true"></i>
                    Cost: <span id="costLabel" style="color:#a78bfa;font-weight:500">1 cr</span> per message
                    &nbsp;·&nbsp; Provider: <span id="providerLabel" style="color:#a78bfa">
                        <?= h($services[0]['name'] ?? 'None') ?>
                    </span>
                </div>
                <div class="input-row">
                    <textarea
                        id="msgInput"
                        class="msg-input"
                        placeholder="Type your message... (Enter to send, Shift+Enter for new line)"
                        rows="1"
                        maxlength="4000"
                        aria-label="Chat message input"></textarea>
                    <button class="send-btn" id="sendBtn" onclick="sendMessage()" aria-label="Send message">
                        <i class="ti ti-send" id="sendIcon" aria-hidden="true"></i>
                    </button>
                </div>
            </div>
        </div><!-- end chat-main -->
    </div><!-- end chat-wrap -->
</div><!-- end main -->

<!-- Info panel -->
<div class="info-panel" id="infoPanel" aria-label="Tool information">
    <button class="info-close" onclick="toggleInfo()" aria-label="Close info panel">
        <i class="ti ti-x" aria-hidden="true"></i>
    </button>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:1rem">
        <div style="width:40px;height:40px;border-radius:10px;background:rgba(167,139,250,.15);
                    display:flex;align-items:center;justify-content:center;font-size:20px;color:#a78bfa">
            <i class="ti ti-message-circle" aria-hidden="true"></i>
        </div>
        <div>
            <h3>AI Chat Assistant</h3>
            <div style="font-size:12px;color:#9b9bc0">Multi-provider AI chat</div>
        </div>
    </div>

    <div class="info-section">
        <h4>How to use</h4>
        <div class="info-item"><i class="ti ti-point" aria-hidden="true"></i> Select your preferred AI provider from the left panel</div>
        <div class="info-item"><i class="ti ti-point" aria-hidden="true"></i> Type your message and press Enter or click Send</div>
        <div class="info-item"><i class="ti ti-point" aria-hidden="true"></i> Use Shift+Enter for a new line in your message</div>
        <div class="info-item"><i class="ti ti-point" aria-hidden="true"></i> Adjust tone and language settings in the left panel</div>
    </div>

    <div class="info-section">
        <h4>Features</h4>
        <div class="info-item"><i class="ti ti-check" aria-hidden="true"></i> Multi-turn conversation memory</div>
        <div class="info-item"><i class="ti ti-check" aria-hidden="true"></i> Multiple AI providers — DeepSeek, Groq, GPT, Claude</div>
        <div class="info-item"><i class="ti ti-check" aria-hidden="true"></i> Tone control (creative, precise, formal, friendly)</div>
        <div class="info-item"><i class="ti ti-check" aria-hidden="true"></i> English and Urdu support</div>
        <div class="info-item"><i class="ti ti-check" aria-hidden="true"></i> Code syntax highlighting</div>
        <div class="info-item"><i class="ti ti-check" aria-hidden="true"></i> Copy response with one click</div>
    </div>

    <div class="info-section">
        <h4>Credit cost per message</h4>
        <?php foreach ($services as $svc): ?>
        <div class="info-item">
            <i class="ti ti-coin" aria-hidden="true"></i>
            <?= h($svc['name']) ?> — <strong style="color:#a78bfa"><?= $svc['credit_cost'] ?> cr</strong>
        </div>
        <?php endforeach; ?>
        <?php if (empty($services)): ?>
        <div class="info-item" style="color:#9b9bc0">No services configured yet</div>
        <?php endif; ?>
    </div>

    <?php if ($tool['info_tips']): ?>
    <div class="info-section">
        <h4>Tips</h4>
        <p><?= nl2br(h($tool['info_tips'])) ?></p>
    </div>
    <?php endif; ?>
</div>

<script>
const CSRF   = '<?= Security::generateCsrfToken() ?>';
const BALANCE = <?= (int)$user['credit_balance'] ?>;

let chatHistory    = [];
let selectedApiId  = <?= (int)($services[0]['id'] ?? 0) ?>;
let selectedCost   = <?= (int)($services[0]['credit_cost'] ?? 1) ?>;
let currentBalance = BALANCE;
let isGenerating   = false;

/* Auto-resize textarea */
const input = document.getElementById('msgInput');
input.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 120) + 'px';
});

/* Enter to send */
input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
});

/* Select API provider */
function selectApi(el, id, cost, name) {
    document.querySelectorAll('.api-chip').forEach(c => {
        c.classList.remove('selected');
        const dot = c.querySelector('.active-dot');
        if (dot) dot.remove();
    });
    el.classList.add('selected');
    const dot = document.createElement('div');
    dot.className = 'active-dot';
    el.appendChild(dot);
    selectedApiId   = id;
    selectedCost    = cost;
    document.getElementById('costLabel').textContent    = cost + ' cr';
    document.getElementById('providerLabel').textContent = name;
    checkCredits();
}

function checkCredits() {
    const warn = document.getElementById('creditWarn');
    warn.style.display = currentBalance < selectedCost ? 'flex' : 'none';
}

/* Send message */
async function sendMessage() {
    const msg = input.value.trim();
    if (!msg || isGenerating) return;
    if (currentBalance < selectedCost) {
        document.getElementById('creditWarn').style.display = 'flex';
        return;
    }
    if (!selectedApiId) {
        alert('Please select an AI provider first.');
        return;
    }

    isGenerating = true;
    setLoading(true);

    // Hide welcome screen
    const welcome = document.getElementById('welcomeScreen');
    if (welcome) welcome.style.display = 'none';

    // Add user message
    chatHistory.push({ role: 'user', content: msg });
    appendMessage('user', msg);
    input.value = '';
    input.style.height = 'auto';

    // Show typing indicator
    const typingId = showTyping();

    try {
        const res = await fetch('/aistudio/public/api/chat-handler.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': CSRF,
            },
            body: JSON.stringify({
                api_service_id: selectedApiId,
                message:        msg,
                history:        chatHistory.slice(-10),
                tone:           document.getElementById('chatTone').value,
                language:       document.getElementById('chatLang').value,
                max_tokens:     parseInt(document.getElementById('maxLenVal').textContent),
            }),
        });

        removeTyping(typingId);
        const data = await res.json();

        if (data.success) {
            chatHistory.push({ role: 'assistant', content: data.reply });
            appendMessage('ai', data.reply);
            currentBalance = data.new_balance;
            document.getElementById('creditBal').textContent = currentBalance.toLocaleString();
            checkCredits();
        } else {
            appendMessage('ai', '⚠️ ' + (data.error || 'Something went wrong. Please try again.'), true);
        }
    } catch (err) {
        removeTyping(typingId);
        appendMessage('ai', '⚠️ Network error. Please check your connection.', true);
    }

    isGenerating = false;
    setLoading(false);
}

function appendMessage(role, content, isError = false) {
    const msgs  = document.getElementById('messages');
    const div   = document.createElement('div');
    div.className = 'msg ' + role;

    const initials = role === 'user' ? '<?= strtoupper(substr($user['name'], 0, 1)) ?>' : 'AI';
    const formattedContent = formatContent(content);
    const time = new Date().toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});

    div.innerHTML = `
        <div class="msg-avatar">${initials}</div>
        <div>
            <div class="msg-bubble${isError ? ' style="border-color:rgba(239,68,68,.3)"' : ''}">${formattedContent}</div>
            <div class="msg-time">${time}</div>
        </div>
    `;

    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;

    // Add copy button to AI messages
    if (role === 'ai' && !isError) {
        const copyBtn = document.createElement('button');
        copyBtn.innerHTML = '<i class="ti ti-copy" aria-hidden="true"></i>';
        copyBtn.style.cssText = 'background:none;border:none;color:#6b6b90;cursor:pointer;font-size:13px;margin-top:4px;padding:2px 4px;transition:color .2s';
        copyBtn.title = 'Copy response';
        copyBtn.onclick = () => {
            navigator.clipboard.writeText(content);
            copyBtn.innerHTML = '<i class="ti ti-check" aria-hidden="true"></i>';
            setTimeout(() => copyBtn.innerHTML = '<i class="ti ti-copy" aria-hidden="true"></i>', 2000);
        };
        div.querySelector('.msg-time').appendChild(copyBtn);
    }
}

function formatContent(text) {
    // Code blocks
    text = text.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) =>
        `<pre style="background:rgba(0,0,0,.4);border:.5px solid rgba(167,139,250,.2);
         border-radius:8px;padding:12px;overflow-x:auto;font-size:13px;margin:8px 0;
         font-family:monospace"><code>${escHtml(code.trim())}</code></pre>`
    );
    // Inline code
    text = text.replace(/`([^`]+)`/g, '<code style="background:rgba(167,139,250,.15);padding:1px 5px;border-radius:4px;font-size:13px;font-family:monospace">$1</code>');
    // Bold
    text = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    // New lines
    text = text.replace(/\n/g, '<br>');
    return text;
}

function escHtml(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

let typingCounter = 0;
function showTyping() {
    const id   = 'typing-' + (++typingCounter);
    const msgs = document.getElementById('messages');
    const div  = document.createElement('div');
    div.id = id;
    div.className = 'msg ai';
    div.innerHTML = `<div class="msg-avatar">AI</div>
        <div class="msg-bubble" style="padding:8px 14px">
            <div class="typing"><span></span><span></span><span></span></div>
        </div>`;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
    return id;
}
function removeTyping(id) {
    document.getElementById(id)?.remove();
}

function setLoading(on) {
    const btn  = document.getElementById('sendBtn');
    const icon = document.getElementById('sendIcon');
    btn.disabled   = on;
    btn.classList.toggle('loading', on);
    icon.className = on ? 'ti ti-loader' : 'ti ti-send';
    if (on) {
        let rot = 0;
        icon._timer = setInterval(() => { rot+=10; icon.style.transform=`rotate(${rot}deg)`; }, 30);
    } else {
        clearInterval(icon._timer);
        icon.style.transform = '';
    }
}

function clearChat() {
    chatHistory = [];
    const msgs  = document.getElementById('messages');
    msgs.innerHTML = `<div class="welcome" id="welcomeScreen">
        <div class="welcome-icon"><i class="ti ti-message-circle"></i></div>
        <h2>AI Chat Assistant</h2>
        <p>Ask anything — coding, writing, analysis, math, or just have a conversation.</p>
        <div class="starter-prompts">
            <div class="starter-btn" onclick="useStarter('Explain quantum computing in simple terms')">Explain quantum computing</div>
            <div class="starter-btn" onclick="useStarter('Write a Python function to sort a list')">Write Python code</div>
            <div class="starter-btn" onclick="useStarter('What are the best practices for SEO in 2026?')">SEO best practices</div>
        </div>
    </div>`;
}

function useStarter(text) {
    input.value = text;
    input.dispatchEvent(new Event('input'));
    input.focus();
}

function toggleInfo() {
    document.getElementById('infoPanel').classList.toggle('open');
}

checkCredits();
</script>
</body>
</html>
