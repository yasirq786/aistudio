<?php
// AIStudio — ai-seo tool
// Uses universal tool template
$toolSlug = 'ai-seo';
require_once __DIR__ . '/_universal.php';
