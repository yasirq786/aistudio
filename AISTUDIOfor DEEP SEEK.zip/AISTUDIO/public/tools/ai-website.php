<?php
// AIStudio — ai-website tool
// Uses universal tool template
$toolSlug = 'ai-website';
require_once __DIR__ . '/_universal.php';
