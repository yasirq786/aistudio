<?php
// AIStudio — ai-content tool
// Uses universal tool template
$toolSlug = 'ai-content';
require_once __DIR__ . '/_universal.php';
