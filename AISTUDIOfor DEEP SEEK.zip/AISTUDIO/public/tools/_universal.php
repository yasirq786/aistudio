<?php
/**
 * AIStudio — Universal Tool Template
 * Works for: AI Chat (text), Content Writer, SEO, Code, Blogger,
 * Landing Page, Meta Tags, Social Comment, Email Writer, etc.
 *
 * To create a new tool page, just change $toolSlug below.
 */

define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';

Security::startSession();
Security::checkIpBan();
Auth::requireLogin('/aistudio/public/login.php');

// ── Detect which tool this is from URL ────────────────────────────
$urlPath  = $_SERVER['PHP_SELF'] ?? '';
$fileName = basename($urlPath, '.php');  // e.g. "ai-content"
// Use pre-set slug from individual tool file, or detect from URL
$toolSlug = isset($toolSlug) ? $toolSlug : $fileName;

$user = Auth::user();
$tool = DB::queryOne("SELECT * FROM tools WHERE slug=? AND is_enabled=1", [$toolSlug]);
if (!$tool) {
    header('Location: /aistudio/public/dashboard.php');
    exit;
}

$services = DB::query(
    "SELECT * FROM api_services WHERE tool_id=? AND is_enabled=1 ORDER BY sort_order ASC",
    [$tool['id']]
);

// Tool-specific configurations
$toolConfigs = [
    'ai-content' => [
        'placeholder'  => 'Describe what content you need... e.g. "Write a 500-word blog post about AI trends in 2026"',
        'starters'     => ['Blog post about AI','Product description','Social media caption','Email newsletter','Press release'],
        'settings'     => ['tone','language','length'],
    ],
    'ai-seo' => [
        'placeholder'  => 'Enter your website URL or topic to optimize... e.g. "Analyze SEO for a digital marketing agency"',
        'starters'     => ['SEO audit checklist','Keyword research for fitness','On-page SEO tips','Meta tags for e-commerce'],
        'settings'     => ['language'],
    ],
    'ai-code' => [
        'placeholder'  => 'Describe what code you need... e.g. "Write a Python function to parse JSON and extract emails"',
        'starters'     => ['REST API in Node.js','Python data parser','React login form','SQL query optimizer','Docker compose file'],
        'settings'     => ['language'],
        'output_format'=> 'code',
    ],
    'ai-blogger' => [
        'placeholder'  => 'Enter your blog topic... e.g. "How to start a dropshipping business in 2026"',
        'starters'     => ['How to make money online','Best travel destinations','Health tips for remote workers','AI tools for business'],
        'settings'     => ['tone','language','length'],
    ],
    'ai-landing' => [
        'placeholder'  => 'Describe your product/service... e.g. "SaaS project management tool for remote teams"',
        'starters'     => ['SaaS product landing page','E-commerce store','Mobile app download page','Agency services page'],
        'settings'     => ['tone','language'],
        'output_format'=> 'code',
    ],
    'ai-metatags' => [
        'placeholder'  => 'Enter your page title and description... e.g. "AI image generator platform for creatives"',
        'starters'     => ['E-commerce homepage','Blog about fitness','Agency portfolio','SaaS pricing page'],
        'settings'     => ['language'],
    ],
    'ai-socialcomment' => [
        'placeholder'  => 'Describe the post you want to comment on... e.g. "A post about entrepreneurship tips on LinkedIn"',
        'starters'     => ['LinkedIn business post','Instagram travel photo','Twitter tech announcement','Facebook community post'],
        'settings'     => ['tone','language'],
    ],
    'ai-email' => [
        'placeholder'  => 'Describe the email you need... e.g. "Professional email requesting a meeting with a potential client"',
        'starters'     => ['Meeting request email','Follow-up email','Sales pitch email','Job application email','Apology email'],
        'settings'     => ['tone','language'],
    ],
    'ai-funnel' => [
        'placeholder'  => 'Describe your product/offer for the funnel... e.g. "Online fitness coaching program for beginners"',
        'starters'     => ['Fitness coaching funnel','Online course funnel','E-book lead magnet','Webinar registration funnel'],
        'settings'     => ['tone','language'],
    ],
    'ai-website' => [
        'placeholder'  => 'Describe the website you want to build... e.g. "Modern portfolio website for a photographer"',
        'starters'     => ['Portfolio website','Business landing page','Restaurant website','Agency website'],
        'settings'     => ['language'],
        'output_format'=> 'code',
    ],
    'ai-app' => [
        'placeholder'  => 'Describe the app you want to build... e.g. "A task management mobile app with dark mode"',
        'starters'     => ['Task manager app','Fitness tracker app','E-commerce app','Chat application'],
        'settings'     => ['language'],
        'output_format'=> 'code',
    ],
    'ai-videosummary' => [
        'placeholder'  => 'Paste YouTube URL or video transcript to summarize...',
        'starters'     => ['Summarize a tech talk','Key points from a tutorial','Meeting transcript summary'],
        'settings'     => ['language','length'],
    ],
    'ai-subtitles' => [
        'placeholder'  => 'Paste your video transcript or audio text to generate subtitles...',
        'starters'     => ['Generate SRT subtitles','Convert transcript to captions','Add timestamps to text'],
        'settings'     => ['language'],
    ],
    'ai-socialmedia' => [
        'placeholder'  => 'Describe what you want to post... e.g. "Motivational post about entrepreneurship for LinkedIn"',
        'starters'     => ['LinkedIn post','Instagram caption','Twitter thread','Facebook post','TikTok caption'],
        'settings'     => ['tone','language'],
    ],
];

$config      = $toolConfigs[$toolSlug] ?? [
    'placeholder' => 'Enter your request...',
    'starters'    => [],
    'settings'    => ['tone','language'],
];
$isCodeOutput = ($config['output_format'] ?? '') === 'code';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= h($tool['name']) ?> — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/atom-one-dark.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d0d1a;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:64px;min-height:100vh;background:#08080f;border-right:.5px solid rgba(167,139,250,.1);display:flex;flex-direction:column;position:fixed;left:0;top:0;transition:width .25s;overflow:hidden;z-index:100}
.sidebar:hover{width:220px}
.sidebar-logo{padding:16px 14px 20px;font-size:17px;font-weight:600;white-space:nowrap;overflow:hidden;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.tool-btn{display:flex;align-items:center;gap:12px;padding:10px 14px;color:#9b9bc0;text-decoration:none;white-space:nowrap;transition:all .15s;font-size:13px;border-left:2px solid transparent}
.tool-btn i{font-size:19px;flex-shrink:0;min-width:20px}
.tool-btn:hover{color:#a78bfa;background:rgba(167,139,250,.07)}
.tool-btn.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.tool-label{opacity:0;transition:opacity .2s}
.sidebar:hover .tool-label{opacity:1}
.sep{height:.5px;background:rgba(167,139,250,.1);margin:6px 14px}
.main{margin-left:64px;flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden}
.topbar{height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 1.25rem;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.9);flex-shrink:0;z-index:50}
.tool-title{font-size:15px;font-weight:500;display:flex;align-items:center;gap:8px}
.info-btn{width:22px;height:22px;border-radius:50%;background:rgba(167,139,250,.15);border:.5px solid rgba(167,139,250,.3);color:#a78bfa;font-size:12px;cursor:pointer;display:flex;align-items:center;justify-content:center}
.credit-pill{display:flex;align-items:center;gap:5px;padding:4px 12px;background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.2);border-radius:20px;font-size:12px;font-weight:500;color:#a78bfa}
.tool-wrap{display:flex;flex:1;overflow:hidden}

/* Left settings */
.settings-panel{width:220px;flex-shrink:0;border-right:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.6);padding:12px;overflow-y:auto;display:flex;flex-direction:column;gap:8px}
.panel-label{font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.05em;margin-bottom:5px}
.api-chip{display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:9px;border:.5px solid rgba(167,139,250,.15);background:rgba(255,255,255,.02);cursor:pointer;transition:all .2s;margin-bottom:4px}
.api-chip:hover{border-color:rgba(167,139,250,.3);background:rgba(167,139,250,.06)}
.api-chip.selected{background:rgba(167,139,250,.12);border-color:#a78bfa}
.api-chip-icon{width:26px;height:26px;border-radius:6px;background:rgba(167,139,250,.15);display:flex;align-items:center;justify-content:center;font-size:11px;color:#a78bfa;font-weight:700;flex-shrink:0}
.api-chip-name{font-size:12px;font-weight:500;color:#f1f1ff}
.api-chip-cost{font-size:10px;color:#9b9bc0}
.api-chip.selected .api-chip-name{color:#a78bfa}
.active-dot{width:6px;height:6px;border-radius:50%;background:#22c55e;margin-left:auto;flex-shrink:0}
.form-sel{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:7px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:12px;padding:7px 10px;outline:none;cursor:pointer}
.form-sel option{background:#1a1a2e;color:#f1f1ff}
.form-sel:focus{border-color:#a78bfa}

/* Center */
.center-panel{flex:1;display:flex;flex-direction:column;overflow:hidden}
.output-scroll{flex:1;overflow-y:auto;padding:1.25rem;display:flex;flex-direction:column;gap:12px}
.output-scroll::-webkit-scrollbar{width:4px}
.output-scroll::-webkit-scrollbar-thumb{background:rgba(167,139,250,.2);border-radius:2px}

/* Welcome */
.welcome{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:2rem;color:#9b9bc0}
.welcome .icon{width:64px;height:64px;border-radius:18px;background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.2);display:flex;align-items:center;justify-content:center;font-size:30px;color:#a78bfa;margin-bottom:14px}
.welcome h2{font-size:18px;font-weight:500;color:#f1f1ff;margin-bottom:8px}
.starters{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin-top:12px}
.starter-btn{padding:6px 14px;border-radius:8px;font-size:12px;background:rgba(167,139,250,.08);border:.5px solid rgba(167,139,250,.2);color:#a78bfa;cursor:pointer;transition:all .2s}
.starter-btn:hover{background:rgba(167,139,250,.15)}

/* Result */
.result-card{background:rgba(255,255,255,.04);border:.5px solid rgba(167,139,250,.15);border-radius:14px;overflow:hidden}
.result-header{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:.5px solid rgba(167,139,250,.1)}
.result-prompt{font-size:12px;color:#9b9bc0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.result-btns{display:flex;gap:6px}
.act-btn{display:flex;align-items:center;gap:4px;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:500;cursor:pointer;border:none;font-family:'Inter',sans-serif;transition:all .2s;white-space:nowrap}
.act-btn-copy{background:rgba(167,139,250,.12);color:#a78bfa;border:.5px solid rgba(167,139,250,.25)}
.act-btn-dl{background:rgba(34,197,94,.1);color:#22c55e;border:.5px solid rgba(34,197,94,.25)}
.result-body{padding:14px;font-size:14px;line-height:1.8;color:#e0e0f0;white-space:pre-wrap;max-height:500px;overflow-y:auto}
.result-body pre{background:rgba(0,0,0,.4);border-radius:8px;overflow-x:auto;margin:8px 0}
.result-body code{font-family:monospace;font-size:13px}

/* Loading */
.loading-card{background:rgba(255,255,255,.04);border:.5px solid rgba(167,139,250,.15);border-radius:14px;padding:1.5rem;display:flex;align-items:center;gap:12px;color:#9b9bc0;font-size:14px}
.spin{width:20px;height:20px;border:2px solid rgba(167,139,250,.2);border-top-color:#a78bfa;border-radius:50%;animation:spin .7s linear infinite;flex-shrink:0}
@keyframes spin{to{transform:rotate(360deg)}}

/* Input area */
.input-area{padding:12px 16px;border-top:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.8);flex-shrink:0}
.input-cost{font-size:11px;color:#6b6b90;margin-bottom:6px;display:flex;align-items:center;gap:4px}
.input-row{display:flex;gap:8px;align-items:flex-end}
.main-input{flex:1;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:10px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:14px;padding:10px 14px;outline:none;resize:none;transition:border-color .2s;min-height:44px;max-height:140px}
.main-input:focus{border-color:#a78bfa;box-shadow:0 0 0 3px rgba(167,139,250,.1)}
.main-input::placeholder{color:#6b6b90}
.send-btn{width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,#a78bfa,#7c3aed);border:none;color:#fff;font-size:20px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s}
.send-btn:hover{filter:brightness(1.1);transform:translateY(-1px)}
.send-btn:disabled{opacity:.5;cursor:not-allowed;transform:none}
.credit-warn{padding:8px 14px;border-radius:8px;font-size:12px;background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);color:#fca5a5;margin-bottom:8px;display:flex;align-items:center;gap:6px}

/* Info panel */
.info-panel{position:fixed;right:-340px;top:0;width:320px;height:100vh;background:#0d0d1a;border-left:.5px solid rgba(167,139,250,.2);padding:1.5rem;overflow-y:auto;transition:right .3s;z-index:200}
.info-panel.open{right:0}
.info-close{position:absolute;top:14px;right:14px;background:none;border:none;color:#9b9bc0;font-size:20px;cursor:pointer}
.info-section{margin-bottom:1rem}
.info-section h4{font-size:12px;font-weight:500;color:#a78bfa;margin-bottom:6px;text-transform:uppercase;letter-spacing:.05em}
.info-item{font-size:13px;color:#9b9bc0;padding:4px 0;display:flex;align-items:flex-start;gap:6px;border-top:.5px solid rgba(255,255,255,.04)}
.info-item:first-of-type{border-top:none}
.info-item i{color:#a78bfa;font-size:14px;flex-shrink:0;margin-top:1px}

@media(max-width:680px){.sidebar{display:none}.main{margin-left:0}.settings-panel{display:none}}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?></div>
    <?php
    $allTools = DB::query("SELECT * FROM tools WHERE is_visible_on_landing=1 ORDER BY sort_order ASC");
    foreach ($allTools as $t):
        $active = $t['slug'] === $toolSlug ? ' active' : '';
        $href   = '/aistudio/public/tools/' . h($t['slug']) . '.php';
    ?>
    <a href="<?= $href ?>" class="tool-btn<?= $active ?>" title="<?= h($t['name']) ?>">
        <i class="ti <?= h($t['icon']) ?>"></i>
        <span class="tool-label"><?= h($t['name']) ?></span>
    </a>
    <?php endforeach; ?>
    <div class="sep"></div>
    <a href="/aistudio/public/dashboard.php" class="tool-btn"><i class="ti ti-layout-dashboard"></i><span class="tool-label">Dashboard</span></a>
    <a href="/aistudio/public/logout.php" class="tool-btn" style="margin-top:auto"><i class="ti ti-logout"></i><span class="tool-label">Logout</span></a>
</nav>

<div class="main">
    <header class="topbar">
        <div class="tool-title">
            <i class="ti <?= h($tool['icon']) ?>" style="color:#a78bfa;font-size:18px"></i>
            <?= h($tool['name']) ?>
            <button class="info-btn" onclick="toggleInfo()" title="How to use">i</button>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
            <div class="credit-pill"><i class="ti ti-coin"></i><span id="creditBal"><?= number_format($user['credit_balance']) ?></span> cr</div>
        </div>
    </header>

    <div class="tool-wrap">
        <!-- Settings -->
        <aside class="settings-panel">
            <div>
                <div class="panel-label">AI Provider</div>
                <?php if (empty($services)): ?>
                <div style="font-size:12px;color:#6b6b90;text-align:center;padding:.75rem">
                    No APIs configured.<br><a href="/aistudio/public/admin/apis.php" style="color:#a78bfa">Add in Admin →</a>
                </div>
                <?php else: ?>
                <?php foreach ($services as $i => $svc):
                    $sel = $i===0 ? ' selected' : '';
                    $init= strtoupper(substr($svc['name'],0,2));
                ?>
                <div class="api-chip<?= $sel ?>"
                     onclick="selectApi(this,<?= $svc['id'] ?>,<?= $svc['credit_cost'] ?>,'<?= h($svc['name']) ?>')"
                     data-id="<?= $svc['id'] ?>" data-cost="<?= $svc['credit_cost'] ?>">
                    <div class="api-chip-icon"><?= $init ?></div>
                    <div style="flex:1;min-width:0">
                        <div class="api-chip-name"><?= h($svc['name']) ?></div>
                        <div class="api-chip-cost"><?= $svc['credit_cost'] ?> cr/use</div>
                    </div>
                    <?php if ($sel): ?><div class="active-dot"></div><?php endif; ?>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <?php if (in_array('tone', $config['settings'])): ?>
            <div>
                <div class="panel-label">Tone</div>
                <select id="tone" class="form-sel">
                    <option value="professional">Professional</option>
                    <option value="friendly">Friendly</option>
                    <option value="formal">Formal</option>
                    <option value="creative">Creative</option>
                    <option value="casual">Casual</option>
                    <option value="persuasive">Persuasive</option>
                </select>
            </div>
            <?php endif; ?>

            <?php if (in_array('language', $config['settings'])): ?>
            <div>
                <div class="panel-label">Language</div>
                <select id="language" class="form-sel">
                    <option value="English">English</option>
                    <option value="Urdu">Urdu</option>
                    <option value="Arabic">Arabic</option>
                    <option value="French">French</option>
                    <option value="Spanish">Spanish</option>
                    <option value="German">German</option>
                </select>
            </div>
            <?php endif; ?>

            <?php if (in_array('length', $config['settings'])): ?>
            <div>
                <div class="panel-label">Length</div>
                <select id="length" class="form-sel">
                    <option value="short">Short (200 words)</option>
                    <option value="medium" selected>Medium (500 words)</option>
                    <option value="long">Long (1000 words)</option>
                    <option value="very_long">Very long (2000 words)</option>
                </select>
            </div>
            <?php endif; ?>

            <?php if ($isCodeOutput): ?>
            <div>
                <div class="panel-label">Programming language</div>
                <select id="codeLanguage" class="form-sel">
                    <option value="auto">Auto detect</option>
                    <option value="PHP">PHP</option>
                    <option value="JavaScript">JavaScript</option>
                    <option value="Python">Python</option>
                    <option value="HTML/CSS">HTML/CSS</option>
                    <option value="SQL">SQL</option>
                    <option value="TypeScript">TypeScript</option>
                    <option value="React">React</option>
                    <option value="Node.js">Node.js</option>
                    <option value="Swift">Swift</option>
                    <option value="Kotlin">Kotlin</option>
                </select>
            </div>
            <?php endif; ?>

            <div>
                <div class="panel-label">Max length</div>
                <select id="maxTokens" class="form-sel">
                    <option value="500">Short</option>
                    <option value="1000" selected>Medium</option>
                    <option value="2000">Long</option>
                    <option value="4000">Very long</option>
                </select>
            </div>
        </aside>

        <!-- Output area -->
        <div class="center-panel">
            <div class="output-scroll" id="outputArea">
                <div class="welcome" id="welcomeScreen">
                    <div class="icon"><i class="ti <?= h($tool['icon']) ?>"></i></div>
                    <h2><?= h($tool['name']) ?></h2>
                    <p style="font-size:13px;max-width:360px;line-height:1.6">
                        <?= h($tool['description'] ?: 'Describe what you need and AI will generate it for you.') ?>
                    </p>
                    <?php if (!empty($config['starters'])): ?>
                    <div class="starters">
                        <?php foreach ($config['starters'] as $s): ?>
                        <div class="starter-btn" onclick="useStarter('<?= h($s) ?>')"><?= h($s) ?></div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <?php if ($tool['info_tips']): ?>
                    <div style="margin-top:1rem;padding:10px 16px;background:rgba(167,139,250,.06);border:.5px solid rgba(167,139,250,.15);border-radius:10px;font-size:12px;color:#9b9bc0;text-align:left;max-width:400px">
                        <strong style="color:#a78bfa">Tips:</strong> <?= h($tool['info_tips']) ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="input-area">
                <div id="creditWarn" class="credit-warn" style="display:none">
                    <i class="ti ti-alert-circle"></i>
                    Insufficient credits. <a href="/aistudio/public/billing.php" style="color:#f87171;margin-left:4px;font-weight:500">Top up →</a>
                </div>
                <div class="input-cost">
                    <i class="ti ti-coin"></i>
                    Cost: <span id="costLabel" style="color:#a78bfa;font-weight:500"><?= $services[0]['credit_cost'] ?? 1 ?> cr</span>
                    &nbsp;·&nbsp; Provider: <span id="providerLabel" style="color:#a78bfa"><?= h($services[0]['name'] ?? 'None') ?></span>
                </div>
                <div class="input-row">
                    <textarea id="mainInput" class="main-input"
                              placeholder="<?= h($config['placeholder']) ?>"
                              rows="1"></textarea>
                    <button class="send-btn" id="sendBtn" onclick="generate()" aria-label="Generate">
                        <i class="ti ti-sparkles" id="sendIcon"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Info panel -->
<div class="info-panel" id="infoPanel">
    <button class="info-close" onclick="toggleInfo()"><i class="ti ti-x"></i></button>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:1rem">
        <div style="width:40px;height:40px;border-radius:10px;background:rgba(167,139,250,.15);display:flex;align-items:center;justify-content:center;font-size:20px;color:#a78bfa">
            <i class="ti <?= h($tool['icon']) ?>"></i>
        </div>
        <div>
            <h3 style="font-size:15px;font-weight:500"><?= h($tool['name']) ?></h3>
            <div style="font-size:12px;color:#9b9bc0"><?= h($tool['description'] ?? '') ?></div>
        </div>
    </div>
    <?php if ($tool['info_how_to']): ?>
    <div class="info-section">
        <h4>How to use</h4>
        <?php foreach (explode("\n", $tool['info_how_to']) as $line): if (trim($line)): ?>
        <div class="info-item"><i class="ti ti-point"></i><?= h(trim($line)) ?></div>
        <?php endif; endforeach; ?>
    </div>
    <?php else: ?>
    <div class="info-section">
        <h4>How to use</h4>
        <div class="info-item"><i class="ti ti-point"></i> Select your preferred AI provider from left panel</div>
        <div class="info-item"><i class="ti ti-point"></i> Adjust tone, language and length settings</div>
        <div class="info-item"><i class="ti ti-point"></i> Type your request in detail</div>
        <div class="info-item"><i class="ti ti-point"></i> Click ✨ to generate</div>
        <div class="info-item"><i class="ti ti-point"></i> Copy or download the result</div>
    </div>
    <?php endif; ?>
    <?php if ($tool['info_features']): ?>
    <div class="info-section">
        <h4>Features</h4>
        <?php foreach (explode("\n", $tool['info_features']) as $line): if (trim($line)): ?>
        <div class="info-item"><i class="ti ti-check"></i><?= h(trim($line)) ?></div>
        <?php endif; endforeach; ?>
    </div>
    <?php endif; ?>
    <div class="info-section">
        <h4>Credit cost</h4>
        <?php foreach ($services as $s): ?>
        <div class="info-item"><i class="ti ti-coin"></i><?= h($s['name']) ?> — <strong style="color:#a78bfa"><?= $s['credit_cost'] ?> cr</strong>/use</div>
        <?php endforeach; ?>
        <?php if (empty($services)): ?>
        <div class="info-item" style="color:#9b9bc0">No services configured yet</div>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
<script>
const CSRF       = '<?= Security::generateCsrfToken() ?>';
const TOOL_SLUG  = '<?= h($toolSlug) ?>';
const IS_CODE    = <?= $isCodeOutput ? 'true' : 'false' ?>;
let selApiId     = <?= (int)($services[0]['id'] ?? 0) ?>;
let selCost      = <?= (int)($services[0]['credit_cost'] ?? 1) ?>;
let curBal       = <?= (int)$user['credit_balance'] ?>;
let isGenerating = false;

const inp = document.getElementById('mainInput');
inp.addEventListener('input', function(){
    this.style.height='auto';
    this.style.height=Math.min(this.scrollHeight,140)+'px';
});
inp.addEventListener('keydown', function(e){
    if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();generate();}
});

function selectApi(el,id,cost,name){
    document.querySelectorAll('.api-chip').forEach(c=>{c.classList.remove('selected');const d=c.querySelector('.active-dot');if(d)d.remove()});
    el.classList.add('selected');
    const dot=document.createElement('div');dot.className='active-dot';el.appendChild(dot);
    selApiId=id;selCost=cost;
    document.getElementById('costLabel').textContent=cost+' cr';
    document.getElementById('providerLabel').textContent=name;
    checkCredits();
}

function checkCredits(){
    document.getElementById('creditWarn').style.display=curBal<selCost?'flex':'none';
}

function useStarter(text){
    inp.value=text;inp.dispatchEvent(new Event('input'));inp.focus();
}

async function generate(){
    const prompt=inp.value.trim();
    if(!prompt||isGenerating)return;
    if(curBal<selCost){document.getElementById('creditWarn').style.display='flex';return;}
    if(!selApiId){alert('Select an AI provider first.');return;}

    isGenerating=true;setLoading(true);
    document.getElementById('welcomeScreen')?.remove();

    // Build system prompt based on tool + settings
    const tone     = document.getElementById('tone')?.value     || 'professional';
    const language = document.getElementById('language')?.value || 'English';
    const length   = document.getElementById('length')?.value   || 'medium';
    const codeLang = document.getElementById('codeLanguage')?.value || 'auto';
    const maxTok   = parseInt(document.getElementById('maxTokens').value);

    const lengthMap = {short:'around 200 words',medium:'around 500 words',long:'around 1000 words',very_long:'around 2000 words'};

    let systemPrompt = `You are an expert ${TOOL_SLUG.replace('ai-','')} AI assistant.`;
    if(IS_CODE){
        systemPrompt = `You are an expert software developer. Write clean, well-commented, production-ready code.${codeLang!=='auto'?' Use '+codeLang+'.':''} Format code in markdown code blocks.`;
    } else {
        systemPrompt += ` Write in ${language} language. Tone: ${tone}.`;
        if(length) systemPrompt += ` Length: ${lengthMap[length]||'medium length'}.`;
        systemPrompt += ` Be detailed, accurate, and helpful. Format output clearly with proper structure.`;
    }

    // Show loading
    const loadEl = document.createElement('div');
    loadEl.className='loading-card';loadEl.id='loadingCard';
    loadEl.innerHTML='<div class="spin"></div><span>Generating with AI...</span>';
    document.getElementById('outputArea').appendChild(loadEl);
    loadEl.scrollIntoView({behavior:'smooth'});

    try {
        const res = await fetch('/aistudio/public/api/text-handler.php',{
            method:'POST',
            headers:{'Content-Type':'application/json','X-CSRF-Token':CSRF},
            body:JSON.stringify({
                api_service_id: selApiId,
                tool_slug:      TOOL_SLUG,
                prompt:         prompt,
                system_prompt:  systemPrompt,
                max_tokens:     maxTok,
            })
        });
        const data = await res.json();
        document.getElementById('loadingCard')?.remove();

        if(data.success){
            addResult(prompt, data.reply);
            curBal=data.new_balance;
            document.getElementById('creditBal').textContent=curBal.toLocaleString();
            checkCredits();
            inp.value='';inp.style.height='auto';
        } else {
            showError(data.error||'Generation failed. Try again.');
        }
    } catch(e){
        document.getElementById('loadingCard')?.remove();
        showError('Network error. Please check your connection.');
    }
    isGenerating=false;setLoading(false);
}

function addResult(prompt,content){
    const div=document.createElement('div');
    div.className='result-card';

    const formatted=formatContent(content);
    div.innerHTML=`
    <div class="result-header">
        <div class="result-prompt">${escHtml(prompt)}</div>
        <div class="result-btns">
            <button onclick="copyResult(this)" class="act-btn act-btn-copy"><i class="ti ti-copy"></i> Copy</button>
            <button onclick="downloadResult(this,'${escHtml(prompt).substring(0,20)}')" class="act-btn act-btn-dl"><i class="ti ti-download"></i> Download</button>
        </div>
    </div>
    <div class="result-body">${formatted}</div>`;

    document.getElementById('outputArea').appendChild(div);
    div.scrollIntoView({behavior:'smooth'});

    // Highlight code blocks
    div.querySelectorAll('pre code').forEach(el=>hljs.highlightElement(el));
}

function formatContent(text){
    // Code blocks
    text=text.replace(/```(\w*)\n?([\s\S]*?)```/g,(_,lang,code)=>
        `<pre><code class="language-${lang||'plaintext'}">${escHtml(code.trim())}</code></pre>`);
    // Bold
    text=text.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>');
    // Inline code
    text=text.replace(/`([^`]+)`/g,'<code style="background:rgba(167,139,250,.15);padding:1px 5px;border-radius:4px;font-size:13px;font-family:monospace">$1</code>');
    // Headers
    text=text.replace(/^### (.+)$/gm,'<h4 style="font-size:14px;font-weight:600;color:#a78bfa;margin:12px 0 4px">$1</h4>');
    text=text.replace(/^## (.+)$/gm,'<h3 style="font-size:15px;font-weight:600;color:#f1f1ff;margin:14px 0 6px">$1</h3>');
    text=text.replace(/^# (.+)$/gm,'<h2 style="font-size:18px;font-weight:700;color:#f1f1ff;margin:16px 0 8px">$1</h2>');
    // Lists
    text=text.replace(/^[\-\*] (.+)$/gm,'<li style="margin:3px 0;padding-left:4px">$1</li>');
    text=text.replace(/(<li[^>]*>.*<\/li>\n?)+/g,'<ul style="padding-left:20px;margin:8px 0">$&</ul>');
    // Line breaks
    text=text.replace(/\n\n/g,'<br><br>').replace(/\n/g,'<br>');
    return text;
}

function copyResult(btn){
    const body=btn.closest('.result-card').querySelector('.result-body');
    navigator.clipboard.writeText(body.innerText);
    btn.innerHTML='<i class="ti ti-check"></i> Copied!';
    btn.style.color='#22c55e';
    setTimeout(()=>{btn.innerHTML='<i class="ti ti-copy"></i> Copy';btn.style.color='';},2000);
}

function downloadResult(btn,filename){
    const body=btn.closest('.result-card').querySelector('.result-body');
    const blob=new Blob([body.innerText],{type:'text/plain'});
    const a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download=(filename||'result')+'.txt';
    a.click();
}

function showError(msg){
    const div=document.createElement('div');
    div.style.cssText='padding:12px 16px;background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);border-radius:10px;color:#fca5a5;font-size:13px;display:flex;align-items:center;gap:8px';
    div.innerHTML=`<i class="ti ti-alert-circle"></i>${escHtml(msg)}`;
    document.getElementById('outputArea').appendChild(div);
    setTimeout(()=>div.remove(),6000);
}

function setLoading(on){
    const btn=document.getElementById('sendBtn');
    const ico=document.getElementById('sendIcon');
    btn.disabled=on;
    ico.className=on?'ti ti-loader':'ti ti-sparkles';
    if(on){let r=0;ico._t=setInterval(()=>{r+=12;ico.style.transform=`rotate(${r}deg)`;},30);}
    else{clearInterval(ico._t);ico.style.transform='';}
}

function toggleInfo(){document.getElementById('infoPanel').classList.toggle('open');}
function escHtml(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

checkCredits();
</script>
</body>
</html>
