<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';

Security::startSession();
Security::checkIpBan();
Auth::requireLogin('/aistudio/public/login.php');

$user = Auth::user();
$tool = DB::queryOne("SELECT * FROM tools WHERE slug='ai-image' AND is_enabled=1");
if (!$tool) { header('Location: /aistudio/public/dashboard.php'); exit; }

$services = DB::query(
    "SELECT * FROM api_services WHERE tool_id=? AND is_enabled=1 ORDER BY sort_order ASC",
    [$tool['id']]
);

// Recent generations for this user
$recent = DB::query(
    "SELECT * FROM image_generation_logs WHERE user_id=? ORDER BY created_at DESC LIMIT 12",
    [$user['id']]
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AI Image — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d0d1a;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:64px;min-height:100vh;background:#08080f;border-right:.5px solid rgba(167,139,250,.1);display:flex;flex-direction:column;position:fixed;left:0;top:0;transition:width .25s;overflow:hidden;z-index:100}
.sidebar:hover{width:220px}
.sidebar-logo{padding:16px 14px 20px;font-size:17px;font-weight:600;white-space:nowrap;overflow:hidden;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.tool-btn{display:flex;align-items:center;gap:12px;padding:10px 14px;color:#9b9bc0;text-decoration:none;white-space:nowrap;transition:all .15s;font-size:13px;border-left:2px solid transparent}
.tool-btn i{font-size:19px;flex-shrink:0;min-width:20px}
.tool-btn:hover{color:#a78bfa;background:rgba(167,139,250,.07)}
.tool-btn.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.tool-label{opacity:0;transition:opacity .2s}
.sidebar:hover .tool-label{opacity:1}
.sep{height:.5px;background:rgba(167,139,250,.1);margin:6px 14px}
.main{margin-left:64px;flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden}
.topbar{height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 1.25rem;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.9);flex-shrink:0;position:sticky;top:0;z-index:50}
.tool-title{font-size:15px;font-weight:500;display:flex;align-items:center;gap:8px}
.info-btn{width:22px;height:22px;border-radius:50%;background:rgba(167,139,250,.15);border:.5px solid rgba(167,139,250,.3);color:#a78bfa;font-size:12px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:all .2s;flex-shrink:0}
.info-btn:hover{background:rgba(167,139,250,.25)}
.credit-pill{display:flex;align-items:center;gap:5px;padding:4px 12px;background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.2);border-radius:20px;font-size:12px;font-weight:500;color:#a78bfa}

/* Layout */
.image-wrap{display:flex;flex:1;overflow:hidden}

/* Left settings panel */
.settings-panel{width:260px;flex-shrink:0;border-right:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.6);padding:14px;overflow-y:auto;display:flex;flex-direction:column;gap:10px}
.panel-section{margin-bottom:2px}
.panel-label{font-size:11px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.05em;margin-bottom:6px}
.api-chip{display:flex;align-items:center;gap:8px;padding:9px 10px;border-radius:9px;border:.5px solid rgba(167,139,250,.15);background:rgba(255,255,255,.02);cursor:pointer;transition:all .2s;margin-bottom:5px}
.api-chip:hover{border-color:rgba(167,139,250,.3);background:rgba(167,139,250,.06)}
.api-chip.selected{background:rgba(167,139,250,.12);border-color:#a78bfa}
.api-chip-icon{width:28px;height:28px;border-radius:6px;background:rgba(167,139,250,.15);display:flex;align-items:center;justify-content:center;font-size:12px;color:#a78bfa;font-weight:700;flex-shrink:0}
.api-chip-name{font-size:12px;font-weight:500;color:#f1f1ff}
.api-chip-cost{font-size:10px;color:#9b9bc0}
.api-chip.selected .api-chip-name{color:#a78bfa}
.active-dot{width:6px;height:6px;border-radius:50%;background:#22c55e;margin-left:auto;flex-shrink:0}
.form-select,.form-input-sm{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:7px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:12px;padding:7px 10px;outline:none;cursor:pointer}
.form-select:focus,.form-input-sm:focus{border-color:#a78bfa}
.form-select option{background:#1a1a2e;color:#f1f1ff}
.range-row{display:flex;align-items:center;gap:8px}
.range-row input{flex:1;accent-color:#a78bfa}
.range-val{font-size:11px;color:#a78bfa;min-width:32px;text-align:right}
.style-grid{display:grid;grid-template-columns:1fr 1fr;gap:5px}
.style-btn{padding:5px 8px;border-radius:6px;border:.5px solid rgba(167,139,250,.15);background:rgba(255,255,255,.02);color:#9b9bc0;font-size:11px;cursor:pointer;text-align:center;transition:all .2s}
.style-btn:hover,.style-btn.active{background:rgba(167,139,250,.1);border-color:#a78bfa;color:#a78bfa}

/* Center — prompt + output */
.center-panel{flex:1;display:flex;flex-direction:column;overflow:hidden}
.output-area{flex:1;overflow-y:auto;padding:1.25rem;display:flex;flex-direction:column;gap:12px}
.output-area::-webkit-scrollbar{width:4px}
.output-area::-webkit-scrollbar-thumb{background:rgba(167,139,250,.2);border-radius:2px}

/* Welcome / empty state */
.welcome-img{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:2rem;color:#9b9bc0}
.welcome-img .icon{width:72px;height:72px;border-radius:20px;background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.2);display:flex;align-items:center;justify-content:center;font-size:36px;color:#a78bfa;margin-bottom:14px}
.welcome-img h2{font-size:18px;font-weight:500;color:#f1f1ff;margin-bottom:8px}
.style-prompts{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin-top:12px}
.style-prompt-btn{padding:6px 14px;border-radius:8px;font-size:12px;background:rgba(167,139,250,.08);border:.5px solid rgba(167,139,250,.2);color:#a78bfa;cursor:pointer;transition:all .2s}
.style-prompt-btn:hover{background:rgba(167,139,250,.15)}

/* Generated image */
.gen-result{background:rgba(255,255,255,.04);border:.5px solid rgba(167,139,250,.15);border-radius:14px;overflow:hidden;max-width:600px;align-self:center;width:100%}
.gen-img{width:100%;display:block;border-radius:14px 14px 0 0}
.gen-actions{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;gap:8px}
.gen-prompt{font-size:12px;color:#9b9bc0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.action-btns{display:flex;gap:6px}
.act-btn{display:flex;align-items:center;gap:4px;padding:5px 10px;border-radius:6px;font-size:11px;font-weight:500;cursor:pointer;border:none;font-family:'Inter',sans-serif;transition:all .2s;text-decoration:none;white-space:nowrap}
.act-btn-dl{background:rgba(34,197,94,.12);color:#22c55e;border:.5px solid rgba(34,197,94,.25)}
.act-btn-pub{background:rgba(167,139,250,.12);color:#a78bfa;border:.5px solid rgba(167,139,250,.25)}
.act-btn-regen{background:rgba(56,189,248,.1);color:#38bdf8;border:.5px solid rgba(56,189,248,.2)}

/* Generating state */
.generating-state{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:3rem;gap:12px;color:#9b9bc0}
.gen-spinner{width:48px;height:48px;border:3px solid rgba(167,139,250,.2);border-top-color:#a78bfa;border-radius:50%;animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.gen-progress{width:200px;height:4px;background:rgba(255,255,255,.08);border-radius:2px;overflow:hidden}
.gen-progress-fill{height:100%;background:linear-gradient(90deg,#a78bfa,#38bdf8);border-radius:2px;animation:progress 3s ease-in-out infinite}
@keyframes progress{0%{width:0}100%{width:100%}}

/* Input area */
.input-area{padding:12px 16px;border-top:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.8);flex-shrink:0}
.input-cost{font-size:11px;color:#6b6b90;margin-bottom:6px;display:flex;align-items:center;gap:4px}
.input-row{display:flex;gap:8px}
.prompt-input{flex:1;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:10px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:14px;padding:10px 14px;outline:none;resize:none;transition:border-color .2s;min-height:44px;max-height:100px}
.prompt-input:focus{border-color:#a78bfa;box-shadow:0 0 0 3px rgba(167,139,250,.1)}
.prompt-input::placeholder{color:#6b6b90}
.gen-btn{width:48px;height:48px;border-radius:12px;background:linear-gradient(135deg,#a78bfa,#7c3aed);border:none;color:#fff;font-size:20px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s}
.gen-btn:hover{filter:brightness(1.1);transform:translateY(-1px)}
.gen-btn:disabled{opacity:.5;cursor:not-allowed;transform:none}

/* Right — history panel */
.history-panel{width:180px;flex-shrink:0;border-left:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.5);overflow-y:auto;padding:10px}
.history-title{font-size:11px;color:#6b6b90;text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px;font-weight:500}
.hist-img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px;cursor:pointer;margin-bottom:5px;border:.5px solid rgba(167,139,250,.1);transition:border-color .2s}
.hist-img:hover{border-color:#a78bfa}

/* Info panel */
.info-panel{position:fixed;right:-340px;top:0;width:320px;height:100vh;background:#0d0d1a;border-left:.5px solid rgba(167,139,250,.2);padding:1.5rem;overflow-y:auto;transition:right .3s;z-index:200}
.info-panel.open{right:0}
.info-close{position:absolute;top:14px;right:14px;background:none;border:none;color:#9b9bc0;font-size:20px;cursor:pointer}
.info-section{margin-bottom:1rem}
.info-section h4{font-size:12px;font-weight:500;color:#a78bfa;margin-bottom:6px;text-transform:uppercase;letter-spacing:.05em}
.info-item{font-size:13px;color:#9b9bc0;padding:4px 0;display:flex;align-items:flex-start;gap:6px;border-top:.5px solid rgba(255,255,255,.04)}
.info-item:first-of-type{border-top:none}
.info-item i{color:#a78bfa;font-size:14px;flex-shrink:0;margin-top:1px}

/* Credit warn */
.credit-warn{padding:8px 14px;border-radius:8px;font-size:12px;background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);color:#fca5a5;margin-bottom:8px;display:flex;align-items:center;gap:6px}

@media(max-width:900px){.history-panel{display:none}.settings-panel{width:200px}}
@media(max-width:680px){.sidebar{display:none}.main{margin-left:0}.settings-panel{display:none}}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?></div>
    <?php
    $allTools = DB::query("SELECT * FROM tools WHERE is_visible_on_landing=1 ORDER BY sort_order ASC");
    foreach ($allTools as $t):
        $active = $t['slug'] === 'ai-image' ? ' active' : '';
        $href   = '/aistudio/public/tools/' . h($t['slug']) . '.php';
    ?>
    <a href="<?= $href ?>" class="tool-btn<?= $active ?>" title="<?= h($t['name']) ?>">
        <i class="ti <?= h($t['icon']) ?>"></i>
        <span class="tool-label"><?= h($t['name']) ?></span>
    </a>
    <?php endforeach; ?>
    <div class="sep"></div>
    <a href="/aistudio/public/dashboard.php" class="tool-btn"><i class="ti ti-layout-dashboard"></i><span class="tool-label">Dashboard</span></a>
    <a href="/aistudio/public/logout.php" class="tool-btn" style="margin-top:auto"><i class="ti ti-logout"></i><span class="tool-label">Logout</span></a>
</nav>

<div class="main">
    <header class="topbar">
        <div class="tool-title">
            <i class="ti ti-photo" style="color:#a78bfa;font-size:18px"></i>
            AI Image Generator
            <button class="info-btn" onclick="toggleInfo()" title="How to use">i</button>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
            <div class="credit-pill">
                <i class="ti ti-coin"></i>
                <span id="creditBal"><?= number_format($user['credit_balance']) ?></span> cr
            </div>
        </div>
    </header>

    <div class="image-wrap">
        <!-- Settings panel -->
        <aside class="settings-panel">
            <div class="panel-section">
                <div class="panel-label">AI Provider</div>
                <?php if (empty($services)): ?>
                <div style="font-size:12px;color:#6b6b90;text-align:center;padding:.75rem">
                    No APIs configured.<br>
                    <a href="/aistudio/public/admin/apis.php" style="color:#a78bfa">Add in Admin →</a>
                </div>
                <?php else: ?>
                <?php foreach ($services as $i => $svc):
                    $sel = $i===0 ? ' selected' : '';
                    $init= strtoupper(substr($svc['name'],0,2));
                ?>
                <div class="api-chip<?= $sel ?>"
                     onclick="selectApi(this,<?= $svc['id'] ?>,<?= $svc['credit_cost'] ?>,'<?= h($svc['name']) ?>')"
                     data-id="<?= $svc['id'] ?>" data-cost="<?= $svc['credit_cost'] ?>">
                    <div class="api-chip-icon"><?= $init ?></div>
                    <div style="flex:1;min-width:0">
                        <div class="api-chip-name"><?= h($svc['name']) ?></div>
                        <div class="api-chip-cost"><?= $svc['credit_cost'] ?> cr/image</div>
                    </div>
                    <?php if ($sel): ?><div class="active-dot"></div><?php endif; ?>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div class="panel-section">
                <div class="panel-label">Image size</div>
                <select id="imgSize" class="form-select">
                    <option value="512x512">512×512 (Square)</option>
                    <option value="1024x1024" selected>1024×1024 (HD Square)</option>
                    <option value="1024x768">1024×768 (Landscape)</option>
                    <option value="768x1024">768×1024 (Portrait)</option>
                    <option value="1920x1080">1920×1080 (Widescreen)</option>
                </select>
            </div>

            <div class="panel-section">
                <div class="panel-label">Art style</div>
                <div class="style-grid">
                    <?php
                    $styles = ['Realistic','Anime','Digital Art','Oil Painting','Watercolor','Sketch','Cinematic','Fantasy','Minimalist','3D Render'];
                    foreach ($styles as $s):
                    ?>
                    <div class="style-btn" onclick="selectStyle(this,'<?= $s ?>')"><?= $s ?></div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="panel-section">
                <div class="panel-label">Steps (quality)</div>
                <div class="range-row">
                    <input type="range" id="steps" min="10" max="50" value="30"
                           oninput="document.getElementById('stepsVal').textContent=this.value">
                    <span class="range-val" id="stepsVal">30</span>
                </div>
            </div>

            <div class="panel-section">
                <div class="panel-label">CFG Scale</div>
                <div class="range-row">
                    <input type="range" id="cfg" min="1" max="20" value="7" step="0.5"
                           oninput="document.getElementById('cfgVal').textContent=this.value">
                    <span class="range-val" id="cfgVal">7</span>
                </div>
            </div>

            <div class="panel-section">
                <div class="panel-label">Negative prompt</div>
                <textarea id="negPrompt" class="form-input-sm" rows="3"
                          placeholder="What to avoid: blurry, low quality, text..."
                          style="resize:vertical"></textarea>
            </div>

            <div class="panel-section">
                <div class="panel-label">Seed (optional)</div>
                <input type="number" id="seed" class="form-input-sm" placeholder="Random if empty">
            </div>

            <div class="panel-section">
                <div class="panel-label">Number of images</div>
                <select id="numImages" class="form-select">
                    <option value="1" selected>1 image</option>
                    <option value="2">2 images</option>
                    <option value="4">4 images</option>
                </select>
            </div>
        </aside>

        <!-- Center: output -->
        <div class="center-panel">
            <div class="output-area" id="outputArea">
                <div class="welcome-img" id="welcomeScreen">
                    <div class="icon"><i class="ti ti-photo"></i></div>
                    <h2>AI Image Generator</h2>
                    <p style="font-size:13px;max-width:320px">Describe what you want to create. Add style, mood, lighting details for best results.</p>
                    <div class="style-prompts">
                        <div class="style-prompt-btn" onclick="usePrompt('A majestic snow-capped mountain at golden hour, photorealistic, 8K')">Mountain at golden hour</div>
                        <div class="style-prompt-btn" onclick="usePrompt('A futuristic cyberpunk city at night, neon lights, rain, cinematic')">Cyberpunk city</div>
                        <div class="style-prompt-btn" onclick="usePrompt('A beautiful anime girl with flowing hair, cherry blossom background, Studio Ghibli style')">Anime portrait</div>
                        <div class="style-prompt-btn" onclick="usePrompt('A magical forest with glowing mushrooms and fairies, fantasy art, highly detailed')">Fantasy forest</div>
                        <div class="style-prompt-btn" onclick="usePrompt('Professional product photography of a luxury watch on marble surface, studio lighting')">Product photo</div>
                        <div class="style-prompt-btn" onclick="usePrompt('Abstract geometric art with vibrant colors, modern minimalist design')">Abstract art</div>
                    </div>
                </div>
            </div>

            <div class="input-area">
                <div id="creditWarn" class="credit-warn" style="display:none">
                    <i class="ti ti-alert-circle"></i>
                    Insufficient credits. <a href="/aistudio/public/billing.php" style="color:#f87171;margin-left:4px;font-weight:500">Top up →</a>
                </div>
                <div class="input-cost">
                    <i class="ti ti-coin"></i>
                    Cost: <span id="costLabel" style="color:#a78bfa;font-weight:500"><?= $services[0]['credit_cost'] ?? 2 ?> cr</span>
                    &nbsp;·&nbsp; Provider: <span id="providerLabel" style="color:#a78bfa"><?= h($services[0]['name'] ?? 'None') ?></span>
                </div>
                <div class="input-row">
                    <textarea id="promptInput" class="prompt-input" placeholder="Describe your image... e.g. 'A stunning sunset over the ocean, photorealistic, 4K'" rows="1"></textarea>
                    <button class="gen-btn" id="genBtn" onclick="generateImage()" aria-label="Generate">
                        <i class="ti ti-sparkles" id="genIcon"></i>
                    </button>
                </div>
            </div>
        </div>

        <!-- History panel -->
        <aside class="history-panel">
            <div class="history-title">Recent</div>
            <div id="historyGrid">
                <?php foreach ($recent as $img): ?>
                <?php if ($img['image_url']): ?>
                <img src="<?= h($img['image_url']) ?>" class="hist-img"
                     onclick="viewFull('<?= h($img['image_url']) ?>')"
                     title="<?= h($img['prompt'] ?? '') ?>">
                <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </aside>
    </div>
</div>

<!-- Info panel -->
<div class="info-panel" id="infoPanel">
    <button class="info-close" onclick="toggleInfo()"><i class="ti ti-x"></i></button>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:1rem">
        <div style="width:40px;height:40px;border-radius:10px;background:rgba(167,139,250,.15);display:flex;align-items:center;justify-content:center;font-size:20px;color:#a78bfa">
            <i class="ti ti-photo"></i>
        </div>
        <div>
            <h3 style="font-size:15px;font-weight:500">AI Image Generator</h3>
            <div style="font-size:12px;color:#9b9bc0">Create stunning AI images</div>
        </div>
    </div>
    <div class="info-section">
        <h4>How to use</h4>
        <div class="info-item"><i class="ti ti-point"></i> Select your AI provider from left panel</div>
        <div class="info-item"><i class="ti ti-point"></i> Choose image size, style and quality settings</div>
        <div class="info-item"><i class="ti ti-point"></i> Describe your image in detail in the prompt box</div>
        <div class="info-item"><i class="ti ti-point"></i> Add negative prompt to avoid unwanted elements</div>
        <div class="info-item"><i class="ti ti-point"></i> Click ✨ to generate</div>
    </div>
    <div class="info-section">
        <h4>Pro tips</h4>
        <div class="info-item"><i class="ti ti-check"></i> Be specific: "photorealistic, 8K, studio lighting" gives better results</div>
        <div class="info-item"><i class="ti ti-check"></i> Add style: "oil painting", "anime", "digital art"</div>
        <div class="info-item"><i class="ti ti-check"></i> Add mood: "dramatic", "peaceful", "cinematic"</div>
        <div class="info-item"><i class="ti ti-check"></i> Higher steps = better quality but same credit cost</div>
    </div>
    <div class="info-section">
        <h4>Credit cost</h4>
        <?php foreach ($services as $s): ?>
        <div class="info-item"><i class="ti ti-coin"></i> <?= h($s['name']) ?> — <strong style="color:#a78bfa"><?= $s['credit_cost'] ?> cr</strong>/image</div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Full image viewer -->
<div id="imgViewer" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.9);z-index:300;align-items:center;justify-content:center;padding:1rem"
     onclick="this.style.display='none'">
    <img id="viewerImg" src="" style="max-width:90%;max-height:90vh;border-radius:12px;object-fit:contain">
</div>

<script>
const CSRF    = '<?= Security::generateCsrfToken() ?>';
let selApiId  = <?= (int)($services[0]['id'] ?? 0) ?>;
let selCost   = <?= (int)($services[0]['credit_cost'] ?? 2) ?>;
let curBal    = <?= (int)$user['credit_balance'] ?>;
let selStyle  = '';
let isGen     = false;
let lastPrompt= '';

// Auto-resize textarea
const inp = document.getElementById('promptInput');
inp.addEventListener('input',function(){this.style.height='auto';this.style.height=Math.min(this.scrollHeight,100)+'px'});
inp.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();generateImage()}});

function selectApi(el,id,cost,name){
    document.querySelectorAll('.api-chip').forEach(c=>{c.classList.remove('selected');const d=c.querySelector('.active-dot');if(d)d.remove()});
    el.classList.add('selected');
    const dot=document.createElement('div');dot.className='active-dot';el.appendChild(dot);
    selApiId=id;selCost=cost;
    document.getElementById('costLabel').textContent=cost+' cr';
    document.getElementById('providerLabel').textContent=name;
    checkCredits();
}

function selectStyle(el,style){
    document.querySelectorAll('.style-btn').forEach(b=>b.classList.remove('active'));
    el.classList.add('active');
    selStyle = selStyle===style?'':style;
    if(!selStyle)el.classList.remove('active');
}

function checkCredits(){
    document.getElementById('creditWarn').style.display = curBal<selCost?'flex':'none';
}

function usePrompt(text){
    inp.value=text;inp.dispatchEvent(new Event('input'));inp.focus();
}

async function generateImage(){
    const prompt = inp.value.trim();
    if(!prompt||isGen)return;
    if(curBal<selCost){document.getElementById('creditWarn').style.display='flex';return;}
    if(!selApiId){alert('Select an AI provider first.');return;}

    isGen=true;lastPrompt=prompt;
    setLoading(true);
    document.getElementById('welcomeScreen')?.remove();

    const fullPrompt = selStyle ? `${prompt}, ${selStyle} style` : prompt;
    const size       = document.getElementById('imgSize').value.split('x');

    // Show generating state
    const loadDiv = document.createElement('div');
    loadDiv.className='generating-state';loadDiv.id='genState';
    loadDiv.innerHTML=`<div class="gen-spinner"></div>
        <div style="font-size:14px">Generating your image...</div>
        <div class="gen-progress"><div class="gen-progress-fill"></div></div>
        <div style="font-size:12px;color:#6b6b90">"${fullPrompt.substring(0,60)}..."</div>`;
    document.getElementById('outputArea').appendChild(loadDiv);
    loadDiv.scrollIntoView({behavior:'smooth'});

    try {
        const res = await fetch('/aistudio/public/api/image-handler.php',{
            method:'POST',
            headers:{'Content-Type':'application/json','X-CSRF-Token':CSRF},
            body:JSON.stringify({
                api_service_id: selApiId,
                prompt:         fullPrompt,
                negative_prompt:document.getElementById('negPrompt').value,
                width:          parseInt(size[0]),
                height:         parseInt(size[1]),
                steps:          parseInt(document.getElementById('steps').value),
                cfg_scale:      parseFloat(document.getElementById('cfg').value),
                seed:           document.getElementById('seed').value||null,
                num_images:     parseInt(document.getElementById('numImages').value),
            })
        });
        const data = await res.json();
        loadDiv.remove();

        if(data.success && data.images?.length){
            data.images.forEach(imgUrl=>{
                addImageResult(imgUrl,fullPrompt,data.log_id);
                addToHistory(imgUrl);
            });
            curBal=data.new_balance;
            document.getElementById('creditBal').textContent=curBal.toLocaleString();
            checkCredits();
        } else {
            showError(data.error||'Generation failed. Please try again.');
        }
    } catch(e) {
        loadDiv.remove();
        showError('Network error. Please check your connection.');
    }
    isGen=false;setLoading(false);
}

function addImageResult(url,prompt,logId){
    const div=document.createElement('div');
    div.className='gen-result';
    div.innerHTML=`<img src="${url}" class="gen-img" onclick="viewFull('${url}')" alt="Generated image">
        <div class="gen-actions">
            <div class="gen-prompt">${escHtml(prompt)}</div>
            <div class="action-btns">
                <a href="${url}" download class="act-btn act-btn-dl"><i class="ti ti-download"></i> Download</a>
                <button onclick="publishImage(${logId||0},this)" class="act-btn act-btn-pub"><i class="ti ti-upload"></i> Publish</button>
                <button onclick="usePrompt('${prompt.replace(/'/g,"\\'")}');generateImage()" class="act-btn act-btn-regen"><i class="ti ti-refresh"></i></button>
            </div>
        </div>`;
    document.getElementById('outputArea').appendChild(div);
    div.scrollIntoView({behavior:'smooth'});
}

function addToHistory(url){
    const img=document.createElement('img');
    img.src=url;img.className='hist-img';
    img.onclick=()=>viewFull(url);
    const grid=document.getElementById('historyGrid');
    grid.insertBefore(img,grid.firstChild);
}

function showError(msg){
    const div=document.createElement('div');
    div.style.cssText='padding:1rem;background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);border-radius:10px;color:#fca5a5;font-size:13px;display:flex;align-items:center;gap:8px';
    div.innerHTML=`<i class="ti ti-alert-circle"></i>${msg}`;
    document.getElementById('outputArea').appendChild(div);
    setTimeout(()=>div.remove(),5000);
}

async function publishImage(logId,btn){
    if(!logId)return;
    try{
        const res=await fetch('/aistudio/public/api/publish-image.php',{
            method:'POST',
            headers:{'Content-Type':'application/json','X-CSRF-Token':CSRF},
            body:JSON.stringify({log_id:logId})
        });
        const d=await res.json();
        if(d.success){btn.innerHTML='<i class="ti ti-check"></i> Published';btn.style.color='#22c55e';btn.disabled=true;}
        else alert(d.error||'Could not publish');
    }catch(e){alert('Error publishing');}
}

function setLoading(on){
    const btn=document.getElementById('genBtn');
    const ico=document.getElementById('genIcon');
    btn.disabled=on;
    ico.className=on?'ti ti-loader':'ti ti-sparkles';
    if(on){let r=0;ico._t=setInterval(()=>{r+=12;ico.style.transform=`rotate(${r}deg)`},30);}
    else{clearInterval(ico._t);ico.style.transform='';}
}

function viewFull(url){
    document.getElementById('viewerImg').src=url;
    document.getElementById('imgViewer').style.display='flex';
}

function toggleInfo(){document.getElementById('infoPanel').classList.toggle('open');}
function escHtml(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}

checkCredits();
</script>
</body>
</html>
