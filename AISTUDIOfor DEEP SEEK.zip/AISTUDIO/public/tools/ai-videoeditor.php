<?php
// AIStudio — ai-videoeditor tool
// Uses universal tool template
$toolSlug = 'ai-videoeditor';
require_once __DIR__ . '/_universal.php';
