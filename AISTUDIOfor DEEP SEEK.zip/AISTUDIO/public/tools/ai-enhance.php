<?php
// AIStudio — ai-enhance tool
// Uses universal tool template
$toolSlug = 'ai-enhance';
require_once __DIR__ . '/_universal.php';
