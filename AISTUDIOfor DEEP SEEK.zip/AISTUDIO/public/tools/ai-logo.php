<?php
// AIStudio — ai-logo tool
// Uses universal tool template
$toolSlug = 'ai-logo';
require_once __DIR__ . '/_universal.php';
