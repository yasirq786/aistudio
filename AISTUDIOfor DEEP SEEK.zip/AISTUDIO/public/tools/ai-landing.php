<?php
// AIStudio — ai-landing tool
// Uses universal tool template
$toolSlug = 'ai-landing';
require_once __DIR__ . '/_universal.php';
