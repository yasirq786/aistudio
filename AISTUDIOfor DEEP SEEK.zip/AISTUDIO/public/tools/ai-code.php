<?php
// AIStudio — ai-code tool
// Uses universal tool template
$toolSlug = 'ai-code';
require_once __DIR__ . '/_universal.php';
