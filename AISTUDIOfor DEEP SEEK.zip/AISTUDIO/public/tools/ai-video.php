<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
Security::startSession();
Security::checkIpBan();
Auth::requireLogin('/aistudio/public/login.php');
$user       = Auth::user();
$tool       = DB::queryOne("SELECT * FROM tools WHERE slug='ai-video' AND is_enabled=1");
if (!$tool) { header('Location: /aistudio/public/dashboard.php'); exit; }
$services   = DB::query("SELECT * FROM api_services WHERE tool_id=? AND is_enabled=1 ORDER BY sort_order", [$tool['id']]);
$videoTiers = DB::query("SELECT * FROM video_credit_tiers ORDER BY sort_order");
$recent     = DB::query("SELECT * FROM video_generation_logs WHERE user_id=? ORDER BY created_at DESC LIMIT 10", [$user['id']]);
$allTools   = DB::query("SELECT * FROM tools WHERE is_visible_on_landing=1 ORDER BY sort_order");
$csrf       = Security::generateCsrfToken();
$defCost    = (int)($videoTiers[0]['credit_cost'] ?? 5);
$defDur     = (int)($videoTiers[0]['duration_sec'] ?? 5);
$defProv    = h($services[0]['name'] ?? 'None');
$defApiId   = (int)($services[0]['id'] ?? 0);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AI Video — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d0d1a;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sb{width:64px;min-height:100vh;background:#08080f;border-right:.5px solid rgba(167,139,250,.1);display:flex;flex-direction:column;position:fixed;left:0;top:0;transition:width .25s;overflow:hidden;z-index:100}
.sb:hover{width:220px}
.sb-logo{padding:16px 14px 20px;font-size:17px;font-weight:600;white-space:nowrap;overflow:hidden;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.tb{display:flex;align-items:center;gap:12px;padding:10px 14px;color:#9b9bc0;text-decoration:none;white-space:nowrap;transition:all .15s;font-size:13px;border-left:2px solid transparent}
.tb i{font-size:19px;flex-shrink:0;min-width:20px}
.tb:hover{color:#a78bfa;background:rgba(167,139,250,.07)}
.tb.a{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.tl{opacity:0;transition:opacity .2s}
.sb:hover .tl{opacity:1}
.sp{height:.5px;background:rgba(167,139,250,.1);margin:6px 14px}
.mn{margin-left:64px;flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden}
.top{height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 1.25rem;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.9);flex-shrink:0;z-index:50}
.cp{display:flex;align-items:center;gap:5px;padding:4px 12px;background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.2);border-radius:20px;font-size:12px;font-weight:500;color:#a78bfa}
.wr{display:flex;flex:1;overflow:hidden}
.lp{width:250px;flex-shrink:0;border-right:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.6);padding:12px;overflow-y:auto;display:flex;flex-direction:column;gap:8px}
.lp::-webkit-scrollbar{width:3px}
.lp::-webkit-scrollbar-thumb{background:rgba(167,139,250,.2)}
.sl{font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-bottom:4px}
.mtabs{display:flex;gap:3px;background:rgba(0,0,0,.3);border-radius:8px;padding:3px}
.mt{flex:1;padding:6px;border-radius:5px;font-size:11px;font-weight:500;cursor:pointer;text-align:center;transition:all .2s;color:#9b9bc0;border:none;background:transparent;font-family:inherit}
.mt.a{background:rgba(167,139,250,.2);color:#a78bfa}
.ac{display:flex;align-items:center;gap:7px;padding:8px 9px;border-radius:8px;border:.5px solid rgba(167,139,250,.15);background:rgba(255,255,255,.02);cursor:pointer;transition:all .2s;margin-bottom:4px}
.ac:hover{border-color:rgba(167,139,250,.3);background:rgba(167,139,250,.06)}
.ac.s{background:rgba(167,139,250,.12);border-color:#a78bfa}
.ai{width:28px;height:28px;border-radius:6px;background:rgba(167,139,250,.15);display:flex;align-items:center;justify-content:center;font-size:11px;color:#a78bfa;font-weight:700;flex-shrink:0}
.an{font-size:12px;font-weight:500;color:#f1f1ff}
.ac.s .an{color:#a78bfa}
.as{font-size:10px;color:#9b9bc0}
.ad{width:6px;height:6px;border-radius:50%;background:#22c55e;margin-left:auto;flex-shrink:0}
.tg{display:grid;grid-template-columns:1fr 1fr;gap:5px}
.tr{padding:8px;border-radius:7px;border:.5px solid rgba(167,139,250,.15);background:rgba(255,255,255,.02);cursor:pointer;text-align:center;transition:all .2s}
.tr:hover{border-color:rgba(167,139,250,.3)}
.tr.s{background:rgba(167,139,250,.12);border-color:#a78bfa}
.ts{font-size:13px;font-weight:600;color:#f1f1ff}
.tc{font-size:10px;color:#a78bfa;margin-top:1px}
.fs{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:7px;color:#f1f1ff;font-family:inherit;font-size:12px;padding:6px 9px;outline:none;cursor:pointer}
.fs:focus{border-color:#a78bfa}
.fs option{background:#1a1a2e;color:#f1f1ff}
.ft{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:7px;color:#f1f1ff;font-family:inherit;font-size:12px;padding:6px 9px;outline:none;resize:vertical;min-height:52px}
.ft:focus{border-color:#a78bfa}
.ft::placeholder{color:#6b6b90}
.iu{border:1.5px dashed rgba(167,139,250,.3);border-radius:10px;padding:.9rem;text-align:center;cursor:pointer;transition:all .2s;background:rgba(167,139,250,.02)}
.iu:hover{border-color:#a78bfa;background:rgba(167,139,250,.06)}
.iu.hi{border-style:solid;border-color:#a78bfa}
.ip{width:100%;border-radius:7px;margin-top:8px;display:none}
.cn{flex:1;display:flex;flex-direction:column;overflow:hidden}
.oa{flex:1;overflow-y:auto;padding:1.25rem;display:flex;flex-direction:column;gap:14px}
.oa::-webkit-scrollbar{width:4px}
.oa::-webkit-scrollbar-thumb{background:rgba(167,139,250,.2);border-radius:2px}
.wc{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:2rem;color:#9b9bc0}
.wi{width:80px;height:80px;border-radius:24px;background:linear-gradient(135deg,rgba(167,139,250,.15),rgba(56,189,248,.1));border:.5px solid rgba(167,139,250,.2);display:flex;align-items:center;justify-content:center;font-size:38px;color:#a78bfa;margin-bottom:16px}
.st{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin-top:14px;max-width:520px}
.sb2{padding:6px 14px;border-radius:20px;font-size:12px;background:rgba(167,139,250,.08);border:.5px solid rgba(167,139,250,.2);color:#a78bfa;cursor:pointer;transition:all .2s}
.sb2:hover{background:rgba(167,139,250,.18);transform:translateY(-1px)}
.vr{background:rgba(255,255,255,.04);border:.5px solid rgba(167,139,250,.15);border-radius:16px;overflow:hidden;max-width:720px;align-self:center;width:100%}
.vr video{width:100%;max-height:440px;display:block;background:#000;border-radius:16px 16px 0 0}
.vf{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;gap:8px;flex-wrap:wrap;border-top:.5px solid rgba(167,139,250,.08)}
.vm{flex:1;min-width:0}
.vp{font-size:12px;color:#9b9bc0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.vs{font-size:10px;color:#6b6b90;margin-top:2px}
.vb{display:flex;gap:5px}
.vbtn{display:flex;align-items:center;gap:4px;padding:5px 11px;border-radius:7px;font-size:11px;font-weight:500;cursor:pointer;border:none;font-family:inherit;transition:all .2s;text-decoration:none;white-space:nowrap}
.dl{background:rgba(34,197,94,.1);color:#22c55e;border:.5px solid rgba(34,197,94,.25)}
.pb{background:rgba(167,139,250,.1);color:#a78bfa;border:.5px solid rgba(167,139,250,.25)}
.fs2{background:rgba(56,189,248,.1);color:#38bdf8;border:.5px solid rgba(56,189,248,.2)}
.gb2{background:rgba(255,255,255,.05);color:#9b9bc0;border:.5px solid rgba(255,255,255,.1)}
.gn{background:rgba(167,139,250,.06);border:1px solid rgba(167,139,250,.2);border-radius:16px;padding:2rem;text-align:center;max-width:540px;align-self:center;width:100%}
.gs{width:56px;height:56px;border:3px solid rgba(167,139,250,.15);border-top-color:#a78bfa;border-radius:50%;animation:sp .9s linear infinite;margin:0 auto 16px}
@keyframes sp{to{transform:rotate(360deg)}}
.gp{width:100%;height:5px;background:rgba(255,255,255,.06);border-radius:3px;overflow:hidden;margin:14px 0 6px}
.gf{height:100%;background:linear-gradient(90deg,#a78bfa,#38bdf8,#f0abfc);border-radius:3px;transition:width 3s ease}
.ia{padding:12px 16px;border-top:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.85);flex-shrink:0}
.im{font-size:11px;color:#6b6b90;margin-bottom:7px;display:flex;align-items:center;gap:5px;flex-wrap:wrap}
.ir{display:flex;gap:8px;align-items:flex-end}
.pi{flex:1;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:10px;color:#f1f1ff;font-family:inherit;font-size:14px;padding:10px 14px;outline:none;resize:none;transition:border-color .2s;min-height:46px;max-height:110px;line-height:1.5}
.pi:focus{border-color:#a78bfa;box-shadow:0 0 0 3px rgba(167,139,250,.1)}
.pi::placeholder{color:#6b6b90}
.gb{width:50px;height:50px;border-radius:12px;background:linear-gradient(135deg,#a78bfa,#7c3aed);border:none;color:#fff;font-size:22px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s}
.gb:hover{filter:brightness(1.1);transform:translateY(-2px);box-shadow:0 6px 20px rgba(167,139,250,.3)}
.gb:disabled{opacity:.45;cursor:not-allowed;transform:none;box-shadow:none}
.cw{padding:8px 14px;border-radius:8px;font-size:12px;background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);color:#fca5a5;margin-bottom:8px;display:flex;align-items:center;gap:6px}
.hp{width:175px;flex-shrink:0;border-left:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.5);overflow-y:auto;padding:10px}
.ht{font-size:10px;color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px;font-weight:500;padding-bottom:6px;border-bottom:.5px solid rgba(167,139,250,.08)}
.hv{width:100%;aspect-ratio:16/9;object-fit:cover;border-radius:8px;margin-bottom:6px;border:.5px solid rgba(167,139,250,.1);cursor:pointer;background:#111;display:block;transition:border-color .2s}
.hv:hover{border-color:#a78bfa}
.hpend{width:100%;aspect-ratio:16/9;background:rgba(245,158,11,.07);border:.5px solid rgba(245,158,11,.2);border-radius:8px;margin-bottom:6px;display:flex;flex-direction:column;align-items:center;justify-content:center;font-size:10px;color:#f59e0b;gap:3px}
.hfail{width:100%;aspect-ratio:16/9;background:rgba(239,68,68,.07);border:.5px solid rgba(239,68,68,.2);border-radius:8px;margin-bottom:6px;display:flex;align-items:center;justify-content:center;font-size:10px;color:#ef4444}
#inf{position:fixed;right:-350px;top:0;width:330px;height:100vh;background:#0d0d1a;border-left:.5px solid rgba(167,139,250,.2);padding:1.5rem;overflow-y:auto;transition:right .3s;z-index:200}
#inf.o{right:0}
#vv{position:fixed;inset:0;background:rgba(0,0,0,.95);z-index:500;align-items:center;justify-content:center;display:none}
#vv.o{display:flex}
@media(max-width:1000px){.hp{display:none}}
@media(max-width:700px){.sb{display:none}.mn{margin-left:0}.lp{width:200px}}
@media(max-width:560px){.lp{display:none}}
</style>
</head>
<body>
<nav class="sb">
    <div class="sb-logo">◆ <?= ThemeEngine::siteName() ?></div>
    <?php foreach($allTools as $t): $ac=$t['slug']==='ai-video'?' a':''; ?>
    <a href="/aistudio/public/tools/<?= h($t['slug']) ?>.php" class="tb<?= $ac ?>" title="<?= h($t['name']) ?>">
        <i class="ti <?= h($t['icon']) ?>"></i><span class="tl"><?= h($t['name']) ?></span>
    </a>
    <?php endforeach; ?>
    <div class="sp"></div>
    <a href="/aistudio/public/dashboard.php" class="tb"><i class="ti ti-layout-dashboard"></i><span class="tl">Dashboard</span></a>
    <a href="/aistudio/public/logout.php" class="tb" style="margin-top:auto"><i class="ti ti-logout"></i><span class="tl">Logout</span></a>
</nav>

<div class="mn">
    <header class="top">
        <div style="display:flex;align-items:center;gap:8px">
            <i class="ti ti-player-play" style="color:#a78bfa;font-size:20px"></i>
            <span style="font-size:15px;font-weight:500">AI Video Generator</span>
            <button style="width:22px;height:22px;border-radius:50%;background:rgba(167,139,250,.15);border:.5px solid rgba(167,139,250,.3);color:#a78bfa;font-size:12px;cursor:pointer;display:flex;align-items:center;justify-content:center" onclick="document.getElementById('inf').classList.toggle('o')">i</button>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
            <div class="cp"><i class="ti ti-coin"></i><span id="cb"><?= number_format($user['credit_balance']) ?></span> cr</div>
        </div>
    </header>

    <div class="wr">
        <aside class="lp">
            <div>
                <div class="sl">Mode</div>
                <div class="mtabs">
                    <button class="mt a" id="mt0" onclick="setMode('text')"><i class="ti ti-text-caption" style="font-size:12px"></i> Text→Video</button>
                    <button class="mt" id="mt1" onclick="setMode('image')"><i class="ti ti-photo" style="font-size:12px"></i> Image→Video</button>
                </div>
            </div>

            <div id="imgSec" style="display:none">
                <div class="sl">Reference Image</div>
                <div class="iu" id="iuda" onclick="document.getElementById('imgf').click()">
                    <i class="ti ti-photo-up" style="font-size:22px;color:#a78bfa;display:block;margin-bottom:5px"></i>
                    <div style="font-size:11px;color:#9b9bc0">Click to upload or drag & drop</div>
                    <div style="font-size:10px;color:#6b6b90;margin-top:3px">JPG/PNG — max 10MB</div>
                    <input type="file" id="imgf" accept="image/*" style="display:none" onchange="ldImg(this)">
                    <img id="imgp" class="ip" alt="preview">
                </div>
            </div>

            <div>
                <div class="sl">AI Provider</div>
                <?php if(empty($services)): ?>
                <div style="font-size:12px;color:#6b6b90;text-align:center;padding:.75rem;line-height:1.6">No video APIs.<br><a href="/aistudio/public/admin/apis.php" style="color:#a78bfa">Add in Admin →</a></div>
                <?php else: foreach($services as $i=>$s):
                    $sel=$i===0?' s':'';
                    $init=strtoupper(substr($s['name'],0,2));
                    $pv=strtolower($s['provider']);
                    $badge=str_contains($pv,'replicate')?'Seedance 2.0':(str_contains($pv,'eachlabs')||str_contains($pv,'veo')?'Veo 3.1':(str_contains($pv,'leonardo')?'Leonardo':'Custom'));
                ?>
                <div class="ac<?= $sel ?>" onclick="selA(this,<?= $s['id'] ?>,'<?= h($s['name']) ?>')" data-id="<?= $s['id'] ?>">
                    <div class="ai"><?= $init ?></div>
                    <div style="flex:1;min-width:0"><div class="an"><?= h($s['name']) ?></div><div class="as"><?= $badge ?></div></div>
                    <?php if($sel): ?><div class="ad"></div><?php endif; ?>
                </div>
                <?php endforeach; endif; ?>
            </div>

            <div>
                <div class="sl">Duration & Credits</div>
                <?php if(empty($videoTiers)): ?>
                <div style="font-size:12px;color:#6b6b90">No tiers. <a href="/aistudio/public/admin/subscriptions.php" style="color:#a78bfa">Set →</a></div>
                <?php else: ?>
                <div class="tg">
                    <?php foreach($videoTiers as $i=>$t): ?>
                    <div class="tr <?= $i===0?'s':'' ?>" onclick="selT(this,<?= $t['duration_sec'] ?>,<?= $t['credit_cost'] ?>)">
                        <div class="ts"><?= $t['duration_sec'] ?>s</div>
                        <div class="tc"><?= $t['credit_cost'] ?> cr</div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <div>
                <div class="sl">Video Style</div>
                <select id="vs" class="fs">
                    <option value="">Auto</option>
                    <option value="cinematic, film quality">Cinematic</option>
                    <option value="photorealistic, ultra detailed">Photorealistic</option>
                    <option value="anime style">Anime</option>
                    <option value="3D rendered, CGI">3D Rendered</option>
                    <option value="documentary style">Documentary</option>
                    <option value="artistic, painterly">Artistic</option>
                    <option value="fantasy, magical">Fantasy</option>
                    <option value="sci-fi, futuristic">Sci-Fi</option>
                    <option value="vintage, retro film grain">Vintage</option>
                </select>
            </div>

            <div>
                <div class="sl">Aspect Ratio</div>
                <select id="va" class="fs">
                    <option value="16:9">16:9 — Landscape</option>
                    <option value="9:16">9:16 — Portrait/Reels</option>
                    <option value="1:1">1:1 — Square</option>
                    <option value="4:3">4:3 — Classic</option>
                    <option value="21:9">21:9 — Cinematic</option>
                </select>
            </div>

            <div>
                <div class="sl">Camera Movement</div>
                <select id="vc" class="fs">
                    <option value="">Auto</option>
                    <option value="slow pan left">Pan left</option>
                    <option value="slow pan right">Pan right</option>
                    <option value="zoom in slowly">Zoom in</option>
                    <option value="zoom out slowly">Zoom out</option>
                    <option value="aerial drone shot">Drone shot</option>
                    <option value="dolly forward">Dolly forward</option>
                    <option value="tracking shot">Tracking shot</option>
                    <option value="orbital camera">Orbital</option>
                    <option value="handheld camera">Handheld</option>
                </select>
            </div>

            <div>
                <div class="sl">Lighting</div>
                <select id="vl" class="fs">
                    <option value="">Default</option>
                    <option value="golden hour, warm sunlight">Golden hour</option>
                    <option value="blue hour, cool tones">Blue hour</option>
                    <option value="neon lights, vibrant colors">Neon lights</option>
                    <option value="soft natural daylight">Soft daylight</option>
                    <option value="dramatic shadows, high contrast">Dramatic</option>
                    <option value="studio lighting, professional">Studio</option>
                    <option value="moonlight, night scene">Moonlight</option>
                    <option value="misty foggy atmosphere">Foggy/Misty</option>
                </select>
            </div>

            <div>
                <div class="sl">Motion</div>
                <select id="vm" class="fs">
                    <option value="subtle minimal motion">Subtle</option>
                    <option value="" selected>Moderate</option>
                    <option value="dynamic energetic motion">Dynamic</option>
                    <option value="slow motion">Slow motion</option>
                    <option value="fast action">Fast action</option>
                </select>
            </div>

            <div>
                <div class="sl">Negative Prompt</div>
                <textarea id="vn" class="ft" placeholder="What to avoid...">blurry, low quality, distorted, watermark, text</textarea>
            </div>
        </aside>

        <div class="cn">
            <div class="oa" id="oa">
                <div class="wc" id="ws">
                    <div class="wi"><i class="ti ti-player-play"></i></div>
                    <h2 style="font-size:20px;font-weight:600;color:#f1f1ff;margin-bottom:8px">AI Video Generator</h2>
                    <p style="font-size:14px;max-width:440px;line-height:1.7;margin-bottom:4px">Create stunning videos from text or images using Seedance 2.0, Veo 3.1 &amp; Leonardo AI</p>
                    <div class="st">
                        <div class="sb2" onclick="u('A cinematic drone shot over snow-capped mountains at golden hour, misty valleys, 4K ultra HD')">Mountain drone</div>
                        <div class="sb2" onclick="u('Cyberpunk city at night, neon lights reflecting in rain, cinematic, high quality')">Cyberpunk rain</div>
                        <div class="sb2" onclick="u('Ocean waves crashing on rocky cliffs at sunset, slow motion, photorealistic')">Ocean sunset</div>
                        <div class="sb2" onclick="u('Abstract colorful fluid art with smooth hypnotic flowing motion, 4K')">Abstract fluid</div>
                        <div class="sb2" onclick="u('Cherry blossom forest in Japan, petals falling, soft sunlight, anime style')">Cherry blossoms</div>
                        <div class="sb2" onclick="u('Luxury product showcase, perfume bottle rotating on marble, studio lighting')">Product showcase</div>
                        <div class="sb2" onclick="u('Time lapse of clouds over mountains, golden sunset, dramatic sky')">Cloud time lapse</div>
                        <div class="sb2" onclick="u('Cozy cabin in snowy forest at night, warm light, snowflakes falling')">Snow cabin</div>
                    </div>
                </div>
            </div>

            <div class="ia">
                <div id="cwb" class="cw" style="display:none">
                    <i class="ti ti-alert-circle"></i>Insufficient credits.
                    <a href="/aistudio/public/billing.php" style="color:#f87171;margin-left:4px;font-weight:500">Top up →</a>
                </div>
                <div class="im">
                    <i class="ti ti-coin"></i>Cost: <span id="cl" style="color:#a78bfa;font-weight:500"><?= $defCost ?> cr</span>
                    &nbsp;·&nbsp; <span id="dl"><?= $defDur ?>s</span>
                    &nbsp;·&nbsp; <span id="pl" style="color:#a78bfa"><?= $defProv ?></span>
                    &nbsp;·&nbsp; Mode: <span id="ml" style="color:#38bdf8">Text→Video</span>
                </div>
                <div class="ir">
                    <textarea id="pi" class="pi" rows="1" placeholder="Describe your video scene in detail..."></textarea>
                    <button class="gb" id="gb" onclick="gen()"><i class="ti ti-sparkles" id="gi"></i></button>
                </div>
            </div>
        </div>

        <aside class="hp">
            <div class="ht"><i class="ti ti-history" style="font-size:11px"></i> Recent</div>
            <div id="hg">
                <?php foreach($recent as $v): ?>
                <?php if($v['status']==='completed'&&$v['video_url']): ?>
                <video class="hv" src="<?= h($v['video_url']) ?>" muted onclick="pv('<?= h($v['video_url']) ?>')" title="<?= h(substr($v['prompt']??'',0,50)) ?>"></video>
                <?php elseif(in_array($v['status'],['pending','processing'])): ?>
                <div class="hpend"><i class="ti ti-loader" style="animation:sp .8s linear infinite"></i>Processing</div>
                <?php else: ?>
                <div class="hfail"><i class="ti ti-x"></i> Failed</div>
                <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </aside>
    </div>
</div>

<div id="inf">
    <button onclick="document.getElementById('inf').classList.remove('o')" style="position:absolute;top:14px;right:14px;background:none;border:none;color:#9b9bc0;font-size:20px;cursor:pointer"><i class="ti ti-x"></i></button>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:1.25rem">
        <div style="width:42px;height:42px;border-radius:12px;background:linear-gradient(135deg,rgba(167,139,250,.2),rgba(56,189,248,.1));display:flex;align-items:center;justify-content:center;font-size:20px;color:#a78bfa"><i class="ti ti-player-play"></i></div>
        <div><h3 style="font-size:15px;font-weight:600">AI Video Generator</h3><div style="font-size:12px;color:#9b9bc0">Text-to-Video &amp; Image-to-Video</div></div>
    </div>
    <div style="font-size:13px;color:#9b9bc0;line-height:1.7">
        <p style="color:#a78bfa;font-weight:500;margin-bottom:4px">Modes</p>
        <p><strong style="color:#f1f1ff">Text→Video:</strong> Describe any scene — AI creates from scratch.</p>
        <p><strong style="color:#f1f1ff">Image→Video:</strong> Upload an image — AI animates it.</p><br>
        <p style="color:#a78bfa;font-weight:500;margin-bottom:4px">Providers</p>
        <p><strong style="color:#f1f1ff">Seedance 2.0:</strong> Best quality T2V &amp; I2V</p>
        <p><strong style="color:#f1f1ff">Veo 3.1:</strong> Cinematic quality, realistic scenes</p>
        <p><strong style="color:#f1f1ff">Leonardo:</strong> Fast, good for artistic styles</p><br>
        <p style="color:#a78bfa;font-weight:500;margin-bottom:4px">Pro Tips</p>
        <p>• Camera: "slow pan left", "drone shot", "zoom in"</p>
        <p>• Light: "golden hour", "neon lights", "studio"</p>
        <p>• Quality: "4K, ultra detailed, photorealistic"</p>
        <p>• Motion: "slow motion", "dynamic", "flowing"</p><br>
        <p style="color:#a78bfa;font-weight:500;margin-bottom:4px">Credit Tiers</p>
        <?php foreach($videoTiers as $t): ?>
        <p><?= $t['duration_sec'] ?>s = <strong style="color:#a78bfa"><?= $t['credit_cost'] ?> cr</strong></p>
        <?php endforeach; ?>
    </div>
</div>

<div id="vv" onclick="this.classList.remove('o')">
    <button onclick="document.getElementById('vv').classList.remove('o')" style="position:absolute;top:16px;right:16px;background:rgba(0,0,0,.5);border:none;color:#fff;font-size:24px;cursor:pointer;border-radius:50%;width:40px;height:40px;display:flex;align-items:center;justify-content:center"><i class="ti ti-x"></i></button>
    <video id="vvid" controls style="max-width:94%;max-height:90vh;border-radius:12px" onclick="event.stopPropagation()"></video>
</div>

<script>
const CSRF='<?= $csrf ?>';
let sApi=<?= $defApiId ?>,sDur=<?= $defDur ?>,sCost=<?= $defCost ?>,curBal=<?= (int)$user['credit_balance'] ?>,mode='text',imgB64='',isGen=false,polls={};
const inp=document.getElementById('pi');
inp.addEventListener('input',()=>{inp.style.height='auto';inp.style.height=Math.min(inp.scrollHeight,110)+'px'});
inp.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();gen();}});
function setMode(m){
    mode=m;
    document.getElementById('mt0').classList.toggle('a',m==='text');
    document.getElementById('mt1').classList.toggle('a',m==='image');
    document.getElementById('imgSec').style.display=m==='image'?'block':'none';
    document.getElementById('ml').textContent=m==='text'?'Text→Video':'Image→Video';
    inp.placeholder=m==='text'?'Describe your video scene in detail...':'Describe how to animate the image...';
}
function ldImg(input){
    const f=input.files[0];if(!f)return;
    const r=new FileReader();
    r.onload=e=>{
        imgB64=e.target.result.split(',')[1];
        const p=document.getElementById('imgp');const da=document.getElementById('iuda');
        p.src=e.target.result;p.style.display='block';da.classList.add('hi');
    };
    r.readAsDataURL(f);
}
const da=document.getElementById('iuda');
da.addEventListener('dragover',e=>{e.preventDefault();da.style.borderColor='#a78bfa'});
da.addEventListener('dragleave',()=>{da.style.borderColor=''});
da.addEventListener('drop',e=>{
    e.preventDefault();da.style.borderColor='';
    const f=e.dataTransfer.files[0];
    if(f&&f.type.startsWith('image/')){const inp2=document.getElementById('imgf');const dt=new DataTransfer();dt.items.add(f);inp2.files=dt.files;ldImg(inp2);}
});
function selA(el,id,name){
    document.querySelectorAll('.ac').forEach(c=>{c.classList.remove('s');const d=c.querySelector('.ad');if(d)d.remove()});
    el.classList.add('s');const d=document.createElement('div');d.className='ad';el.appendChild(d);
    sApi=id;document.getElementById('pl').textContent=name;
}
function selT(el,sec,cost){
    document.querySelectorAll('.tr').forEach(b=>b.classList.remove('s'));
    el.classList.add('s');sDur=sec;sCost=cost;
    document.getElementById('cl').textContent=cost+' cr';
    document.getElementById('dl').textContent=sec+'s';chkCr();
}
function chkCr(){document.getElementById('cwb').style.display=curBal<sCost?'flex':'none';}
function u(t){inp.value=t;inp.dispatchEvent(new Event('input'));inp.focus();}
async function gen(){
    const prompt=inp.value.trim();
    if(!prompt||isGen)return;
    if(mode==='image'&&!imgB64){alert('Upload a reference image first.');return;}
    if(curBal<sCost){document.getElementById('cwb').style.display='flex';return;}
    if(!sApi){alert('Select an AI provider.');return;}
    isGen=true;setLoad(true);
    document.getElementById('ws')?.remove();
    const style=document.getElementById('vs').value,cam=document.getElementById('vc').value,
          light=document.getElementById('vl').value,motion=document.getElementById('vm').value,
          neg=document.getElementById('vn').value,aspect=document.getElementById('va').value;
    const parts=[prompt];
    if(style)parts.push(style);if(cam)parts.push(cam);if(light)parts.push(light);if(motion)parts.push(motion);
    parts.push('high quality');
    const fp=parts.join(', ');
    const card=document.createElement('div');card.className='gn';card.id='gc';
    card.innerHTML=`<div class="gs"></div>
        <div style="font-size:15px;color:#f1f1ff;font-weight:600;margin-bottom:6px">Generating video...</div>
        <div style="font-size:11px;color:#9b9bc0;margin-bottom:4px">${mode==='image'?'Image→Video':'Text→Video'} · ${sDur}s · ${document.getElementById('pl').textContent}</div>
        <div style="font-size:11px;color:#6b6b90;margin-bottom:12px;max-width:380px;margin-left:auto;margin-right:auto">"${esc(fp.substring(0,90))}${fp.length>90?'...':''}"</div>
        <div class="gp"><div class="gf" id="gf" style="width:4%"></div></div>
        <div style="font-size:11px;color:#6b6b90;margin-top:5px" id="gst">Connecting to AI...</div>`;
    document.getElementById('oa').appendChild(card);card.scrollIntoView({behavior:'smooth'});
    let p=4;const pt=setInterval(()=>{p=Math.min(p+1,88);const f=document.getElementById('gf');if(f)f.style.width=p+'%';},4000);
    try{
        const res=await fetch('/aistudio/public/api/video-handler.php',{
            method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':CSRF},
            body:JSON.stringify({api_service_id:sApi,prompt:fp,negative_prompt:neg,duration_sec:sDur,aspect_ratio:aspect,mode,image_base64:mode==='image'?imgB64:''})
        });
        const data=await res.json();clearInterval(pt);
        if(data.success){
            curBal=data.new_balance||(curBal-sCost);
            document.getElementById('cb').textContent=curBal.toLocaleString();chkCr();
            if(data.video_url){card.remove();addR(data.video_url,fp,data.log_id,aspect);}
            else if(data.log_id){
                const gf=document.getElementById('gf');if(gf)gf.style.width='90%';
                const gs=document.getElementById('gst');if(gs)gs.textContent='Processing... polling every 5s';
                poll(data.log_id,card,fp,aspect);
            }
        } else {clearInterval(pt);card.remove();showE(data.error||'Generation failed.');}
    }catch(e){clearInterval(pt);card.remove();showE('Network error.');}
    isGen=false;setLoad(false);
}
function poll(lid,card,prompt,aspect){
    let att=0;
    polls[lid]=setInterval(async()=>{
        att++;const gs=document.getElementById('gst');if(gs)gs.textContent=`Checking... (${att}/60)`;
        if(att>60){clearInterval(polls[lid]);card.remove();showE('Timed out. Check history later.');return;}
        try{
            const r=await fetch('/aistudio/public/api/poll-video.php?id='+lid);
            const d=await r.json();
            if(d.status==='completed'&&d.video_url){clearInterval(polls[lid]);card.remove();addR(d.video_url,prompt,lid,aspect);}
            else if(d.status==='failed'){clearInterval(polls[lid]);card.remove();showE('Generation failed on provider.');}
        }catch(e){}
    },5000);
}
function addR(url,prompt,logId,aspect){
    const div=document.createElement('div');div.className='vr';
    const port=aspect==='9:16';
    div.innerHTML=`<video src="${url}" controls style="width:100%;max-height:${port?'580px':'440px'};display:block;background:#000;border-radius:16px 16px 0 0"></video>
    <div class="vf">
        <div class="vm"><div class="vp">${esc(prompt)}</div><div class="vs">${sDur}s · ${document.getElementById('pl').textContent} · ${aspect}</div></div>
        <div class="vb">
            <a href="${url}" download="aistudio_video.mp4" class="vbtn dl"><i class="ti ti-download"></i> Download</a>
            <button onclick="pub(${logId||0},this)" class="vbtn pb"><i class="ti ti-upload"></i> Publish</button>
            <button onclick="pv('${url}')" class="vbtn fs2"><i class="ti ti-maximize"></i></button>
            <button onclick="u('${esc(prompt)}');window.scrollTo(0,999999)" class="vbtn gb2"><i class="ti ti-refresh"></i></button>
        </div>
    </div>`;
    document.getElementById('oa').appendChild(div);div.scrollIntoView({behavior:'smooth'});
    const hg=document.getElementById('hg');const v=document.createElement('video');v.src=url;v.className='hv';v.muted=true;v.onclick=()=>pv(url);hg.insertBefore(v,hg.firstChild);
}
async function pub(lid,btn){
    if(!lid)return;
    try{const r=await fetch('/aistudio/public/api/publish-video.php',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':CSRF},body:JSON.stringify({log_id:lid})});
    const d=await r.json();if(d.success){btn.innerHTML='<i class="ti ti-check"></i> Published';btn.style.color='#22c55e';btn.disabled=true;}else alert(d.error||'Error');}catch(e){alert('Error');}
}
function pv(url){document.getElementById('vvid').src=url;document.getElementById('vv').classList.add('o');}
function showE(m){const d=document.createElement('div');d.style.cssText='padding:12px 16px;background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);border-radius:12px;color:#fca5a5;font-size:13px;display:flex;align-items:center;gap:8px;max-width:600px;align-self:center;width:100%';d.innerHTML='<i class="ti ti-alert-circle"></i>'+esc(m);document.getElementById('oa').appendChild(d);setTimeout(()=>d.remove(),10000);}
function setLoad(on){const b=document.getElementById('gb');const i=document.getElementById('gi');b.disabled=on;i.className=on?'ti ti-loader':'ti ti-sparkles';if(on){let r=0;i._t=setInterval(()=>{r+=12;i.style.transform=`rotate(${r}deg)`;},30);}else{clearInterval(i._t);i.style.transform='';}}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
chkCr();
</script>
</body>
</html>
