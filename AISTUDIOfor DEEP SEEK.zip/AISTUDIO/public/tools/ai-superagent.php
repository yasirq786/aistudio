<?php
// AIStudio — ai-superagent tool
// Uses universal tool template
$toolSlug = 'ai-superagent';
require_once __DIR__ . '/_universal.php';
