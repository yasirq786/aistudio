<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';

Security::startSession();
Security::checkIpBan();
Auth::requireLogin('/aistudio/public/login.php');

$user     = Auth::user();
$tool     = DB::queryOne("SELECT * FROM tools WHERE slug='ai-voice' AND is_enabled=1");
if (!$tool) { header('Location: /aistudio/public/dashboard.php'); exit; }

$services     = DB::query("SELECT * FROM api_services WHERE tool_id=? AND is_enabled=1 ORDER BY sort_order", [$tool['id']]);
$clonedVoices = DB::query("SELECT * FROM user_cloned_voices WHERE user_id=? AND is_active=1 ORDER BY created_at DESC", [$user['id']]);
$allTools     = DB::query("SELECT * FROM tools WHERE is_visible_on_landing=1 ORDER BY sort_order");
$csrf         = Security::generateCsrfToken();

// ElevenLabs built-in voice library — all free voices
$freeVoices = [
    ['id'=>'21m00Tcm4TlvDq8ikWAM','name'=>'Rachel','gender'=>'F','accent'=>'American','age'=>'Young','style'=>'Calm, professional narration'],
    ['id'=>'AZnzlk1XvdvUeBnXmlld','name'=>'Domi',  'gender'=>'F','accent'=>'American','age'=>'Young','style'=>'Strong, confident narration'],
    ['id'=>'EXAVITQu4vr4xnSDxMaL','name'=>'Bella',  'gender'=>'F','accent'=>'American','age'=>'Young','style'=>'Soft, gentle narration'],
    ['id'=>'MF3mGyEYCl7XYWbV9V6O','name'=>'Elli',   'gender'=>'F','accent'=>'American','age'=>'Young','style'=>'Emotional, expressive'],
    ['id'=>'XrExE9yKIg1WjnnlVkGX','name'=>'Matilda','gender'=>'F','accent'=>'American','age'=>'Middle','style'=>'Warm, confident'],
    ['id'=>'cgSgspJ2msm6clMCkdW9','name'=>'Jessica','gender'=>'F','accent'=>'American','age'=>'Young','style'=>'Conversational, pleasant'],
    ['id'=>'Xb7hH8MSUJpSbSDYk0k2','name'=>'Alice',  'gender'=>'F','accent'=>'British', 'age'=>'Middle','style'=>'Confident news presenter'],
    ['id'=>'XB0fDUnXU5powFXDhCwa','name'=>'Charlotte','gender'=>'F','accent'=>'Swedish','age'=>'Young','style'=>'Seductive, dramatic'],
    ['id'=>'ErXwobaYiN019PkySvjV', 'name'=>'Antoni','gender'=>'M','accent'=>'American','age'=>'Young','style'=>'Well-rounded, versatile'],
    ['id'=>'TxGEqnHWrfWFTfGW9XjX','name'=>'Josh',   'gender'=>'M','accent'=>'American','age'=>'Young','style'=>'Deep, warm narration'],
    ['id'=>'VR6AewLTigWG4xSOukaG','name'=>'Arnold', 'gender'=>'M','accent'=>'American','age'=>'Middle','style'=>'Crisp, strong character'],
    ['id'=>'pNInz6obpgDQGcFmaJgB','name'=>'Adam',   'gender'=>'M','accent'=>'American','age'=>'Middle','style'=>'Deep, authoritative'],
    ['id'=>'yoZ06aMxZJJ28mfd3POQ','name'=>'Sam',    'gender'=>'M','accent'=>'American','age'=>'Young','style'=>'Raspy, intense'],
    ['id'=>'D38z5RcWu1voky8WS1ja','name'=>'Fin',    'gender'=>'M','accent'=>'Irish',   'age'=>'Old',  'style'=>'Old sailor character'],
    ['id'=>'flq6f7yk4E4fJM5XTYuZ','name'=>'Michael','gender'=>'M','accent'=>'American','age'=>'Middle','style'=>'Orotund narrator'],
    ['id'=>'g5CIjZEefAph4nQFvHAz','name'=>'Callum', 'gender'=>'M','accent'=>'American','age'=>'Middle','style'=>'Intense, dramatic'],
    ['id'=>'IKne3meq5aSn9XLyUdCD','name'=>'Charlie','gender'=>'M','accent'=>'Australian','age'=>'Middle','style'=>'Casual, engaging'],
    ['id'=>'onwK4e9ZLuTAKqWW03F9','name'=>'Daniel', 'gender'=>'M','accent'=>'British', 'age'=>'Middle','style'=>'Deep, authoritative news'],
    ['id'=>'nPczCjzI2devNBz1zQrb','name'=>'Brian',  'gender'=>'M','accent'=>'American','age'=>'Middle','style'=>'Deep, American narrator'],
    ['id'=>'N2lVS1w4EtoT3dr4eOWO','name'=>'Callum2','gender'=>'M','accent'=>'Transatlantic','age'=>'Middle','style'=>'Intense character voice'],
];

// ElevenLabs models
$voiceModels = [
    'eleven_multilingual_v2' => 'Multilingual v2 — Best quality, 29 languages',
    'eleven_turbo_v2_5'      => 'Turbo v2.5 — Fastest, 32 languages',
    'eleven_turbo_v2'        => 'Turbo v2 — Fast, English focused',
    'eleven_monolingual_v1'  => 'Monolingual v1 — English only, legacy',
    'eleven_multilingual_v1' => 'Multilingual v1 — Legacy multilingual',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AI Voice Over — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d0d1a;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
/* Sidebar */
.sb{width:64px;min-height:100vh;background:#08080f;border-right:.5px solid rgba(167,139,250,.1);display:flex;flex-direction:column;position:fixed;left:0;top:0;transition:width .25s;overflow:hidden;z-index:100}
.sb:hover{width:220px}
.sb-logo{padding:16px 14px 20px;font-size:17px;font-weight:600;white-space:nowrap;overflow:hidden;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.tbtn{display:flex;align-items:center;gap:12px;padding:10px 14px;color:#9b9bc0;text-decoration:none;white-space:nowrap;transition:all .15s;font-size:13px;border-left:2px solid transparent}
.tbtn i{font-size:19px;flex-shrink:0;min-width:20px}
.tbtn:hover{color:#a78bfa;background:rgba(167,139,250,.07)}
.tbtn.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.tl{opacity:0;transition:opacity .2s}.sb:hover .tl{opacity:1}
.sepsb{height:.5px;background:rgba(167,139,250,.1);margin:6px 14px}
/* Layout */
.mn{margin-left:64px;flex:1;display:flex;flex-direction:column;height:100vh;overflow:hidden}
.topbar{height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 1.25rem;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.9);flex-shrink:0;z-index:50}
.cr-pill{display:flex;align-items:center;gap:5px;padding:4px 12px;background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.2);border-radius:20px;font-size:12px;font-weight:500;color:#a78bfa}
.wrap{display:flex;flex:1;overflow:hidden}
/* Left panel */
.lp{width:280px;flex-shrink:0;border-right:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.6);overflow-y:auto;display:flex;flex-direction:column}
.lp::-webkit-scrollbar{width:3px}
.lp::-webkit-scrollbar-thumb{background:rgba(167,139,250,.2)}
/* Tabs in left panel */
.lp-tabs{display:flex;border-bottom:.5px solid rgba(167,139,250,.1);flex-shrink:0}
.lp-tab{flex:1;padding:12px 8px;font-size:12px;font-weight:500;text-align:center;cursor:pointer;color:#9b9bc0;border-bottom:2px solid transparent;transition:all .2s}
.lp-tab:hover{color:#f1f1ff}
.lp-tab.active{color:#a78bfa;border-bottom-color:#a78bfa}
.lp-section{padding:14px;display:none;flex-direction:column;gap:10px}
.lp-section.active{display:flex}
/* Labels */
.sl{font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-bottom:5px}
/* Provider chip */
.pchip{display:flex;align-items:center;gap:8px;padding:9px 10px;border-radius:9px;border:.5px solid rgba(167,139,250,.15);background:rgba(255,255,255,.02);cursor:pointer;transition:all .2s;margin-bottom:5px}
.pchip:hover{border-color:rgba(167,139,250,.3);background:rgba(167,139,250,.06)}
.pchip.sel{background:rgba(167,139,250,.12);border-color:#a78bfa}
.pchip-ic{width:28px;height:28px;border-radius:6px;background:rgba(167,139,250,.15);display:flex;align-items:center;justify-content:center;font-size:11px;color:#a78bfa;font-weight:700;flex-shrink:0}
.pchip-n{font-size:12px;font-weight:500;color:#f1f1ff}.pchip.sel .pchip-n{color:#a78bfa}
.pchip-s{font-size:10px;color:#9b9bc0}
.pdot{width:6px;height:6px;border-radius:50%;background:#22c55e;margin-left:auto;flex-shrink:0}
/* Voice search */
.vsearch{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:8px;color:#f1f1ff;font-family:inherit;font-size:13px;padding:8px 12px;outline:none;margin-bottom:8px}
.vsearch:focus{border-color:#a78bfa}
.vsearch::placeholder{color:#6b6b90}
/* Filter tabs */
.filter-row{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px}
.ftag{padding:3px 10px;border-radius:12px;font-size:11px;cursor:pointer;border:.5px solid rgba(167,139,250,.15);color:#9b9bc0;background:transparent;font-family:inherit;transition:all .2s}
.ftag:hover{border-color:rgba(167,139,250,.3);color:#f1f1ff}
.ftag.active{background:rgba(167,139,250,.15);border-color:#a78bfa;color:#a78bfa}
/* Voice list */
.vlist{display:flex;flex-direction:column;gap:4px;max-height:260px;overflow-y:auto;padding-right:2px}
.vlist::-webkit-scrollbar{width:3px}
.vlist::-webkit-scrollbar-thumb{background:rgba(167,139,250,.2)}
.vc{display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:8px;border:.5px solid rgba(167,139,250,.1);background:rgba(255,255,255,.02);cursor:pointer;transition:all .2s}
.vc:hover{border-color:rgba(167,139,250,.25);background:rgba(167,139,250,.05)}
.vc.sel{background:rgba(167,139,250,.1);border-color:#a78bfa}
.va{width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:600;color:#fff;flex-shrink:0;background:linear-gradient(135deg,#a78bfa,#7c3aed)}
.va.f{background:linear-gradient(135deg,#f0abfc,#a78bfa)}
.va.cloned{background:linear-gradient(135deg,#38bdf8,#0ea5e9)}
.vname{font-size:12px;font-weight:500;color:#f1f1ff}.vc.sel .vname{color:#a78bfa}
.vdesc{font-size:10px;color:#9b9bc0;margin-top:1px;line-height:1.3}
.vtags{display:flex;gap:3px;margin-top:3px;flex-wrap:wrap}
.vtag{font-size:9px;padding:1px 5px;border-radius:3px;background:rgba(167,139,250,.1);color:#a78bfa}
.vtag.green{background:rgba(34,197,94,.1);color:#22c55e}
.vtag.blue{background:rgba(56,189,248,.1);color:#38bdf8}
.vactions{display:flex;gap:4px;margin-left:auto;flex-shrink:0}
.vpbtn{background:none;border:.5px solid rgba(167,139,250,.2);border-radius:5px;color:#9b9bc0;cursor:pointer;font-size:11px;padding:3px 6px;transition:all .2s}
.vpbtn:hover{color:#a78bfa;border-color:#a78bfa}
/* Form inputs */
.fs{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:7px;color:#f1f1ff;font-family:inherit;font-size:12px;padding:7px 10px;outline:none;cursor:pointer}
.fs:focus{border-color:#a78bfa}
.fs option{background:#1a1a2e;color:#f1f1ff}
/* Range slider */
.range-group{margin-bottom:2px}
.range-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:4px}
.range-label{font-size:11px;color:#9b9bc0}
.range-val{font-size:11px;color:#a78bfa;font-weight:500;min-width:32px;text-align:right}
input[type=range]{width:100%;accent-color:#a78bfa;height:3px}
/* Clone section */
.clone-section{background:rgba(56,189,248,.05);border:.5px solid rgba(56,189,248,.15);border-radius:12px;padding:14px}
.clone-title{font-size:13px;font-weight:500;color:#38bdf8;display:flex;align-items:center;gap:6px;margin-bottom:10px}
.clone-step{display:flex;align-items:flex-start;gap:8px;margin-bottom:8px;font-size:12px;color:#9b9bc0}
.clone-step-n{width:18px;height:18px;border-radius:50%;background:rgba(56,189,248,.2);color:#38bdf8;font-size:10px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px}
.clone-upload{border:1.5px dashed rgba(56,189,248,.3);border-radius:8px;padding:12px;text-align:center;cursor:pointer;transition:all .2s;margin-bottom:8px}
.clone-upload:hover{border-color:#38bdf8;background:rgba(56,189,248,.04)}
.clone-upload.has-file{border-style:solid;border-color:#38bdf8}
.finput{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(56,189,248,.2);border-radius:7px;color:#f1f1ff;font-family:inherit;font-size:12px;padding:7px 10px;outline:none;margin-bottom:7px}
.finput:focus{border-color:#38bdf8}
.clone-btn{width:100%;padding:9px;background:linear-gradient(135deg,#38bdf8,#0ea5e9);border:none;border-radius:8px;color:#000;font-family:inherit;font-size:13px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;transition:all .2s}
.clone-btn:hover{filter:brightness(1.1)}
.clone-btn:disabled{opacity:.5;cursor:not-allowed}
.tip-box{background:rgba(245,158,11,.06);border:.5px solid rgba(245,158,11,.2);border-radius:8px;padding:8px 10px;font-size:11px;color:#f59e0b;line-height:1.5;margin-top:4px}
/* Center */
.cn{flex:1;display:flex;flex-direction:column;overflow:hidden}
.oa{flex:1;overflow-y:auto;padding:1.5rem;display:flex;flex-direction:column;gap:16px}
.oa::-webkit-scrollbar{width:4px}
.oa::-webkit-scrollbar-thumb{background:rgba(167,139,250,.2);border-radius:2px}
/* Welcome */
.wc{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:2rem;color:#9b9bc0}
.wi{width:80px;height:80px;border-radius:24px;background:linear-gradient(135deg,rgba(167,139,250,.15),rgba(56,189,248,.1));border:.5px solid rgba(167,139,250,.2);display:flex;align-items:center;justify-content:center;font-size:38px;color:#a78bfa;margin-bottom:16px}
.starters{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;margin-top:14px;max-width:540px}
.sbtn{padding:6px 14px;border-radius:20px;font-size:12px;background:rgba(167,139,250,.08);border:.5px solid rgba(167,139,250,.2);color:#a78bfa;cursor:pointer;transition:all .2s}
.sbtn:hover{background:rgba(167,139,250,.18);transform:translateY(-1px)}
/* Audio result card */
.ar{background:rgba(255,255,255,.04);border:.5px solid rgba(167,139,250,.15);border-radius:16px;overflow:hidden;max-width:720px;align-self:center;width:100%}
.ar-header{padding:14px 16px;border-bottom:.5px solid rgba(167,139,250,.08);display:flex;align-items:center;gap:12px}
.ar-avatar{width:44px;height:44px;border-radius:50%;background:linear-gradient(135deg,#a78bfa,#7c3aed);display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:700;color:#fff;flex-shrink:0}
.ar-avatar.f{background:linear-gradient(135deg,#f0abfc,#a78bfa)}
.ar-avatar.cloned{background:linear-gradient(135deg,#38bdf8,#0ea5e9)}
.ar-info{flex:1;min-width:0}
.ar-name{font-size:14px;font-weight:500;color:#f1f1ff}
.ar-meta{font-size:11px;color:#9b9bc0;margin-top:2px}
.ar-body{padding:14px 16px}
.ar-text{font-size:13px;color:#9b9bc0;line-height:1.6;margin-bottom:12px;max-height:80px;overflow:hidden;position:relative}
.ar-text::after{content:'';position:absolute;bottom:0;left:0;right:0;height:20px;background:linear-gradient(transparent,rgba(255,255,255,.04))}
/* Custom audio player */
.audio-player{background:rgba(0,0,0,.3);border-radius:10px;padding:12px 14px;margin-bottom:12px}
.ap-controls{display:flex;align-items:center;gap:10px}
.ap-play{width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,#a78bfa,#7c3aed);border:none;color:#fff;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all .2s}
.ap-play:hover{filter:brightness(1.1);transform:scale(1.05)}
.ap-progress{flex:1;height:4px;background:rgba(255,255,255,.1);border-radius:2px;cursor:pointer;position:relative;overflow:hidden}
.ap-fill{height:100%;background:linear-gradient(90deg,#a78bfa,#38bdf8);border-radius:2px;width:0%;transition:width .1s}
.ap-time{font-size:11px;color:#9b9bc0;flex-shrink:0;min-width:60px;text-align:right}
.ap-volume{display:flex;align-items:center;gap:6px;margin-top:8px}
.ap-volume i{font-size:14px;color:#9b9bc0}
.ap-vol-slider{flex:1;height:3px;accent-color:#a78bfa}
.ap-speed{font-size:11px;color:#9b9bc0;background:rgba(167,139,250,.1);padding:2px 8px;border-radius:4px;cursor:pointer;border:none;font-family:inherit}
.ar-actions{display:flex;gap:6px;flex-wrap:wrap}
.abtn{display:flex;align-items:center;gap:4px;padding:7px 14px;border-radius:8px;font-size:12px;font-weight:500;cursor:pointer;border:none;font-family:inherit;transition:all .2s;text-decoration:none;white-space:nowrap}
.abtn-dl{background:rgba(34,197,94,.1);color:#22c55e;border:.5px solid rgba(34,197,94,.25)}
.abtn-cp{background:rgba(167,139,250,.1);color:#a78bfa;border:.5px solid rgba(167,139,250,.25)}
.abtn-re{background:rgba(56,189,248,.1);color:#38bdf8;border:.5px solid rgba(56,189,248,.2)}
.abtn-share{background:rgba(245,158,11,.1);color:#f59e0b;border:.5px solid rgba(245,158,11,.2)}
/* Generating */
.gbox{background:rgba(167,139,250,.06);border:1px solid rgba(167,139,250,.2);border-radius:14px;padding:1.5rem;text-align:center;max-width:500px;align-self:center;width:100%;display:flex;flex-direction:column;align-items:center;gap:8px}
.gspin{width:40px;height:40px;border:3px solid rgba(167,139,250,.15);border-top-color:#a78bfa;border-radius:50%;animation:spin .8s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
/* Input area */
.ia{border-top:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.85);flex-shrink:0;padding:14px 16px}
.ia-meta{font-size:11px;color:#6b6b90;margin-bottom:8px;display:flex;align-items:center;gap:5px;flex-wrap:wrap}
.ta-wrap{position:relative}
.main-ta{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:10px;color:#f1f1ff;font-family:inherit;font-size:14px;padding:12px 14px;outline:none;resize:vertical;min-height:90px;max-height:220px;line-height:1.65;transition:border-color .2s}
.main-ta:focus{border-color:#a78bfa;box-shadow:0 0 0 3px rgba(167,139,250,.1)}
.main-ta::placeholder{color:#6b6b90}
.char-ct{position:absolute;bottom:8px;right:10px;font-size:10px;color:#6b6b90;pointer-events:none}
.ia-btns{display:flex;gap:8px;margin-top:10px;align-items:center;flex-wrap:wrap}
.gen-btn{padding:11px 28px;border-radius:10px;background:linear-gradient(135deg,#a78bfa,#7c3aed);border:none;color:#fff;font-family:inherit;font-size:14px;font-weight:500;cursor:pointer;display:flex;align-items:center;gap:7px;transition:all .2s}
.gen-btn:hover{filter:brightness(1.1);transform:translateY(-1px);box-shadow:0 6px 20px rgba(167,139,250,.3)}
.gen-btn:disabled{opacity:.45;cursor:not-allowed;transform:none;box-shadow:none}
.clear-btn{padding:11px 18px;border-radius:10px;background:rgba(255,255,255,.05);border:.5px solid rgba(255,255,255,.1);color:#9b9bc0;font-family:inherit;font-size:14px;cursor:pointer;transition:all .2s}
.clear-btn:hover{background:rgba(255,255,255,.08);color:#f1f1ff}
.cw-bar{padding:8px 14px;border-radius:8px;font-size:12px;background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);color:#fca5a5;margin-bottom:8px;display:flex;align-items:center;gap:6px}
/* Info panel */
#inf{position:fixed;right:-360px;top:0;width:340px;height:100vh;background:#0d0d1a;border-left:.5px solid rgba(167,139,250,.2);padding:1.5rem;overflow-y:auto;transition:right .3s;z-index:200}
#inf.open{right:0}
@media(max-width:900px){.lp{width:230px}}
@media(max-width:700px){.sb{display:none}.mn{margin-left:0}.lp{display:none}}
</style>
</head>
<body>

<nav class="sb">
    <div class="sb-logo">◆ <?= ThemeEngine::siteName() ?></div>
    <?php foreach($allTools as $t): $ac=$t['slug']==='ai-voice'?' active':''; ?>
    <a href="/aistudio/public/tools/<?= h($t['slug']) ?>.php" class="tbtn<?= $ac ?>" title="<?= h($t['name']) ?>">
        <i class="ti <?= h($t['icon']) ?>"></i><span class="tl"><?= h($t['name']) ?></span>
    </a>
    <?php endforeach; ?>
    <div class="sepsb"></div>
    <a href="/aistudio/public/dashboard.php" class="tbtn"><i class="ti ti-layout-dashboard"></i><span class="tl">Dashboard</span></a>
    <a href="/aistudio/public/logout.php" class="tbtn" style="margin-top:auto"><i class="ti ti-logout"></i><span class="tl">Logout</span></a>
</nav>

<div class="mn">
    <header class="topbar">
        <div style="display:flex;align-items:center;gap:8px">
            <i class="ti ti-microphone" style="color:#a78bfa;font-size:20px"></i>
            <span style="font-size:15px;font-weight:500">AI Voice Over</span>
            <button style="width:22px;height:22px;border-radius:50%;background:rgba(167,139,250,.15);border:.5px solid rgba(167,139,250,.3);color:#a78bfa;font-size:12px;cursor:pointer;display:flex;align-items:center;justify-content:center" onclick="document.getElementById('inf').classList.toggle('open')">i</button>
        </div>
        <div style="display:flex;align-items:center;gap:10px">
            <div class="cr-pill"><i class="ti ti-coin"></i><span id="cb"><?= number_format($user['credit_balance']) ?></span> cr</div>
        </div>
    </header>

    <div class="wrap">

        <!-- Left panel with 3 tabs -->
        <aside class="lp">
            <div class="lp-tabs">
                <div class="lp-tab active" id="ltab0" onclick="setLTab(0)"><i class="ti ti-microphone-2" style="font-size:13px"></i> Voices</div>
                <div class="lp-tab" id="ltab1" onclick="setLTab(1)"><i class="ti ti-adjustments" style="font-size:13px"></i> Settings</div>
                <div class="lp-tab" id="ltab2" onclick="setLTab(2)"><i class="ti ti-user-check" style="font-size:13px"></i> Clone</div>
            </div>

            <!-- Tab 0: Voice selection -->
            <div class="lp-section active" id="ls0">
                <!-- Provider -->
                <div>
                    <div class="sl">Provider</div>
                    <?php if(empty($services)): ?>
                    <div style="font-size:12px;color:#6b6b90;text-align:center;padding:.75rem;line-height:1.6">No voice APIs.<br><a href="/aistudio/public/admin/apis.php" style="color:#a78bfa">Add ElevenLabs →</a></div>
                    <?php else: foreach($services as $i=>$s): $sel=$i===0?' sel':''; $init=strtoupper(substr($s['name'],0,2)); ?>
                    <div class="pchip<?= $sel ?>" onclick="selProv(this,<?= $s['id'] ?>,'<?= h($s['name']) ?>',<?= $s['credit_cost'] ?>)" data-id="<?= $s['id'] ?>">
                        <div class="pchip-ic"><?= $init ?></div>
                        <div style="flex:1;min-width:0"><div class="pchip-n"><?= h($s['name']) ?></div><div class="pchip-s"><?= $s['credit_cost'] ?> cr/gen</div></div>
                        <?php if($sel): ?><div class="pdot"></div><?php endif; ?>
                    </div>
                    <?php endforeach; endif; ?>
                </div>

                <!-- Voice search & filter -->
                <div>
                    <div class="sl">Select Voice</div>
                    <input type="text" class="vsearch" id="voiceSearch" placeholder="Search voices..." oninput="filterVoices()">
                    <div class="filter-row">
                        <button class="ftag active" onclick="filterGender('all',this)">All</button>
                        <button class="ftag" onclick="filterGender('F',this)">Female</button>
                        <button class="ftag" onclick="filterGender('M',this)">Male</button>
                        <button class="ftag" onclick="filterGender('cloned',this)">Cloned</button>
                    </div>
                    <div class="vlist" id="voiceList">
                        <!-- Cloned voices first -->
                        <?php foreach($clonedVoices as $cv): ?>
                        <div class="vc" onclick="selVoice(this,'<?= h($cv['provider_id']) ?>','<?= h($cv['name']) ?>','cloned')" data-vid="<?= h($cv['provider_id']) ?>" data-gender="cloned" data-name="<?= h(strtolower($cv['name'])) ?>">
                            <div class="va cloned"><i class="ti ti-user-check" style="font-size:15px;color:#fff"></i></div>
                            <div style="flex:1;min-width:0">
                                <div class="vname"><?= h($cv['name']) ?></div>
                                <div class="vdesc">Your cloned voice</div>
                                <div class="vtags"><span class="vtag green">Cloned</span><span class="vtag blue">Custom</span></div>
                            </div>
                            <div class="vactions">
                                <button class="vpbtn" onclick="prevVoice(event,'<?= h($cv['provider_id']) ?>','<?= h($cv['name']) ?>')" title="Preview"><i class="ti ti-player-play"></i></button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <!-- Free voices -->
                        <?php foreach($freeVoices as $i=>$v): ?>
                        <div class="vc <?= $i===0&&empty($clonedVoices)?'sel':'' ?>"
                             onclick="selVoice(this,'<?= $v['id'] ?>','<?= h($v['name']) ?>','<?= $v['gender'] ?>')"
                             data-vid="<?= $v['id'] ?>" data-gender="<?= $v['gender'] ?>" data-name="<?= h(strtolower($v['name'].' '.$v['style'])) ?>">
                            <div class="va <?= $v['gender']==='F'?'f':'' ?>"><?= strtoupper(substr($v['name'],0,1)) ?></div>
                            <div style="flex:1;min-width:0">
                                <div class="vname"><?= h($v['name']) ?></div>
                                <div class="vdesc"><?= h($v['style']) ?></div>
                                <div class="vtags">
                                    <span class="vtag"><?= $v['gender']==='F'?'Female':'Male' ?></span>
                                    <span class="vtag blue"><?= h($v['accent']) ?></span>
                                    <span class="vtag"><?= h($v['age']) ?></span>
                                </div>
                            </div>
                            <div class="vactions">
                                <button class="vpbtn" onclick="prevVoice(event,'<?= $v['id'] ?>','<?= h($v['name']) ?>')" title="Preview voice"><i class="ti ti-player-play"></i></button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Tab 1: Voice Settings -->
            <div class="lp-section" id="ls1">
                <div>
                    <div class="sl">AI Model</div>
                    <select id="voiceModel" class="fs">
                        <?php foreach($voiceModels as $mid=>$mname): ?>
                        <option value="<?= h($mid) ?>" <?= $mid==='eleven_multilingual_v2'?'selected':'' ?>><?= h($mname) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div style="font-size:10px;color:#6b6b90;margin-top:4px">Multilingual v2 recommended for best quality</div>
                </div>

                <div class="range-group">
                    <div class="range-header">
                        <div class="range-label">Stability</div>
                        <div class="range-val" id="stab-v">0.50</div>
                    </div>
                    <input type="range" id="stability" min="0" max="1" step="0.01" value="0.50" oninput="document.getElementById('stab-v').textContent=parseFloat(this.value).toFixed(2)">
                    <div style="font-size:10px;color:#6b6b90;margin-top:3px">High = consistent tone · Low = more expressive</div>
                </div>

                <div class="range-group">
                    <div class="range-header">
                        <div class="range-label">Similarity Boost</div>
                        <div class="range-val" id="sim-v">0.75</div>
                    </div>
                    <input type="range" id="similarity" min="0" max="1" step="0.01" value="0.75" oninput="document.getElementById('sim-v').textContent=parseFloat(this.value).toFixed(2)">
                    <div style="font-size:10px;color:#6b6b90;margin-top:3px">How closely to match the voice model</div>
                </div>

                <div class="range-group">
                    <div class="range-header">
                        <div class="range-label">Style Exaggeration</div>
                        <div class="range-val" id="style-v">0.00</div>
                    </div>
                    <input type="range" id="styleEx" min="0" max="1" step="0.01" value="0" oninput="document.getElementById('style-v').textContent=parseFloat(this.value).toFixed(2)">
                    <div style="font-size:10px;color:#6b6b90;margin-top:3px">More dramatic style variation (increases latency)</div>
                </div>

                <div class="range-group">
                    <div class="range-header">
                        <div class="range-label">Speaker Boost</div>
                        <div class="range-val" id="boost-v" style="color:#22c55e">ON</div>
                    </div>
                    <input type="range" id="speakerBoost" min="0" max="1" step="1" value="1" oninput="document.getElementById('boost-v').textContent=this.value==='1'?'ON':'OFF';document.getElementById('boost-v').style.color=this.value==='1'?'#22c55e':'#ef4444'">
                    <div style="font-size:10px;color:#6b6b90;margin-top:3px">Boost to make voice sound closer to original</div>
                </div>

                <div>
                    <div class="sl">Output Format</div>
                    <select id="outFmt" class="fs">
                        <option value="mp3_44100_128">MP3 128kbps — Recommended</option>
                        <option value="mp3_44100_192">MP3 192kbps — High quality</option>
                        <option value="mp3_22050_32">MP3 32kbps — Small file</option>
                        <option value="pcm_16000">PCM 16kHz — Telephony</option>
                        <option value="pcm_22050">PCM 22kHz — Standard</option>
                        <option value="pcm_44100">PCM 44kHz — Lossless</option>
                        <option value="ulaw_8000">μ-law 8kHz — Phone system</option>
                    </select>
                </div>

                <div>
                    <div class="sl">Language</div>
                    <select id="voiceLang" class="fs">
                        <option value="">Auto detect</option>
                        <option value="en">English</option>
                        <option value="ur">Urdu / اردو</option>
                        <option value="ar">Arabic / عربي</option>
                        <option value="fr">French</option>
                        <option value="de">German</option>
                        <option value="es">Spanish</option>
                        <option value="it">Italian</option>
                        <option value="pt">Portuguese</option>
                        <option value="ja">Japanese</option>
                        <option value="ko">Korean</option>
                        <option value="zh">Chinese</option>
                        <option value="hi">Hindi</option>
                        <option value="tr">Turkish</option>
                        <option value="pl">Polish</option>
                        <option value="nl">Dutch</option>
                        <option value="sv">Swedish</option>
                        <option value="fi">Finnish</option>
                        <option value="no">Norwegian</option>
                        <option value="da">Danish</option>
                        <option value="cs">Czech</option>
                        <option value="ro">Romanian</option>
                        <option value="hu">Hungarian</option>
                    </select>
                </div>

                <div style="background:rgba(167,139,250,.06);border:.5px solid rgba(167,139,250,.15);border-radius:10px;padding:10px 12px">
                    <div style="font-size:11px;font-weight:500;color:#a78bfa;margin-bottom:6px"><i class="ti ti-bulb" style="font-size:12px"></i> SSML Tips</div>
                    <div style="font-size:11px;color:#9b9bc0;line-height:1.7">
                        Add pauses: <code style="background:rgba(0,0,0,.3);padding:1px 4px;border-radius:3px;color:#38bdf8">&lt;break time="1s"/&gt;</code><br>
                        Emphasis: <code style="background:rgba(0,0,0,.3);padding:1px 4px;border-radius:3px;color:#38bdf8">WORD in CAPS</code><br>
                        Dramatic pause: <code style="background:rgba(0,0,0,.3);padding:1px 4px;border-radius:3px;color:#38bdf8">...</code>
                    </div>
                </div>
            </div>

            <!-- Tab 2: Voice Cloning -->
            <div class="lp-section" id="ls2">
                <div class="clone-section">
                    <div class="clone-title"><i class="ti ti-user-check"></i> Clone Your Voice</div>

                    <div class="clone-step">
                        <div class="clone-step-n">1</div>
                        <div>Record yourself speaking naturally for <strong style="color:#38bdf8">1-3 minutes</strong>. No background noise, clear pronunciation.</div>
                    </div>
                    <div class="clone-step">
                        <div class="clone-step-n">2</div>
                        <div>Upload the audio file below (MP3, WAV, M4A)</div>
                    </div>
                    <div class="clone-step">
                        <div class="clone-step-n">3</div>
                        <div>Give your voice a name and click Clone</div>
                    </div>

                    <div class="clone-upload" id="cloneDropArea" onclick="document.getElementById('cloneFile').click()">
                        <i class="ti ti-upload" style="font-size:22px;color:#38bdf8;display:block;margin-bottom:5px"></i>
                        <div style="font-size:12px;color:#9b9bc0">Click to upload or drag & drop</div>
                        <div style="font-size:10px;color:#6b6b90;margin-top:3px">MP3, WAV, M4A, OGG — max 25MB</div>
                        <input type="file" id="cloneFile" accept="audio/*" style="display:none" onchange="onCloneFile(this)">
                        <div id="cloneFileName" style="font-size:11px;color:#38bdf8;margin-top:5px;display:none"></div>
                    </div>

                    <input type="text" id="cloneVoiceName" class="finput" placeholder="Voice name (e.g. My Voice, John)" maxlength="50">

                    <div>
                        <div class="sl" style="margin-bottom:5px">Consent (required by ElevenLabs)</div>
                        <label style="display:flex;align-items:flex-start;gap:7px;font-size:11px;color:#9b9bc0;cursor:pointer;line-height:1.5">
                            <input type="checkbox" id="cloneConsent" style="accent-color:#38bdf8;margin-top:2px;flex-shrink:0">
                            I own rights to this audio and consent to voice cloning per ElevenLabs Terms of Service
                        </label>
                    </div>

                    <button class="clone-btn" id="cloneBtn" onclick="doClone()">
                        <i class="ti ti-user-plus"></i> Clone My Voice
                    </button>

                    <div class="tip-box">
                        <i class="ti ti-info-circle" style="font-size:12px"></i>
                        Best results: speak clearly, vary sentences, avoid music/noise. Longer samples = better quality.
                    </div>
                </div>

                <!-- Existing cloned voices management -->
                <?php if(!empty($clonedVoices)): ?>
                <div>
                    <div class="sl">Your Cloned Voices (<?= count($clonedVoices) ?>)</div>
                    <?php foreach($clonedVoices as $cv): ?>
                    <div style="display:flex;align-items:center;gap:8px;padding:8px 10px;border-radius:8px;border:.5px solid rgba(56,189,248,.15);background:rgba(56,189,248,.04);margin-bottom:5px">
                        <div class="va cloned" style="width:30px;height:30px;font-size:12px"><i class="ti ti-user-check" style="font-size:13px;color:#fff"></i></div>
                        <div style="flex:1;min-width:0">
                            <div style="font-size:12px;font-weight:500;color:#f1f1ff"><?= h($cv['name']) ?></div>
                            <div style="font-size:10px;color:#6b6b90"><?= date('M j, Y', strtotime($cv['created_at'])) ?></div>
                        </div>
                        <div style="display:flex;gap:4px">
                            <button class="vpbtn" onclick="prevVoice(event,'<?= h($cv['provider_id']) ?>','<?= h($cv['name']) ?>')" title="Preview">
                                <i class="ti ti-player-play"></i>
                            </button>
                            <button onclick="deleteClone(<?= $cv['id'] ?>,this)" class="vpbtn" style="color:#ef4444;border-color:rgba(239,68,68,.2)" title="Delete">
                                <i class="ti ti-trash"></i>
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </aside>

        <!-- Center: output + input -->
        <div class="cn">
            <div class="oa" id="oa">
                <div class="wc" id="ws">
                    <div class="wi"><i class="ti ti-microphone"></i></div>
                    <h2 style="font-size:20px;font-weight:600;color:#f1f1ff;margin-bottom:8px">AI Voice Over</h2>
                    <p style="font-size:14px;max-width:460px;line-height:1.7">Convert text to natural AI voice with 20+ voices, voice cloning, multilingual support, and studio-quality audio.</p>
                    <div class="starters">
                        <div class="sbtn" onclick="useT('Welcome to AIStudio — the most powerful AI platform. Generate images, videos, voice and more with just a few clicks. Sign up today and get 50 free credits.')">Platform intro</div>
                        <div class="sbtn" onclick="useT('In a world where technology shapes every aspect of our lives, artificial intelligence stands at the forefront of innovation... transforming how we work, create, and connect with each other.')">Cinematic narration</div>
                        <div class="sbtn" onclick="useT('Hey everyone! Welcome back to my channel. Today I want to share something really exciting with you. This AI voice technology sounds completely natural — can you believe this is AI?')">YouTube intro</div>
                        <div class="sbtn" onclick="useT('Thank you for calling. Your call is important to us. Please stay on the line and a representative will assist you shortly. Estimated wait time is two minutes.')">IVR / Phone system</div>
                        <div class="sbtn" onclick="useT('Discover the power of AI today. Create stunning images. Generate amazing videos. Clone your voice. Bring your ideas to life in seconds. Try it free — no credit card required.')">Ad copy</div>
                        <div class="sbtn" onclick="useT('Chapter one. It was a dark and stormy night. The rain fell in sheets against the windows of the old mansion, and lightning split the sky with a terrifying crack.')">Audiobook narration</div>
                    </div>
                </div>
            </div>

            <div class="ia">
                <div id="cwb" class="cw-bar" style="display:none">
                    <i class="ti ti-alert-circle"></i>Insufficient credits.
                    <a href="/aistudio/public/billing.php" style="color:#f87171;margin-left:4px;font-weight:500">Top up →</a>
                </div>
                <div class="ia-meta">
                    <i class="ti ti-coin"></i>Cost: <span id="cost-lbl" style="color:#a78bfa;font-weight:500"><?= $services[0]['credit_cost'] ?? 1 ?> cr</span>
                    &nbsp;·&nbsp; Voice: <span id="voice-lbl" style="color:#a78bfa"><?= !empty($clonedVoices) ? h($clonedVoices[0]['name']) : 'Rachel' ?></span>
                    &nbsp;·&nbsp; Provider: <span id="prov-lbl" style="color:#a78bfa"><?= h($services[0]['name'] ?? 'None') ?></span>
                    &nbsp;·&nbsp; <span id="char-meta" style="color:#6b6b90">0 / 5000</span>
                </div>
                <div class="ta-wrap">
                    <textarea id="textInput" class="main-ta"
                              placeholder="Type or paste your text here...&#10;&#10;Tip: Use CAPS for emphasis, ... for pauses, punctuation for natural rhythm."
                              maxlength="5000"
                              oninput="onTextInput()"></textarea>
                    <span class="char-ct" id="charCt">0</span>
                </div>
                <div class="ia-btns">
                    <button class="gen-btn" id="gb" onclick="generate()">
                        <i class="ti ti-player-play" id="gi"></i> Generate Voice
                    </button>
                    <button class="clear-btn" onclick="document.getElementById('textInput').value='';onTextInput()">
                        <i class="ti ti-x"></i> Clear
                    </button>
                    <div style="margin-left:auto;display:flex;align-items:center;gap:6px;font-size:11px;color:#6b6b90">
                        <i class="ti ti-keyboard" style="font-size:13px"></i>
                        Ctrl+Enter to generate
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Info panel -->
<div id="inf">
    <button onclick="document.getElementById('inf').classList.remove('open')" style="position:absolute;top:14px;right:14px;background:none;border:none;color:#9b9bc0;font-size:20px;cursor:pointer"><i class="ti ti-x"></i></button>
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:1.25rem">
        <div style="width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,rgba(167,139,250,.2),rgba(56,189,248,.1));display:flex;align-items:center;justify-content:center;font-size:22px;color:#a78bfa"><i class="ti ti-microphone"></i></div>
        <div><h3 style="font-size:15px;font-weight:600">AI Voice Over</h3><div style="font-size:12px;color:#9b9bc0">Powered by ElevenLabs</div></div>
    </div>
    <div style="font-size:13px;color:#9b9bc0;line-height:1.8">
        <p style="color:#a78bfa;font-weight:500;margin-bottom:4px">Features</p>
        <p>• 20 built-in voice models</p>
        <p>• Voice cloning — upload your voice</p>
        <p>• 23 language support</p>
        <p>• Stability, similarity, style controls</p>
        <p>• Multiple output formats</p>
        <p>• Speaker boost for clarity</p><br>
        <p style="color:#a78bfa;font-weight:500;margin-bottom:4px">Voice Settings</p>
        <p><strong style="color:#f1f1ff">Stability:</strong> 0.3–0.7 for expressive · 0.7+ for narration</p>
        <p><strong style="color:#f1f1ff">Similarity:</strong> Higher = more true to model</p>
        <p><strong style="color:#f1f1ff">Style:</strong> 0 = natural · 0.5+ = dramatic</p><br>
        <p style="color:#a78bfa;font-weight:500;margin-bottom:4px">Text Tips</p>
        <p>• CAPS = emphasis on words</p>
        <p>• ... = dramatic pause</p>
        <p>• Comma, period = natural pauses</p>
        <p>• Question marks = rising tone</p>
        <p>• Max 5000 characters per generation</p><br>
        <p style="color:#a78bfa;font-weight:500;margin-bottom:4px">Voice Cloning</p>
        <p>Upload 1–3 min of clear audio. No background noise. ElevenLabs clones your exact voice characteristics.</p>
    </div>
</div>

<!-- Hidden preview audio -->
<audio id="prevAudio" style="display:none"></audio>

<script>
const CSRF = '<?= $csrf ?>';
let selApiId  = <?= (int)($services[0]['id'] ?? 0) ?>;
let selCost   = <?= (int)($services[0]['credit_cost'] ?? 1) ?>;
let selVoiceId = '<?= !empty($clonedVoices) ? h($clonedVoices[0]['provider_id']) : '21m00Tcm4TlvDq8ikWAM' ?>';
let selVoiceName = '<?= !empty($clonedVoices) ? h($clonedVoices[0]['name']) : 'Rachel' ?>';
let selGender = '<?= !empty($clonedVoices) ? 'cloned' : 'F' ?>';
let curBal    = <?= (int)$user['credit_balance'] ?>;
let genderFilter = 'all';
let isGen = false;
let prevPlaying = false;

// Keyboard shortcut
document.addEventListener('keydown', e => { if ((e.ctrlKey||e.metaKey) && e.key==='Enter') generate(); });

// Left panel tabs
function setLTab(n) {
    [0,1,2].forEach(i => {
        document.getElementById('ltab'+i).classList.toggle('active', i===n);
        document.getElementById('ls'+i).classList.toggle('active', i===n);
    });
}

// Provider selection
function selProv(el, id, name, cost) {
    document.querySelectorAll('.pchip').forEach(c => { c.classList.remove('sel'); const d=c.querySelector('.pdot'); if(d)d.remove(); });
    el.classList.add('sel');
    const d=document.createElement('div'); d.className='pdot'; el.appendChild(d);
    selApiId=id; selCost=cost;
    document.getElementById('prov-lbl').textContent=name;
    document.getElementById('cost-lbl').textContent=cost+' cr';
    chkCr();
}

// Voice selection
function selVoice(el, vid, name, gender) {
    document.querySelectorAll('.vc').forEach(c => c.classList.remove('sel'));
    el.classList.add('sel');
    selVoiceId=vid; selVoiceName=name; selGender=gender;
    document.getElementById('voice-lbl').textContent=name;
}

// Voice filter
function filterGender(g, btn) {
    document.querySelectorAll('.ftag').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    genderFilter=g;
    filterVoices();
}

function filterVoices() {
    const q = document.getElementById('voiceSearch').value.toLowerCase();
    document.querySelectorAll('.vc').forEach(vc => {
        const n = vc.dataset.name||'';
        const g = vc.dataset.gender||'';
        const matchG = genderFilter==='all' || g===genderFilter;
        const matchQ = !q || n.includes(q);
        vc.style.display = matchG && matchQ ? '' : 'none';
    });
}

// Voice preview
function prevVoice(e, vid, name) {
    e.stopPropagation();
    const btn=e.currentTarget;
    const origHtml=btn.innerHTML;
    btn.innerHTML='<i class="ti ti-loader" style="animation:spin .8s linear infinite"></i>';
    const au=document.getElementById('prevAudio');
    if (!au.paused) { au.pause(); au.currentTime=0; }
    fetch('/aistudio/public/api/preview-voice.php?voice_id='+encodeURIComponent(vid)+'&api_id='+selApiId)
        .then(r => { if(!r.ok) throw new Error('No preview'); return r.blob(); })
        .then(b => {
            const url=URL.createObjectURL(b);
            au.src=url; au.play();
            btn.innerHTML='<i class="ti ti-player-pause"></i>';
            au.onended=()=>{ btn.innerHTML=origHtml; URL.revokeObjectURL(url); };
        })
        .catch(()=>{ btn.innerHTML=origHtml; alert('Preview not available. Check API key.'); });
}

// Text input
function onTextInput() {
    const l = document.getElementById('textInput').value.length;
    document.getElementById('charCt').textContent=l;
    document.getElementById('char-meta').textContent=l+' / 5000';
}

function useT(t) { document.getElementById('textInput').value=t; onTextInput(); document.getElementById('textInput').focus(); }
function chkCr() { document.getElementById('cwb').style.display=curBal<selCost?'flex':'none'; }

// Generate
async function generate() {
    const text = document.getElementById('textInput').value.trim();
    if (!text) { alert('Please enter some text.'); return; }
    if (isGen) return;
    if (!selApiId) { alert('Select an API provider first.'); return; }
    if (curBal < selCost) { document.getElementById('cwb').style.display='flex'; return; }

    isGen=true; setLoad(true);
    document.getElementById('ws')?.remove();

    const card = document.createElement('div'); card.className='gbox'; card.id='gc';
    card.innerHTML=`<div class="gspin"></div>
        <div style="font-size:14px;color:#f1f1ff;font-weight:500">Generating voice...</div>
        <div style="font-size:12px;color:#9b9bc0">${esc(selVoiceName)} · ${document.getElementById('prov-lbl').textContent}</div>
        <div style="font-size:11px;color:#6b6b90;max-width:340px">"${esc(text.substring(0,80))}${text.length>80?'...':''}"</div>`;
    document.getElementById('oa').appendChild(card); card.scrollIntoView({behavior:'smooth'});

    try {
        const res = await fetch('/aistudio/public/api/voice-handler.php', {
            method:'POST',
            headers:{'Content-Type':'application/json','X-CSRF-Token':CSRF},
            body: JSON.stringify({
                api_service_id: selApiId,
                text,
                voice_id:       selVoiceId,
                voice_name:     selVoiceName,
                model_id:       document.getElementById('voiceModel').value,
                stability:      parseFloat(document.getElementById('stability').value),
                similarity_boost: parseFloat(document.getElementById('similarity').value),
                style:          parseFloat(document.getElementById('styleEx').value),
                use_speaker_boost: document.getElementById('speakerBoost').value==='1',
                output_format:  document.getElementById('outFmt').value,
                language:       document.getElementById('voiceLang').value,
            })
        });
        const data = await res.json(); card.remove();
        if (data.success) {
            curBal = data.new_balance;
            document.getElementById('cb').textContent=curBal.toLocaleString();
            chkCr();
            addResult(data.audio_url, text, selVoiceName, selGender, data.duration_secs||0);
        } else {
            showErr(data.error || 'Generation failed. Please try again.');
        }
    } catch(e) { card.remove(); showErr('Network error. Check your connection.'); }
    isGen=false; setLoad(false);
}

function addResult(url, text, voiceName, gender, dur) {
    const div = document.createElement('div'); div.className='ar';
    const initial = voiceName.charAt(0).toUpperCase();
    const avatarClass = gender==='cloned' ? 'cloned' : (gender==='F' ? 'f' : '');
    const avatarContent = gender==='cloned'
        ? '<i class="ti ti-user-check" style="font-size:16px;color:#fff"></i>'
        : initial;
    const model = document.getElementById('voiceModel').options[document.getElementById('voiceModel').selectedIndex].text.split('—')[0].trim();
    const fmt   = document.getElementById('outFmt').value.replace(/_/g,' ').toUpperCase();

    div.innerHTML=`
    <div class="ar-header">
        <div class="ar-avatar ${avatarClass}">${avatarContent}</div>
        <div class="ar-info">
            <div class="ar-name">${esc(voiceName)} ${dur?'· '+dur.toFixed(1)+'s':''}</div>
            <div class="ar-meta">${esc(model)} · ${fmt} · ${document.getElementById('prov-lbl').textContent}</div>
        </div>
    </div>
    <div class="ar-body">
        <div class="ar-text">${esc(text)}</div>
        <div class="audio-player" id="ap_${Date.now()}">
            <div class="ap-controls">
                <button class="ap-play" id="apbtn" onclick="togglePlay(this, '${url}')"><i class="ti ti-player-play-filled"></i></button>
                <div class="ap-progress" onclick="seekAudio(event,this,'${url}')">
                    <div class="ap-fill" id="apfill"></div>
                </div>
                <div class="ap-time" id="aptime">0:00 / 0:00</div>
            </div>
            <div class="ap-volume">
                <i class="ti ti-volume"></i>
                <input type="range" class="ap-vol-slider" min="0" max="1" step="0.05" value="1" oninput="setVolume(this.value)" style="flex:1">
                <button class="ap-speed" onclick="cycleSpeed(this)">1x</button>
            </div>
        </div>
        <div class="ar-actions">
            <a href="${url}" download="${esc(voiceName).toLowerCase().replace(/\s+/g,'-')}_voice.mp3" class="abtn abtn-dl"><i class="ti ti-download"></i> Download</a>
            <button onclick="copyText(this)" data-text="${esc(text)}" class="abtn abtn-cp"><i class="ti ti-copy"></i> Copy text</button>
            <button onclick="reGenerate()" class="abtn abtn-re"><i class="ti ti-refresh"></i> Regenerate</button>
        </div>
    </div>`;

    document.getElementById('oa').appendChild(div); div.scrollIntoView({behavior:'smooth'});
    // Init audio for this card
    initPlayer(div, url);
}

// Audio player
let currentAudio = null;
let currentBtn   = null;

function initPlayer(card, url) {
    const au = new Audio(url);
    card._audio = au;
    au.addEventListener('timeupdate', () => {
        if (!au.duration) return;
        const pct = (au.currentTime / au.duration * 100).toFixed(1);
        const fill = card.querySelector('.ap-fill');
        const time = card.querySelector('.ap-time');
        if (fill) fill.style.width = pct+'%';
        if (time) time.textContent = fmt(au.currentTime)+' / '+fmt(au.duration);
    });
    au.addEventListener('ended', () => {
        const btn = card.querySelector('.ap-play');
        if (btn) btn.innerHTML='<i class="ti ti-player-play-filled"></i>';
        const fill = card.querySelector('.ap-fill');
        if (fill) fill.style.width='0%';
    });
}

function togglePlay(btn, url) {
    const card = btn.closest('.ar');
    const au = card?._audio;
    if (!au) return;
    if (currentAudio && currentAudio !== au) {
        currentAudio.pause();
        if (currentBtn) currentBtn.innerHTML='<i class="ti ti-player-play-filled"></i>';
    }
    if (au.paused) {
        au.play();
        btn.innerHTML='<i class="ti ti-player-pause-filled"></i>';
        currentAudio=au; currentBtn=btn;
    } else {
        au.pause();
        btn.innerHTML='<i class="ti ti-player-play-filled"></i>';
    }
}

function seekAudio(e, bar, url) {
    const card = bar.closest('.ar');
    const au = card?._audio;
    if (!au||!au.duration) return;
    const rect = bar.getBoundingClientRect();
    const pct = (e.clientX - rect.left) / rect.width;
    au.currentTime = pct * au.duration;
}

function setVolume(v) {
    if (currentAudio) currentAudio.volume = parseFloat(v);
}

const speeds = [0.5, 0.75, 1, 1.25, 1.5, 2];
function cycleSpeed(btn) {
    const cur = parseFloat(btn.textContent);
    const idx = speeds.indexOf(cur);
    const next = speeds[(idx+1)%speeds.length];
    btn.textContent = next+'x';
    if (currentAudio) currentAudio.playbackRate = next;
}

function fmt(s) {
    const m = Math.floor(s/60);
    return m+':'+(Math.floor(s%60)+'').padStart(2,'0');
}

function copyText(btn) {
    navigator.clipboard.writeText(btn.dataset.text);
    const orig=btn.innerHTML; btn.innerHTML='<i class="ti ti-check"></i> Copied!'; btn.style.color='#22c55e';
    setTimeout(()=>{btn.innerHTML=orig;btn.style.color='';},2000);
}

function reGenerate() { generate(); }

// Voice cloning
function onCloneFile(input) {
    const f = input.files[0];
    if (!f) return;
    const area = document.getElementById('cloneDropArea');
    const nm   = document.getElementById('cloneFileName');
    area.classList.add('has-file');
    nm.textContent = f.name + ' (' + (f.size/1024/1024).toFixed(1) + 'MB)';
    nm.style.display = 'block';
}

const cloneDA = document.getElementById('cloneDropArea');
cloneDA.addEventListener('dragover',  e=>{e.preventDefault();cloneDA.style.borderColor='#38bdf8'});
cloneDA.addEventListener('dragleave', ()=>cloneDA.style.borderColor='');
cloneDA.addEventListener('drop', e=>{
    e.preventDefault(); cloneDA.style.borderColor='';
    const f = e.dataTransfer.files[0];
    if (f && f.type.startsWith('audio/')) {
        const dt=new DataTransfer(); dt.items.add(f);
        document.getElementById('cloneFile').files=dt.files;
        onCloneFile(document.getElementById('cloneFile'));
    }
});

async function doClone() {
    const f    = document.getElementById('cloneFile').files[0];
    const name = document.getElementById('cloneVoiceName').value.trim();
    const cons = document.getElementById('cloneConsent').checked;
    if (!f)    { alert('Upload an audio file first.'); return; }
    if (!name) { alert('Enter a name for your cloned voice.'); return; }
    if (!cons) { alert('Please accept the consent checkbox.'); return; }
    if (!selApiId) { alert('Select a provider first.'); return; }

    const btn=document.getElementById('cloneBtn');
    btn.disabled=true;
    btn.innerHTML='<div style="width:16px;height:16px;border:2px solid rgba(0,0,0,.3);border-top-color:#000;border-radius:50%;animation:spin .8s linear infinite"></div> Cloning...';

    const fd=new FormData();
    fd.append('audio',f); fd.append('name',name);
    fd.append('api_service_id',selApiId); fd.append('_csrf',CSRF);

    try {
        const r=await fetch('/aistudio/public/api/clone-voice.php',{method:'POST',body:fd});
        const d=await r.json();
        if (d.success) {
            btn.style.background='linear-gradient(135deg,#22c55e,#16a34a)';
            btn.innerHTML='<i class="ti ti-check"></i> Voice Cloned! Reloading...';
            setTimeout(()=>location.reload(),1500);
        } else {
            btn.disabled=false;
            btn.innerHTML='<i class="ti ti-user-plus"></i> Clone My Voice';
            alert(d.error||'Cloning failed. Check your API key and try again.');
        }
    } catch(e) {
        btn.disabled=false;
        btn.innerHTML='<i class="ti ti-user-plus"></i> Clone My Voice';
        alert('Network error during cloning.');
    }
}

async function deleteClone(id, btn) {
    if (!confirm('Delete this cloned voice? This also removes it from ElevenLabs.')) return;
    const orig=btn.innerHTML; btn.innerHTML='<i class="ti ti-loader"></i>'; btn.disabled=true;
    try {
        const r=await fetch('/aistudio/public/api/delete-clone.php',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':CSRF},body:JSON.stringify({id})});
        const d=await r.json();
        if(d.success) location.reload();
        else { btn.innerHTML=orig;btn.disabled=false;alert(d.error||'Delete failed'); }
    } catch(e){btn.innerHTML=orig;btn.disabled=false;}
}

function showErr(m) {
    const d=document.createElement('div');
    d.style.cssText='padding:12px 16px;background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);border-radius:12px;color:#fca5a5;font-size:13px;display:flex;align-items:center;gap:8px;max-width:680px;align-self:center;width:100%';
    d.innerHTML='<i class="ti ti-alert-circle" style="flex-shrink:0"></i>'+esc(m);
    document.getElementById('oa').appendChild(d);
    setTimeout(()=>d.remove(),12000);
}

function setLoad(on) {
    const b=document.getElementById('gb'); const i=document.getElementById('gi');
    b.disabled=on;
    if(on){b.innerHTML='<i class="ti ti-loader" style="animation:spin .8s linear infinite"></i> Generating...';}
    else {b.innerHTML='<i class="ti ti-player-play"></i> Generate Voice';}
}

function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
chkCr();
</script>
</body>
</html>
