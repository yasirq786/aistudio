<?php
// AIStudio — ai-funnel tool
// Uses universal tool template
$toolSlug = 'ai-funnel';
require_once __DIR__ . '/_universal.php';
