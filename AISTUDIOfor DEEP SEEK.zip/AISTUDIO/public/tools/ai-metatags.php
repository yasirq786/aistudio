<?php
// AIStudio — ai-metatags tool
// Uses universal tool template
$toolSlug = 'ai-metatags';
require_once __DIR__ . '/_universal.php';
