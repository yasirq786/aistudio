<?php
// AIStudio — ai-human tool
// Uses universal tool template
$toolSlug = 'ai-human';
require_once __DIR__ . '/_universal.php';
