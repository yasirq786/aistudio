<?php
// AIStudio — ai-app tool
// Uses universal tool template
$toolSlug = 'ai-app';
require_once __DIR__ . '/_universal.php';
