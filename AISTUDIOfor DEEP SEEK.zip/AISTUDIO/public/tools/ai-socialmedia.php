<?php
// AIStudio — ai-socialmedia tool
// Uses universal tool template
$toolSlug = 'ai-socialmedia';
require_once __DIR__ . '/_universal.php';
