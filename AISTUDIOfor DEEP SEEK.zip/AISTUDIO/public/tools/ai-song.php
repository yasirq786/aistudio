<?php
// AIStudio — ai-song tool
// Uses universal tool template
$toolSlug = 'ai-song';
require_once __DIR__ . '/_universal.php';
