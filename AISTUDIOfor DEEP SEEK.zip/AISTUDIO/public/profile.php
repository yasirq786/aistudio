<?php
define('ROOT', dirname(__DIR__));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();
Auth::requireLogin('/aistudio/public/login.php');

$user  = Auth::user();
$msg   = '';
$error = '';
$csrf  = Security::generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();
    $action = $_POST['action'] ?? '';

    if ($action === 'update_profile') {
        $name   = Security::sanitizeRaw($_POST['name']   ?? '');
        $mobile = Security::sanitizeRaw($_POST['mobile'] ?? '');
        $lang   = in_array($_POST['language'] ?? 'en', ['en','ur']) ? $_POST['language'] : 'en';

        // Email change
        $newEmail = strtolower(trim($_POST['email'] ?? ''));
        if ($newEmail !== $user['email']) {
            $exists = DB::scalar("SELECT COUNT(*) FROM users WHERE email=? AND id!=?", [$newEmail, $user['id']]);
            if ($exists) {
                $error = 'Email already in use.';
            }
        }

        if (!$error) {
            DB::execute(
                "UPDATE users SET name=?, email=?, mobile=?, language=? WHERE id=?",
                [$name, $newEmail ?: $user['email'], $mobile, $lang, $user['id']]
            );

            // Photo upload
            if (!empty($_FILES['photo']['name'])) {
                $ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
                if (in_array($ext, ['jpg','jpeg','png','webp']) && $_FILES['photo']['size'] < 2097152) {
                    $dir = ROOT . '/public/assets/img/avatars/';
                    if (!is_dir($dir)) mkdir($dir, 0755, true);
                    $fname = 'user_' . $user['id'] . '.' . $ext;
                    move_uploaded_file($_FILES['photo']['tmp_name'], $dir . $fname);
                    DB::execute("UPDATE users SET photo=? WHERE id=?",
                        ['/aistudio/public/assets/img/avatars/' . $fname, $user['id']]);
                }
            }
            $msg = 'Profile updated successfully.';
        }
    }
    elseif ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $new     = $_POST['new_password']     ?? '';
        $confirm = $_POST['confirm_password'] ?? '';

        $dbUser = DB::queryOne("SELECT password FROM users WHERE id=?", [$user['id']]);

        if (!password_verify($current, $dbUser['password'])) {
            $error = 'Current password is incorrect.';
        } elseif (strlen($new) < 8) {
            $error = 'New password must be at least 8 characters.';
        } elseif ($new !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            DB::execute(
                "UPDATE users SET password=? WHERE id=?",
                [password_hash($new, PASSWORD_BCRYPT, ['cost' => 12]), $user['id']]
            );
            $msg = 'Password changed successfully.';
        }
    }

    // Refresh user data
    $user = DB::queryOne("SELECT * FROM users WHERE id=?", [$user['id']]);
}

$referralCount = (int)DB::scalar("SELECT COUNT(*) FROM users WHERE referred_by=?", [$user['id']]);
$subscription  = DB::queryOne(
    "SELECT us.*, sp.name as plan_name FROM user_subscriptions us
     JOIN subscription_plans sp ON sp.id=us.plan_id
     WHERE us.user_id=? AND us.status='active' AND us.expires_at>NOW()
     ORDER BY us.expires_at DESC LIMIT 1",
    [$user['id']]
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Profile — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d0d1a;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:64px;min-height:100vh;background:#08080f;border-right:.5px solid rgba(167,139,250,.1);display:flex;flex-direction:column;position:fixed;left:0;top:0;transition:width .25s;overflow:hidden;z-index:100}
.sidebar:hover{width:220px}
.sidebar-logo{padding:16px 14px 20px;font-size:17px;font-weight:600;white-space:nowrap;overflow:hidden;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.tool-btn{display:flex;align-items:center;gap:12px;padding:10px 14px;color:#9b9bc0;text-decoration:none;white-space:nowrap;transition:all .15s;font-size:13px;border-left:2px solid transparent}
.tool-btn i{font-size:19px;flex-shrink:0;min-width:20px}
.tool-btn:hover{color:#a78bfa;background:rgba(167,139,250,.07)}
.tool-btn.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.tool-label{opacity:0;transition:opacity .2s}
.sidebar:hover .tool-label{opacity:1}
.sep{height:.5px;background:rgba(167,139,250,.1);margin:6px 14px}
.main{margin-left:64px;flex:1;display:flex;flex-direction:column}
.topbar{height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(8,8,15,.9);position:sticky;top:0;z-index:50}
.content{padding:1.5rem;max-width:700px}
.card{background:rgba(255,255,255,.04);border:.5px solid rgba(167,139,250,.15);border-radius:14px;padding:1.25rem;margin-bottom:1.25rem}
.card-title{font-size:14px;font-weight:500;color:#f1f1ff;margin-bottom:1rem;display:flex;align-items:center;gap:8px;padding-bottom:10px;border-bottom:.5px solid rgba(167,139,250,.1)}
.card-title i{color:#a78bfa;font-size:17px}
.form-group{margin-bottom:14px}
.form-label{display:block;font-size:12px;font-weight:500;color:#9b9bc0;margin-bottom:5px}
.form-input{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:9px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:14px;padding:10px 13px;outline:none;transition:border-color .2s}
.form-input:focus{border-color:#a78bfa;box-shadow:0 0 0 3px rgba(167,139,250,.1)}
select.form-input option{background:#1a1a2e;color:#f1f1ff}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.btn{display:inline-flex;align-items:center;gap:6px;padding:10px 20px;border-radius:9px;font-size:14px;font-weight:500;cursor:pointer;border:none;font-family:'Inter',sans-serif;transition:all .2s}
.btn-primary{background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff}
.btn-primary:hover{filter:brightness(1.1)}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:1rem;display:flex;align-items:center;gap:8px}
.alert-success{background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.alert-error{background:rgba(239,68,68,.1);border:.5px solid #ef4444;color:#fca5a5}
.avatar-wrap{display:flex;align-items:center;gap:16px;margin-bottom:1rem}
.avatar-big{width:72px;height:72px;border-radius:50%;background:linear-gradient(135deg,#a78bfa,#7c3aed);display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:600;color:#fff;overflow:hidden;flex-shrink:0}
.avatar-big img{width:100%;height:100%;object-fit:cover}
.info-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.info-item{background:rgba(167,139,250,.06);border-radius:10px;padding:12px}
.info-label{font-size:11px;color:#6b6b90;margin-bottom:4px}
.info-val{font-size:14px;font-weight:500;color:#f1f1ff}
.copy-btn{background:none;border:none;color:#a78bfa;cursor:pointer;font-size:13px;margin-left:6px;padding:0;transition:opacity .2s}
.copy-btn:hover{opacity:.7}
.credit-pill{display:flex;align-items:center;gap:5px;padding:4px 12px;background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.2);border-radius:20px;font-size:12px;font-weight:500;color:#a78bfa}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?></div>
    <?php $tools = DB::query("SELECT slug,name,icon,is_enabled FROM tools WHERE is_visible_on_landing=1 ORDER BY sort_order LIMIT 25");
    foreach ($tools as $t): ?>
    <a href="/aistudio/public/tools/<?= h($t['slug']) ?>.php" class="tool-btn" title="<?= h($t['name']) ?>">
        <i class="ti <?= h($t['icon']) ?>"></i><span class="tool-label"><?= h($t['name']) ?></span>
    </a>
    <?php endforeach; ?>
    <div class="sep"></div>
    <a href="/aistudio/public/dashboard.php" class="tool-btn"><i class="ti ti-layout-dashboard"></i><span class="tool-label">Dashboard</span></a>
    <a href="/aistudio/public/profile.php"   class="tool-btn active"><i class="ti ti-user"></i><span class="tool-label">Profile</span></a>
    <a href="/aistudio/public/billing.php"   class="tool-btn"><i class="ti ti-receipt"></i><span class="tool-label">Billing</span></a>
    <a href="/aistudio/public/logout.php"    class="tool-btn" style="margin-top:auto"><i class="ti ti-logout"></i><span class="tool-label">Logout</span></a>
</nav>

<div class="main">
    <header class="topbar">
        <span style="font-size:14px;font-weight:500">My Profile</span>
        <div style="display:flex;align-items:center;gap:10px">
            <div class="credit-pill"><i class="ti ti-coin"></i><?= number_format($user['credit_balance']) ?> cr</div>
        </div>
    </header>
    <div class="content">
        <?php if ($msg):   ?><div class="alert alert-success"><i class="ti ti-check"></i><?= h($msg) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><i class="ti ti-alert-circle"></i><?= h($error) ?></div><?php endif; ?>

        <!-- Account info -->
        <div class="card">
            <div class="card-title"><i class="ti ti-user-circle"></i>Account Info</div>
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">Member since</div>
                    <div class="info-val"><?= date('M j, Y', strtotime($user['created_at'])) ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Plan</div>
                    <div class="info-val"><?= $subscription ? h($subscription['plan_name']) : 'Free' ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Referral code</div>
                    <div class="info-val">
                        <?= h($user['referral_code']) ?>
                        <button class="copy-btn" onclick="copyRef()" title="Copy"><i class="ti ti-copy"></i></button>
                    </div>
                </div>
                <div class="info-item">
                    <div class="info-label">Referrals</div>
                    <div class="info-val"><?= $referralCount ?> users joined</div>
                </div>
            </div>
        </div>

        <!-- Edit profile -->
        <div class="card">
            <div class="card-title"><i class="ti ti-edit"></i>Edit Profile</div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="_csrf"   value="<?= h($csrf) ?>">
                <input type="hidden" name="action"  value="update_profile">

                <div class="avatar-wrap">
                    <div class="avatar-big">
                        <?php if (!empty($user['photo'])): ?>
                            <img src="<?= h($user['photo']) ?>" alt="avatar">
                        <?php else: ?>
                            <?= strtoupper(substr($user['name'], 0, 1)) ?>
                        <?php endif; ?>
                    </div>
                    <div>
                        <label style="display:inline-flex;align-items:center;gap:6px;padding:7px 14px;background:rgba(167,139,250,.1);border:.5px solid rgba(167,139,250,.25);border-radius:8px;cursor:pointer;font-size:13px;color:#a78bfa">
                            <i class="ti ti-upload"></i> Change photo
                            <input type="file" name="photo" accept=".jpg,.jpeg,.png,.webp" style="display:none" onchange="previewPhoto(this)">
                        </label>
                        <div style="font-size:11px;color:#6b6b90;margin-top:5px">JPG, PNG or WebP — max 2MB</div>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Full name</label>
                        <input type="text" name="name" class="form-input" value="<?= h($user['name']) ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Email address</label>
                        <input type="email" name="email" class="form-input" value="<?= h($user['email']) ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Mobile number</label>
                        <input type="tel" name="mobile" class="form-input" value="<?= h($user['mobile'] ?? '') ?>" placeholder="+92 3XX XXXXXXX">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Language</label>
                        <select name="language" class="form-input">
                            <option value="en" <?= ($user['language'] ?? 'en') === 'en' ? 'selected' : '' ?>>English (US)</option>
                            <option value="ur" <?= ($user['language'] ?? 'en') === 'ur' ? 'selected' : '' ?>>اردو (Urdu)</option>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="ti ti-check"></i> Save changes</button>
            </form>
        </div>

        <!-- Change password -->
        <div class="card">
            <div class="card-title"><i class="ti ti-lock"></i>Change Password</div>
            <form method="POST">
                <input type="hidden" name="_csrf"  value="<?= h($csrf) ?>">
                <input type="hidden" name="action" value="change_password">
                <div class="form-group">
                    <label class="form-label">Current password</label>
                    <input type="password" name="current_password" class="form-input" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">New password</label>
                        <input type="password" name="new_password" class="form-input" minlength="8" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Confirm new password</label>
                        <input type="password" name="confirm_password" class="form-input" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="ti ti-key"></i> Change password</button>
            </form>
        </div>
    </div>
</div>

<script>
function copyRef() {
    navigator.clipboard.writeText('<?= h($user['referral_code']) ?>');
    const btn = event.target.closest('.copy-btn');
    btn.innerHTML = '<i class="ti ti-check"></i>';
    setTimeout(() => btn.innerHTML = '<i class="ti ti-copy"></i>', 2000);
}
function previewPhoto(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            const av = document.querySelector('.avatar-big');
            av.innerHTML = `<img src="${e.target.result}" alt="preview">`;
        };
        reader.readAsDataURL(input.files[0]);
    }
}
</script>
</body>
</html>
