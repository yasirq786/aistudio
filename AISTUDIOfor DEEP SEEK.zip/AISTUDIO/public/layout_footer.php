        </main><!-- end .as-content -->
    </div><!-- end .as-main -->
</div><!-- end .as-layout -->

<!-- ── Mobile bottom nav ──────────────────────────────────────── -->
<nav class="as-mobile-nav" aria-label="Mobile tool navigation">
    <?php
    $mobileTools = DB::query(
        "SELECT slug, name, icon, is_enabled FROM tools ORDER BY sort_order ASC LIMIT 5"
    );
    foreach ($mobileTools as $mt):
        $href   = $mt['is_enabled'] ? '/tools/' . h($mt['slug']) : '#';
        $active = ($mt['slug'] === ($pageToolSlug ?? '')) ? 'color:var(--as-primary)' : '';
    ?>
    <a href="<?= $href ?>" style="<?= $active ?>;display:flex;flex-direction:column;
       align-items:center;gap:2px;font-size:10px;color:var(--as-text-secondary);
       text-decoration:none" aria-label="<?= h($mt['name']) ?>">
        <i class="ti <?= h($mt['icon']) ?>" style="font-size:22px" aria-hidden="true"></i>
        <span><?= h(substr($mt['name'], 3)) ?></span>
    </a>
    <?php endforeach; ?>

    <a href="/dashboard" style="display:flex;flex-direction:column;align-items:center;
       gap:2px;font-size:10px;color:var(--as-text-secondary);text-decoration:none" aria-label="Dashboard">
        <i class="ti ti-layout-dashboard" style="font-size:22px" aria-hidden="true"></i>
        <span>Home</span>
    </a>
</nav>

<!-- ── Scripts ────────────────────────────────────────────────── -->
<script>
const CSRF_TOKEN = document.querySelector('meta[name="csrf-token"]')?.content ?? '';

/* Auto-dismiss flash messages */
const flash = document.getElementById('asFlash');
if (flash) setTimeout(() => flash.remove(), 4000);

/* Language toggle */
function toggleLanguage() {
    fetch('/api/toggle-language.php', {
        method: 'POST',
        headers: { 'X-CSRF-Token': CSRF_TOKEN, 'Content-Type': 'application/json' }
    }).then(() => location.reload());
}

/* Credit balance refresh */
function refreshCredits() {
    fetch('/api/get-credits.php')
        .then(r => r.json())
        .then(d => {
            const el = document.getElementById('creditBalance');
            if (el && d.balance !== undefined) {
                el.textContent = d.balance.toLocaleString();
            }
        });
}

/* Toast helper — call from any tool page */
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `as-flash as-flash-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3500);
}

/* Generation loading state helper */
function setGenerating(btnId, loadingId, loading = true) {
    const btn  = document.getElementById(btnId);
    const load = document.getElementById(loadingId);
    if (btn)  btn.disabled   = loading;
    if (load) load.style.display = loading ? 'flex' : 'none';
}
</script>

<?php
/* ── Neural net animation ──────────────────────────────────────── */
$animation = ThemeEngine::get('theme_animation', 'neural_net');
if ($animation === 'neural_net'):
?>
<script>
(function() {
    const canvas = document.getElementById('asNeuralCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const primary = getComputedStyle(document.documentElement)
        .getPropertyValue('--as-primary').trim() || '#a78bfa';

    let nodes = [];
    const NODE_COUNT = 60;
    const CONNECT_DIST = 140;

    function resize() {
        canvas.width  = window.innerWidth;
        canvas.height = window.innerHeight;
    }

    function init() {
        nodes = [];
        for (let i = 0; i < NODE_COUNT; i++) {
            nodes.push({
                x:  Math.random() * canvas.width,
                y:  Math.random() * canvas.height,
                vx: (Math.random() - 0.5) * 0.4,
                vy: (Math.random() - 0.5) * 0.4,
                r:  Math.random() * 2 + 1,
            });
        }
    }

    function draw() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        for (let i = 0; i < nodes.length; i++) {
            const n = nodes[i];
            n.x += n.vx;
            n.y += n.vy;
            if (n.x < 0 || n.x > canvas.width)  n.vx *= -1;
            if (n.y < 0 || n.y > canvas.height)  n.vy *= -1;

            for (let j = i + 1; j < nodes.length; j++) {
                const m = nodes[j];
                const dx = n.x - m.x;
                const dy = n.y - m.y;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist < CONNECT_DIST) {
                    ctx.beginPath();
                    ctx.strokeStyle = primary;
                    ctx.globalAlpha = (1 - dist / CONNECT_DIST) * 0.25;
                    ctx.lineWidth   = 0.5;
                    ctx.moveTo(n.x, n.y);
                    ctx.lineTo(m.x, m.y);
                    ctx.stroke();
                }
            }

            ctx.beginPath();
            ctx.globalAlpha = 0.6;
            ctx.fillStyle   = primary;
            ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
            ctx.fill();
        }

        requestAnimationFrame(draw);
    }

    window.addEventListener('resize', () => { resize(); init(); });
    resize();
    init();

    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!prefersReduced) draw();
})();
</script>
<?php endif; ?>

<?php if ($animation === 'particles'): ?>
<script>
/* Lightweight particle animation */
(function() {
    const canvas = document.createElement('canvas');
    canvas.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:0;opacity:0.3';
    document.body.prepend(canvas);
    const ctx   = canvas.getContext('2d');
    const color = '#a78bfa';
    let pts = [];

    const resize = () => { canvas.width = innerWidth; canvas.height = innerHeight; };
    resize();
    window.addEventListener('resize', resize);

    for (let i = 0; i < 80; i++) pts.push({
        x: Math.random() * innerWidth,
        y: Math.random() * innerHeight,
        vy: Math.random() * 0.3 + 0.1,
        r: Math.random() * 1.5 + 0.5,
        o: Math.random() * 0.5 + 0.2,
    });

    if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
        (function loop() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            pts.forEach(p => {
                p.y -= p.vy;
                if (p.y < -5) { p.y = canvas.height + 5; p.x = Math.random() * canvas.width; }
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                ctx.fillStyle = color;
                ctx.globalAlpha = p.o;
                ctx.fill();
            });
            requestAnimationFrame(loop);
        })();
    }
})();
</script>
<?php endif; ?>

</body>
</html>
