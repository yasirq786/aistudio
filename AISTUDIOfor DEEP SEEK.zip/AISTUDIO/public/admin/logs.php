<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();
Auth::requireAdmin();

$msg  = '';
$csrf = Security::generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();
    $action = $_POST['action'] ?? '';

    if ($action === 'delete_selected') {
        $ids = array_map('intval', $_POST['ids'] ?? []);
        if ($ids) {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            DB::execute("DELETE FROM api_call_logs WHERE id IN ({$placeholders})", $ids);
            $msg = count($ids) . ' log(s) deleted.';
        }
    }
    elseif ($action === 'delete_older') {
        $days = max(1, (int)($_POST['days'] ?? 30));
        $count = DB::execute("DELETE FROM api_call_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)", [$days]);
        $msg = "{$count} logs older than {$days} days deleted.";
    }
    elseif ($action === 'delete_all') {
        DB::execute("DELETE FROM api_call_logs WHERE 1");
        $msg = 'All API logs cleared.';
    }
}

// Filters
$fUser   = Security::sanitizeRaw($_GET['user']   ?? '');
$fTool   = (int)($_GET['tool']                   ?? 0);
$fStatus = $_GET['status']                        ?? '';
$fFrom   = $_GET['from']                          ?? '';
$fTo     = $_GET['to']                            ?? '';
$page    = max(1,(int)($_GET['page']              ?? 1));
$perPage = 30;

$where  = ['1=1'];
$params = [];
if ($fUser) {
    $where[]  = '(u.email LIKE ? OR u.name LIKE ?)';
    $params[] = "%{$fUser}%";
    $params[] = "%{$fUser}%";
}
if ($fTool)   { $where[] = 'acl.tool_id=?';   $params[] = $fTool; }
if ($fStatus) { $where[] = 'acl.status=?';    $params[] = $fStatus; }
if ($fFrom)   { $where[] = 'acl.created_at>=?'; $params[] = $fFrom.' 00:00:00'; }
if ($fTo)     { $where[] = 'acl.created_at<=?'; $params[] = $fTo.' 23:59:59'; }

$whereStr = implode(' AND ', $where);
$total    = (int)DB::scalar(
    "SELECT COUNT(*) FROM api_call_logs acl LEFT JOIN users u ON u.id=acl.user_id WHERE {$whereStr}",
    $params
);
$offset = ($page-1)*$perPage;

$logs = DB::query(
    "SELECT acl.*, u.name as user_name, u.email as user_email,
            t.name as tool_name, a.name as api_name
     FROM api_call_logs acl
     LEFT JOIN users u         ON u.id  = acl.user_id
     LEFT JOIN tools t         ON t.id  = acl.tool_id
     LEFT JOIN api_services a  ON a.id  = acl.api_service_id
     WHERE {$whereStr}
     ORDER BY acl.created_at DESC
     LIMIT ? OFFSET ?",
    array_merge($params, [$perPage, $offset])
);

$tools = DB::query("SELECT id,name FROM tools ORDER BY sort_order");

// Summary stats
$totalCost   = (float)DB::scalar("SELECT COALESCE(SUM(api_cost_usd),0) FROM api_call_logs");
$todayCalls  = (int)DB::scalar("SELECT COUNT(*) FROM api_call_logs WHERE DATE(created_at)=CURDATE()");
$failedCalls = (int)DB::scalar("SELECT COUNT(*) FROM api_call_logs WHERE status='failed'");
$avgLatency  = (int)DB::scalar("SELECT COALESCE(AVG(latency_ms),0) FROM api_call_logs WHERE status='success'");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>API Logs — Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:220px;min-height:100vh;background:#050508;border-right:.5px solid rgba(167,139,250,.12);position:fixed;left:0;top:0;z-index:100;overflow-y:auto;display:flex;flex-direction:column}
.sidebar-logo{padding:18px 16px 14px;font-size:15px;font-weight:600;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;border-bottom:.5px solid rgba(167,139,250,.1)}
.sidebar-logo span{display:block;font-size:10px;color:#6b6b90;-webkit-text-fill-color:#6b6b90;background:none;margin-top:2px}
.nav-section{padding:10px 10px 4px;font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-top:4px}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 14px;color:#9b9bc0;text-decoration:none;font-size:13px;transition:all .15s;border-left:2px solid transparent;border-radius:0 8px 8px 0;margin:1px 6px 1px 0}
.nav-item i{font-size:17px;flex-shrink:0}
.nav-item:hover{color:#f1f1ff;background:rgba(167,139,250,.07)}
.nav-item.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.main{margin-left:220px;flex:1;min-height:100vh}
.topbar{height:52px;display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;background:#050508;border-bottom:.5px solid rgba(167,139,250,.1);position:sticky;top:0;z-index:50}
.content{padding:1.5rem}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:1.25rem}
.stat{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:12px;padding:.9rem 1.1rem}
.stat-label{font-size:11px;color:#6b6b90;margin-bottom:5px}
.stat-val{font-size:20px;font-weight:600;color:#f1f1ff}
.stat-sub{font-size:11px;color:#9b9bc0;margin-top:3px}
.card{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:14px;overflow:hidden;margin-bottom:1rem}
.filter-bar{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:1rem;align-items:flex-end}
.fi{display:flex;flex-direction:column;gap:4px}
.fi label{font-size:11px;color:#6b6b90;font-weight:500}
.form-input{background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:7px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:12px;padding:7px 10px;outline:none}
.form-input:focus{border-color:#a78bfa}
select.form-input option{background:#1a1a2e;color:#f1f1ff}
.btn{display:inline-flex;align-items:center;gap:4px;padding:7px 13px;border-radius:7px;font-size:12px;font-weight:500;cursor:pointer;border:none;font-family:'Inter',sans-serif;transition:all .2s;text-decoration:none;white-space:nowrap}
.btn-primary{background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff}
.btn-danger{background:rgba(239,68,68,.12);color:#ef4444;border:.5px solid rgba(239,68,68,.3)}
.btn-warn{background:rgba(245,158,11,.1);color:#f59e0b;border:.5px solid rgba(245,158,11,.25)}
table{width:100%;border-collapse:collapse}
th{padding:8px 12px;text-align:left;font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(0,0,0,.2)}
td{padding:8px 12px;font-size:12px;color:#9b9bc0;border-top:.5px solid rgba(255,255,255,.04);vertical-align:middle}
tr:first-child td{border-top:none}
tr:hover td{background:rgba(167,139,250,.03)}
.badge{display:inline-block;padding:2px 7px;border-radius:4px;font-size:10px;font-weight:500}
.badge-success{background:rgba(34,197,94,.12);color:#22c55e}
.badge-danger{background:rgba(239,68,68,.12);color:#ef4444}
.badge-warning{background:rgba(245,158,11,.12);color:#f59e0b}
.badge-pending{background:rgba(56,189,248,.12);color:#38bdf8}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:1rem;display:flex;align-items:center;gap:8px;background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.expand-btn{background:none;border:none;color:#a78bfa;cursor:pointer;font-size:11px;padding:2px 6px;border-radius:4px;border:.5px solid rgba(167,139,250,.2)}
.expand-row{display:none;background:rgba(0,0,0,.3)}
.expand-row.open{display:table-row}
.expand-row td{padding:10px 12px}
pre{font-size:11px;color:#9b9bc0;background:rgba(0,0,0,.4);padding:10px;border-radius:6px;overflow-x:auto;max-height:200px;white-space:pre-wrap;word-break:break-all}
.pages{display:flex;gap:5px;padding:10px 12px;flex-wrap:wrap}
.page-btn{padding:4px 10px;border-radius:5px;font-size:11px;text-decoration:none;color:#9b9bc0;border:.5px solid rgba(167,139,250,.15)}
.page-btn.active{background:rgba(167,139,250,.15);color:#a78bfa;border-color:#a78bfa}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?><span>Admin Panel</span></div>
    <div class="nav-section">Overview</div>
    <a href="index.php"  class="nav-item"><i class="ti ti-dashboard"></i> Dashboard</a>
    <div class="nav-section">Management</div>
    <a href="tools.php"  class="nav-item"><i class="ti ti-tool"></i> Tools</a>
    <a href="apis.php"   class="nav-item"><i class="ti ti-api"></i> API Services</a>
    <a href="users.php"  class="nav-item"><i class="ti ti-users"></i> Users</a>
    <div class="nav-section">Monetisation</div>
    <a href="subscriptions.php" class="nav-item"><i class="ti ti-ticket"></i> Plans</a>
    <a href="payments.php"      class="nav-item"><i class="ti ti-credit-card"></i> Payments</a>
    <div class="nav-section">Logs</div>
    <a href="logs.php"     class="nav-item active"><i class="ti ti-list"></i> API Logs</a>
    <a href="activity.php" class="nav-item"><i class="ti ti-activity"></i> Activity</a>
    <div class="nav-section">Settings</div>
    <a href="settings.php" class="nav-item"><i class="ti ti-settings"></i> Settings</a>
    <a href="theme.php"    class="nav-item"><i class="ti ti-palette"></i> Theme</a>
    <div style="margin-top:auto;padding:10px">
        <a href="/aistudio/public/dashboard.php" style="display:flex;align-items:center;gap:8px;padding:8px 10px;color:#9b9bc0;text-decoration:none;font-size:12px;border-radius:8px;border:.5px solid rgba(167,139,250,.1)">
            <i class="ti ti-arrow-left"></i> Back to site
        </a>
    </div>
</nav>

<div class="main">
    <header class="topbar">
        <span style="font-size:15px;font-weight:500"><i class="ti ti-list" style="color:#a78bfa;vertical-align:-2px;margin-right:6px"></i>API Logs <span style="color:#6b6b90;font-size:12px">(<?= number_format($total) ?>)</span></span>
    </header>

    <div class="content">
        <?php if ($msg): ?><div class="alert"><i class="ti ti-check"></i><?= h($msg) ?></div><?php endif; ?>

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat"><div class="stat-label">Total calls</div><div class="stat-val"><?= number_format($total) ?></div></div>
            <div class="stat"><div class="stat-label">Today</div><div class="stat-val"><?= number_format($todayCalls) ?></div></div>
            <div class="stat"><div class="stat-label">Failed</div><div class="stat-val" style="color:#ef4444"><?= number_format($failedCalls) ?></div></div>
            <div class="stat"><div class="stat-label">Total API cost</div><div class="stat-val">$<?= number_format($totalCost,4) ?></div></div>
            <div class="stat"><div class="stat-label">Avg latency</div><div class="stat-val"><?= number_format($avgLatency) ?><span style="font-size:12px;color:#9b9bc0">ms</span></div></div>
        </div>

        <!-- Filters -->
        <form method="GET" class="filter-bar">
            <div class="fi"><label>User</label><input type="text" name="user" class="form-input" placeholder="Email or name" value="<?= h($fUser) ?>" style="width:160px"></div>
            <div class="fi">
                <label>Tool</label>
                <select name="tool" class="form-input" style="width:140px">
                    <option value="">All tools</option>
                    <?php foreach ($tools as $t): ?>
                    <option value="<?= $t['id'] ?>" <?= $fTool==$t['id']?'selected':'' ?>><?= h($t['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="fi">
                <label>Status</label>
                <select name="status" class="form-input">
                    <option value="">All</option>
                    <option value="success" <?= $fStatus==='success'?'selected':'' ?>>Success</option>
                    <option value="failed"  <?= $fStatus==='failed'?'selected':'' ?>>Failed</option>
                    <option value="pending" <?= $fStatus==='pending'?'selected':'' ?>>Pending</option>
                </select>
            </div>
            <div class="fi"><label>From</label><input type="date" name="from" class="form-input" value="<?= h($fFrom) ?>"></div>
            <div class="fi"><label>To</label><input type="date" name="to" class="form-input" value="<?= h($fTo) ?>"></div>
            <button type="submit" class="btn btn-primary"><i class="ti ti-search"></i> Filter</button>
            <a href="logs.php" class="btn" style="background:rgba(255,255,255,.05);color:#9b9bc0;border:.5px solid rgba(255,255,255,.1)">Reset</a>
        </form>

        <!-- Delete actions -->
        <div style="display:flex;gap:8px;margin-bottom:1rem;flex-wrap:wrap">
            <form method="POST" onsubmit="return confirmDelete('selected')">
                <input type="hidden" name="_csrf"   value="<?= h($csrf) ?>">
                <input type="hidden" name="action"  value="delete_selected">
                <input type="hidden" name="ids"     id="selectedIds" value="">
                <button type="submit" class="btn btn-danger"><i class="ti ti-trash"></i> Delete selected</button>
            </form>
            <form method="POST" style="display:flex;gap:6px;align-items:center" onsubmit="return confirm('Delete logs older than this many days?')">
                <input type="hidden" name="_csrf"  value="<?= h($csrf) ?>">
                <input type="hidden" name="action" value="delete_older">
                <input type="number" name="days" value="30" min="1" class="form-input" style="width:70px">
                <button type="submit" class="btn btn-warn"><i class="ti ti-clock"></i> Delete older than N days</button>
            </form>
            <form method="POST" onsubmit="return confirm('Delete ALL api logs? This cannot be undone.')">
                <input type="hidden" name="_csrf"  value="<?= h($csrf) ?>">
                <input type="hidden" name="action" value="delete_all">
                <button type="submit" class="btn btn-danger"><i class="ti ti-trash-x"></i> Clear all</button>
            </form>
        </div>

        <!-- Logs table -->
        <div class="card">
            <form id="logsForm">
            <table>
                <thead>
                    <tr>
                        <th><input type="checkbox" id="selectAll" onchange="toggleAll(this)" style="accent-color:#a78bfa"></th>
                        <th>#</th><th>User</th><th>Tool</th><th>API</th>
                        <th>Status</th><th>HTTP</th><th>Latency</th><th>Cost</th><th>Credits</th><th>Time</th><th></th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($logs)): ?>
                <tr><td colspan="12" style="text-align:center;padding:2rem;color:#6b6b90">No logs found</td></tr>
                <?php else: ?>
                <?php foreach ($logs as $i => $log): ?>
                <tr onclick="toggleRow(<?= $log['id'] ?>)">
                    <td onclick="event.stopPropagation()">
                        <input type="checkbox" class="log-check" value="<?= $log['id'] ?>" style="accent-color:#a78bfa">
                    </td>
                    <td style="color:#6b6b90;font-size:11px"><?= $log['id'] ?></td>
                    <td>
                        <div style="color:#f1f1ff;font-size:12px"><?= h($log['user_name'] ?? '—') ?></div>
                        <div style="font-size:10px;color:#6b6b90"><?= h($log['user_email'] ?? '') ?></div>
                    </td>
                    <td style="font-size:12px"><?= h($log['tool_name'] ?? '—') ?></td>
                    <td style="font-size:12px;color:#a78bfa"><?= h($log['api_name'] ?? '—') ?></td>
                    <td>
                        <?php $sc = ['success'=>'badge-success','failed'=>'badge-danger','pending'=>'badge-pending','timeout'=>'badge-warning'][$log['status']] ?? 'badge-warning'; ?>
                        <span class="badge <?= $sc ?>"><?= h($log['status']) ?></span>
                    </td>
                    <td style="font-size:11px;<?= ($log['http_status']??200) >= 400 ? 'color:#ef4444' : 'color:#22c55e' ?>">
                        <?= $log['http_status'] ?? '—' ?>
                    </td>
                    <td style="font-size:11px"><?= $log['latency_ms'] ? number_format($log['latency_ms']).'ms' : '—' ?></td>
                    <td style="font-size:11px;color:#f59e0b"><?= $log['api_cost_usd'] ? '$'.number_format($log['api_cost_usd'],5) : '—' ?></td>
                    <td style="color:#a78bfa;font-size:11px"><?= $log['credits_charged'] ?: '—' ?></td>
                    <td style="font-size:10px;color:#6b6b90"><?= timeAgo($log['created_at']) ?></td>
                    <td onclick="event.stopPropagation()">
                        <button class="expand-btn" onclick="toggleRow(<?= $log['id'] ?>)">
                            <i class="ti ti-code"></i>
                        </button>
                    </td>
                </tr>
                <tr class="expand-row" id="expand-<?= $log['id'] ?>">
                    <td colspan="12">
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
                            <div>
                                <div style="font-size:11px;color:#a78bfa;margin-bottom:4px;font-weight:500">REQUEST</div>
                                <pre><?= h(json_encode(json_decode($log['request_payload'] ?? '{}'), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)) ?></pre>
                            </div>
                            <div>
                                <div style="font-size:11px;color:#a78bfa;margin-bottom:4px;font-weight:500">RESPONSE</div>
                                <pre><?= h(json_encode(json_decode($log['response_payload'] ?? '{}'), JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)) ?></pre>
                            </div>
                        </div>
                        <?php if ($log['error_message']): ?>
                        <div style="margin-top:8px">
                            <div style="font-size:11px;color:#ef4444;margin-bottom:4px;font-weight:500">ERROR</div>
                            <pre style="color:#fca5a5"><?= h($log['error_message']) ?></pre>
                        </div>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
            </form>

            <?php if ($total > $perPage):
                $totalPages = ceil($total/$perPage);
                $q = http_build_query(array_filter(['user'=>$fUser,'tool'=>$fTool,'status'=>$fStatus,'from'=>$fFrom,'to'=>$fTo]));
                echo '<div class="pages">';
                for ($i=1; $i<=$totalPages; $i++):
                    $link = $q ? "logs.php?{$q}&page={$i}" : "logs.php?page={$i}";
                    $active = $i===$page ? ' active' : '';
                    echo "<a href='{$link}' class='page-btn{$active}'>{$i}</a>";
                endfor;
                echo '</div>';
            endif; ?>
        </div>
    </div>
</div>

<script>
function toggleRow(id) {
    const row = document.getElementById('expand-' + id);
    row.classList.toggle('open');
}
function toggleAll(cb) {
    document.querySelectorAll('.log-check').forEach(c => c.checked = cb.checked);
}
function confirmDelete(type) {
    const ids = [...document.querySelectorAll('.log-check:checked')].map(c => c.value);
    if (!ids.length) { alert('Select at least one log.'); return false; }
    document.getElementById('selectedIds').value = ids.join(',');
    // Convert to hidden inputs
    const form = document.querySelector('form[onsubmit*="confirmDelete"]');
    ids.forEach(id => {
        const inp = document.createElement('input');
        inp.type = 'hidden'; inp.name = 'ids[]'; inp.value = id;
        form.appendChild(inp);
    });
    return confirm(`Delete ${ids.length} selected log(s)?`);
}
</script>
</body>
</html>
