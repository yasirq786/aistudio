<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';

Security::startSession();
Security::checkIpBan();
Auth::requireAdmin();

$msg   = '';
$error = '';
$csrf  = Security::generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();
    $action = $_POST['action'] ?? '';
    $pid    = (int)($_POST['payment_id'] ?? 0);

    if ($action === 'verify') {
        $payment = DB::queryOne(
            "SELECT p.*, sp.credits_included FROM payments p
             JOIN subscription_plans sp ON sp.id = p.plan_id
             WHERE p.id = ? AND p.status = 'pending'",
            [$pid]
        );
        if ($payment) {
            DB::beginTransaction();
            try {
                // Mark payment verified
                DB::execute(
                    "UPDATE payments SET status='verified', verified_by=?, verified_at=NOW() WHERE id=?",
                    [Auth::id(), $pid]
                );
                // Activate subscription
                $starts  = date('Y-m-d H:i:s');
                $plan    = DB::queryOne("SELECT * FROM subscription_plans WHERE id=?", [$payment['plan_id']]);
                $expires = date('Y-m-d H:i:s', strtotime("+{$plan['duration_days']} days"));

                // Cancel existing active sub
                DB::execute(
                    "UPDATE user_subscriptions SET status='cancelled' WHERE user_id=? AND status='active'",
                    [$payment['user_id']]
                );
                DB::execute(
                    "INSERT INTO user_subscriptions (user_id,plan_id,payment_id,status,started_at,expires_at)
                     VALUES (?,?,?,'active',?,?)",
                    [$payment['user_id'], $payment['plan_id'], $pid, $starts, $expires]
                );
                // Add credits
                CreditEngine::add(
                    $payment['user_id'],
                    $plan['credits_included'],
                    'subscription',
                    'Subscription: ' . $plan['name'],
                    'pay_' . $pid
                );
                DB::commit();
                $msg = "Payment #{$pid} verified. Subscription activated + {$plan['credits_included']} credits added.";
            } catch (Throwable $e) {
                DB::rollback();
                $error = 'Verification failed: ' . $e->getMessage();
            }
        }
    }
    elseif ($action === 'reject') {
        $note = Security::sanitizeRaw($_POST['note'] ?? 'Payment rejected');
        DB::execute(
            "UPDATE payments SET status='rejected', verified_by=?, verified_at=NOW(), note=? WHERE id=?",
            [Auth::id(), $note, $pid]
        );
        $msg = "Payment #{$pid} rejected.";
    }
}

// Filters
$fStatus  = $_GET['status']  ?? 'pending';
$fGateway = $_GET['gateway'] ?? '';
$page     = max(1,(int)($_GET['page'] ?? 1));
$perPage  = 20;

$where  = ['1=1'];
$params = [];
if ($fStatus)  { $where[] = 'p.status=?';  $params[] = $fStatus; }
if ($fGateway) { $where[] = 'p.gateway=?'; $params[] = $fGateway; }
$whereStr = implode(' AND ', $where);

$total = (int)DB::scalar(
    "SELECT COUNT(*) FROM payments p WHERE {$whereStr}", $params
);
$payments = DB::query(
    "SELECT p.*, u.name as user_name, u.email as user_email, sp.name as plan_name
     FROM payments p
     JOIN users u              ON u.id  = p.user_id
     JOIN subscription_plans sp ON sp.id = p.plan_id
     WHERE {$whereStr}
     ORDER BY p.created_at DESC LIMIT ? OFFSET ?",
    array_merge($params, [$perPage, ($page-1)*$perPage])
);

$pendingCount  = (int)DB::scalar("SELECT COUNT(*) FROM payments WHERE status='pending'");
$verifiedTotal = (float)DB::scalar("SELECT COALESCE(SUM(amount_usd),0) FROM payments WHERE status='verified'");
$pkrRate       = (float)ThemeEngine::get('pkr_rate','278');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Payments — Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:220px;min-height:100vh;background:#050508;border-right:.5px solid rgba(167,139,250,.12);position:fixed;left:0;top:0;z-index:100;overflow-y:auto;display:flex;flex-direction:column}
.sidebar-logo{padding:18px 16px 14px;font-size:15px;font-weight:600;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;border-bottom:.5px solid rgba(167,139,250,.1)}
.sidebar-logo span{display:block;font-size:10px;color:#6b6b90;-webkit-text-fill-color:#6b6b90;background:none;margin-top:2px}
.nav-section{padding:10px 10px 4px;font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-top:4px}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 14px;color:#9b9bc0;text-decoration:none;font-size:13px;transition:all .15s;border-left:2px solid transparent;border-radius:0 8px 8px 0;margin:1px 6px 1px 0}
.nav-item i{font-size:17px;flex-shrink:0}
.nav-item:hover{color:#f1f1ff;background:rgba(167,139,250,.07)}
.nav-item.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.nav-badge{margin-left:auto;background:rgba(239,68,68,.2);color:#ef4444;font-size:10px;font-weight:600;padding:1px 6px;border-radius:10px}
.main{margin-left:220px;flex:1}
.topbar{height:52px;display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;background:#050508;border-bottom:.5px solid rgba(167,139,250,.1);position:sticky;top:0;z-index:50}
.content{padding:1.5rem}
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:1.25rem}
.stat{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:12px;padding:.9rem 1.1rem}
.stat-label{font-size:11px;color:#6b6b90;margin-bottom:5px}
.stat-val{font-size:20px;font-weight:600;color:#f1f1ff}
.stat-sub{font-size:11px;color:#9b9bc0;margin-top:3px}
.filter-tabs{display:flex;gap:6px;margin-bottom:1rem;flex-wrap:wrap}
.ftab{padding:6px 16px;border-radius:7px;font-size:12px;text-decoration:none;color:#9b9bc0;border:.5px solid rgba(167,139,250,.15);transition:all .2s}
.ftab:hover,.ftab.active{background:rgba(167,139,250,.1);border-color:#a78bfa;color:#a78bfa}
.card{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:14px;overflow:hidden;margin-bottom:1rem}
table{width:100%;border-collapse:collapse}
th{padding:9px 14px;text-align:left;font-size:11px;font-weight:500;color:#6b6b90;text-transform:uppercase;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(0,0,0,.2)}
td{padding:10px 14px;font-size:12px;color:#9b9bc0;border-top:.5px solid rgba(255,255,255,.04);vertical-align:middle}
tr:first-child td{border-top:none}
.badge{display:inline-block;padding:2px 8px;border-radius:5px;font-size:11px;font-weight:500}
.badge-success{background:rgba(34,197,94,.12);color:#22c55e}
.badge-danger{background:rgba(239,68,68,.12);color:#ef4444}
.badge-warning{background:rgba(245,158,11,.12);color:#f59e0b}
.badge-info{background:rgba(56,189,248,.12);color:#38bdf8}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:1rem;display:flex;align-items:center;gap:8px}
.alert-success{background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.alert-error{background:rgba(239,68,68,.1);border:.5px solid #ef4444;color:#fca5a5}
.btn{display:inline-flex;align-items:center;gap:4px;padding:6px 12px;border-radius:7px;font-size:12px;font-weight:500;cursor:pointer;border:none;font-family:'Inter',sans-serif;transition:all .2s;text-decoration:none;white-space:nowrap}
.btn-success{background:rgba(34,197,94,.15);color:#22c55e;border:.5px solid rgba(34,197,94,.3)}
.btn-success:hover{background:rgba(34,197,94,.25)}
.btn-danger{background:rgba(239,68,68,.12);color:#ef4444;border:.5px solid rgba(239,68,68,.3)}
.btn-danger:hover{background:rgba(239,68,68,.22)}
.screenshot-thumb{width:48px;height:36px;object-fit:cover;border-radius:5px;cursor:pointer;border:.5px solid rgba(167,139,250,.2)}
.modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.8);z-index:200;align-items:center;justify-content:center;padding:1rem}
.modal.open{display:flex}
.modal-box{background:#0d0d1a;border:.5px solid rgba(167,139,250,.3);border-radius:16px;padding:1.5rem;width:100%;max-width:480px;max-height:90vh;overflow-y:auto}
.modal-title{font-size:15px;font-weight:500;margin-bottom:1rem;display:flex;align-items:center;justify-content:space-between}
.close-btn{background:none;border:none;color:#9b9bc0;font-size:20px;cursor:pointer}
.form-label{display:block;font-size:12px;color:#9b9bc0;margin-bottom:4px;font-weight:500}
.form-input{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:8px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:13px;padding:9px 12px;outline:none}
.pages{display:flex;gap:5px;padding:10px 14px;flex-wrap:wrap}
.page-btn{padding:5px 11px;border-radius:5px;font-size:11px;text-decoration:none;color:#9b9bc0;border:.5px solid rgba(167,139,250,.15)}
.page-btn.active{background:rgba(167,139,250,.15);color:#a78bfa;border-color:#a78bfa}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?><span>Admin Panel</span></div>
    <div class="nav-section">Overview</div>
    <a href="index.php"  class="nav-item"><i class="ti ti-dashboard"></i> Dashboard</a>
    <div class="nav-section">Management</div>
    <a href="tools.php"  class="nav-item"><i class="ti ti-tool"></i> Tools</a>
    <a href="apis.php"   class="nav-item"><i class="ti ti-api"></i> API Services</a>
    <a href="users.php"  class="nav-item"><i class="ti ti-users"></i> Users</a>
    <div class="nav-section">Monetisation</div>
    <a href="subscriptions.php" class="nav-item"><i class="ti ti-ticket"></i> Plans</a>
    <a href="payments.php"      class="nav-item active"><i class="ti ti-credit-card"></i> Payments
        <?php if ($pendingCount): ?><span class="nav-badge"><?= $pendingCount ?></span><?php endif; ?>
    </a>
    <div class="nav-section">Logs</div>
    <a href="logs.php"     class="nav-item"><i class="ti ti-list"></i> API Logs</a>
    <a href="activity.php" class="nav-item"><i class="ti ti-activity"></i> Activity</a>
    <div class="nav-section">Settings</div>
    <a href="settings.php" class="nav-item"><i class="ti ti-settings"></i> Settings</a>
    <a href="theme.php"    class="nav-item"><i class="ti ti-palette"></i> Theme</a>
    <div style="margin-top:auto;padding:10px">
        <a href="/aistudio/public/dashboard.php" style="display:flex;align-items:center;gap:8px;padding:8px 10px;color:#9b9bc0;text-decoration:none;font-size:12px;border-radius:8px;border:.5px solid rgba(167,139,250,.1)">
            <i class="ti ti-arrow-left"></i> Back to site
        </a>
    </div>
</nav>

<div class="main">
    <header class="topbar">
        <span style="font-size:15px;font-weight:500">
            <i class="ti ti-credit-card" style="color:#a78bfa;vertical-align:-2px;margin-right:6px"></i>
            Payments
            <?php if ($pendingCount): ?>
            <span style="background:rgba(239,68,68,.15);color:#ef4444;font-size:11px;padding:2px 8px;border-radius:10px;margin-left:6px">
                <?= $pendingCount ?> pending
            </span>
            <?php endif; ?>
        </span>
    </header>

    <div class="content">
        <?php if ($msg):   ?><div class="alert alert-success"><i class="ti ti-check"></i><?= h($msg) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><i class="ti ti-alert-circle"></i><?= h($error) ?></div><?php endif; ?>

        <div class="stats-grid">
            <div class="stat"><div class="stat-label">Pending</div><div class="stat-val" style="color:#f59e0b"><?= $pendingCount ?></div><div class="stat-sub">awaiting verification</div></div>
            <div class="stat"><div class="stat-label">Total revenue</div><div class="stat-val">$<?= number_format($verifiedTotal,2) ?></div><div class="stat-sub">Rs <?= number_format($verifiedTotal*$pkrRate,0) ?> PKR</div></div>
            <div class="stat"><div class="stat-label">This month</div>
                <div class="stat-val">$<?= number_format((float)DB::scalar("SELECT COALESCE(SUM(amount_usd),0) FROM payments WHERE status='verified' AND MONTH(created_at)=MONTH(NOW())"),2) ?></div>
            </div>
        </div>

        <!-- Status filter tabs -->
        <div class="filter-tabs">
            <a href="?status=pending"  class="ftab <?= $fStatus==='pending'?'active':'' ?>">Pending <?php $pc=(int)DB::scalar("SELECT COUNT(*) FROM payments WHERE status='pending'"); if($pc) echo "<span class='nav-badge'>{$pc}</span>"; ?></a>
            <a href="?status=verified" class="ftab <?= $fStatus==='verified'?'active':'' ?>">Verified</a>
            <a href="?status=rejected" class="ftab <?= $fStatus==='rejected'?'active':'' ?>">Rejected</a>
            <a href="?status="         class="ftab <?= !$fStatus?'active':'' ?>">All</a>
        </div>

        <div class="card">
            <table>
                <thead>
                    <tr><th>#</th><th>User</th><th>Plan</th><th>Amount</th><th>Gateway</th><th>Ref / Screenshot</th><th>Status</th><th>Date</th><th>Actions</th></tr>
                </thead>
                <tbody>
                <?php if (empty($payments)): ?>
                <tr><td colspan="9" style="text-align:center;padding:2rem;color:#6b6b90">No payments found</td></tr>
                <?php else: ?>
                <?php foreach ($payments as $p): ?>
                <tr>
                    <td style="color:#6b6b90;font-size:11px"><?= $p['id'] ?></td>
                    <td>
                        <div style="color:#f1f1ff;font-weight:500;font-size:13px"><?= h($p['user_name']) ?></div>
                        <div style="font-size:11px;color:#6b6b90"><?= h($p['user_email']) ?></div>
                    </td>
                    <td style="font-size:13px;color:#a78bfa"><?= h($p['plan_name']) ?></td>
                    <td>
                        <div style="color:#22c55e;font-weight:500">$<?= number_format($p['amount_usd'],2) ?></div>
                        <div style="font-size:11px;color:#6b6b90">Rs <?= number_format($p['amount_pkr'] ?? ($p['amount_usd']*$pkrRate),0) ?></div>
                    </td>
                    <td><span class="badge badge-info"><?= h(ucfirst(str_replace('_',' ',$p['gateway']))) ?></span></td>
                    <td>
                        <?php if ($p['screenshot_url']): ?>
                        <img src="<?= h($p['screenshot_url']) ?>" class="screenshot-thumb"
                             onclick="viewScreenshot('<?= h($p['screenshot_url']) ?>')" alt="screenshot">
                        <?php elseif ($p['gateway_ref']): ?>
                        <code style="font-size:11px;color:#9b9bc0"><?= h(substr($p['gateway_ref'],0,20)) ?></code>
                        <?php else: ?>
                        <span style="color:#6b6b90;font-size:11px">—</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($p['status']==='verified'): ?>
                            <span class="badge badge-success">Verified</span>
                        <?php elseif ($p['status']==='pending'): ?>
                            <span class="badge badge-warning">Pending</span>
                        <?php elseif ($p['status']==='rejected'): ?>
                            <span class="badge badge-danger">Rejected</span>
                        <?php else: ?>
                            <span class="badge badge-info"><?= h($p['status']) ?></span>
                        <?php endif; ?>
                        <?php if ($p['verified_at']): ?>
                        <div style="font-size:10px;color:#6b6b90;margin-top:2px"><?= date('M j H:i',strtotime($p['verified_at'])) ?></div>
                        <?php endif; ?>
                    </td>
                    <td style="font-size:11px"><?= date('M j, Y',strtotime($p['created_at'])) ?></td>
                    <td>
                        <?php if ($p['status']==='pending'): ?>
                        <div style="display:flex;gap:5px">
                            <form method="POST" onsubmit="return confirm('Verify this payment and activate subscription?')">
                                <input type="hidden" name="_csrf"       value="<?= h($csrf) ?>">
                                <input type="hidden" name="action"      value="verify">
                                <input type="hidden" name="payment_id"  value="<?= $p['id'] ?>">
                                <button type="submit" class="btn btn-success"><i class="ti ti-check"></i> Verify</button>
                            </form>
                            <button onclick="openReject(<?= $p['id'] ?>)" class="btn btn-danger"><i class="ti ti-x"></i> Reject</button>
                        </div>
                        <?php else: ?>
                        <span style="color:#6b6b90;font-size:11px">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
            <?php if ($total > $perPage):
                $totalPages = ceil($total/$perPage);
                echo '<div class="pages">';
                for ($i=1;$i<=$totalPages;$i++):
                    $active = $i===$page?' active':'';
                    echo "<a href='?status={$fStatus}&page={$i}' class='page-btn{$active}'>{$i}</a>";
                endfor;
                echo '</div>';
            endif; ?>
        </div>
    </div>
</div>

<!-- Reject modal -->
<div class="modal" id="rejectModal">
    <div class="modal-box">
        <div class="modal-title">
            <span><i class="ti ti-x" style="color:#ef4444"></i> Reject Payment</span>
            <button class="close-btn" onclick="closeReject()"><i class="ti ti-x"></i></button>
        </div>
        <form method="POST">
            <input type="hidden" name="_csrf"      value="<?= h($csrf) ?>">
            <input type="hidden" name="action"     value="reject">
            <input type="hidden" name="payment_id" id="rejectId">
            <div style="margin-bottom:12px">
                <label class="form-label">Reason for rejection</label>
                <input type="text" name="note" class="form-input" placeholder="e.g. Screenshot unclear, wrong amount" required>
            </div>
            <div style="display:flex;gap:8px;justify-content:flex-end">
                <button type="button" onclick="closeReject()" class="btn" style="background:rgba(255,255,255,.05);color:#9b9bc0">Cancel</button>
                <button type="submit" class="btn btn-danger"><i class="ti ti-x"></i> Reject Payment</button>
            </div>
        </form>
    </div>
</div>

<!-- Screenshot modal -->
<div class="modal" id="ssModal">
    <div style="max-width:700px;width:100%;position:relative">
        <button onclick="document.getElementById('ssModal').classList.remove('open')"
                style="position:absolute;top:-36px;right:0;background:none;border:none;color:#fff;font-size:24px;cursor:pointer">
            <i class="ti ti-x"></i>
        </button>
        <img id="ssImg" src="" alt="Payment screenshot" style="width:100%;border-radius:12px;max-height:80vh;object-fit:contain">
    </div>
</div>

<script>
function openReject(id) {
    document.getElementById('rejectId').value = id;
    document.getElementById('rejectModal').classList.add('open');
}
function closeReject() {
    document.getElementById('rejectModal').classList.remove('open');
}
function viewScreenshot(url) {
    document.getElementById('ssImg').src = url;
    document.getElementById('ssModal').classList.add('open');
}
['rejectModal','ssModal'].forEach(id => {
    document.getElementById(id).addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('open');
    });
});
</script>
</body>
</html>
