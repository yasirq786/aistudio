<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();
Auth::requireAdmin();

$msg  = '';
$csrf = Security::generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();

    $settings = [
        'site_name'        => Security::sanitizeRaw($_POST['site_name']        ?? ''),
        'site_description' => Security::sanitizeRaw($_POST['site_description'] ?? ''),
        'pkr_rate'         => (float)($_POST['pkr_rate'] ?? 278),
        'user_log_limit'   => max(5, min(100, (int)($_POST['user_log_limit'] ?? 10))),
        'maintenance_mode' => isset($_POST['maintenance_mode']) ? '1' : '0',
        'smtp_host'        => Security::sanitizeRaw($_POST['smtp_host']  ?? ''),
        'smtp_port'        => Security::sanitizeRaw($_POST['smtp_port']  ?? '587'),
        'smtp_user'        => Security::sanitizeRaw($_POST['smtp_user']  ?? ''),
        'smtp_from'        => Security::sanitizeRaw($_POST['smtp_from']  ?? ''),
        'smtp_from_name'   => Security::sanitizeRaw($_POST['smtp_from_name'] ?? ''),
    ];

    // Only update SMTP pass if provided
    if (!empty($_POST['smtp_pass'])) {
        $settings['smtp_pass'] = $_POST['smtp_pass'];
    }

    foreach ($settings as $key => $val) {
        ThemeEngine::set($key, (string)$val);
    }

    // Handle logo upload
    if (!empty($_FILES['site_logo']['name'])) {
        $ext    = strtolower(pathinfo($_FILES['site_logo']['name'], PATHINFO_EXTENSION));
        $allowed= ['jpg','jpeg','png','svg','webp'];
        if (in_array($ext, $allowed) && $_FILES['site_logo']['size'] < 2097152) {
            $dir  = ROOT . '/public/assets/img/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            $name = 'logo.' . $ext;
            move_uploaded_file($_FILES['site_logo']['tmp_name'], $dir . $name);
            ThemeEngine::set('site_logo', '/aistudio/public/assets/img/' . $name);
        }
    }
    if (!empty($_FILES['site_favicon']['name'])) {
        $ext = strtolower(pathinfo($_FILES['site_favicon']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['ico','png']) && $_FILES['site_favicon']['size'] < 512000) {
            $dir = ROOT . '/public/assets/img/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            move_uploaded_file($_FILES['site_favicon']['tmp_name'], $dir . 'favicon.' . $ext);
            ThemeEngine::set('site_favicon', '/aistudio/public/assets/img/favicon.' . $ext);
        }
    }

    $msg = 'Settings saved successfully.';
    ThemeEngine::$settings = []; // clear cache
}

// Load current settings
$s = [];
$rows = DB::query("SELECT `key`,`value` FROM theme_settings");
foreach ($rows as $r) $s[$r['key']] = $r['value'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Settings — Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:220px;min-height:100vh;background:#050508;border-right:.5px solid rgba(167,139,250,.12);position:fixed;left:0;top:0;z-index:100;overflow-y:auto;display:flex;flex-direction:column}
.sidebar-logo{padding:18px 16px 14px;font-size:15px;font-weight:600;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;border-bottom:.5px solid rgba(167,139,250,.1)}
.sidebar-logo span{display:block;font-size:10px;color:#6b6b90;-webkit-text-fill-color:#6b6b90;background:none;margin-top:2px}
.nav-section{padding:10px 10px 4px;font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-top:4px}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 14px;color:#9b9bc0;text-decoration:none;font-size:13px;transition:all .15s;border-left:2px solid transparent;border-radius:0 8px 8px 0;margin:1px 6px 1px 0}
.nav-item i{font-size:17px;flex-shrink:0}
.nav-item:hover{color:#f1f1ff;background:rgba(167,139,250,.07)}
.nav-item.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.main{margin-left:220px;flex:1}
.topbar{height:52px;display:flex;align-items:center;padding:0 1.5rem;background:#050508;border-bottom:.5px solid rgba(167,139,250,.1);position:sticky;top:0;z-index:50;font-size:15px;font-weight:500}
.content{padding:1.5rem;max-width:800px}
.section{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:14px;padding:1.25rem;margin-bottom:1.25rem}
.section-title{font-size:13px;font-weight:500;color:#a78bfa;margin-bottom:1rem;display:flex;align-items:center;gap:6px;padding-bottom:10px;border-bottom:.5px solid rgba(167,139,250,.1)}
.form-group{margin-bottom:14px}
.form-label{display:block;font-size:12px;font-weight:500;color:#9b9bc0;margin-bottom:5px}
.form-input{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:8px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:13px;padding:9px 12px;outline:none;transition:border-color .2s}
.form-input:focus{border-color:#a78bfa;box-shadow:0 0 0 3px rgba(167,139,250,.1)}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.btn-save{padding:10px 24px;background:linear-gradient(135deg,#a78bfa,#7c3aed);border:none;border-radius:8px;color:#fff;font-family:'Inter',sans-serif;font-size:14px;font-weight:500;cursor:pointer;transition:filter .2s;display:inline-flex;align-items:center;gap:6px}
.btn-save:hover{filter:brightness(1.1)}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:1rem;display:flex;align-items:center;gap:8px}
.alert-success{background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.toggle-row{display:flex;align-items:center;justify-content:space-between;padding:10px 0}
.toggle-row .label{font-size:13px;color:#f1f1ff}
.toggle-row .sub{font-size:12px;color:#9b9bc0}
.toggle{position:relative;display:inline-block;width:44px;height:24px}
.toggle input{opacity:0;width:0;height:0}
.toggle-slider{position:absolute;inset:0;background:rgba(255,255,255,.1);border-radius:12px;cursor:pointer;transition:.3s}
.toggle-slider:before{content:'';position:absolute;width:18px;height:18px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.3s}
input:checked + .toggle-slider{background:#a78bfa}
input:checked + .toggle-slider:before{transform:translateX(20px)}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?><span>Admin Panel</span></div>
    <div class="nav-section">Overview</div>
    <a href="index.php"  class="nav-item"><i class="ti ti-dashboard"></i> Dashboard</a>
    <div class="nav-section">Management</div>
    <a href="tools.php"  class="nav-item"><i class="ti ti-tool"></i> Tools</a>
    <a href="apis.php"   class="nav-item"><i class="ti ti-api"></i> API Services</a>
    <a href="users.php"  class="nav-item"><i class="ti ti-users"></i> Users</a>
    <div class="nav-section">Monetisation</div>
    <a href="subscriptions.php" class="nav-item"><i class="ti ti-ticket"></i> Plans</a>
    <a href="payments.php"      class="nav-item"><i class="ti ti-credit-card"></i> Payments</a>
    <div class="nav-section">Settings</div>
    <a href="settings.php" class="nav-item active"><i class="ti ti-settings"></i> Settings</a>
    <a href="theme.php"    class="nav-item"><i class="ti ti-palette"></i> Theme</a>
    <div style="margin-top:auto;padding:10px">
        <a href="/aistudio/public/dashboard.php" style="display:flex;align-items:center;gap:8px;padding:8px 10px;color:#9b9bc0;text-decoration:none;font-size:12px;border-radius:8px;border:.5px solid rgba(167,139,250,.1)">
            <i class="ti ti-arrow-left"></i> Back to site
        </a>
    </div>
</nav>

<div class="main">
    <header class="topbar">
        <i class="ti ti-settings" style="color:#a78bfa;margin-right:8px"></i> Settings
    </header>
    <div class="content">
        <?php if ($msg): ?><div class="alert alert-success"><i class="ti ti-check"></i><?= h($msg) ?></div><?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="_csrf" value="<?= h($csrf) ?>">

            <!-- General -->
            <div class="section">
                <div class="section-title"><i class="ti ti-world"></i> General</div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Site name</label>
                        <input type="text" name="site_name" class="form-input" value="<?= h($s['site_name'] ?? 'AIStudio') ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">PKR rate (1 USD = ? PKR)</label>
                        <input type="number" name="pkr_rate" class="form-input" value="<?= h($s['pkr_rate'] ?? '278') ?>" step="0.01">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Site description (SEO)</label>
                    <input type="text" name="site_description" class="form-input" value="<?= h($s['site_description'] ?? '') ?>">
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">Site logo (PNG/SVG, max 2MB)</label>
                        <?php if (!empty($s['site_logo'])): ?>
                        <img src="<?= h($s['site_logo']) ?>" alt="logo" style="height:32px;margin-bottom:6px;display:block">
                        <?php endif; ?>
                        <input type="file" name="site_logo" class="form-input" accept=".png,.jpg,.svg,.webp">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Favicon (ICO/PNG, max 512KB)</label>
                        <input type="file" name="site_favicon" class="form-input" accept=".ico,.png">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">User dashboard log limit</label>
                    <input type="number" name="user_log_limit" class="form-input" value="<?= h($s['user_log_limit'] ?? '10') ?>" min="5" max="100" style="max-width:120px">
                    <span style="font-size:12px;color:#6b6b90;margin-left:8px">logs shown per user on dashboard</span>
                </div>
                <div class="toggle-row">
                    <div>
                        <div class="label">Maintenance mode</div>
                        <div class="sub">When ON — site shows maintenance page to all visitors (admin can still access)</div>
                    </div>
                    <label class="toggle">
                        <input type="checkbox" name="maintenance_mode" value="1" <?= ($s['maintenance_mode'] ?? '0') === '1' ? 'checked' : '' ?>>
                        <span class="toggle-slider"></span>
                    </label>
                </div>
            </div>

            <!-- SMTP -->
            <div class="section">
                <div class="section-title"><i class="ti ti-mail"></i> Email / SMTP</div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">SMTP host</label>
                        <input type="text" name="smtp_host" class="form-input" placeholder="smtp.hostinger.com" value="<?= h($s['smtp_host'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">SMTP port</label>
                        <input type="text" name="smtp_port" class="form-input" placeholder="587" value="<?= h($s['smtp_port'] ?? '587') ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">SMTP username</label>
                        <input type="text" name="smtp_user" class="form-input" value="<?= h($s['smtp_user'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">SMTP password (leave blank to keep)</label>
                        <input type="password" name="smtp_pass" class="form-input" placeholder="Leave blank to keep current" autocomplete="off">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">From email</label>
                        <input type="email" name="smtp_from" class="form-input" value="<?= h($s['smtp_from'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label">From name</label>
                        <input type="text" name="smtp_from_name" class="form-input" value="<?= h($s['smtp_from_name'] ?? 'AIStudio') ?>">
                    </div>
                </div>
            </div>

            <button type="submit" class="btn-save"><i class="ti ti-device-floppy"></i> Save Settings</button>
        </form>
    </div>
</div>
</body>
</html>
