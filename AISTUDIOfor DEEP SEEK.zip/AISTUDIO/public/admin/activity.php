<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();
Auth::requireAdmin();

$msg  = '';
$csrf = Security::generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();
    $action = $_POST['action'] ?? '';

    if ($action === 'delete_older') {
        $days = max(1,(int)($_POST['days'] ?? 30));
        // Keep logs visible to users — only delete hidden ones older than N days
        $count = DB::execute(
            "DELETE FROM user_activity_logs WHERE is_visible_to_user=0 AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)",
            [$days]
        );
        $msg = "{$count} archived logs deleted.";
    }
    elseif ($action === 'set_limit') {
        $limit = max(5, min(100, (int)($_POST['limit'] ?? 10)));
        DB::execute("INSERT INTO theme_settings (`key`,`value`) VALUES ('user_log_limit',?) ON DUPLICATE KEY UPDATE `value`=?", [$limit,$limit]);
        $msg = "User dashboard log limit set to {$limit}.";
    }
    elseif ($action === 'hide_log') {
        $id = (int)$_POST['id'];
        DB::execute("UPDATE user_activity_logs SET is_visible_to_user=0 WHERE id=?", [$id]);
        $msg = 'Log hidden from user.';
    }
}

$fUser   = Security::sanitizeRaw($_GET['user'] ?? '');
$fTool   = (int)($_GET['tool'] ?? 0);
$fStatus = $_GET['status'] ?? '';
$page    = max(1,(int)($_GET['page'] ?? 1));
$perPage = 30;

$where  = ['1=1'];
$params = [];
if ($fUser)   { $where[]='(u.email LIKE ? OR u.name LIKE ?)'; $params[]="%{$fUser}%"; $params[]="%{$fUser}%"; }
if ($fTool)   { $where[]='ual.tool_id=?'; $params[]=$fTool; }
if ($fStatus) { $where[]='ual.status=?';  $params[]=$fStatus; }

$whereStr = implode(' AND ',$where);
$total    = (int)DB::scalar(
    "SELECT COUNT(*) FROM user_activity_logs ual LEFT JOIN users u ON u.id=ual.user_id WHERE {$whereStr}",
    $params
);

$logs = DB::query(
    "SELECT ual.*, u.name as user_name, u.email as user_email,
            t.name as tool_name, t.icon as tool_icon, a.name as api_name
     FROM user_activity_logs ual
     LEFT JOIN users u         ON u.id  = ual.user_id
     LEFT JOIN tools t         ON t.id  = ual.tool_id
     LEFT JOIN api_services a  ON a.id  = ual.api_service_id
     WHERE {$whereStr}
     ORDER BY ual.created_at DESC LIMIT ? OFFSET ?",
    array_merge($params, [$perPage, ($page-1)*$perPage])
);

$tools       = DB::query("SELECT id,name FROM tools ORDER BY sort_order");
$currentLimit= (int)DB::scalar("SELECT value FROM theme_settings WHERE `key`='user_log_limit'") ?: 10;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Activity Logs — Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:220px;min-height:100vh;background:#050508;border-right:.5px solid rgba(167,139,250,.12);position:fixed;left:0;top:0;z-index:100;overflow-y:auto;display:flex;flex-direction:column}
.sidebar-logo{padding:18px 16px 14px;font-size:15px;font-weight:600;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;border-bottom:.5px solid rgba(167,139,250,.1)}
.sidebar-logo span{display:block;font-size:10px;color:#6b6b90;-webkit-text-fill-color:#6b6b90;background:none;margin-top:2px}
.nav-section{padding:10px 10px 4px;font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-top:4px}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 14px;color:#9b9bc0;text-decoration:none;font-size:13px;transition:all .15s;border-left:2px solid transparent;border-radius:0 8px 8px 0;margin:1px 6px 1px 0}
.nav-item i{font-size:17px;flex-shrink:0}
.nav-item:hover{color:#f1f1ff;background:rgba(167,139,250,.07)}
.nav-item.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.main{margin-left:220px;flex:1}
.topbar{height:52px;display:flex;align-items:center;padding:0 1.5rem;background:#050508;border-bottom:.5px solid rgba(167,139,250,.1);position:sticky;top:0;z-index:50;font-size:15px;font-weight:500}
.content{padding:1.5rem}
.card{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:14px;overflow:hidden;margin-bottom:1rem}
.section{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:12px;padding:1rem 1.25rem;margin-bottom:1rem}
.section-title{font-size:13px;font-weight:500;color:#a78bfa;margin-bottom:.75rem;display:flex;align-items:center;gap:6px}
.filter-bar{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:1rem;align-items:flex-end}
.fi{display:flex;flex-direction:column;gap:4px}
.fi label{font-size:11px;color:#6b6b90;font-weight:500}
.form-input{background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:7px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:12px;padding:7px 10px;outline:none}
.form-input:focus{border-color:#a78bfa}
select.form-input option{background:#1a1a2e;color:#f1f1ff}
.btn{display:inline-flex;align-items:center;gap:4px;padding:7px 13px;border-radius:7px;font-size:12px;font-weight:500;cursor:pointer;border:none;font-family:'Inter',sans-serif;transition:all .2s;text-decoration:none;white-space:nowrap}
.btn-primary{background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff}
.btn-warn{background:rgba(245,158,11,.1);color:#f59e0b;border:.5px solid rgba(245,158,11,.25)}
.btn-sm{padding:4px 9px;font-size:11px}
table{width:100%;border-collapse:collapse}
th{padding:8px 12px;text-align:left;font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(0,0,0,.2)}
td{padding:8px 12px;font-size:12px;color:#9b9bc0;border-top:.5px solid rgba(255,255,255,.04);vertical-align:middle}
tr:first-child td{border-top:none}
.badge{display:inline-block;padding:2px 7px;border-radius:4px;font-size:10px;font-weight:500}
.badge-success{background:rgba(34,197,94,.12);color:#22c55e}
.badge-danger{background:rgba(239,68,68,.12);color:#ef4444}
.badge-warning{background:rgba(245,158,11,.12);color:#f59e0b}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:1rem;display:flex;align-items:center;gap:8px;background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.visible-badge{display:inline-block;width:7px;height:7px;border-radius:50%;background:#22c55e;margin-right:4px}
.hidden-badge{display:inline-block;width:7px;height:7px;border-radius:50%;background:#6b6b90;margin-right:4px}
.pages{display:flex;gap:5px;padding:10px 12px;flex-wrap:wrap}
.page-btn{padding:4px 10px;border-radius:5px;font-size:11px;text-decoration:none;color:#9b9bc0;border:.5px solid rgba(167,139,250,.15)}
.page-btn.active{background:rgba(167,139,250,.15);color:#a78bfa;border-color:#a78bfa}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?><span>Admin Panel</span></div>
    <div class="nav-section">Overview</div>
    <a href="index.php"  class="nav-item"><i class="ti ti-dashboard"></i> Dashboard</a>
    <div class="nav-section">Management</div>
    <a href="tools.php"  class="nav-item"><i class="ti ti-tool"></i> Tools</a>
    <a href="apis.php"   class="nav-item"><i class="ti ti-api"></i> API Services</a>
    <a href="users.php"  class="nav-item"><i class="ti ti-users"></i> Users</a>
    <div class="nav-section">Monetisation</div>
    <a href="subscriptions.php" class="nav-item"><i class="ti ti-ticket"></i> Plans</a>
    <a href="payments.php"      class="nav-item"><i class="ti ti-credit-card"></i> Payments</a>
    <div class="nav-section">Logs</div>
    <a href="logs.php"     class="nav-item"><i class="ti ti-list"></i> API Logs</a>
    <a href="activity.php" class="nav-item active"><i class="ti ti-activity"></i> Activity</a>
    <div class="nav-section">Settings</div>
    <a href="settings.php" class="nav-item"><i class="ti ti-settings"></i> Settings</a>
    <a href="theme.php"    class="nav-item"><i class="ti ti-palette"></i> Theme</a>
    <div style="margin-top:auto;padding:10px">
        <a href="/aistudio/public/dashboard.php" style="display:flex;align-items:center;gap:8px;padding:8px 10px;color:#9b9bc0;text-decoration:none;font-size:12px;border-radius:8px;border:.5px solid rgba(167,139,250,.1)">
            <i class="ti ti-arrow-left"></i> Back to site
        </a>
    </div>
</nav>

<div class="main">
    <header class="topbar">
        <i class="ti ti-activity" style="color:#a78bfa;margin-right:8px"></i>
        User Activity Logs <span style="color:#6b6b90;font-size:12px;margin-left:6px">(<?= number_format($total) ?>)</span>
    </header>

    <div class="content">
        <?php if ($msg): ?><div class="alert"><i class="ti ti-check"></i><?= h($msg) ?></div><?php endif; ?>

        <!-- Settings -->
        <div class="section">
            <div class="section-title"><i class="ti ti-settings"></i> Log display settings</div>
            <div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap">
                <div style="font-size:13px;color:#9b9bc0">
                    Users see last <strong style="color:#a78bfa"><?= $currentLimit ?></strong> logs on their dashboard
                </div>
                <form method="POST" style="display:flex;gap:8px;align-items:center">
                    <input type="hidden" name="_csrf"  value="<?= h($csrf) ?>">
                    <input type="hidden" name="action" value="set_limit">
                    <input type="number" name="limit" value="<?= $currentLimit ?>" min="5" max="100"
                           class="form-input" style="width:70px">
                    <button type="submit" class="btn btn-primary btn-sm">Set limit</button>
                </form>
                <form method="POST" style="display:flex;gap:8px;align-items:center" onsubmit="return confirm('Delete old archived logs?')">
                    <input type="hidden" name="_csrf"  value="<?= h($csrf) ?>">
                    <input type="hidden" name="action" value="delete_older">
                    <input type="number" name="days" value="30" min="1" class="form-input" style="width:70px">
                    <button type="submit" class="btn btn-warn btn-sm"><i class="ti ti-trash"></i> Delete archived older than N days</button>
                </form>
            </div>
            <div style="font-size:11px;color:#6b6b90;margin-top:8px">
                <span class="visible-badge"></span> Green dot = visible to user &nbsp;·&nbsp;
                <span class="hidden-badge"></span> Gray dot = archived (not shown to user)
            </div>
        </div>

        <!-- Filters -->
        <form method="GET" class="filter-bar">
            <div class="fi"><label>User</label><input type="text" name="user" class="form-input" placeholder="Email or name" value="<?= h($fUser) ?>" style="width:160px"></div>
            <div class="fi">
                <label>Tool</label>
                <select name="tool" class="form-input" style="width:150px">
                    <option value="">All tools</option>
                    <?php foreach ($tools as $t): ?>
                    <option value="<?= $t['id'] ?>" <?= $fTool==$t['id']?'selected':'' ?>><?= h($t['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="fi">
                <label>Status</label>
                <select name="status" class="form-input">
                    <option value="">All</option>
                    <option value="success" <?= $fStatus==='success'?'selected':'' ?>>Success</option>
                    <option value="failed"  <?= $fStatus==='failed'?'selected':'' ?>>Failed</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary"><i class="ti ti-search"></i> Filter</button>
            <a href="activity.php" class="btn" style="background:rgba(255,255,255,.05);color:#9b9bc0;border:.5px solid rgba(255,255,255,.1)">Reset</a>
        </form>

        <div class="card">
            <table>
                <thead>
                    <tr><th>Visible</th><th>User</th><th>Tool</th><th>API</th><th>Input preview</th><th>Credits</th><th>Status</th><th>Time</th><th></th></tr>
                </thead>
                <tbody>
                <?php if (empty($logs)): ?>
                <tr><td colspan="9" style="text-align:center;padding:2rem;color:#6b6b90">No activity logs found</td></tr>
                <?php else: ?>
                <?php foreach ($logs as $log): ?>
                <tr>
                    <td>
                        <?php if ($log['is_visible_to_user']): ?>
                        <span class="visible-badge" title="Visible to user"></span>
                        <?php else: ?>
                        <span class="hidden-badge" title="Archived"></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div style="color:#f1f1ff;font-size:12px;font-weight:500"><?= h($log['user_name'] ?? '—') ?></div>
                        <div style="font-size:10px;color:#6b6b90"><?= h($log['user_email'] ?? '') ?></div>
                    </td>
                    <td>
                        <div style="display:flex;align-items:center;gap:6px">
                            <i class="ti <?= h($log['tool_icon'] ?? 'ti-wand') ?>" style="color:#a78bfa;font-size:14px"></i>
                            <span style="font-size:12px"><?= h($log['tool_name'] ?? '—') ?></span>
                        </div>
                    </td>
                    <td style="font-size:11px;color:#38bdf8"><?= h($log['api_name'] ?? '—') ?></td>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px">
                        <?= h($log['input_preview'] ?? '—') ?>
                    </td>
                    <td style="color:#a78bfa;font-weight:500;font-size:12px">
                        <?= $log['credits_used'] ? '-'.$log['credits_used'] : '—' ?>
                    </td>
                    <td>
                        <span class="badge <?= $log['status']==='success' ? 'badge-success' : 'badge-danger' ?>">
                            <?= h($log['status']) ?>
                        </span>
                    </td>
                    <td style="font-size:10px;color:#6b6b90"><?= timeAgo($log['created_at']) ?></td>
                    <td>
                        <?php if ($log['is_visible_to_user']): ?>
                        <form method="POST">
                            <input type="hidden" name="_csrf"  value="<?= h($csrf) ?>">
                            <input type="hidden" name="action" value="hide_log">
                            <input type="hidden" name="id"     value="<?= $log['id'] ?>">
                            <button type="submit" class="btn btn-sm" style="background:rgba(255,255,255,.05);color:#6b6b90;border:.5px solid rgba(255,255,255,.1)" title="Hide from user">
                                <i class="ti ti-eye-off"></i>
                            </button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
            <?php if ($total > $perPage):
                $totalPages = ceil($total/$perPage);
                $q = http_build_query(array_filter(['user'=>$fUser,'tool'=>$fTool,'status'=>$fStatus]));
                echo '<div class="pages">';
                for ($i=1;$i<=$totalPages;$i++):
                    $link = $q ? "activity.php?{$q}&page={$i}" : "activity.php?page={$i}";
                    $active = $i===$page?' active':'';
                    echo "<a href='{$link}' class='page-btn{$active}'>{$i}</a>";
                endfor;
                echo '</div>';
            endif; ?>
        </div>
    </div>
</div>
</body>
</html>
