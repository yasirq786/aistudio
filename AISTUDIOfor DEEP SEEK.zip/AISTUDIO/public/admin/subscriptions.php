<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();
Auth::requireAdmin();

$msg   = '';
$error = '';
$csrf  = Security::generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();
    $action = $_POST['action'] ?? '';

    if ($action === 'add_plan') {
        $name     = Security::sanitizeRaw($_POST['name']     ?? '');
        $price    = (float)$_POST['price_usd'];
        $days     = max(1, (int)$_POST['duration_days']);
        $credits  = max(0, (int)$_POST['credits_included']);
        $featured = isset($_POST['is_featured']) ? 1 : 0;
        $features = Security::sanitizeRaw($_POST['features'] ?? '');
        $slug     = strtolower(preg_replace('/[^a-z0-9]+/', '-', $name));

        DB::execute(
            "INSERT INTO subscription_plans (name,slug,price_usd,duration_days,credits_included,features,is_featured,is_active,sort_order)
             VALUES (?,?,?,?,?,?,?,1,(SELECT COALESCE(MAX(sort_order),0)+1 FROM subscription_plans sp2))",
            [$name, $slug, $price, $days, $credits, $features, $featured]
        );
        $msg = "Plan '{$name}' created.";
    }
    elseif ($action === 'edit_plan') {
        $id       = (int)$_POST['id'];
        $name     = Security::sanitizeRaw($_POST['name']     ?? '');
        $price    = (float)$_POST['price_usd'];
        $days     = max(1, (int)$_POST['duration_days']);
        $credits  = max(0, (int)$_POST['credits_included']);
        $featured = isset($_POST['is_featured']) ? 1 : 0;
        $active   = isset($_POST['is_active'])   ? 1 : 0;
        $features = Security::sanitizeRaw($_POST['features'] ?? '');

        DB::execute(
            "UPDATE subscription_plans SET name=?,price_usd=?,duration_days=?,
             credits_included=?,features=?,is_featured=?,is_active=? WHERE id=?",
            [$name, $price, $days, $credits, $features, $featured, $active, $id]
        );
        $msg = "Plan updated.";
    }
    elseif ($action === 'delete_plan') {
        $id = (int)$_POST['id'];
        DB::execute("DELETE FROM subscription_plans WHERE id=?", [$id]);
        $msg = 'Plan deleted.';
    }
    elseif ($action === 'save_video_tiers') {
        $durations = $_POST['duration']    ?? [];
        $costs     = $_POST['credit_cost'] ?? [];
        $labels    = $_POST['label']       ?? [];

        DB::execute("DELETE FROM video_credit_tiers");
        foreach ($durations as $i => $dur) {
            $dur  = (int)$dur;
            $cost = (int)($costs[$i] ?? 1);
            $lbl  = Security::sanitizeRaw($labels[$i] ?? '');
            if ($dur > 0 && $cost > 0) {
                DB::execute(
                    "INSERT INTO video_credit_tiers (duration_sec,credit_cost,label,sort_order) VALUES (?,?,?,?)",
                    [$dur, $cost, $lbl, $i + 1]
                );
            }
        }
        $msg = 'Video credit tiers saved.';
    }
}

$plans      = DB::query("SELECT * FROM subscription_plans ORDER BY sort_order ASC");
$videoTiers = DB::query("SELECT * FROM video_credit_tiers ORDER BY sort_order ASC");
$pkrRate    = (float)ThemeEngine::get('pkr_rate', '278');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Subscriptions — Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:220px;min-height:100vh;background:#050508;border-right:.5px solid rgba(167,139,250,.12);position:fixed;left:0;top:0;z-index:100;overflow-y:auto;display:flex;flex-direction:column}
.sidebar-logo{padding:18px 16px 14px;font-size:15px;font-weight:600;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;border-bottom:.5px solid rgba(167,139,250,.1)}
.sidebar-logo span{display:block;font-size:10px;color:#6b6b90;-webkit-text-fill-color:#6b6b90;background:none;margin-top:2px}
.nav-section{padding:10px 10px 4px;font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-top:4px}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 14px;color:#9b9bc0;text-decoration:none;font-size:13px;transition:all .15s;border-left:2px solid transparent;border-radius:0 8px 8px 0;margin:1px 6px 1px 0}
.nav-item i{font-size:17px;flex-shrink:0}
.nav-item:hover{color:#f1f1ff;background:rgba(167,139,250,.07)}
.nav-item.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.main{margin-left:220px;flex:1}
.topbar{height:52px;display:flex;align-items:center;padding:0 1.5rem;background:#050508;border-bottom:.5px solid rgba(167,139,250,.1);position:sticky;top:0;z-index:50;font-size:15px;font-weight:500}
.content{padding:1.5rem}
.section{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:14px;padding:1.25rem;margin-bottom:1.25rem}
.section-title{font-size:13px;font-weight:500;color:#a78bfa;margin-bottom:1rem;display:flex;align-items:center;gap:6px;padding-bottom:10px;border-bottom:.5px solid rgba(167,139,250,.1)}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:1rem;display:flex;align-items:center;gap:8px;background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.form-label{display:block;font-size:12px;font-weight:500;color:#9b9bc0;margin-bottom:5px}
.form-input{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:8px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:13px;padding:9px 12px;outline:none;transition:border-color .2s}
.form-input:focus{border-color:#a78bfa}
.form-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:12px}
.form-group{margin-bottom:12px}
.btn{display:inline-flex;align-items:center;gap:5px;padding:8px 16px;border-radius:8px;font-size:13px;font-weight:500;cursor:pointer;border:none;font-family:'Inter',sans-serif;transition:all .2s;text-decoration:none}
.btn-primary{background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff}
.btn-primary:hover{filter:brightness(1.1)}
.btn-danger{background:rgba(239,68,68,.12);color:#ef4444;border:.5px solid rgba(239,68,68,.3)}
.btn-edit{background:rgba(56,189,248,.1);color:#38bdf8;border:.5px solid rgba(56,189,248,.25)}
.btn-sm{padding:5px 10px;font-size:12px}
table{width:100%;border-collapse:collapse}
th{padding:9px 14px;text-align:left;font-size:11px;font-weight:500;color:#6b6b90;text-transform:uppercase;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(0,0,0,.2)}
td{padding:10px 14px;font-size:13px;color:#9b9bc0;border-top:.5px solid rgba(255,255,255,.04);vertical-align:middle}
tr:first-child td{border-top:none}
.badge{display:inline-block;padding:2px 8px;border-radius:5px;font-size:11px;font-weight:500}
.badge-success{background:rgba(34,197,94,.12);color:#22c55e}
.badge-danger{background:rgba(239,68,68,.12);color:#ef4444}
.badge-warning{background:rgba(245,158,11,.12);color:#f59e0b}
.plan-cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;margin-bottom:1rem}
.plan-card{background:rgba(167,139,250,.06);border:.5px solid rgba(167,139,250,.2);border-radius:12px;padding:1.25rem;position:relative}
.plan-card.featured{border-color:#a78bfa;background:rgba(167,139,250,.1)}
.plan-name{font-size:16px;font-weight:600;color:#f1f1ff;margin-bottom:4px}
.plan-price{font-size:24px;font-weight:700;color:#a78bfa}
.plan-price span{font-size:13px;color:#9b9bc0;font-weight:400}
.plan-pkr{font-size:12px;color:#6b6b90;margin-bottom:8px}
.plan-credits{font-size:13px;color:#38bdf8;margin-bottom:12px}
.plan-actions{display:flex;gap:6px;margin-top:12px}
.tier-row{display:grid;grid-template-columns:100px 120px 1fr 36px;gap:8px;align-items:center;margin-bottom:8px}
.modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:200;align-items:center;justify-content:center;padding:1rem}
.modal.open{display:flex}
.modal-box{background:#0d0d1a;border:.5px solid rgba(167,139,250,.3);border-radius:16px;padding:1.5rem;width:100%;max-width:500px;max-height:90vh;overflow-y:auto}
.modal-title{font-size:15px;font-weight:500;margin-bottom:1.25rem;display:flex;align-items:center;justify-content:space-between}
.close-btn{background:none;border:none;color:#9b9bc0;font-size:20px;cursor:pointer}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?><span>Admin Panel</span></div>
    <div class="nav-section">Overview</div>
    <a href="index.php"  class="nav-item"><i class="ti ti-dashboard"></i> Dashboard</a>
    <div class="nav-section">Management</div>
    <a href="tools.php"  class="nav-item"><i class="ti ti-tool"></i> Tools</a>
    <a href="apis.php"   class="nav-item"><i class="ti ti-api"></i> API Services</a>
    <a href="users.php"  class="nav-item"><i class="ti ti-users"></i> Users</a>
    <div class="nav-section">Monetisation</div>
    <a href="subscriptions.php" class="nav-item active"><i class="ti ti-ticket"></i> Plans</a>
    <a href="payments.php"      class="nav-item"><i class="ti ti-credit-card"></i> Payments</a>
    <div class="nav-section">Settings</div>
    <a href="settings.php" class="nav-item"><i class="ti ti-settings"></i> Settings</a>
    <a href="theme.php"    class="nav-item"><i class="ti ti-palette"></i> Theme</a>
    <div style="margin-top:auto;padding:10px">
        <a href="/aistudio/public/dashboard.php" style="display:flex;align-items:center;gap:8px;padding:8px 10px;color:#9b9bc0;text-decoration:none;font-size:12px;border-radius:8px;border:.5px solid rgba(167,139,250,.1)">
            <i class="ti ti-arrow-left"></i> Back to site
        </a>
    </div>
</nav>

<div class="main">
    <header class="topbar"><i class="ti ti-ticket" style="color:#a78bfa;margin-right:8px"></i>Subscription Plans</header>
    <div class="content">
        <?php if ($msg): ?><div class="alert"><i class="ti ti-check"></i><?= h($msg) ?></div><?php endif; ?>

        <!-- Current plans -->
        <div class="section">
            <div class="section-title"><i class="ti ti-cards"></i> Active Plans</div>
            <?php if (empty($plans)): ?>
            <p style="color:#6b6b90;font-size:13px">No plans yet — create one below.</p>
            <?php else: ?>
            <div class="plan-cards">
                <?php foreach ($plans as $p): ?>
                <div class="plan-card <?= $p['is_featured'] ? 'featured' : '' ?>">
                    <?php if ($p['is_featured']): ?>
                    <div style="position:absolute;top:-1px;right:12px;background:#a78bfa;color:#000;font-size:10px;font-weight:600;padding:2px 10px;border-radius:0 0 6px 6px">POPULAR</div>
                    <?php endif; ?>
                    <div class="plan-name"><?= h($p['name']) ?></div>
                    <div class="plan-price">$<?= number_format($p['price_usd'], 2) ?><span>/<?= $p['duration_days'] ?> days</span></div>
                    <div class="plan-pkr">≈ Rs <?= number_format($p['price_usd'] * $pkrRate, 0) ?> PKR</div>
                    <div class="plan-credits"><i class="ti ti-coin" style="font-size:13px"></i> <?= number_format($p['credits_included']) ?> credits included</div>
                    <?php if ($p['features']): ?>
                    <div style="font-size:12px;color:#9b9bc0"><?= h($p['features']) ?></div>
                    <?php endif; ?>
                    <div style="margin-top:6px">
                        <span class="badge <?= $p['is_active'] ? 'badge-success' : 'badge-danger' ?>"><?= $p['is_active'] ? 'Active' : 'Hidden' ?></span>
                    </div>
                    <div class="plan-actions">
                        <button onclick='openEdit(<?= htmlspecialchars(json_encode($p), ENT_QUOTES) ?>)' class="btn btn-edit btn-sm">
                            <i class="ti ti-edit"></i> Edit
                        </button>
                        <form method="POST" style="display:inline" onsubmit="return confirm('Delete this plan?')">
                            <input type="hidden" name="_csrf"   value="<?= h($csrf) ?>">
                            <input type="hidden" name="action"  value="delete_plan">
                            <input type="hidden" name="id"      value="<?= $p['id'] ?>">
                            <button type="submit" class="btn btn-danger btn-sm"><i class="ti ti-trash"></i></button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>

        <!-- Add new plan -->
        <div class="section">
            <div class="section-title"><i class="ti ti-plus"></i> Add New Plan</div>
            <form method="POST">
                <input type="hidden" name="_csrf"   value="<?= h($csrf) ?>">
                <input type="hidden" name="action"  value="add_plan">
                <div class="form-row">
                    <div class="form-group" style="margin-bottom:0">
                        <label class="form-label">Plan name *</label>
                        <input type="text" name="name" class="form-input" placeholder="e.g. Pro" required>
                    </div>
                    <div class="form-group" style="margin-bottom:0">
                        <label class="form-label">Price (USD) *</label>
                        <input type="number" name="price_usd" class="form-input" placeholder="19.99" step="0.01" min="0" required>
                    </div>
                    <div class="form-group" style="margin-bottom:0">
                        <label class="form-label">Duration (days)</label>
                        <input type="number" name="duration_days" class="form-input" value="30" min="1">
                    </div>
                    <div class="form-group" style="margin-bottom:0">
                        <label class="form-label">Credits included</label>
                        <input type="number" name="credits_included" class="form-input" value="1000" min="0">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Features (shown on pricing page)</label>
                    <input type="text" name="features" class="form-input" placeholder="Unlimited chat, HD images, Priority support">
                </div>
                <div style="display:flex;align-items:center;justify-content:space-between">
                    <label style="display:flex;align-items:center;gap:8px;font-size:13px;color:#9b9bc0;cursor:pointer">
                        <input type="checkbox" name="is_featured" style="accent-color:#a78bfa"> Mark as featured (shows "Popular" badge)
                    </label>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-plus"></i> Create Plan</button>
                </div>
            </form>
        </div>

        <!-- Video credit tiers -->
        <div class="section">
            <div class="section-title"><i class="ti ti-player-play"></i> Video Generation Credit Tiers</div>
            <p style="font-size:12px;color:#6b6b90;margin-bottom:1rem">Set credit cost per video duration. Users see these prices before generating.</p>
            <form method="POST">
                <input type="hidden" name="_csrf"  value="<?= h($csrf) ?>">
                <input type="hidden" name="action" value="save_video_tiers">

                <div style="display:grid;grid-template-columns:110px 130px 1fr;gap:8px;margin-bottom:8px">
                    <div style="font-size:11px;color:#6b6b90;font-weight:500;text-transform:uppercase">Duration (sec)</div>
                    <div style="font-size:11px;color:#6b6b90;font-weight:500;text-transform:uppercase">Credit cost</div>
                    <div style="font-size:11px;color:#6b6b90;font-weight:500;text-transform:uppercase">Label</div>
                </div>

                <div id="tierRows">
                    <?php foreach ($videoTiers as $i => $tier): ?>
                    <div class="tier-row" id="tier<?= $i ?>">
                        <input type="number" name="duration[]"    class="form-input" value="<?= $tier['duration_sec'] ?>" min="1" placeholder="4">
                        <input type="number" name="credit_cost[]" class="form-input" value="<?= $tier['credit_cost'] ?>"  min="1" placeholder="5">
                        <input type="text"   name="label[]"       class="form-input" value="<?= h($tier['label'] ?? '') ?>" placeholder="4 seconds">
                        <button type="button" onclick="this.closest('.tier-row').remove()" style="background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);color:#ef4444;border-radius:7px;cursor:pointer;width:32px;height:32px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                            <i class="ti ti-x" style="font-size:14px"></i>
                        </button>
                    </div>
                    <?php endforeach; ?>
                    <?php if (empty($videoTiers)): ?>
                    <div class="tier-row">
                        <input type="number" name="duration[]"    class="form-input" value="4"  placeholder="4">
                        <input type="number" name="credit_cost[]" class="form-input" value="5"  placeholder="5">
                        <input type="text"   name="label[]"       class="form-input" value="4 seconds">
                        <button type="button" onclick="this.closest('.tier-row').remove()" style="background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);color:#ef4444;border-radius:7px;cursor:pointer;width:32px;height:32px;display:flex;align-items:center;justify-content:center;flex-shrink:0"><i class="ti ti-x" style="font-size:14px"></i></button>
                    </div>
                    <?php endif; ?>
                </div>

                <div style="display:flex;gap:10px;margin-top:10px">
                    <button type="button" onclick="addTier()" class="btn" style="background:rgba(255,255,255,.05);color:#9b9bc0;border:.5px solid rgba(255,255,255,.1)">
                        <i class="ti ti-plus"></i> Add tier
                    </button>
                    <button type="submit" class="btn btn-primary"><i class="ti ti-device-floppy"></i> Save tiers</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit plan modal -->
<div class="modal" id="editModal">
    <div class="modal-box">
        <div class="modal-title">
            <span><i class="ti ti-edit" style="color:#a78bfa"></i> Edit Plan</span>
            <button class="close-btn" onclick="closeModal()"><i class="ti ti-x"></i></button>
        </div>
        <form method="POST">
            <input type="hidden" name="_csrf"  value="<?= h($csrf) ?>">
            <input type="hidden" name="action" value="edit_plan">
            <input type="hidden" name="id"     id="eId">
            <div class="form-row">
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Plan name</label>
                    <input type="text" name="name" id="eName" class="form-input" required>
                </div>
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Price (USD)</label>
                    <input type="number" name="price_usd" id="ePrice" class="form-input" step="0.01" min="0">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Duration (days)</label>
                    <input type="number" name="duration_days" id="eDays" class="form-input">
                </div>
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Credits included</label>
                    <input type="number" name="credits_included" id="eCredits" class="form-input">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Features</label>
                <input type="text" name="features" id="eFeatures" class="form-input">
            </div>
            <div style="display:flex;gap:16px;margin-bottom:1rem">
                <label style="display:flex;align-items:center;gap:6px;font-size:13px;color:#9b9bc0;cursor:pointer">
                    <input type="checkbox" name="is_featured" id="eFeatured" style="accent-color:#a78bfa"> Featured
                </label>
                <label style="display:flex;align-items:center;gap:6px;font-size:13px;color:#9b9bc0;cursor:pointer">
                    <input type="checkbox" name="is_active" id="eActive" style="accent-color:#a78bfa"> Active (visible)
                </label>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:10px">
                <button type="button" onclick="closeModal()" class="btn" style="background:rgba(255,255,255,.05);color:#9b9bc0">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="ti ti-check"></i> Save</button>
            </div>
        </form>
    </div>
</div>

<script>
let tierCount = <?= count($videoTiers) ?: 1 ?>;
function addTier() {
    const row = document.createElement('div');
    row.className = 'tier-row';
    row.innerHTML = `<input type="number" name="duration[]" class="form-input" placeholder="sec" min="1">
        <input type="number" name="credit_cost[]" class="form-input" placeholder="credits" min="1">
        <input type="text" name="label[]" class="form-input" placeholder="Label">
        <button type="button" onclick="this.closest('.tier-row').remove()" style="background:rgba(239,68,68,.1);border:.5px solid rgba(239,68,68,.3);color:#ef4444;border-radius:7px;cursor:pointer;width:32px;height:32px;display:flex;align-items:center;justify-content:center;flex-shrink:0"><i class="ti ti-x" style="font-size:14px"></i></button>`;
    document.getElementById('tierRows').appendChild(row);
}
function openEdit(p) {
    document.getElementById('eId').value       = p.id;
    document.getElementById('eName').value     = p.name;
    document.getElementById('ePrice').value    = p.price_usd;
    document.getElementById('eDays').value     = p.duration_days;
    document.getElementById('eCredits').value  = p.credits_included;
    document.getElementById('eFeatures').value = p.features || '';
    document.getElementById('eFeatured').checked = p.is_featured == 1;
    document.getElementById('eActive').checked   = p.is_active   == 1;
    document.getElementById('editModal').classList.add('open');
}
function closeModal() { document.getElementById('editModal').classList.remove('open'); }
document.getElementById('editModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});
</script>
</body>
</html>
