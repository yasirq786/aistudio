<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';

Security::startSession();
Security::checkIpBan();
Auth::requireAdmin();

// ── Stats ─────────────────────────────────────────────────────────
$totalUsers       = (int)DB::scalar("SELECT COUNT(*) FROM users WHERE role='user'");
$totalAdmins      = (int)DB::scalar("SELECT COUNT(*) FROM users WHERE role IN ('admin','super_admin','moderator')");
$activeSubscribers= (int)DB::scalar("SELECT COUNT(*) FROM user_subscriptions WHERE status='active' AND expires_at > NOW()");
$totalCreditsHeld = (int)DB::scalar("SELECT COALESCE(SUM(credit_balance),0) FROM users");
$onlineUsers      = (int)DB::scalar("SELECT COUNT(*) FROM users WHERE last_seen_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)");
$newTodayUsers    = (int)DB::scalar("SELECT COUNT(*) FROM users WHERE DATE(created_at)=CURDATE()");

// Revenue this month
$revenueMonth = (float)DB::scalar(
    "SELECT COALESCE(SUM(amount_usd),0) FROM payments
     WHERE status='verified' AND MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())"
);
$revenueTotal = (float)DB::scalar("SELECT COALESCE(SUM(amount_usd),0) FROM payments WHERE status='verified'");

// API cost this month
$apiCostMonth = (float)DB::scalar(
    "SELECT COALESCE(SUM(api_cost_usd),0) FROM api_call_logs
     WHERE MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())"
);
$profitMonth = $revenueMonth - $apiCostMonth;

// Recent users
$recentUsers = DB::query(
    "SELECT id, name, email, role, status, credit_balance, last_seen_at, last_ip, created_at
     FROM users ORDER BY created_at DESC LIMIT 8"
);

// Recent payments pending
$pendingPayments = DB::query(
    "SELECT p.*, u.name as user_name, u.email as user_email, sp.name as plan_name
     FROM payments p
     JOIN users u ON u.id = p.user_id
     JOIN subscription_plans sp ON sp.id = p.plan_id
     WHERE p.status='pending'
     ORDER BY p.created_at DESC LIMIT 5"
);

// API call stats
$totalApiCalls  = (int)DB::scalar("SELECT COUNT(*) FROM api_call_logs");
$failedApiCalls = (int)DB::scalar("SELECT COUNT(*) FROM api_call_logs WHERE status='failed'");
$todayApiCalls  = (int)DB::scalar("SELECT COUNT(*) FROM api_call_logs WHERE DATE(created_at)=CURDATE()");

$pkrRate = (float)ThemeEngine::get('pkr_rate', '278');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel — <?= ThemeEngine::siteName() ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}

/* Sidebar */
.sidebar{
    width:220px;min-height:100vh;background:#050508;
    border-right:.5px solid rgba(167,139,250,.12);
    display:flex;flex-direction:column;
    position:fixed;left:0;top:0;z-index:100;overflow-y:auto;
}
.sidebar-logo{
    padding:18px 16px 14px;
    font-size:15px;font-weight:600;
    background:linear-gradient(135deg,#a78bfa,#38bdf8);
    -webkit-background-clip:text;-webkit-text-fill-color:transparent;
    border-bottom:.5px solid rgba(167,139,250,.1);
}
.sidebar-logo span{display:block;font-size:10px;color:#6b6b90;margin-top:2px;
                    -webkit-text-fill-color:#6b6b90;background:none}
.nav-section{padding:10px 10px 4px;font-size:10px;font-weight:500;
             color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-top:4px}
.nav-item{
    display:flex;align-items:center;gap:10px;
    padding:9px 14px;color:#9b9bc0;text-decoration:none;
    font-size:13px;transition:all .15s;border-left:2px solid transparent;
    border-radius:0 8px 8px 0;margin:1px 6px 1px 0;
}
.nav-item i{font-size:17px;flex-shrink:0}
.nav-item:hover{color:#f1f1ff;background:rgba(167,139,250,.07)}
.nav-item.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.nav-badge{
    margin-left:auto;background:rgba(239,68,68,.2);color:#ef4444;
    font-size:10px;font-weight:600;padding:1px 6px;border-radius:10px;
}

/* Main */
.main{margin-left:220px;flex:1;min-height:100vh;display:flex;flex-direction:column}
.topbar{
    height:52px;display:flex;align-items:center;justify-content:space-between;
    padding:0 1.5rem;background:#050508;
    border-bottom:.5px solid rgba(167,139,250,.1);
    position:sticky;top:0;z-index:50;
}
.topbar-title{font-size:15px;font-weight:500}
.topbar-right{display:flex;align-items:center;gap:12px}
.admin-badge{
    font-size:11px;padding:3px 10px;border-radius:20px;
    background:rgba(167,139,250,.12);border:.5px solid rgba(167,139,250,.25);color:#a78bfa;
}
.content{padding:1.5rem;flex:1}

/* Stats grid */
.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:1.5rem}
.stat{
    background:rgba(255,255,255,.03);
    border:.5px solid rgba(167,139,250,.12);
    border-radius:14px;padding:1rem 1.25rem;
    transition:border-color .2s;
}
.stat:hover{border-color:rgba(167,139,250,.25)}
.stat-label{font-size:11px;color:#6b6b90;margin-bottom:8px;display:flex;align-items:center;gap:6px}
.stat-label i{font-size:14px}
.stat-val{font-size:24px;font-weight:600;color:#f1f1ff;line-height:1}
.stat-sub{font-size:11px;color:#9b9bc0;margin-top:5px}
.stat-up{color:#22c55e}
.stat-down{color:#ef4444}

/* Profit card */
.profit-positive{border-color:rgba(34,197,94,.2)!important}
.profit-negative{border-color:rgba(239,68,68,.2)!important}

/* Section */
.section-title{
    font-size:13px;font-weight:500;color:#9b9bc0;
    margin-bottom:10px;display:flex;align-items:center;
    justify-content:space-between;gap:6px;
}
.section-title a{font-size:12px;color:#a78bfa;text-decoration:none}
.section-title a:hover{text-decoration:underline}

/* Table card */
.table-card{
    background:rgba(255,255,255,.03);
    border:.5px solid rgba(167,139,250,.1);
    border-radius:14px;overflow:hidden;margin-bottom:1.5rem;
}
table{width:100%;border-collapse:collapse}
th{
    padding:9px 14px;text-align:left;font-size:11px;font-weight:500;
    color:#6b6b90;text-transform:uppercase;letter-spacing:.04em;
    border-bottom:.5px solid rgba(167,139,250,.1);
    background:rgba(0,0,0,.2);
}
td{
    padding:10px 14px;font-size:13px;color:#9b9bc0;
    border-top:.5px solid rgba(255,255,255,.04);
}
tr:first-child td{border-top:none}
tr:hover td{background:rgba(167,139,250,.03)}
.td-main{color:#f1f1ff;font-weight:500}

/* Badges */
.badge{display:inline-block;padding:2px 8px;border-radius:5px;font-size:11px;font-weight:500}
.badge-success{background:rgba(34,197,94,.12);color:#22c55e}
.badge-danger{background:rgba(239,68,68,.12);color:#ef4444}
.badge-warning{background:rgba(245,158,11,.12);color:#f59e0b}
.badge-info{background:rgba(56,189,248,.12);color:#38bdf8}
.badge-purple{background:rgba(167,139,250,.12);color:#a78bfa}

/* Online dot */
.online-dot{display:inline-block;width:7px;height:7px;border-radius:50%;
            background:#22c55e;margin-right:4px}
.offline-dot{display:inline-block;width:7px;height:7px;border-radius:50%;
             background:#6b6b90;margin-right:4px}

/* Quick actions */
.quick-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px;margin-bottom:1.5rem}
.quick-btn{
    display:flex;flex-direction:column;align-items:center;gap:8px;
    padding:14px 12px;border-radius:12px;text-decoration:none;
    background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);
    color:#9b9bc0;font-size:12px;font-weight:500;text-align:center;
    transition:all .2s;cursor:pointer;
}
.quick-btn:hover{background:rgba(167,139,250,.08);border-color:rgba(167,139,250,.3);color:#f1f1ff;transform:translateY(-2px)}
.quick-btn i{font-size:22px;color:#a78bfa}

/* Empty state */
.empty{padding:1.5rem;text-align:center;color:#6b6b90;font-size:13px}
.empty i{font-size:28px;display:block;margin-bottom:8px;opacity:.4}

/* Grid 2 */
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
@media(max-width:1100px){.grid2{grid-template-columns:1fr}}
@media(max-width:768px){.sidebar{width:0;overflow:hidden}.main{margin-left:0}}
</style>
</head>
<body>

<!-- Sidebar -->
<nav class="sidebar" aria-label="Admin navigation">
    <div class="sidebar-logo">
        &#9670; <?= ThemeEngine::siteName() ?>
        <span>Admin Panel</span>
    </div>

    <div class="nav-section">Overview</div>
    <a href="index.php" class="nav-item active"><i class="ti ti-dashboard"></i> Dashboard</a>

    <div class="nav-section">Management</div>
    <a href="tools.php"  class="nav-item"><i class="ti ti-tool"></i> Tools</a>
    <a href="apis.php"   class="nav-item"><i class="ti ti-api"></i> API Services</a>
    <a href="users.php"  class="nav-item"><i class="ti ti-users"></i> Users</a>

    <div class="nav-section">Monetisation</div>
    <a href="subscriptions.php" class="nav-item"><i class="ti ti-ticket"></i> Plans</a>
    <a href="coupons.php"       class="nav-item"><i class="ti ti-discount"></i> Coupons</a>
    <a href="payments.php"      class="nav-item">
        <i class="ti ti-credit-card"></i> Payments
        <?php if (count($pendingPayments)): ?>
        <span class="nav-badge"><?= count($pendingPayments) ?></span>
        <?php endif; ?>
    </a>

    <div class="nav-section">Content</div>
    <a href="gallery.php"       class="nav-item"><i class="ti ti-photo"></i> Gallery</a>
    <a href="reviews.php"       class="nav-item"><i class="ti ti-star"></i> Reviews</a>
    <a href="advertisements.php"class="nav-item"><i class="ti ti-ad"></i> Ads</a>

    <div class="nav-section">Logs</div>
    <a href="logs.php"     class="nav-item"><i class="ti ti-list"></i> API Logs</a>
    <a href="activity.php" class="nav-item"><i class="ti ti-activity"></i> Activity</a>

    <div class="nav-section">Settings</div>
    <a href="settings.php" class="nav-item"><i class="ti ti-settings"></i> Settings</a>
    <a href="theme.php"    class="nav-item"><i class="ti ti-palette"></i> Theme</a>

    <div style="margin-top:auto;padding:10px">
        <a href="/aistudio/public/dashboard.php"
           style="display:flex;align-items:center;gap:8px;padding:8px 10px;
                  color:#9b9bc0;text-decoration:none;font-size:12px;border-radius:8px;
                  border:.5px solid rgba(167,139,250,.1);transition:all .2s"
           onmouseover="this.style.borderColor='rgba(167,139,250,.3)'"
           onmouseout="this.style.borderColor='rgba(167,139,250,.1)'">
            <i class="ti ti-arrow-left" style="font-size:15px"></i> Back to site
        </a>
    </div>
</nav>

<!-- Main content -->
<div class="main">
    <header class="topbar">
        <span class="topbar-title">Dashboard</span>
        <div class="topbar-right">
            <span style="font-size:12px;color:#6b6b90"><?= date('D, M j Y') ?></span>
            <span class="admin-badge">
                <i class="ti ti-shield-check" style="font-size:12px"></i>
                <?= h(Auth::user()['role']) ?>
            </span>
            <span style="font-size:13px;color:#f1f1ff"><?= h(Auth::user()['name']) ?></span>
        </div>
    </header>

    <div class="content">

        <!-- Stats -->
        <div class="stats-grid">
            <div class="stat">
                <div class="stat-label"><i class="ti ti-users"></i> Total users</div>
                <div class="stat-val"><?= number_format($totalUsers) ?></div>
                <div class="stat-sub"><span class="stat-up">+<?= $newTodayUsers ?></span> today &nbsp;·&nbsp; <?= $onlineUsers ?> online now</div>
            </div>
            <div class="stat">
                <div class="stat-label"><i class="ti ti-crown"></i> Subscribers</div>
                <div class="stat-val"><?= number_format($activeSubscribers) ?></div>
                <div class="stat-sub"><?= $totalUsers > 0 ? round($activeSubscribers/$totalUsers*100,1) : 0 ?>% of users</div>
            </div>
            <div class="stat">
                <div class="stat-label"><i class="ti ti-coin"></i> Credits held</div>
                <div class="stat-val"><?= number_format($totalCreditsHeld) ?></div>
                <div class="stat-sub">≈ <?= formatUsd(CreditEngine::creditsToUsd($totalCreditsHeld)) ?> liability</div>
            </div>
            <div class="stat">
                <div class="stat-label"><i class="ti ti-cash"></i> Revenue (month)</div>
                <div class="stat-val"><?= formatUsd($revenueMonth) ?></div>
                <div class="stat-sub">Rs <?= number_format($revenueMonth * $pkrRate, 0) ?> PKR &nbsp;·&nbsp; Total <?= formatUsd($revenueTotal) ?></div>
            </div>
            <div class="stat">
                <div class="stat-label"><i class="ti ti-api"></i> API cost (month)</div>
                <div class="stat-val"><?= formatUsd($apiCostMonth) ?></div>
                <div class="stat-sub"><?= number_format($todayApiCalls) ?> calls today &nbsp;·&nbsp; <?= number_format($failedApiCalls) ?> failed</div>
            </div>
            <div class="stat <?= $profitMonth >= 0 ? 'profit-positive' : 'profit-negative' ?>">
                <div class="stat-label"><i class="ti ti-trending-up"></i> Net profit (month)</div>
                <div class="stat-val" style="color:<?= $profitMonth >= 0 ? '#22c55e' : '#ef4444' ?>">
                    <?= formatUsd($profitMonth) ?>
                </div>
                <div class="stat-sub">Revenue − API cost</div>
            </div>
        </div>

        <!-- Quick actions -->
        <div class="section-title"><span><i class="ti ti-bolt" style="font-size:14px"></i> Quick actions</span></div>
        <div class="quick-grid">
            <a href="apis.php" class="quick-btn">
                <i class="ti ti-api"></i>Add API Key
            </a>
            <a href="tools.php" class="quick-btn">
                <i class="ti ti-tool"></i>Manage Tools
            </a>
            <a href="users.php" class="quick-btn">
                <i class="ti ti-user-plus"></i>Add User
            </a>
            <a href="payments.php" class="quick-btn">
                <i class="ti ti-credit-card"></i>
                Payments
                <?php if (count($pendingPayments)): ?>
                <span style="background:rgba(239,68,68,.2);color:#ef4444;font-size:10px;padding:1px 6px;border-radius:8px">
                    <?= count($pendingPayments) ?> pending
                </span>
                <?php endif; ?>
            </a>
            <a href="settings.php" class="quick-btn">
                <i class="ti ti-settings"></i>Site Settings
            </a>
            <a href="theme.php" class="quick-btn">
                <i class="ti ti-palette"></i>Change Theme
            </a>
            <a href="subscriptions.php" class="quick-btn">
                <i class="ti ti-ticket"></i>Add Plan
            </a>
            <a href="logs.php" class="quick-btn">
                <i class="ti ti-list"></i>View Logs
            </a>
        </div>

        <div class="grid2">
            <!-- Recent users -->
            <div>
                <div class="section-title">
                    <span><i class="ti ti-users" style="font-size:14px"></i> Recent users</span>
                    <a href="users.php">View all →</a>
                </div>
                <div class="table-card">
                    <table>
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Credits</th>
                                <th>Status</th>
                                <th>Online</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (empty($recentUsers)): ?>
                        <tr><td colspan="4" class="empty"><i class="ti ti-users"></i>No users yet</td></tr>
                        <?php else: ?>
                        <?php foreach ($recentUsers as $u): ?>
                        <tr>
                            <td>
                                <div class="td-main"><?= h($u['name']) ?></div>
                                <div style="font-size:11px;color:#6b6b90"><?= h($u['email']) ?></div>
                            </td>
                            <td style="color:#a78bfa;font-weight:500"><?= number_format($u['credit_balance']) ?></td>
                            <td>
                                <?php if ($u['status'] === 'active'): ?>
                                    <span class="badge badge-success">active</span>
                                <?php elseif ($u['status'] === 'suspended'): ?>
                                    <span class="badge badge-warning">suspended</span>
                                <?php else: ?>
                                    <span class="badge badge-danger">banned</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($u['last_seen_at'] && isOnline($u['last_seen_at'])): ?>
                                    <span class="online-dot"></span><span style="font-size:11px;color:#22c55e">Online</span>
                                <?php else: ?>
                                    <span class="offline-dot"></span><span style="font-size:11px"><?= $u['last_seen_at'] ? timeAgo($u['last_seen_at']) : 'Never' ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Pending payments -->
            <div>
                <div class="section-title">
                    <span><i class="ti ti-credit-card" style="font-size:14px"></i> Pending payments</span>
                    <a href="payments.php">View all →</a>
                </div>
                <div class="table-card">
                    <table>
                        <thead>
                            <tr><th>User</th><th>Plan</th><th>Amount</th><th>Action</th></tr>
                        </thead>
                        <tbody>
                        <?php if (empty($pendingPayments)): ?>
                        <tr><td colspan="4" class="empty"><i class="ti ti-check"></i>No pending payments</td></tr>
                        <?php else: ?>
                        <?php foreach ($pendingPayments as $p): ?>
                        <tr>
                            <td>
                                <div class="td-main"><?= h($p['user_name']) ?></div>
                                <div style="font-size:11px;color:#6b6b90"><?= h($p['gateway']) ?></div>
                            </td>
                            <td><?= h($p['plan_name']) ?></td>
                            <td style="color:#22c55e;font-weight:500"><?= formatUsd($p['amount_usd']) ?></td>
                            <td>
                                <a href="payments.php?verify=<?= $p['id'] ?>"
                                   style="color:#a78bfa;font-size:12px;text-decoration:none">
                                    Verify →
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- API tools status -->
        <div class="section-title">
            <span><i class="ti ti-api" style="font-size:14px"></i> API services status</span>
            <a href="apis.php">Manage →</a>
        </div>
        <div class="table-card">
            <?php
            $apis = DB::query(
                "SELECT a.*, t.name as tool_name
                 FROM api_services a JOIN tools t ON t.id = a.tool_id
                 ORDER BY t.sort_order, a.sort_order LIMIT 15"
            );
            ?>
            <table>
                <thead>
                    <tr><th>Tool</th><th>Provider</th><th>Model</th><th>Cost</th><th>Status</th></tr>
                </thead>
                <tbody>
                <?php if (empty($apis)): ?>
                <tr>
                    <td colspan="5" class="empty">
                        <i class="ti ti-api"></i>
                        No API services yet.
                        <a href="apis.php" style="color:#a78bfa">Add your first API →</a>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($apis as $api): ?>
                <tr>
                    <td class="td-main"><?= h($api['tool_name']) ?></td>
                    <td><?= h($api['name']) ?></td>
                    <td style="font-size:11px;color:#6b6b90"><?= h($api['model'] ?: '—') ?></td>
                    <td style="color:#a78bfa"><?= $api['credit_cost'] ?> cr</td>
                    <td>
                        <?php if ($api['is_enabled'] && $api['api_key']): ?>
                            <span class="badge badge-success"><i class="ti ti-wifi"></i> Active</span>
                        <?php elseif (!$api['api_key']): ?>
                            <span class="badge badge-warning">No key</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Disabled</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div><!-- end content -->
</div><!-- end main -->

</body>
</html>
