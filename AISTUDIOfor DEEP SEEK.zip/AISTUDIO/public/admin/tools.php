<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();
Auth::requireAdmin();

$msg   = '';
$error = '';
$csrf  = Security::generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();
    $action = $_POST['action'] ?? '';

    if ($action === 'toggle') {
        $id  = (int)$_POST['id'];
        DB::execute("UPDATE tools SET is_enabled = 1-is_enabled WHERE id=?", [$id]);
        $msg = 'Tool status updated.';
    }
    elseif ($action === 'toggle_landing') {
        $id = (int)$_POST['id'];
        DB::execute("UPDATE tools SET is_visible_on_landing = 1-is_visible_on_landing WHERE id=?", [$id]);
        $msg = 'Landing page visibility updated.';
    }
    elseif ($action === 'edit') {
        $id          = (int)$_POST['id'];
        $name        = Security::sanitizeRaw($_POST['name']        ?? '');
        $icon        = Security::sanitizeRaw($_POST['icon']        ?? '');
        $description = Security::sanitizeRaw($_POST['description'] ?? '');
        $infoHowTo   = Security::sanitizeRaw($_POST['info_how_to'] ?? '');
        $infoFeatures= Security::sanitizeRaw($_POST['info_features']?? '');
        $infoTips    = Security::sanitizeRaw($_POST['info_tips']   ?? '');
        $sortOrder   = (int)$_POST['sort_order'];

        DB::execute(
            "UPDATE tools SET name=?,icon=?,description=?,info_how_to=?,
             info_features=?,info_tips=?,sort_order=? WHERE id=?",
            [$name, $icon, $description, $infoHowTo, $infoFeatures, $infoTips, $sortOrder, $id]
        );
        $msg = "Tool '{$name}' updated.";
    }
    elseif ($action === 'allow_publish') {
        $id = (int)$_POST['id'];
        DB::execute("UPDATE tools SET allow_publish = 1-allow_publish WHERE id=?", [$id]);
        $msg = 'Publish setting updated.';
    }
}

$tools = DB::query("SELECT * FROM tools ORDER BY sort_order ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Tools — Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:220px;min-height:100vh;background:#050508;border-right:.5px solid rgba(167,139,250,.12);position:fixed;left:0;top:0;z-index:100;overflow-y:auto;display:flex;flex-direction:column}
.sidebar-logo{padding:18px 16px 14px;font-size:15px;font-weight:600;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;border-bottom:.5px solid rgba(167,139,250,.1)}
.sidebar-logo span{display:block;font-size:10px;color:#6b6b90;-webkit-text-fill-color:#6b6b90;background:none;margin-top:2px}
.nav-section{padding:10px 10px 4px;font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-top:4px}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 14px;color:#9b9bc0;text-decoration:none;font-size:13px;transition:all .15s;border-left:2px solid transparent;border-radius:0 8px 8px 0;margin:1px 6px 1px 0}
.nav-item i{font-size:17px;flex-shrink:0}
.nav-item:hover{color:#f1f1ff;background:rgba(167,139,250,.07)}
.nav-item.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.main{margin-left:220px;flex:1;min-height:100vh}
.topbar{height:52px;display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;background:#050508;border-bottom:.5px solid rgba(167,139,250,.1);position:sticky;top:0;z-index:50}
.topbar-title{font-size:15px;font-weight:500}
.content{padding:1.5rem}
.card{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:14px;overflow:hidden;margin-bottom:1.25rem}
table{width:100%;border-collapse:collapse}
th{padding:9px 14px;text-align:left;font-size:11px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.04em;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(0,0,0,.2)}
td{padding:10px 14px;font-size:13px;color:#9b9bc0;border-top:.5px solid rgba(255,255,255,.04);vertical-align:middle}
tr:first-child td{border-top:none}
tr:hover td{background:rgba(167,139,250,.03)}
.badge{display:inline-block;padding:2px 8px;border-radius:5px;font-size:11px;font-weight:500}
.badge-success{background:rgba(34,197,94,.12);color:#22c55e}
.badge-danger{background:rgba(239,68,68,.12);color:#ef4444}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:1rem;display:flex;align-items:center;gap:8px}
.alert-success{background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.btn{display:inline-flex;align-items:center;gap:5px;padding:5px 12px;border-radius:7px;font-size:12px;font-weight:500;cursor:pointer;border:none;transition:all .2s;font-family:'Inter',sans-serif;text-decoration:none;white-space:nowrap}
.btn-sm{padding:4px 10px;font-size:11px}
.btn-primary{background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff}
.btn-enable{background:rgba(34,197,94,.12);color:#22c55e;border:.5px solid rgba(34,197,94,.25)}
.btn-disable{background:rgba(239,68,68,.12);color:#ef4444;border:.5px solid rgba(239,68,68,.25)}
.btn-edit{background:rgba(56,189,248,.12);color:#38bdf8;border:.5px solid rgba(56,189,248,.25)}
.btn-warn{background:rgba(245,158,11,.12);color:#f59e0b;border:.5px solid rgba(245,158,11,.25)}
.form-input{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:8px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:13px;padding:8px 12px;outline:none;transition:border-color .2s}
.form-input:focus{border-color:#a78bfa}
.form-label{display:block;font-size:12px;font-weight:500;color:#9b9bc0;margin-bottom:4px}
textarea.form-input{resize:vertical;min-height:80px}
.modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:200;align-items:center;justify-content:center;padding:1rem}
.modal.open{display:flex}
.modal-box{background:#0d0d1a;border:.5px solid rgba(167,139,250,.3);border-radius:16px;padding:1.5rem;width:100%;max-width:560px;max-height:90vh;overflow-y:auto}
.modal-title{font-size:15px;font-weight:500;margin-bottom:1.25rem;display:flex;align-items:center;justify-content:space-between}
.close-btn{background:none;border:none;color:#9b9bc0;font-size:20px;cursor:pointer}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}
.form-group{margin-bottom:12px}
.tool-icon{width:32px;height:32px;border-radius:8px;background:rgba(167,139,250,.1);display:flex;align-items:center;justify-content:center;font-size:17px;color:#a78bfa;flex-shrink:0}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?><span>Admin Panel</span></div>
    <div class="nav-section">Overview</div>
    <a href="index.php"  class="nav-item"><i class="ti ti-dashboard"></i> Dashboard</a>
    <div class="nav-section">Management</div>
    <a href="tools.php"  class="nav-item active"><i class="ti ti-tool"></i> Tools</a>
    <a href="apis.php"   class="nav-item"><i class="ti ti-api"></i> API Services</a>
    <a href="users.php"  class="nav-item"><i class="ti ti-users"></i> Users</a>
    <div class="nav-section">Monetisation</div>
    <a href="subscriptions.php" class="nav-item"><i class="ti ti-ticket"></i> Plans</a>
    <a href="payments.php"      class="nav-item"><i class="ti ti-credit-card"></i> Payments</a>
    <div class="nav-section">Settings</div>
    <a href="settings.php" class="nav-item"><i class="ti ti-settings"></i> Settings</a>
    <a href="theme.php"    class="nav-item"><i class="ti ti-palette"></i> Theme</a>
    <div style="margin-top:auto;padding:10px">
        <a href="/aistudio/public/dashboard.php" style="display:flex;align-items:center;gap:8px;padding:8px 10px;color:#9b9bc0;text-decoration:none;font-size:12px;border-radius:8px;border:.5px solid rgba(167,139,250,.1)">
            <i class="ti ti-arrow-left"></i> Back to site
        </a>
    </div>
</nav>

<div class="main">
    <header class="topbar">
        <span class="topbar-title"><i class="ti ti-tool" style="color:#a78bfa;vertical-align:-2px;margin-right:6px"></i>Tools Management</span>
        <span style="font-size:12px;color:#6b6b90"><?= count($tools) ?> tools total</span>
    </header>
    <div class="content">
        <?php if ($msg): ?><div class="alert alert-success"><i class="ti ti-check"></i><?= h($msg) ?></div><?php endif; ?>

        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Tool</th>
                        <th>Slug</th>
                        <th>APIs</th>
                        <th>Enabled</th>
                        <th>On Landing</th>
                        <th>Publish</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($tools as $t):
                    $apiCount = (int)DB::scalar("SELECT COUNT(*) FROM api_services WHERE tool_id=? AND is_enabled=1", [$t['id']]);
                ?>
                <tr>
                    <td style="color:#6b6b90;font-size:11px"><?= $t['sort_order'] ?></td>
                    <td>
                        <div style="display:flex;align-items:center;gap:10px">
                            <div class="tool-icon"><i class="ti <?= h($t['icon']) ?>"></i></div>
                            <div>
                                <div style="color:#f1f1ff;font-weight:500"><?= h($t['name']) ?></div>
                                <div style="font-size:11px;color:#6b6b90"><?= h($t['description'] ?: '—') ?></div>
                            </div>
                        </div>
                    </td>
                    <td><code style="font-size:11px;color:#9b9bc0;background:rgba(0,0,0,.3);padding:2px 6px;border-radius:4px"><?= h($t['slug']) ?></code></td>
                    <td>
                        <?php if ($apiCount > 0): ?>
                            <span class="badge badge-success"><?= $apiCount ?> active</span>
                        <?php else: ?>
                            <span class="badge badge-danger">none</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="_csrf"  value="<?= h($csrf) ?>">
                            <input type="hidden" name="action" value="toggle">
                            <input type="hidden" name="id"     value="<?= $t['id'] ?>">
                            <button type="submit" class="btn <?= $t['is_enabled'] ? 'btn-enable' : 'btn-disable' ?>">
                                <?= $t['is_enabled'] ? '<i class="ti ti-check"></i> On' : '<i class="ti ti-x"></i> Off' ?>
                            </button>
                        </form>
                    </td>
                    <td>
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="_csrf"  value="<?= h($csrf) ?>">
                            <input type="hidden" name="action" value="toggle_landing">
                            <input type="hidden" name="id"     value="<?= $t['id'] ?>">
                            <button type="submit" class="btn <?= $t['is_visible_on_landing'] ? 'btn-enable' : 'btn-disable' ?>">
                                <?= $t['is_visible_on_landing'] ? '<i class="ti ti-eye"></i> Yes' : '<i class="ti ti-eye-off"></i> No' ?>
                            </button>
                        </form>
                    </td>
                    <td>
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="_csrf"  value="<?= h($csrf) ?>">
                            <input type="hidden" name="action" value="allow_publish">
                            <input type="hidden" name="id"     value="<?= $t['id'] ?>">
                            <button type="submit" class="btn <?= $t['allow_publish'] ? 'btn-warn' : 'btn-sm' ?>"
                                    style="<?= !$t['allow_publish'] ? 'background:rgba(255,255,255,.05);color:#6b6b90;border:.5px solid rgba(255,255,255,.1)' : '' ?>">
                                <?= $t['allow_publish'] ? '<i class="ti ti-upload"></i> Yes' : 'No' ?>
                            </button>
                        </form>
                    </td>
                    <td>
                        <button onclick='openEdit(<?= htmlspecialchars(json_encode($t), ENT_QUOTES) ?>)'
                                class="btn btn-edit">
                            <i class="ti ti-edit"></i> Edit
                        </button>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Edit modal -->
<div class="modal" id="editModal">
    <div class="modal-box">
        <div class="modal-title">
            <span><i class="ti ti-edit" style="color:#a78bfa"></i> Edit Tool</span>
            <button class="close-btn" onclick="closeModal()"><i class="ti ti-x"></i></button>
        </div>
        <form method="POST">
            <input type="hidden" name="_csrf"   value="<?= h($csrf) ?>">
            <input type="hidden" name="action"  value="edit">
            <input type="hidden" name="id"      id="eId">
            <div class="form-row">
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Tool name</label>
                    <input type="text" name="name" id="eName" class="form-input" required>
                </div>
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Icon class (Tabler)</label>
                    <input type="text" name="icon" id="eIcon" class="form-input" placeholder="ti-message-circle">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Sort order</label>
                    <input type="number" name="sort_order" id="eSort" class="form-input" min="0">
                </div>
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Short description</label>
                    <input type="text" name="description" id="eDesc" class="form-input">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">How to use (shown in info panel)</label>
                <textarea name="info_how_to" id="eHowTo" class="form-input"></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Features list</label>
                <textarea name="info_features" id="eFeatures" class="form-input"></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Tips & examples</label>
                <textarea name="info_tips" id="eTips" class="form-input"></textarea>
            </div>
            <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:4px">
                <button type="button" onclick="closeModal()" class="btn" style="background:rgba(255,255,255,.05);color:#9b9bc0">Cancel</button>
                <button type="submit" class="btn btn-primary"><i class="ti ti-check"></i> Save changes</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEdit(t) {
    document.getElementById('eId').value       = t.id;
    document.getElementById('eName').value     = t.name;
    document.getElementById('eIcon').value     = t.icon;
    document.getElementById('eSort').value     = t.sort_order;
    document.getElementById('eDesc').value     = t.description   || '';
    document.getElementById('eHowTo').value    = t.info_how_to   || '';
    document.getElementById('eFeatures').value = t.info_features || '';
    document.getElementById('eTips').value     = t.info_tips     || '';
    document.getElementById('editModal').classList.add('open');
}
function closeModal() {
    document.getElementById('editModal').classList.remove('open');
}
document.getElementById('editModal').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});
</script>
</body>
</html>
