<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();
Auth::requireAdmin();

$msg  = '';
$csrf = Security::generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();

    $preset    = $_POST['preset']    ?? 'deep_space';
    $font      = $_POST['font']      ?? 'Inter';
    $radius    = $_POST['radius']    ?? 'soft';
    $animation = $_POST['animation'] ?? 'neural_net';

    ThemeEngine::set('theme_preset',    $preset);
    ThemeEngine::set('theme_font',      $font);
    ThemeEngine::set('theme_radius',    $radius);
    ThemeEngine::set('theme_animation', $animation);

    if ($preset === 'custom') {
        ThemeEngine::set('primary_color',        $_POST['primary_color']        ?? '#a78bfa');
        ThemeEngine::set('secondary_color',      $_POST['secondary_color']      ?? '#38bdf8');
        ThemeEngine::set('custom_bg_primary',    $_POST['custom_bg_primary']    ?? '#0d0d1a');
        ThemeEngine::set('custom_bg_secondary',  $_POST['custom_bg_secondary']  ?? '#13132a');
        ThemeEngine::set('custom_bg_card',       $_POST['custom_bg_card']       ?? '#1a1a35');
        ThemeEngine::set('custom_bg_sidebar',    $_POST['custom_bg_sidebar']    ?? '#0a0a16');
        ThemeEngine::set('custom_text_primary',  $_POST['custom_text_primary']  ?? '#f1f1ff');
        ThemeEngine::set('custom_text_secondary',$_POST['custom_text_secondary']?? '#9b9bc0');
    } else {
        ThemeEngine::applyPreset($preset);
    }

    // Background image upload
    if (!empty($_FILES['bg_image']['name'])) {
        $ext = strtolower(pathinfo($_FILES['bg_image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','webp']) && $_FILES['bg_image']['size'] < 5242880) {
            $dir = ROOT . '/public/assets/img/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            move_uploaded_file($_FILES['bg_image']['tmp_name'], $dir . 'bg.' . $ext);
            ThemeEngine::set('theme_bg_image', '/aistudio/public/assets/img/bg.' . $ext);
        }
    }
    if (isset($_POST['remove_bg'])) {
        ThemeEngine::set('theme_bg_image', '');
    }

    ThemeEngine::$settings = [];
    $msg = 'Theme updated! Refresh the site to see changes.';
}

$rows = [];
$dbRows = DB::query("SELECT `key`,`value` FROM theme_settings");
foreach ($dbRows as $r) $rows[$r['key']] = $r['value'];
$currentPreset    = $rows['theme_preset']    ?? 'deep_space';
$currentFont      = $rows['theme_font']      ?? 'Inter';
$currentRadius    = $rows['theme_radius']    ?? 'soft';
$currentAnimation = $rows['theme_animation'] ?? 'neural_net';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Theme — Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:220px;min-height:100vh;background:#050508;border-right:.5px solid rgba(167,139,250,.12);position:fixed;left:0;top:0;z-index:100;overflow-y:auto;display:flex;flex-direction:column}
.sidebar-logo{padding:18px 16px 14px;font-size:15px;font-weight:600;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;border-bottom:.5px solid rgba(167,139,250,.1)}
.sidebar-logo span{display:block;font-size:10px;color:#6b6b90;-webkit-text-fill-color:#6b6b90;background:none;margin-top:2px}
.nav-section{padding:10px 10px 4px;font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-top:4px}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 14px;color:#9b9bc0;text-decoration:none;font-size:13px;transition:all .15s;border-left:2px solid transparent;border-radius:0 8px 8px 0;margin:1px 6px 1px 0}
.nav-item i{font-size:17px;flex-shrink:0}
.nav-item:hover{color:#f1f1ff;background:rgba(167,139,250,.07)}
.nav-item.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.main{margin-left:220px;flex:1}
.topbar{height:52px;display:flex;align-items:center;padding:0 1.5rem;background:#050508;border-bottom:.5px solid rgba(167,139,250,.1);position:sticky;top:0;z-index:50;font-size:15px;font-weight:500}
.content{padding:1.5rem;max-width:860px}
.section{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:14px;padding:1.25rem;margin-bottom:1.25rem}
.section-title{font-size:13px;font-weight:500;color:#a78bfa;margin-bottom:1rem;display:flex;align-items:center;gap:6px;padding-bottom:10px;border-bottom:.5px solid rgba(167,139,250,.1)}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:1rem;display:flex;align-items:center;gap:8px;background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.form-label{display:block;font-size:12px;font-weight:500;color:#9b9bc0;margin-bottom:6px}
.form-input{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:8px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:13px;padding:9px 12px;outline:none;transition:border-color .2s}
.form-input:focus{border-color:#a78bfa}
select.form-input option{background:#1a1a2e;color:#f1f1ff}
.btn-save{padding:11px 28px;background:linear-gradient(135deg,#a78bfa,#7c3aed);border:none;border-radius:9px;color:#fff;font-family:'Inter',sans-serif;font-size:14px;font-weight:500;cursor:pointer;display:inline-flex;align-items:center;gap:6px;transition:filter .2s}
.btn-save:hover{filter:brightness(1.1)}

/* Preset grid */
.preset-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:4px}
.preset-card{border-radius:12px;overflow:hidden;cursor:pointer;border:2px solid transparent;transition:all .2s;position:relative}
.preset-card:hover{transform:translateY(-2px)}
.preset-card.selected{border-color:#a78bfa}
.preset-card.selected::after{content:'✓';position:absolute;top:6px;right:8px;background:#a78bfa;color:#fff;width:18px;height:18px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700}
.preset-preview{height:72px;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:500;position:relative;overflow:hidden}
.preset-dots{display:flex;gap:3px;position:absolute;bottom:6px;left:8px}
.preset-dot{width:8px;height:8px;border-radius:50%}
.preset-name{padding:7px 10px;font-size:12px;font-weight:500;color:#f1f1ff;background:rgba(0,0,0,.4)}
.preset-sub{padding:0 10px 7px;font-size:10px;color:#9b9bc0;background:rgba(0,0,0,.4)}

/* Option cards */
.option-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(110px,1fr));gap:8px}
.option-card{padding:10px;border-radius:10px;border:.5px solid rgba(167,139,250,.15);cursor:pointer;text-align:center;transition:all .2s;background:rgba(255,255,255,.02)}
.option-card:hover{background:rgba(167,139,250,.08);border-color:rgba(167,139,250,.3)}
.option-card.selected{background:rgba(167,139,250,.12);border-color:#a78bfa}
.option-card input{display:none}
.option-label{font-size:12px;font-weight:500;color:#f1f1ff;margin-top:4px}
.option-sub{font-size:10px;color:#9b9bc0;margin-top:2px}

/* Custom colors */
.color-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}
.color-item{display:flex;align-items:center;gap:10px}
.color-item input[type=color]{width:36px;height:36px;border-radius:8px;border:.5px solid rgba(167,139,250,.3);background:none;cursor:pointer;padding:2px}
.color-item label{font-size:12px;color:#9b9bc0}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?><span>Admin Panel</span></div>
    <div class="nav-section">Overview</div>
    <a href="index.php"  class="nav-item"><i class="ti ti-dashboard"></i> Dashboard</a>
    <div class="nav-section">Management</div>
    <a href="tools.php"  class="nav-item"><i class="ti ti-tool"></i> Tools</a>
    <a href="apis.php"   class="nav-item"><i class="ti ti-api"></i> API Services</a>
    <a href="users.php"  class="nav-item"><i class="ti ti-users"></i> Users</a>
    <div class="nav-section">Monetisation</div>
    <a href="subscriptions.php" class="nav-item"><i class="ti ti-ticket"></i> Plans</a>
    <a href="payments.php"      class="nav-item"><i class="ti ti-credit-card"></i> Payments</a>
    <div class="nav-section">Settings</div>
    <a href="settings.php" class="nav-item"><i class="ti ti-settings"></i> Settings</a>
    <a href="theme.php"    class="nav-item active"><i class="ti ti-palette"></i> Theme</a>
    <div style="margin-top:auto;padding:10px">
        <a href="/aistudio/public/dashboard.php" style="display:flex;align-items:center;gap:8px;padding:8px 10px;color:#9b9bc0;text-decoration:none;font-size:12px;border-radius:8px;border:.5px solid rgba(167,139,250,.1)">
            <i class="ti ti-arrow-left"></i> Back to site
        </a>
    </div>
</nav>

<div class="main">
    <header class="topbar"><i class="ti ti-palette" style="color:#a78bfa;margin-right:8px"></i>Theme</header>
    <div class="content">
        <?php if ($msg): ?><div class="alert"><i class="ti ti-check"></i><?= h($msg) ?></div><?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="_csrf" value="<?= h($csrf) ?>">

            <!-- Presets -->
            <div class="section">
                <div class="section-title"><i class="ti ti-swatchbook"></i> Color Theme</div>
                <div class="preset-grid">
                    <?php
                    $presets = [
                        'deep_space'  => ['label'=>'Deep space',   'sub'=>'Dark purple',   'bg'=>'linear-gradient(135deg,#1a0533,#0d1a3a)', 'dots'=>['#a78bfa','#38bdf8','#f0abfc']],
                        'arctic_light'=> ['label'=>'Arctic light',  'sub'=>'Clean white',   'bg'=>'linear-gradient(135deg,#f0f4ff,#fafbff)', 'dots'=>['#4338ca','#059669','#0ea5e9']],
                        'matrix_dark' => ['label'=>'Matrix dark',   'sub'=>'Hacker green',  'bg'=>'linear-gradient(135deg,#0a0a0a,#111)',    'dots'=>['#00ff88','#00ccff','#ff6b00']],
                        'ember_forge' => ['label'=>'Ember forge',   'sub'=>'Orange bold',   'bg'=>'linear-gradient(135deg,#1a0500,#2d1200)', 'dots'=>['#ff6b35','#ffd700','#ff3366']],
                        'sand_rose'   => ['label'=>'Sand & rose',   'sub'=>'Warm elegant',  'bg'=>'linear-gradient(135deg,#fef3c7,#fce7f3)', 'dots'=>['#92400e','#be185d','#d97706']],
                        'neon_ocean'  => ['label'=>'Neon ocean',    'sub'=>'Cyan futuristic','bg'=>'linear-gradient(135deg,#000510,#001020)', 'dots'=>['#00e5ff','#69ff47','#ff4081']],
                        'custom'      => ['label'=>'Custom',        'sub'=>'Your colors',   'bg'=>'linear-gradient(135deg,#1a1a2e,#16213e)', 'dots'=>['#fff','#fff','#fff']],
                    ];
                    foreach ($presets as $key => $p):
                        $sel = $currentPreset === $key ? ' selected' : '';
                    ?>
                    <label class="preset-card<?= $sel ?>" onclick="selectPreset('<?= $key ?>')">
                        <input type="radio" name="preset" value="<?= $key ?>" <?= $currentPreset===$key?'checked':'' ?> style="display:none">
                        <div class="preset-preview" style="background:<?= $p['bg'] ?>">
                            <div class="preset-dots">
                                <?php foreach ($p['dots'] as $d): ?>
                                <div class="preset-dot" style="background:<?= $d ?>"></div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <div class="preset-name"><?= $p['label'] ?></div>
                        <div class="preset-sub"><?= $p['sub'] ?></div>
                    </label>
                    <?php endforeach; ?>
                </div>

                <!-- Custom colors (shown when custom selected) -->
                <div id="customColors" style="margin-top:1rem;<?= $currentPreset !== 'custom' ? 'display:none' : '' ?>">
                    <div style="font-size:12px;color:#9b9bc0;margin-bottom:10px">Custom color settings:</div>
                    <div class="color-grid">
                        <div class="color-item">
                            <input type="color" name="primary_color" value="<?= h($rows['primary_color'] ?? '#a78bfa') ?>">
                            <label>Primary color</label>
                        </div>
                        <div class="color-item">
                            <input type="color" name="secondary_color" value="<?= h($rows['secondary_color'] ?? '#38bdf8') ?>">
                            <label>Secondary color</label>
                        </div>
                        <div class="color-item">
                            <input type="color" name="custom_bg_primary" value="<?= h($rows['custom_bg_primary'] ?? '#0d0d1a') ?>">
                            <label>Background</label>
                        </div>
                        <div class="color-item">
                            <input type="color" name="custom_bg_card" value="<?= h($rows['custom_bg_card'] ?? '#1a1a35') ?>">
                            <label>Card background</label>
                        </div>
                        <div class="color-item">
                            <input type="color" name="custom_text_primary" value="<?= h($rows['custom_text_primary'] ?? '#f1f1ff') ?>">
                            <label>Text color</label>
                        </div>
                        <div class="color-item">
                            <input type="color" name="custom_bg_sidebar" value="<?= h($rows['custom_bg_sidebar'] ?? '#0a0a16') ?>">
                            <label>Sidebar color</label>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Font -->
            <div class="section">
                <div class="section-title"><i class="ti ti-typography"></i> Font</div>
                <div class="option-grid">
                    <?php
                    $fonts = ['Inter'=>'Modern','Sora'=>'Rounded','Space Grotesk'=>'Technical','Plus Jakarta Sans'=>'Clean','Outfit'=>'Friendly','Geist'=>'Minimal'];
                    foreach ($fonts as $font => $sub):
                        $sel = $currentFont === $font ? ' selected' : '';
                    ?>
                    <label class="option-card<?= $sel ?>">
                        <input type="radio" name="font" value="<?= h($font) ?>" <?= $currentFont===$font?'checked':'' ?>>
                        <div class="option-label" style="font-family:'<?= $font ?>',sans-serif"><?= h($font) ?></div>
                        <div class="option-sub"><?= $sub ?></div>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Border radius -->
            <div class="section">
                <div class="section-title"><i class="ti ti-border-radius"></i> Border Radius</div>
                <div class="option-grid" style="max-width:400px">
                    <?php
                    $radii = ['sharp'=>['Sharp','0px corners'],'soft'=>['Soft','8px corners'],'rounded'=>['Rounded','16px corners']];
                    foreach ($radii as $key => [$label, $sub]):
                        $sel = $currentRadius === $key ? ' selected' : '';
                    ?>
                    <label class="option-card<?= $sel ?>">
                        <input type="radio" name="radius" value="<?= $key ?>" <?= $currentRadius===$key?'checked':'' ?>>
                        <div class="option-label"><?= $label ?></div>
                        <div class="option-sub"><?= $sub ?></div>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Animation -->
            <div class="section">
                <div class="section-title"><i class="ti ti-sparkles"></i> Background Animation</div>
                <div class="option-grid">
                    <?php
                    $anims = [
                        'none'       => ['None',         'No animation'],
                        'subtle'     => ['Subtle',       'Soft transitions'],
                        'neural_net' => ['Neural Net',   'Connecting dots ✨'],
                        'particles'  => ['Particles',    'Floating dots'],
                        'glow_pulse' => ['Glow Pulse',   'Glowing buttons'],
                    ];
                    foreach ($anims as $key => [$label, $sub]):
                        $sel = $currentAnimation === $key ? ' selected' : '';
                    ?>
                    <label class="option-card<?= $sel ?>">
                        <input type="radio" name="animation" value="<?= $key ?>" <?= $currentAnimation===$key?'checked':'' ?>>
                        <div class="option-label"><?= $label ?></div>
                        <div class="option-sub"><?= $sub ?></div>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Background image -->
            <div class="section">
                <div class="section-title"><i class="ti ti-photo"></i> Background Image (optional)</div>
                <?php if (!empty($rows['theme_bg_image'])): ?>
                <div style="margin-bottom:10px">
                    <img src="<?= h($rows['theme_bg_image']) ?>" alt="bg" style="height:60px;border-radius:8px;object-fit:cover">
                    <label style="display:flex;align-items:center;gap:6px;margin-top:8px;font-size:13px;color:#ef4444;cursor:pointer">
                        <input type="checkbox" name="remove_bg" value="1"> Remove background image
                    </label>
                </div>
                <?php endif; ?>
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Upload new background (JPG/PNG/WebP, max 5MB)</label>
                    <input type="file" name="bg_image" class="form-input" accept=".jpg,.jpeg,.png,.webp">
                </div>
                <div style="font-size:12px;color:#6b6b90;margin-top:6px">Background image will be overlaid with a dark tint so text remains readable.</div>
            </div>

            <button type="submit" class="btn-save"><i class="ti ti-device-floppy"></i> Apply Theme</button>
            <a href="/aistudio/public/dashboard.php" target="_blank"
               style="display:inline-flex;align-items:center;gap:6px;margin-left:12px;color:#a78bfa;font-size:13px;text-decoration:none">
                <i class="ti ti-external-link"></i> Preview site
            </a>
        </form>
    </div>
</div>

<script>
function selectPreset(key) {
    document.querySelectorAll('.preset-card').forEach(c => c.classList.remove('selected'));
    document.querySelector(`input[value="${key}"]`).closest('.preset-card').classList.add('selected');
    document.querySelector(`input[value="${key}"]`).checked = true;
    document.getElementById('customColors').style.display = key === 'custom' ? 'block' : 'none';
}
document.querySelectorAll('.option-card').forEach(card => {
    card.addEventListener('click', function() {
        const name = this.querySelector('input').name;
        document.querySelectorAll(`input[name="${name}"]`).forEach(i => i.closest('.option-card').classList.remove('selected'));
        this.classList.add('selected');
    });
});
</script>
</body>
</html>
