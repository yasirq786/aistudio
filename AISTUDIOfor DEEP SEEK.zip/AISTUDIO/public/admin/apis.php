<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';

Security::startSession();
Security::checkIpBan();
Auth::requireAdmin();

$msg   = '';
$error = '';
$csrf  = Security::generateCsrfToken();

// ── Handle actions ────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();
    $action = $_POST['action'] ?? '';

    // ADD new API service
    if ($action === 'add') {
        $toolId     = (int)$_POST['tool_id'];
        $name       = Security::sanitizeRaw($_POST['name']        ?? '');
        $provider   = Security::sanitizeRaw($_POST['provider']    ?? '');
        $apiKey     = trim($_POST['api_key']                      ?? '');
        $model      = Security::sanitizeRaw($_POST['model']       ?? '');
        $endpoint   = Security::sanitizeRaw($_POST['endpoint']    ?? '');
        $creditCost = max(1, (int)$_POST['credit_cost']);
        $isDefault  = isset($_POST['is_default']) ? 1 : 0;

        if (!$toolId || !$name || !$provider) {
            $error = 'Tool, name and provider are required.';
        } else {
            // If setting as default, unset others
            if ($isDefault) {
                DB::execute("UPDATE api_services SET is_default=0 WHERE tool_id=?", [$toolId]);
            }
            DB::execute(
                "INSERT INTO api_services (tool_id,name,provider,api_key,model,endpoint,credit_cost,is_default,is_enabled)
                 VALUES (?,?,?,?,?,?,?,?,1)",
                [$toolId, $name, $provider, $apiKey ?: null, $model ?: null, $endpoint ?: null, $creditCost, $isDefault]
            );
            $msg = "API service '{$name}' added successfully.";
        }
    }

    // EDIT
    elseif ($action === 'edit') {
        $id         = (int)$_POST['id'];
        $name       = Security::sanitizeRaw($_POST['name']        ?? '');
        $provider   = Security::sanitizeRaw($_POST['provider']    ?? '');
        $apiKey     = trim($_POST['api_key']                      ?? '');
        $model      = Security::sanitizeRaw($_POST['model']       ?? '');
        $endpoint   = Security::sanitizeRaw($_POST['endpoint']    ?? '');
        $creditCost = max(1, (int)$_POST['credit_cost']);
        $isDefault  = isset($_POST['is_default']) ? 1 : 0;
        $isEnabled  = isset($_POST['is_enabled']) ? 1 : 0;

        $existing = DB::queryOne("SELECT tool_id FROM api_services WHERE id=?", [$id]);
        if ($existing && $isDefault) {
            DB::execute("UPDATE api_services SET is_default=0 WHERE tool_id=?", [$existing['tool_id']]);
        }

        // Only update api_key if a new one was provided
        if ($apiKey) {
            DB::execute(
                "UPDATE api_services SET name=?,provider=?,api_key=?,model=?,endpoint=?,
                 credit_cost=?,is_default=?,is_enabled=? WHERE id=?",
                [$name, $provider, $apiKey, $model ?: null, $endpoint ?: null, $creditCost, $isDefault, $isEnabled, $id]
            );
        } else {
            DB::execute(
                "UPDATE api_services SET name=?,provider=?,model=?,endpoint=?,
                 credit_cost=?,is_default=?,is_enabled=? WHERE id=?",
                [$name, $provider, $model ?: null, $endpoint ?: null, $creditCost, $isDefault, $isEnabled, $id]
            );
        }
        $msg = "API service updated.";
    }

    // TOGGLE enable/disable
    elseif ($action === 'toggle') {
        $id = (int)$_POST['id'];
        DB::execute("UPDATE api_services SET is_enabled = 1-is_enabled WHERE id=?", [$id]);
        $msg = 'Status updated.';
    }

    // DELETE
    elseif ($action === 'delete') {
        $id = (int)$_POST['id'];
        DB::execute("DELETE FROM api_services WHERE id=?", [$id]);
        $msg = 'API service deleted.';
    }
}

// Get data
$tools   = DB::query("SELECT id, name, slug FROM tools ORDER BY sort_order ASC");
$filter  = (int)($_GET['tool'] ?? 0);
$services = $filter
    ? DB::query("SELECT a.*,t.name as tool_name FROM api_services a JOIN tools t ON t.id=a.tool_id WHERE a.tool_id=? ORDER BY a.sort_order", [$filter])
    : DB::query("SELECT a.*,t.name as tool_name FROM api_services a JOIN tools t ON t.id=a.tool_id ORDER BY t.sort_order,a.sort_order");

// Common providers list
$providers = [
    'DeepSeek'   => ['model' => 'deepseek-chat',          'endpoint' => 'https://api.deepseek.com/v1/chat/completions'],
    'Groq'       => ['model' => 'llama3-8b-8192',          'endpoint' => 'https://api.groq.com/openai/v1/chat/completions'],
    'OpenAI'     => ['model' => 'gpt-4o-mini',             'endpoint' => 'https://api.openai.com/v1/chat/completions'],
    'Anthropic'  => ['model' => 'claude-3-5-haiku-20241022','endpoint' => 'https://api.anthropic.com/v1/messages'],
    'Stability AI'=> ['model'=> 'stable-diffusion-xl-1024-v1-0','endpoint' => 'https://api.stability.ai/v1/generation'],
    'Leonardo AI'=> ['model' => 'aa77f04e-3eec-4034-9c07-d0a6e63f5240','endpoint' => 'https://cloud.leonardo.ai/api/rest/v1'],
    'ElevenLabs' => ['model' => 'eleven_monolingual_v1',   'endpoint' => 'https://api.elevenlabs.io/v1'],
    'Suno AI'    => ['model' => 'chirp-v3-5',              'endpoint' => ''],
    'Eachlabs'   => ['model' => '',                        'endpoint' => 'https://api.eachlabs.ai/v1'],
    'Custom'     => ['model' => '',                        'endpoint' => ''],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>API Services — Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:220px;min-height:100vh;background:#050508;border-right:.5px solid rgba(167,139,250,.12);position:fixed;left:0;top:0;z-index:100;overflow-y:auto;display:flex;flex-direction:column}
.sidebar-logo{padding:18px 16px 14px;font-size:15px;font-weight:600;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;border-bottom:.5px solid rgba(167,139,250,.1)}
.sidebar-logo span{display:block;font-size:10px;color:#6b6b90;-webkit-text-fill-color:#6b6b90;background:none;margin-top:2px}
.nav-section{padding:10px 10px 4px;font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-top:4px}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 14px;color:#9b9bc0;text-decoration:none;font-size:13px;transition:all .15s;border-left:2px solid transparent;border-radius:0 8px 8px 0;margin:1px 6px 1px 0}
.nav-item i{font-size:17px;flex-shrink:0}
.nav-item:hover{color:#f1f1ff;background:rgba(167,139,250,.07)}
.nav-item.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.main{margin-left:220px;flex:1;min-height:100vh}
.topbar{height:52px;display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;background:#050508;border-bottom:.5px solid rgba(167,139,250,.1);position:sticky;top:0;z-index:50}
.topbar-title{font-size:15px;font-weight:500}
.content{padding:1.5rem}
.card{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:14px;overflow:hidden;margin-bottom:1.25rem}
.card-header{padding:12px 16px;border-bottom:.5px solid rgba(167,139,250,.1);font-size:13px;font-weight:500;display:flex;align-items:center;justify-content:space-between;gap:8px}
.card-body{padding:1.25rem}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}
.form-row-3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;margin-bottom:12px}
.form-group{margin-bottom:12px}
.form-label{display:block;font-size:12px;font-weight:500;color:#9b9bc0;margin-bottom:5px}
.form-input{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:8px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:13px;padding:9px 12px;outline:none;transition:border-color .2s}
.form-input:focus{border-color:#a78bfa;box-shadow:0 0 0 3px rgba(167,139,250,.1)}
.form-input::placeholder{color:#6b6b90}
select.form-input{cursor:pointer}
.btn{display:inline-flex;align-items:center;gap:6px;padding:8px 16px;border-radius:8px;font-size:13px;font-weight:500;cursor:pointer;border:none;transition:all .2s;font-family:'Inter',sans-serif;text-decoration:none}
.btn-primary{background:linear-gradient(135deg,#a78bfa,#7c3aed);color:#fff}
.btn-primary:hover{filter:brightness(1.1)}
.btn-danger{background:rgba(239,68,68,.15);color:#ef4444;border:.5px solid rgba(239,68,68,.3)}
.btn-danger:hover{background:rgba(239,68,68,.25)}
.btn-sm{padding:5px 10px;font-size:12px}
table{width:100%;border-collapse:collapse}
th{padding:9px 14px;text-align:left;font-size:11px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.04em;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(0,0,0,.2)}
td{padding:10px 14px;font-size:13px;color:#9b9bc0;border-top:.5px solid rgba(255,255,255,.04)}
tr:first-child td{border-top:none}
tr:hover td{background:rgba(167,139,250,.03)}
.badge{display:inline-block;padding:2px 8px;border-radius:5px;font-size:11px;font-weight:500}
.badge-success{background:rgba(34,197,94,.12);color:#22c55e}
.badge-danger{background:rgba(239,68,68,.12);color:#ef4444}
.badge-warning{background:rgba(245,158,11,.12);color:#f59e0b}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:1rem;display:flex;align-items:center;gap:8px}
.alert-success{background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.alert-error{background:rgba(239,68,68,.1);border:.5px solid #ef4444;color:#fca5a5}
.key-mask{font-family:monospace;font-size:12px;color:#6b6b90;letter-spacing:1px}
.toggle-wrap{display:flex;align-items:center;gap:8px}
.toggle{width:36px;height:20px;border-radius:10px;background:rgba(255,255,255,.1);position:relative;cursor:pointer;transition:background .2s;border:none;flex-shrink:0}
.toggle.on{background:#a78bfa}
.toggle::after{content:'';width:14px;height:14px;border-radius:50%;background:#fff;position:absolute;top:3px;left:3px;transition:transform .2s}
.toggle.on::after{transform:translateX(16px)}
.filter-bar{display:flex;gap:8px;margin-bottom:1rem;flex-wrap:wrap}
.filter-btn{padding:6px 14px;border-radius:8px;font-size:12px;cursor:pointer;border:.5px solid rgba(167,139,250,.2);background:transparent;color:#9b9bc0;transition:all .2s;text-decoration:none}
.filter-btn:hover,.filter-btn.active{background:rgba(167,139,250,.1);border-color:#a78bfa;color:#a78bfa}
.empty{padding:2rem;text-align:center;color:#6b6b90;font-size:13px}
.empty i{font-size:32px;display:block;margin-bottom:8px;opacity:.4}
</style>
</head>
<body>

<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?><span>Admin Panel</span></div>
    <div class="nav-section">Overview</div>
    <a href="index.php"  class="nav-item"><i class="ti ti-dashboard"></i> Dashboard</a>
    <div class="nav-section">Management</div>
    <a href="tools.php"  class="nav-item"><i class="ti ti-tool"></i> Tools</a>
    <a href="apis.php"   class="nav-item active"><i class="ti ti-api"></i> API Services</a>
    <a href="users.php"  class="nav-item"><i class="ti ti-users"></i> Users</a>
    <div class="nav-section">Monetisation</div>
    <a href="subscriptions.php" class="nav-item"><i class="ti ti-ticket"></i> Plans</a>
    <a href="payments.php"      class="nav-item"><i class="ti ti-credit-card"></i> Payments</a>
    <div class="nav-section">Settings</div>
    <a href="settings.php" class="nav-item"><i class="ti ti-settings"></i> Settings</a>
    <a href="theme.php"    class="nav-item"><i class="ti ti-palette"></i> Theme</a>
    <div style="margin-top:auto;padding:10px">
        <a href="/aistudio/public/dashboard.php" style="display:flex;align-items:center;gap:8px;padding:8px 10px;color:#9b9bc0;text-decoration:none;font-size:12px;border-radius:8px;border:.5px solid rgba(167,139,250,.1)">
            <i class="ti ti-arrow-left"></i> Back to site
        </a>
    </div>
</nav>

<div class="main">
    <header class="topbar">
        <span class="topbar-title"><i class="ti ti-api" style="font-size:16px;color:#a78bfa;vertical-align:-2px"></i> API Services</span>
    </header>

    <div class="content">
        <?php if ($msg): ?><div class="alert alert-success"><i class="ti ti-check"></i><?= h($msg) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><i class="ti ti-alert-circle"></i><?= h($error) ?></div><?php endif; ?>

        <!-- Add new API -->
        <div class="card">
            <div class="card-header">
                <span><i class="ti ti-plus" style="color:#a78bfa"></i> Add API Service</span>
            </div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="_csrf"   value="<?= h($csrf) ?>">
                    <input type="hidden" name="action"  value="add">
                    <div class="form-row">
                        <div class="form-group" style="margin-bottom:0">
                            <label class="form-label">Tool *</label>
                            <select name="tool_id" class="form-input" required>
                                <option value="">— Select tool —</option>
                                <?php foreach ($tools as $t): ?>
                                <option value="<?= $t['id'] ?>"><?= h($t['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group" style="margin-bottom:0">
                            <label class="form-label">Provider *</label>
                            <select name="provider" class="form-input" required onchange="fillProvider(this.value)">
                                <option value="">— Select provider —</option>
                                <?php foreach ($providers as $pName => $pData): ?>
                                <option value="<?= h($pName) ?>"><?= h($pName) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group" style="margin-bottom:0">
                            <label class="form-label">Display name *</label>
                            <input type="text" name="name" class="form-input" placeholder="e.g. DeepSeek Chat" required id="nameInput">
                        </div>
                        <div class="form-group" style="margin-bottom:0">
                            <label class="form-label">Model</label>
                            <input type="text" name="model" class="form-input" placeholder="e.g. deepseek-chat" id="modelInput">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">API Key *</label>
                        <input type="password" name="api_key" class="form-input" placeholder="Paste your API key here" autocomplete="off">
                    </div>
                    <div class="form-row">
                        <div class="form-group" style="margin-bottom:0">
                            <label class="form-label">Endpoint URL (optional)</label>
                            <input type="text" name="endpoint" class="form-input" placeholder="https://api.example.com/v1/..." id="endpointInput">
                        </div>
                        <div class="form-group" style="margin-bottom:0">
                            <label class="form-label">Credit cost per use</label>
                            <input type="number" name="credit_cost" class="form-input" value="1" min="1" max="999">
                        </div>
                    </div>
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-top:12px">
                        <label style="display:flex;align-items:center;gap:8px;font-size:13px;color:#9b9bc0;cursor:pointer">
                            <input type="checkbox" name="is_default" style="accent-color:#a78bfa">
                            Set as default for this tool
                        </label>
                        <button type="submit" class="btn btn-primary">
                            <i class="ti ti-plus"></i> Add API Service
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Filter by tool -->
        <div class="filter-bar">
            <a href="apis.php" class="filter-btn <?= !$filter ? 'active' : '' ?>">All tools</a>
            <?php foreach ($tools as $t): ?>
            <a href="?tool=<?= $t['id'] ?>" class="filter-btn <?= $filter === (int)$t['id'] ? 'active' : '' ?>">
                <?= h($t['name']) ?>
            </a>
            <?php endforeach; ?>
        </div>

        <!-- Services list -->
        <div class="card">
            <div class="card-header">
                <span><i class="ti ti-list" style="color:#a78bfa"></i> Configured API Services (<?= count($services) ?>)</span>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Tool</th><th>Service name</th><th>Provider</th>
                        <th>Model</th><th>Key</th><th>Cost</th><th>Status</th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($services)): ?>
                <tr>
                    <td colspan="8" class="empty">
                        <i class="ti ti-api"></i>
                        No API services yet — add your first one above.<br>
                        <small style="font-size:12px">Start with DeepSeek (free tier available) or Groq (very fast, free)</small>
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($services as $svc): ?>
                <tr>
                    <td style="color:#f1f1ff;font-weight:500;font-size:12px"><?= h($svc['tool_name']) ?></td>
                    <td>
                        <div style="color:#f1f1ff;font-weight:500"><?= h($svc['name']) ?></div>
                        <?php if ($svc['is_default']): ?>
                        <span class="badge badge-warning" style="font-size:9px">default</span>
                        <?php endif; ?>
                    </td>
                    <td><?= h($svc['provider']) ?></td>
                    <td class="key-mask" style="color:#9b9bc0;font-size:11px"><?= h($svc['model'] ?: '—') ?></td>
                    <td>
                        <?php if ($svc['api_key']): ?>
                        <span class="key-mask"><?= substr($svc['api_key'], 0, 8) ?>••••••••</span>
                        <?php else: ?>
                        <span style="color:#ef4444;font-size:11px">Not set</span>
                        <?php endif; ?>
                    </td>
                    <td style="color:#a78bfa;font-weight:500"><?= $svc['credit_cost'] ?> cr</td>
                    <td>
                        <?php if ($svc['is_enabled'] && $svc['api_key']): ?>
                            <span class="badge badge-success">Active</span>
                        <?php elseif (!$svc['api_key']): ?>
                            <span class="badge badge-warning">No key</span>
                        <?php else: ?>
                            <span class="badge badge-danger">Disabled</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div style="display:flex;gap:6px;flex-wrap:wrap">
                            <!-- Toggle -->
                            <form method="POST" style="display:inline">
                                <input type="hidden" name="_csrf"   value="<?= h($csrf) ?>">
                                <input type="hidden" name="action"  value="toggle">
                                <input type="hidden" name="id"      value="<?= $svc['id'] ?>">
                                <button type="submit" class="btn btn-sm"
                                        style="background:rgba(167,139,250,.1);color:#a78bfa;border:.5px solid rgba(167,139,250,.2)">
                                    <?= $svc['is_enabled'] ? 'Disable' : 'Enable' ?>
                                </button>
                            </form>
                            <!-- Edit -->
                            <?php
                            $editData = [
                                'id'          => $svc['id'],
                                'name'        => $svc['name'],
                                'provider'    => $svc['provider'],
                                'model'       => $svc['model'] ?? '',
                                'endpoint'    => $svc['endpoint'] ?? '',
                                'credit_cost' => $svc['credit_cost'],
                                'is_default'  => $svc['is_default'],
                                'is_enabled'  => $svc['is_enabled'],
                            ];
                            ?>
                            <button onclick="openEdit(this)"
                                    data-svc="<?= htmlspecialchars(json_encode($editData), ENT_QUOTES) ?>"
                                    class="btn btn-sm" style="background:rgba(56,189,248,.1);color:#38bdf8;border:.5px solid rgba(56,189,248,.2)">
                                Edit
                            </button>
                            <!-- Delete -->
                            <form method="POST" style="display:inline"
                                  onsubmit="return confirm('Delete this API service?')">
                                <input type="hidden" name="_csrf"  value="<?= h($csrf) ?>">
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id"     value="<?= $svc['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>

<!-- Edit modal -->
<div id="editModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:200;align-items:center;justify-content:center">
    <div style="background:#0d0d1a;border:.5px solid rgba(167,139,250,.3);border-radius:16px;padding:1.5rem;width:100%;max-width:520px;max-height:90vh;overflow-y:auto">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem">
            <h3 style="font-size:15px;font-weight:500">Edit API Service</h3>
            <button onclick="closeEdit()" style="background:none;border:none;color:#9b9bc0;font-size:20px;cursor:pointer">
                <i class="ti ti-x"></i>
            </button>
        </div>
        <form method="POST" id="editForm">
            <input type="hidden" name="_csrf"   value="<?= h($csrf) ?>">
            <input type="hidden" name="action"  value="edit">
            <input type="hidden" name="id"      id="editId">
            <div class="form-row">
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Display name</label>
                    <input type="text" name="name" id="editName" class="form-input" required>
                </div>
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Provider</label>
                    <input type="text" name="provider" id="editProvider" class="form-input" required>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">New API Key (leave blank to keep current)</label>
                <input type="password" name="api_key" class="form-input" placeholder="Leave blank to keep existing key" autocomplete="off">
            </div>
            <div class="form-row">
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Model</label>
                    <input type="text" name="model" id="editModel" class="form-input">
                </div>
                <div class="form-group" style="margin-bottom:0">
                    <label class="form-label">Credit cost</label>
                    <input type="number" name="credit_cost" id="editCost" class="form-input" min="1">
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Endpoint URL</label>
                <input type="text" name="endpoint" id="editEndpoint" class="form-input">
            </div>
            <div style="display:flex;gap:12px;align-items:center;justify-content:space-between;margin-top:8px">
                <div style="display:flex;gap:16px">
                    <label style="display:flex;align-items:center;gap:6px;font-size:13px;color:#9b9bc0;cursor:pointer">
                        <input type="checkbox" name="is_default" id="editDefault" style="accent-color:#a78bfa"> Default
                    </label>
                    <label style="display:flex;align-items:center;gap:6px;font-size:13px;color:#9b9bc0;cursor:pointer">
                        <input type="checkbox" name="is_enabled" id="editEnabled" style="accent-color:#a78bfa"> Enabled
                    </label>
                </div>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
        </form>
    </div>
</div>

<script>
const providerData = <?= json_encode($providers) ?>;

function fillProvider(name) {
    if (providerData[name]) {
        const p = providerData[name];
        document.getElementById('nameInput').value     = name;
        document.getElementById('modelInput').value    = p.model    || '';
        document.getElementById('endpointInput').value = p.endpoint || '';
    }
}

function openEdit(btn) {
    const svc = JSON.parse(btn.getAttribute('data-svc'));
    document.getElementById('editId').value       = svc.id;
    document.getElementById('editName').value     = svc.name;
    document.getElementById('editProvider').value = svc.provider;
    document.getElementById('editModel').value    = svc.model    || '';
    document.getElementById('editCost').value     = svc.credit_cost;
    document.getElementById('editEndpoint').value = svc.endpoint || '';
    document.getElementById('editDefault').checked = svc.is_default == 1;
    document.getElementById('editEnabled').checked = svc.is_enabled == 1;
    document.getElementById('editModal').style.display = 'flex';
}

function closeEdit() {
    document.getElementById('editModal').style.display = 'none';
}

// Close on backdrop click
document.getElementById('editModal').addEventListener('click', function(e) {
    if (e.target === this) closeEdit();
});
</script>
</body>
</html>
