<?php
define('ROOT', dirname(__DIR__, 2));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';
require_once ROOT . '/app/Core/ThemeEngine.php';
require_once ROOT . '/app/Middleware/Security.php';
require_once ROOT . '/app/Helpers/functions.php';
require_once ROOT . '/app/Core/Auth.php';
require_once ROOT . '/app/Core/CreditEngine.php';

Security::startSession();
Security::checkIpBan();
Auth::requireAdmin();

$msg   = '';
$error = '';
$csrf  = Security::generateCsrfToken();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    Security::verifyCsrfToken();
    $action = $_POST['action'] ?? '';
    $uid    = (int)($_POST['user_id'] ?? 0);

    if ($action === 'adjust_credits') {
        $amount = (int)$_POST['amount'];
        $type   = $_POST['type'] === 'credit' ? 'credit' : 'debit';
        $note   = Security::sanitizeRaw($_POST['note'] ?? 'Admin adjustment');
        $result = CreditEngine::adminAdjust($uid, abs($amount), $type, $note);
        $msg    = $result['success'] ? "Credits updated. New balance: {$result['new_balance']}" : $result['error'];
    }
    elseif ($action === 'change_status') {
        $status = in_array($_POST['status'], ['active','suspended','banned']) ? $_POST['status'] : 'active';
        DB::execute("UPDATE users SET status=? WHERE id=?", [$status, $uid]);
        $msg = 'User status updated.';
    }
    elseif ($action === 'ban_ip') {
        $ip     = Security::sanitizeRaw($_POST['ip'] ?? '');
        $reason = Security::sanitizeRaw($_POST['reason'] ?? 'Admin ban');
        $expiry = !empty($_POST['expiry']) ? $_POST['expiry'] : null;
        if ($ip) {
            DB::execute(
                "INSERT INTO ip_bans (ip_address, ban_type, reason, banned_by, expires_at)
                 VALUES (?, 'single', ?, ?, ?)",
                [$ip, $reason, Auth::id(), $expiry]
            );
            $msg = "IP {$ip} banned.";
        }
    }
    elseif ($action === 'force_logout') {
        DB::execute("DELETE FROM user_sessions WHERE user_id=?", [$uid]);
        $msg = 'User sessions cleared — they will be logged out.';
    }
    elseif ($action === 'change_role') {
        $role = in_array($_POST['role'], ['user','moderator','admin','super_admin']) ? $_POST['role'] : 'user';
        // Only super_admin can assign admin roles
        if ($role !== 'user' && !Auth::isSuperAdmin()) {
            $error = 'Only super admin can assign admin roles.';
        } else {
            DB::execute("UPDATE users SET role=? WHERE id=?", [$role, $uid]);
            $msg = 'User role updated.';
        }
    }
}

// Filters
$search     = Security::sanitizeRaw($_GET['q']      ?? '');
$filterRole = $_GET['role']                          ?? '';
$filterStat = $_GET['status']                        ?? '';
$onlineOnly = isset($_GET['online']);
$page       = max(1, (int)($_GET['page'] ?? 1));
$perPage    = 20;

$where  = ['1=1'];
$params = [];
if ($search) {
    $where[]  = '(u.name LIKE ? OR u.email LIKE ? OR u.last_ip LIKE ?)';
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
    $params[] = "%{$search}%";
}
if ($filterRole)  { $where[] = 'u.role=?';   $params[] = $filterRole; }
if ($filterStat)  { $where[] = 'u.status=?'; $params[] = $filterStat; }
if ($onlineOnly)  { $where[] = 'u.last_seen_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE)'; }

$whereStr = implode(' AND ', $where);
$total    = (int)DB::scalar("SELECT COUNT(*) FROM users u WHERE {$whereStr}", $params);
$offset   = ($page - 1) * $perPage;

$pParams  = array_merge($params, [$perPage, $offset]);
$users    = DB::query(
    "SELECT u.*, 
     (SELECT COUNT(*) FROM user_subscriptions s WHERE s.user_id=u.id AND s.status='active' AND s.expires_at>NOW()) as is_subscribed
     FROM users u WHERE {$whereStr}
     ORDER BY u.created_at DESC LIMIT ? OFFSET ?",
    $pParams
);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Users — Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@3.x/tabler-icons.min.css">
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
body{background:#080810;color:#f1f1ff;font-family:'Inter',system-ui,sans-serif;min-height:100vh;display:flex}
.sidebar{width:220px;min-height:100vh;background:#050508;border-right:.5px solid rgba(167,139,250,.12);position:fixed;left:0;top:0;z-index:100;overflow-y:auto;display:flex;flex-direction:column}
.sidebar-logo{padding:18px 16px 14px;font-size:15px;font-weight:600;background:linear-gradient(135deg,#a78bfa,#38bdf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;border-bottom:.5px solid rgba(167,139,250,.1)}
.sidebar-logo span{display:block;font-size:10px;color:#6b6b90;-webkit-text-fill-color:#6b6b90;background:none;margin-top:2px}
.nav-section{padding:10px 10px 4px;font-size:10px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.06em;margin-top:4px}
.nav-item{display:flex;align-items:center;gap:10px;padding:9px 14px;color:#9b9bc0;text-decoration:none;font-size:13px;transition:all .15s;border-left:2px solid transparent;border-radius:0 8px 8px 0;margin:1px 6px 1px 0}
.nav-item i{font-size:17px;flex-shrink:0}
.nav-item:hover{color:#f1f1ff;background:rgba(167,139,250,.07)}
.nav-item.active{color:#a78bfa;background:rgba(167,139,250,.1);border-left-color:#a78bfa}
.main{margin-left:220px;flex:1;min-height:100vh}
.topbar{height:52px;display:flex;align-items:center;justify-content:space-between;padding:0 1.5rem;background:#050508;border-bottom:.5px solid rgba(167,139,250,.1);position:sticky;top:0;z-index:50}
.content{padding:1.5rem}
.card{background:rgba(255,255,255,.03);border:.5px solid rgba(167,139,250,.12);border-radius:14px;overflow:hidden;margin-bottom:1.25rem}
table{width:100%;border-collapse:collapse}
th{padding:9px 14px;text-align:left;font-size:11px;font-weight:500;color:#6b6b90;text-transform:uppercase;letter-spacing:.04em;border-bottom:.5px solid rgba(167,139,250,.1);background:rgba(0,0,0,.2)}
td{padding:9px 14px;font-size:12px;color:#9b9bc0;border-top:.5px solid rgba(255,255,255,.04);vertical-align:middle}
tr:first-child td{border-top:none}
tr:hover td{background:rgba(167,139,250,.03)}
.badge{display:inline-block;padding:2px 7px;border-radius:5px;font-size:10px;font-weight:500}
.badge-success{background:rgba(34,197,94,.12);color:#22c55e}
.badge-danger{background:rgba(239,68,68,.12);color:#ef4444}
.badge-warning{background:rgba(245,158,11,.12);color:#f59e0b}
.badge-purple{background:rgba(167,139,250,.12);color:#a78bfa}
.badge-blue{background:rgba(56,189,248,.12);color:#38bdf8}
.alert{padding:10px 14px;border-radius:8px;font-size:13px;margin-bottom:1rem;display:flex;align-items:center;gap:8px}
.alert-success{background:rgba(34,197,94,.1);border:.5px solid #22c55e;color:#86efac}
.alert-error{background:rgba(239,68,68,.1);border:.5px solid #ef4444;color:#fca5a5}
.btn{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:500;cursor:pointer;border:none;transition:all .2s;font-family:'Inter',sans-serif;white-space:nowrap}
.btn-primary{background:rgba(167,139,250,.15);color:#a78bfa;border:.5px solid rgba(167,139,250,.3)}
.btn-danger{background:rgba(239,68,68,.1);color:#ef4444;border:.5px solid rgba(239,68,68,.25)}
.btn-warn{background:rgba(245,158,11,.1);color:#f59e0b;border:.5px solid rgba(245,158,11,.25)}
.btn-blue{background:rgba(56,189,248,.1);color:#38bdf8;border:.5px solid rgba(56,189,248,.25)}
.search-bar{display:flex;gap:8px;margin-bottom:1rem;flex-wrap:wrap}
.search-input{flex:1;min-width:200px;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:8px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:13px;padding:8px 12px;outline:none}
.search-input:focus{border-color:#a78bfa}
select.search-input{cursor:pointer;max-width:160px}
.filter-link{padding:6px 12px;border-radius:7px;font-size:12px;text-decoration:none;color:#9b9bc0;border:.5px solid rgba(167,139,250,.15);transition:all .2s}
.filter-link:hover,.filter-link.active{background:rgba(167,139,250,.1);border-color:#a78bfa;color:#a78bfa}
.modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:200;align-items:center;justify-content:center;padding:1rem}
.modal.open{display:flex}
.modal-box{background:#0d0d1a;border:.5px solid rgba(167,139,250,.3);border-radius:16px;padding:1.5rem;width:100%;max-width:460px;max-height:90vh;overflow-y:auto}
.modal-title{font-size:15px;font-weight:500;margin-bottom:1.25rem;display:flex;align-items:center;justify-content:space-between}
.close-btn{background:none;border:none;color:#9b9bc0;font-size:20px;cursor:pointer}
.form-group{margin-bottom:12px}
.form-label{display:block;font-size:12px;font-weight:500;color:#9b9bc0;margin-bottom:4px}
.form-input{width:100%;background:rgba(255,255,255,.05);border:.5px solid rgba(167,139,250,.2);border-radius:8px;color:#f1f1ff;font-family:'Inter',sans-serif;font-size:13px;padding:8px 12px;outline:none}
.form-input:focus{border-color:#a78bfa}
.online-dot{display:inline-block;width:7px;height:7px;border-radius:50%;background:#22c55e;margin-right:3px}
.offline-dot{display:inline-block;width:7px;height:7px;border-radius:50%;background:#6b6b90;margin-right:3px}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo">&#9670; <?= ThemeEngine::siteName() ?><span>Admin Panel</span></div>
    <div class="nav-section">Overview</div>
    <a href="index.php"  class="nav-item"><i class="ti ti-dashboard"></i> Dashboard</a>
    <div class="nav-section">Management</div>
    <a href="tools.php"  class="nav-item"><i class="ti ti-tool"></i> Tools</a>
    <a href="apis.php"   class="nav-item"><i class="ti ti-api"></i> API Services</a>
    <a href="users.php"  class="nav-item active"><i class="ti ti-users"></i> Users</a>
    <div class="nav-section">Monetisation</div>
    <a href="subscriptions.php" class="nav-item"><i class="ti ti-ticket"></i> Plans</a>
    <a href="payments.php"      class="nav-item"><i class="ti ti-credit-card"></i> Payments</a>
    <div class="nav-section">Settings</div>
    <a href="settings.php" class="nav-item"><i class="ti ti-settings"></i> Settings</a>
    <a href="theme.php"    class="nav-item"><i class="ti ti-palette"></i> Theme</a>
    <div style="margin-top:auto;padding:10px">
        <a href="/aistudio/public/dashboard.php" style="display:flex;align-items:center;gap:8px;padding:8px 10px;color:#9b9bc0;text-decoration:none;font-size:12px;border-radius:8px;border:.5px solid rgba(167,139,250,.1)">
            <i class="ti ti-arrow-left"></i> Back to site
        </a>
    </div>
</nav>

<div class="main">
    <header class="topbar">
        <span style="font-size:15px;font-weight:500"><i class="ti ti-users" style="color:#a78bfa;vertical-align:-2px;margin-right:6px"></i>Users <span style="color:#6b6b90;font-size:12px">(<?= number_format($total) ?>)</span></span>
        <div style="display:flex;align-items:center;gap:8px">
            <a href="?online=1" class="filter-link <?= $onlineOnly ? 'active' : '' ?>">
                <span class="online-dot"></span>Online now
            </a>
        </div>
    </header>

    <div class="content">
        <?php if ($msg):   ?><div class="alert alert-success"><i class="ti ti-check"></i><?= h($msg) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><i class="ti ti-alert-circle"></i><?= h($error) ?></div><?php endif; ?>

        <!-- Search & filter -->
        <form method="GET" class="search-bar">
            <input type="text" name="q" class="search-input" placeholder="Search name, email, IP..." value="<?= h($search) ?>">
            <select name="role"   class="search-input"><option value="">All roles</option><option value="user" <?= $filterRole==='user'?'selected':'' ?>>User</option><option value="admin" <?= $filterRole==='admin'?'selected':'' ?>>Admin</option><option value="super_admin" <?= $filterRole==='super_admin'?'selected':'' ?>>Super Admin</option><option value="moderator" <?= $filterRole==='moderator'?'selected':'' ?>>Moderator</option></select>
            <select name="status" class="search-input"><option value="">All status</option><option value="active" <?= $filterStat==='active'?'selected':'' ?>>Active</option><option value="suspended" <?= $filterStat==='suspended'?'selected':'' ?>>Suspended</option><option value="banned" <?= $filterStat==='banned'?'selected':'' ?>>Banned</option></select>
            <button type="submit" class="btn btn-primary" style="padding:8px 16px;font-size:13px"><i class="ti ti-search"></i> Search</button>
            <a href="users.php" class="btn" style="padding:8px 12px;font-size:13px;background:rgba(255,255,255,.05);color:#9b9bc0;border:.5px solid rgba(255,255,255,.1)">Reset</a>
        </form>

        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>User</th>
                        <th>Role</th>
                        <th>Credits</th>
                        <th>Plan</th>
                        <th>Last IP</th>
                        <th>Online</th>
                        <th>Status</th>
                        <th>Joined</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($users)): ?>
                <tr><td colspan="9" style="text-align:center;padding:2rem;color:#6b6b90">No users found</td></tr>
                <?php else: ?>
                <?php foreach ($users as $u): ?>
                <tr>
                    <td>
                        <div style="display:flex;align-items:center;gap:8px">
                            <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#a78bfa,#7c3aed);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:600;color:#fff;flex-shrink:0">
                                <?= strtoupper(substr($u['name'],0,1)) ?>
                            </div>
                            <div>
                                <div style="color:#f1f1ff;font-weight:500"><?= h($u['name']) ?></div>
                                <div style="font-size:11px;color:#6b6b90"><?= h($u['email']) ?></div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <?php $roleColors = ['user'=>'badge-blue','moderator'=>'badge-warning','admin'=>'badge-purple','super_admin'=>'badge-success']; ?>
                        <span class="badge <?= $roleColors[$u['role']] ?? 'badge-blue' ?>"><?= h($u['role']) ?></span>
                    </td>
                    <td style="color:#a78bfa;font-weight:500"><?= number_format($u['credit_balance']) ?></td>
                    <td>
                        <?php if ($u['is_subscribed']): ?>
                            <span class="badge badge-success"><i class="ti ti-crown" style="font-size:10px"></i> Active</span>
                        <?php else: ?>
                            <span style="color:#6b6b90;font-size:11px">Free</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <code style="font-size:11px;color:#9b9bc0"><?= h($u['last_ip'] ?: '—') ?></code>
                        <?php if ($u['last_ip']): ?>
                        <button onclick="openBanIp('<?= h($u['last_ip']) ?>')"
                                class="btn btn-danger" style="padding:2px 6px;font-size:10px;margin-left:4px" title="Ban this IP">
                            <i class="ti ti-ban"></i>
                        </button>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($u['last_seen_at'] && isOnline($u['last_seen_at'])): ?>
                            <span class="online-dot"></span><span style="font-size:11px;color:#22c55e">Online</span>
                        <?php else: ?>
                            <span class="offline-dot"></span><span style="font-size:11px"><?= $u['last_seen_at'] ? timeAgo($u['last_seen_at']) : 'Never' ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($u['status']==='active'):   ?><span class="badge badge-success">active</span>
                        <?php elseif ($u['status']==='suspended'): ?><span class="badge badge-warning">suspended</span>
                        <?php else: ?><span class="badge badge-danger">banned</span><?php endif; ?>
                    </td>
                    <td style="font-size:11px"><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
                    <td>
                        <div style="display:flex;gap:4px;flex-wrap:wrap">
                            <button onclick='openUser(<?= htmlspecialchars(json_encode($u), ENT_QUOTES) ?>)'
                                    class="btn btn-primary"><i class="ti ti-edit"></i> Manage</button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <?php if ($total > $perPage):
            $totalPages = ceil($total / $perPage);
            echo '<div style="display:flex;gap:6px;justify-content:center">';
            for ($i = 1; $i <= $totalPages; $i++):
                $q = http_build_query(array_merge($_GET, ['page' => $i]));
                $active = $i === $page ? 'background:rgba(167,139,250,.2);color:#a78bfa;border-color:#a78bfa' : '';
                echo "<a href='?{$q}' style='padding:6px 12px;border-radius:7px;font-size:12px;text-decoration:none;color:#9b9bc0;border:.5px solid rgba(167,139,250,.15);{$active}'>{$i}</a>";
            endfor;
            echo '</div>';
        endif; ?>
    </div>
</div>

<!-- User manage modal -->
<div class="modal" id="userModal">
    <div class="modal-box">
        <div class="modal-title">
            <span id="modalUserName">Manage User</span>
            <button class="close-btn" onclick="closeModal()"><i class="ti ti-x"></i></button>
        </div>

        <!-- Credits -->
        <form method="POST" style="margin-bottom:1rem">
            <input type="hidden" name="_csrf"    value="<?= h($csrf) ?>">
            <input type="hidden" name="action"   value="adjust_credits">
            <input type="hidden" name="user_id"  id="mUid">
            <div style="font-size:12px;font-weight:500;color:#a78bfa;margin-bottom:8px"><i class="ti ti-coin"></i> Adjust Credits</div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:8px">
                <select name="type" class="form-input" style="font-size:12px">
                    <option value="credit">Add</option>
                    <option value="debit">Deduct</option>
                </select>
                <input type="number" name="amount" class="form-input" placeholder="Amount" min="1" required style="font-size:12px">
                <input type="text" name="note" class="form-input" placeholder="Note" style="font-size:12px">
            </div>
            <button type="submit" class="btn btn-primary" style="font-size:12px;padding:7px 14px"><i class="ti ti-check"></i> Apply</button>
        </form>

        <!-- Status -->
        <form method="POST" style="margin-bottom:1rem">
            <input type="hidden" name="_csrf"    value="<?= h($csrf) ?>">
            <input type="hidden" name="action"   value="change_status">
            <input type="hidden" name="user_id"  id="mUid2">
            <div style="font-size:12px;font-weight:500;color:#a78bfa;margin-bottom:8px"><i class="ti ti-user"></i> Account Status</div>
            <div style="display:flex;gap:8px">
                <select name="status" id="mStatus" class="form-input" style="font-size:12px">
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                    <option value="banned">Banned</option>
                </select>
                <button type="submit" class="btn btn-warn" style="font-size:12px;padding:7px 14px">Update</button>
            </div>
        </form>

        <!-- Role -->
        <form method="POST" style="margin-bottom:1rem">
            <input type="hidden" name="_csrf"    value="<?= h($csrf) ?>">
            <input type="hidden" name="action"   value="change_role">
            <input type="hidden" name="user_id"  id="mUid3">
            <div style="font-size:12px;font-weight:500;color:#a78bfa;margin-bottom:8px"><i class="ti ti-shield"></i> Role</div>
            <div style="display:flex;gap:8px">
                <select name="role" id="mRole" class="form-input" style="font-size:12px">
                    <option value="user">User</option>
                    <option value="moderator">Moderator</option>
                    <option value="admin">Admin</option>
                    <option value="super_admin">Super Admin</option>
                </select>
                <button type="submit" class="btn btn-primary" style="font-size:12px;padding:7px 14px">Update</button>
            </div>
        </form>

        <!-- Force logout -->
        <form method="POST">
            <input type="hidden" name="_csrf"    value="<?= h($csrf) ?>">
            <input type="hidden" name="action"   value="force_logout">
            <input type="hidden" name="user_id"  id="mUid4">
            <div style="font-size:12px;font-weight:500;color:#a78bfa;margin-bottom:8px"><i class="ti ti-logout"></i> Session</div>
            <button type="submit" class="btn btn-danger" style="font-size:12px;padding:7px 14px"
                    onclick="return confirm('Force logout this user?')">
                <i class="ti ti-logout"></i> Force Logout
            </button>
        </form>
    </div>
</div>

<!-- IP Ban modal -->
<div class="modal" id="ipModal">
    <div class="modal-box">
        <div class="modal-title">
            <span><i class="ti ti-ban" style="color:#ef4444"></i> Ban IP Address</span>
            <button class="close-btn" onclick="closeIpModal()"><i class="ti ti-x"></i></button>
        </div>
        <form method="POST">
            <input type="hidden" name="_csrf"   value="<?= h($csrf) ?>">
            <input type="hidden" name="action"  value="ban_ip">
            <input type="hidden" name="user_id" value="0">
            <div class="form-group">
                <label class="form-label">IP Address</label>
                <input type="text" name="ip" id="banIpField" class="form-input" required>
            </div>
            <div class="form-group">
                <label class="form-label">Reason</label>
                <input type="text" name="reason" class="form-input" placeholder="Reason for ban" value="Violation of terms">
            </div>
            <div class="form-group">
                <label class="form-label">Expires (leave blank = permanent)</label>
                <input type="datetime-local" name="expiry" class="form-input">
            </div>
            <div style="display:flex;gap:10px;justify-content:flex-end">
                <button type="button" onclick="closeIpModal()" class="btn" style="background:rgba(255,255,255,.05);color:#9b9bc0">Cancel</button>
                <button type="submit" class="btn btn-danger" onclick="return confirm('Ban this IP?')">
                    <i class="ti ti-ban"></i> Ban IP
                </button>
            </div>
        </form>
    </div>
</div>

<script>
function openUser(u) {
    document.getElementById('modalUserName').textContent = 'Manage: ' + u.name;
    ['mUid','mUid2','mUid3','mUid4'].forEach(id => document.getElementById(id).value = u.id);
    document.getElementById('mStatus').value = u.status;
    document.getElementById('mRole').value   = u.role;
    document.getElementById('userModal').classList.add('open');
}
function closeModal() { document.getElementById('userModal').classList.remove('open'); }
function openBanIp(ip) {
    document.getElementById('banIpField').value = ip;
    document.getElementById('ipModal').classList.add('open');
}
function closeIpModal() { document.getElementById('ipModal').classList.remove('open'); }
['userModal','ipModal'].forEach(id => {
    document.getElementById(id).addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('open');
    });
});
</script>
</body>
</html>
