<?php
/**
 * AIStudio — Make admin script
 * Run this ONCE to make your account super_admin
 * Then DELETE this file!
 * URL: localhost/aistudio/public/make-admin.php?email=your@email.com
 */
define('ROOT', dirname(__DIR__));
require_once ROOT . '/config/loadenv.php';
loadEnv(ROOT . '/.env');
require_once ROOT . '/config/database.php';

$email = trim($_GET['email'] ?? '');

if (!$email) {
    die('<h2>Usage: ?email=your@email.com</h2>');
}

$user = DB::queryOne("SELECT id, name, email, role FROM users WHERE email=?", [$email]);

if (!$user) {
    die('<h2 style="color:red">User not found: ' . htmlspecialchars($email) . '</h2>');
}

DB::execute("UPDATE users SET role='super_admin' WHERE id=?", [$user['id']]);

echo '<div style="font-family:sans-serif;max-width:500px;margin:50px auto;padding:2rem;
     background:#0d0d1a;color:#f1f1ff;border-radius:12px;border:1px solid #a78bfa">';
echo '<h2 style="color:#a78bfa">✓ Done!</h2>';
echo '<p><strong>' . htmlspecialchars($user['name']) . '</strong> (' . htmlspecialchars($email) . ') is now <strong style="color:#a78bfa">super_admin</strong></p>';
echo '<br><p style="color:#ef4444"><strong>⚠ DELETE this file now!</strong><br>C:\xampp\htdocs\aistudio\public\make-admin.php</p>';
echo '<br><a href="/aistudio/public/admin/index.php" style="color:#38bdf8">→ Go to Admin Panel</a>';
echo '</div>';
